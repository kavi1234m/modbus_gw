/**
  **************************
  * @file    application.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 30
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "application.h"
#include "hal_ethernet.h"
#include "hal_uart.h"
#include "hal_gpio.h"
#include "netconf.h"
#include "hal_timer.h"
#include "flash.h"
#include "hal_system_init.h"
#include "tcp_client.h"
#include "tcp_server.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"
#include "httpd_structs.h"
#include "spi_flash.h"
#include "client_gw_router.h"
#include "server_gw_router.h"
#include "calix_db.h"
#include "modbus_gw_cfg.h"
#include "cJSON_parser_modbus_gw.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#define SERVER_GATEWAY                       0
#define CLIENT_GATEWAY                       1

#define SLAVE_DEVICE_FAILURE                 0X04  // Exception Response codes
#define GW_PATH_UNAVAILABLE                  0X0A
#define GW_TARGET_DEVICE_FAILED_TO_RESPOND   0X0B

#define MODBUS_TCP_MSG_LEN_MAX               260
#define MODBUS_RTU_MSG_LEN_MAX               256
#define MODBUS_CONNECT_RETRY_FROM_CLIENT     5

#define GATEWAY_TIMEOUT                      1
#define PROCESS_SERIAL_PORT_1                2
#define PROCESS_SERIAL_PORT_2                3

#define WORKING_MODE_STATUS                   0X0A
#define CONFIG_MODE_STATUS                    0X0B

#define WORKING_MODE                         1
#define MODIFY_CONFIG_MODE                   2
#define FACTORY_RESET                        3
#define FACTORY_CONFIG_MODE                  4
#define FRESH_DEVICE_CONFIG                  5
#define MODIFY_CONFIG_STOP                   6
#define MODIFY_CONFIG_CHANGE                 7
#define SPI_ERROR_MODE                       8

#define BUTTON_STATE_IDLE                    1
#define BUTTON_STATE_FIRST_PRESS_DETECTED    2
#define BUTTON_STATE_WAIT_SECOND_PRESS       3
#define BUTTON_STATE_LONG_PRESS_ACTIVE       4
#define BUTTON_STATE_DOUBLE_PRESS            5
#define BUTTON_STATE_FACTORY_TMT             6

#define SERIAL1_LED                          1
#define SERIAL2_LED                          2
#define TCP_LED                              3

#define DATA_BUF_LEN                         300
#define SUSPEND_TASK_FLAG                    0XAA

volatile uint8_t led_mode = 0;
uint8_t device_state;

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

uint8_t firmware_version[] = "V1.0";

modbus_router_t modbus_data = {
    .cfg_flg = 0xFF,
    .nwk_cfg = {
    	.ipv4_address = 0XFA01A8C0,
    	.default_gateway = 0X0101A8C0,
    	.subnet_mask = 0X00FFFFFF,
    },
};

volatile uint8_t tcp_ok;
volatile uint8_t rtu1_ok;
volatile uint8_t rtu2_ok;
uint16_t tcp_port;

uint8_t rtu1_buffer[MODBUS_RTU_MSG_LEN_MAX];
volatile uint16_t rtu1_index;
uint8_t rtu2_buffer[MODBUS_RTU_MSG_LEN_MAX];
volatile uint16_t rtu2_index;

uint8_t tcp_response[MODBUS_TCP_MSG_LEN_MAX];
uint8_t tcp_request[MODBUS_TCP_MSG_LEN_MAX];

uint8_t rtu_response[MODBUS_RTU_MSG_LEN_MAX];
volatile uint16_t tcp_request_len;
volatile uint16_t tcp_response_len;

TaskHandle_t lwip_loop_handler = NULL;
TaskHandle_t server_gw_handler = NULL;
TaskHandle_t client_gw_handler = NULL;
TaskHandle_t network_handler = NULL;
TaskHandle_t timeout_handler = NULL;

volatile uint8_t button_state = BUTTON_STATE_IDLE;
volatile uint8_t button_is_down = 0;
volatile uint32_t press_start_time = 0;
volatile uint16_t tmr_count;

uint8_t suspend_task;
uint8_t data_buf[DATA_BUF_LEN];
uint16_t data_len;
uint8_t msg_type;
volatile uint8_t tcp_connect_ok;
uint32_t tcp_socket_timeout;
uint32_t uart4_frame_tmt;
uint32_t uart5_frame_tmt;
uint32_t rtu1_frame_tmt;
uint32_t rtu2_frame_tmt;
volatile uint8_t ethernet_ok;
/* Private function prototypes -----------------------------------------------*/
void uart_dir_control_gpio_init(void);
/* Private functions ---------------------------------------------------------*/

/******************************************************************************
 * @brief       callback function for Ethernet connection
 * @param[in]   status - connection status
 * @return      none
 ******************************************************************************/
void eth_cbk_app(uint8_t status) {

	ethernet_ok = status;
}
/******************************************************************************
 * @brief       Clear TCP Buffer
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void clear_tcp_buffer(void) {
	memset(tcp_request, 0, MODBUS_TCP_MSG_LEN_MAX);
	memset(tcp_response, 0, MODBUS_TCP_MSG_LEN_MAX);
	tcp_request_len = 0;
	tcp_response_len = 0;
	tcp_ok = 0;
}
/******************************************************************************
 * @brief       Clear RTU Buffer
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void clear_rtu_buffer(void) {

	memset(rtu1_buffer, 0, MODBUS_RTU_MSG_LEN_MAX);
	memset(rtu2_buffer, 0, MODBUS_RTU_MSG_LEN_MAX);
	memset(rtu_response, 0, MODBUS_RTU_MSG_LEN_MAX);
	rtu1_index = 0;
	rtu2_index = 0;
    rtu1_ok = 0;
    rtu2_ok = 0;

}
/******************************************************************************
 * @brief       led mode set - device mode
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void led_mode_set(uint8_t mode) {

	switch(mode) {
	    case WORKING_MODE :
	    	 hal_timer_pwm_cfg(TIMER4, 3500, 85.7); // total_time, dutycycle
	    	 break;
	    case FACTORY_RESET:
	    	 hal_timer_pwm_cfg(TIMER4, 1000, 50);
	    	 break;
	    case FACTORY_CONFIG_MODE:
	    	 hal_timer_pwm_cfg(TIMER4, 2000, 50);
	    	 break;
	    case SPI_ERROR_MODE:
	    	 hal_timer_pwm_cfg(TIMER4, 500, 50);
	    	 break;
        default:
	         break;
    }
}
/******************************************************************************
 * @brief       write modbus config into spi flash
 * @param[in]   data
 * @return      none
 ******************************************************************************/
uint8_t write_modbus_config(void) {

	cdb_clear_conf_db();
	modbus_data.cfg_flg = 0xFF;
	uint8_t *tx_start = ((uint8_t *)&modbus_data) + offsetof(modbus_router_t, gw_type);
	uint8_t *tx_end   = ((uint8_t *)&modbus_data) + offsetof(modbus_router_t, checksum);
	uint8_t tx_cs = calculate_checksum_using_addition(tx_start, tx_end - tx_start);
	modbus_data.checksum = tx_cs;
	PRINTF("TX checksum:%04X\n",tx_cs);
	if(cdb_write_conf((uint8_t*)&modbus_data, sizeof(modbus_router_t))){
		PRINTF("MODBUS CONFIG WRITE DONE\n");
		device_config_mode_set(0x0A);
		return 1;
	} else {
		led_mode_set(SPI_ERROR_MODE);
		return 0;
	}
}
/******************************************************************************
 * @brief       Read modbus config from spi flash
 * @param[in]   data
 * @return      none
 ******************************************************************************/
void Read_modbus_config(void) {
	uint16_t len = 0;
	if (!cdb_read_conf((uint8_t*)&modbus_data, &len, 1)) {
		cdb_read_conf((uint8_t*)&modbus_data, &len, 2);
	}
	uint8_t *rx_start = ((uint8_t *)&modbus_data) + offsetof(modbus_router_t, gw_type);
	uint8_t *rx_end   = ((uint8_t *)&modbus_data) + offsetof(modbus_router_t, checksum);
	uint8_t rx_cs = calculate_checksum_using_addition(rx_start, rx_end - rx_start);
	if (rx_cs != modbus_data.checksum) {
		led_mode_set(SPI_ERROR_MODE);
	}
}
/******************************************************************************
 * @brief       handle fresh device config
 * @param[in]   buffer
 * @param[in]   buffer_length
 * @return      none
 ******************************************************************************/
void handle_fresh_dev_config(uint8_t *buffer, uint16_t buffer_length) {

	if (is_valid_json(buffer, buffer_length)) {
		PRINTF("VALID PACKET\n");
		parse_json_key_value(buffer,"MTP",&msg_type);
		PRINTF("MSG TYPE : %u\n",msg_type);
	} else {
		data_buf[data_len] = '\0';
		msg_type = 5;
	}

}
/******************************************************************************
 * @brief       lwip periodic handle
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void Fresh_dev_task(void *pvParameters) {

	uint8_t output_buffer[256];
	printf("FRESH DEV TASK START\n");
	while(1) {
		switch (msg_type) {
		    case 1 :
		             {
		    	         fresh_device_config_t write_config;
		                 parse_json_for_fresh_config(data_buf,&write_config);
		    	         write_fresh_device_config_into_flash(&write_config);
		    	         prepare_response_with_status(data_buf, 1, output_buffer);
		    	         uint8_t len = strlen(output_buffer);
		    	         uart_transmit(USART_6, output_buffer, len, 1000);
		    	    	 printf("\r\nWRITE CONFIG SUCCESS\r\n");
		    	    	 data_len = 0;
		    	    	 msg_type = 0;
		             }
		             break;
		    case 2 :
		             {
		            	 fresh_device_config_t read_config;
		            	 read_fresh_device_config_from_flash(&read_config);
		    	         prepare_read_back_response_for_fresh_device(read_config, output_buffer);
		    	         uint8_t  ip[256];
		    	         prepare_response_with_status(output_buffer, 1, ip);
		    	         uint8_t len = strlen(ip);
		    	         uart_transmit(USART_6, ip, len,1000);
                         printf("\r\nREAD SUCCESS\r\n");
                         data_len = 0;
                         msg_type = 0;
		             }
		    	     break;
		    case 4 : PRINTF("\r\nCONFIG DONE\r\n");
		    	     hal_system_reset();
		    	     data_len = 0;
		    	     break;
		    default:
		    	msg_type = 0;
		    	data_len = 0;
		    	break;
		}
		vTaskDelay(500);
	}
}
/******************************************************************************
 * @brief       Based on the input slave id Route ip and port number
 * @param[in]   slave id  - incoming Slave id
 * @param[out]  ip_out    - Output ip address
 * @param[out]  port_out  - output Port number
 * @return      none
 ******************************************************************************/
uint8_t get_slave_ip_by_id(uint8_t slave_id, uint16_t *table_num) {

    for (int i = 0; i < modbus_data.client_gw_cfg.nat_table_count; i++) {
        if (modbus_data.client_gw_cfg.client_gw[i].slave_id == slave_id) {
        	*table_num = i;
            return 1;
        }
    }
    return 0;  // Not found
}
/******************************************************************************
 * @brief       HTTP server callback
 * @param[in]   ip_nwk - network data
 * @param[in]   ip_serial  - serial data
 * @param[out]  ip_modbus - modbbus cfg data
 * @return      none
 ******************************************************************************/
uint8_t http_cbk_app(uint8_t event_type) {

	PRINTF("HTTP EVENT:%u\n",event_type);
	switch(event_type) {
	    case 1: if (write_modbus_config()) {
	    	       PRINTF("FRESH CFG SPI\n");
	    	       return 1;
	            } else {
	            	return 0;
	            }
		        break;
	    case 2: hal_system_reset();
	    	    break;
	    case 3: cdb_clear_conf_db();
		        device_config_mode_set(0x0B);
		        hal_system_reset();
	    	    break;
	    case 4 : hal_system_reset();
	    	     break;
	}
	return 1;
}
/******************************************************************************
 * @brief       callback function for tcp server whenever we are getting data from client
 * @param[in]   buffer
 * @param[in]   buffer length
 * @param[in]   server port
 * @return      none
 ******************************************************************************/
void tcp_server_cbk(uint8_t *buffer,uint16_t buffer_length, uint16_t port) {

	if (buffer_length <= MODBUS_TCP_MSG_LEN_MAX) {
		memcpy(tcp_request, buffer, buffer_length);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
		printf("\r\nTCP SERVER:");
		for (uint16_t i = 0; i < buffer_length; i++) {
			printf("%02X ",buffer[i]);
		}
		printf("\n");
#endif
		tcp_port = port;
		tcp_ok = 1;
	}
}
/******************************************************************************
 * @brief       callback function for tcp server whenever we are getting data from client
 * @param[in]   buffer
 * @param[in]   buffer length
 * @param[in]   server port
 * @return      none
 ******************************************************************************/
void tcp_client_cbk(uint8_t *buffer,uint16_t buffer_length, uint8_t event_type) {

	if (event_type == 1) {
		if (buffer_length <= MODBUS_TCP_MSG_LEN_MAX) {
			memcpy(tcp_response, buffer, buffer_length);
			tcp_ok = 1;
			tcp_response_len = buffer_length;
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
		printf("\r\nTCP CLIENT:");
		for (uint16_t i = 0; i < buffer_length; i++) {
			printf("%02X ",buffer[i]);
		}
		printf("\n");
#endif
		}
	} else {
//		PRINTF("<OK>");
		tcp_connect_ok = 1;
	}
}
/******************************************************************************
 * @brief       timer callback function
 * @param[in]   timer_type - which timer triggers interrupt
 * @return      none
 ******************************************************************************/
void timer_cbk(uint8_t timer_type) {

    if (timer_type == TIMER1) {
        tmr_count++;
        switch (button_state) {
             case BUTTON_STATE_FIRST_PRESS_DETECTED:
                  if (button_is_down && (tmr_count >= LONG_PRESS_TIME_MS/10)) {
                	  PRINTF("LONG PRESS\n");
                	  tmr_count = 0;
                	  led_mode_set(FACTORY_RESET);
                      button_state = BUTTON_STATE_FACTORY_TMT;
                  }
                  break;
             case BUTTON_STATE_FACTORY_TMT:
            	  if (tmr_count >= 300) {
            		  device_state = FACTORY_RESET;
            		  button_state = BUTTON_STATE_IDLE;
            		  if (cdb_clear_db()) {
            			  if (device_config_mode_set(CONFIG_MODE_STATUS)) {
            				  hal_system_reset();
            			  }
            		  }

            	  }
            	  break;
             case BUTTON_STATE_WAIT_SECOND_PRESS:
                  if (!button_is_down && (tmr_count >= DOUBLE_PRESS_WINDOW_MS/10)) {
                      PRINTF("SINGLE PRESS\n");
                      hal_timer_enable_disable(TIMER1,0);
                      button_state = BUTTON_STATE_IDLE;
                  }
                  break;
             case BUTTON_STATE_DOUBLE_PRESS:
                 if (!button_is_down && (tmr_count >= MODIFY_CONFIG_TIMEOUT_IN_MS/10)) {
                     PRINTF("MODIFY CONFIG TIMEOUT\n");
                     device_state = MODIFY_CONFIG_STOP;
                     button_state = BUTTON_STATE_IDLE;
                     hal_timer_enable_disable(TIMER1, 0);
                     hal_system_reset();
                 }
                 break;
        }
	} else if (timer_type == TIMER2) {
		uart4_frame_tmt++;
		if (uart4_frame_tmt >= rtu1_frame_tmt) {
			uart4_frame_tmt = 0;
			rtu1_frame_tmt = 0;
			hal_timer_enable_disable(TIMER2, 0);
			rtu1_ok = 1;
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
		    PRINTF("UART4 Length:%u\r\n",rtu1_index);
			for (uint16_t i = 0; i < rtu1_index; i++) {
				PRINTF("%x ",rtu1_buffer[i]);
			}
			PRINTF("\n");
#endif

		}
	} else if (timer_type == TIMER5) {
		uart5_frame_tmt++;
		if (uart5_frame_tmt >= rtu2_frame_tmt) {
			uart5_frame_tmt = 0;
			rtu2_frame_tmt = 0;
			hal_timer_enable_disable(TIMER5, 0);
			rtu2_ok = 1;
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
		    PRINTF("UART5 Length:%u\r\n",rtu2_index);
			for (uint16_t i = 0; i < rtu2_index; i++) {
				PRINTF("%x ",rtu2_buffer[i]);
			}
			PRINTF("\n");
#endif

		}
	}
}
/******************************************************************************
 * @brief       User button callback function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void user_button_cbk(void) {

	uint8_t state = hal_gpio_input_pin_read(GPIO_PORTC, PIN_NUM_0);
    if (!state && !button_is_down) {
    	PRINTF("HIGH\n");
    	button_is_down = 1;
        if (button_state == BUTTON_STATE_IDLE || button_state == BUTTON_STATE_DOUBLE_PRESS) {
            button_state  = BUTTON_STATE_FIRST_PRESS_DETECTED;
            tmr_count     = 0;
            hal_timer_enable_disable(TIMER1, 1);
        }
    } else if (state && button_is_down){
    	PRINTF("LOW\n");
        button_is_down = 0;
        if (button_state == BUTTON_STATE_FIRST_PRESS_DETECTED) {
            button_state = BUTTON_STATE_WAIT_SECOND_PRESS;
        } else if (button_state == BUTTON_STATE_WAIT_SECOND_PRESS) {
        	if (device_state == WORKING_MODE) {
                PRINTF("Double press\n");
                suspend_task = SUSPEND_TASK_FLAG;
                device_state = MODIFY_CONFIG_MODE;
                button_state = BUTTON_STATE_DOUBLE_PRESS;
        	} else if (device_state == MODIFY_CONFIG_MODE) {
        		hal_system_reset();
        	}
        }
    }
}
/******************************************************************************
 * @brief       uart callback function
 * @param[in]   data - data received from rx pin of uart
 * @param[in]   uart_type - It tells the data belongs to which uart
 * @return      none
 ******************************************************************************/
void uart_rx_cbk(uint8_t data, uint8_t uart_type, uint8_t event_type) {

	if (event_type == 1) {
		if(uart_type == UART_4) {
		    if (rtu1_index < MODBUS_RTU_MSG_LEN_MAX) {
		        rtu1_buffer[rtu1_index++] = data;
		    }
		} else if(uart_type == UART_5){
		    if (rtu2_index < MODBUS_RTU_MSG_LEN_MAX) {
		        rtu2_buffer[rtu2_index++] = data;
		    }
		} else {
			data_buf[data_len++] = data;
		}
	} else {
        if (uart_type == UART_4) {
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
		    PRINTF("UART4 Length:%u\r\n",rtu1_index);
			for (uint16_t i = 0; i < rtu1_index; i++) {
				PRINTF("%x ",rtu1_buffer[i]);
			}
			PRINTF("\n");
#endif
			rtu1_ok = 1;
        } else if (uart_type == UART_5) {
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
		    PRINTF("UART5 Length:%u\r\n",rtu2_index);
			for (uint16_t i = 0; i < rtu2_index; i++) {
				PRINTF("%x ",rtu2_buffer[i]);
			}
			PRINTF("\n");
#endif
        	rtu2_ok = 1;
        } else  {
        	data_buf[data_len] = '\0';
        	handle_fresh_dev_config(data_buf, data_len);
        }

	}
}
/******************************************************************************
 * @brief       serial port initialization function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void serial_port_init(void) {

	taskENTER_CRITICAL();
	uart_init(UART_4, modbus_data.serial_cfg.channel1.baud_rate, modbus_data.serial_cfg.channel1.parity, modbus_data.serial_cfg.channel1.data_bits, modbus_data.serial_cfg.channel1.stop_bits);
	uart_init(UART_5, modbus_data.serial_cfg.channel2.baud_rate, modbus_data.serial_cfg.channel2.parity, modbus_data.serial_cfg.channel2.data_bits, modbus_data.serial_cfg.channel2.stop_bits);
	taskEXIT_CRITICAL();
	//	rtu1_frame_tmt = uart_get_3p5_char_time_us(modbus_data.serial_cfg.channel1.baud_rate,modbus_data.serial_cfg.channel1.parity, modbus_data.serial_cfg.channel1.data_bits, modbus_data.serial_cfg.channel1.stop_bits);
//	rtu2_frame_tmt = uart_get_3p5_char_time_us(modbus_data.serial_cfg.channel2.baud_rate,modbus_data.serial_cfg.channel2.parity, modbus_data.serial_cfg.channel2.data_bits, modbus_data.serial_cfg.channel2.stop_bits);
//	PRINTF("FRAME TMT:%u,%u\n",rtu1_frame_tmt, rtu2_frame_tmt);
//	hal_timer_init_for_rtu(TIMER2);
//	hal_timer_init_for_rtu(TIMER5);

}
/******************************************************************************
 * @brief       TCP Timeout handle function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void tcp_timeout_handle(void *parameter) {

	tcp_socket_timeout = modbus_data.server_gw_cfg.connection_tmt * 1000;
	while(1) {
		if (device_state == WORKING_MODE) {
			tcp_timeout_monitor();
		}
		vTaskDelay(50);
	}
}
/******************************************************************************
 * @brief       lwip periodic handle
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void lwip_periodic_handle(void *pvParameters) {

	while(1) {
		hal_gpio_toggle(PORT_WDI, PIN_WDI);
	    handle_ethernet_connection();
	    if (suspend_task == SUSPEND_TASK_FLAG) {
	    	taskENTER_CRITICAL();
		    if(modbus_data.gw_type == SERVER_GATEWAY) {
		    	tcp_server_close(modbus_data.server_gw_cfg.rs485_port1, modbus_data.server_gw_cfg.rs485_port2);
		    	vTaskSuspend(server_gw_handler);
		    	vTaskSuspend(timeout_handler);
		    } else {
		    	vTaskSuspend(client_gw_handler);
		    }
	    	taskEXIT_CRITICAL();
	    	httpd_init();
	    	led_mode_set(FACTORY_CONFIG_MODE);
	    	suspend_task = 0;
	    }
	    vTaskDelay(200);
	}
}
/******************************************************************************
 * @brief       Modbus Server Gateway task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void modbus_server_gw_task(void *parametrs) {

	uint32_t start_time;
	tcp_server_init(modbus_data.server_gw_cfg.rs485_port1,modbus_data.server_gw_cfg.rs485_port2);
	serial_port_init();
	uint8_t slave_id;
	while(1) {

		if (tcp_ok) {
			clear_rtu_buffer();
			hal_timer_one_cycle_mode_set(TCP_LED);
			if (tcp_port == modbus_data.server_gw_cfg.rs485_port1) {
				uint8_t len = tcp_to_rtu_request(tcp_request, rtu1_buffer);
				slave_id = rtu1_buffer[0];
				uart_transmit(UART_4, rtu1_buffer, len, 10);
				hal_timer_one_cycle_mode_set(SERIAL1_LED);
				start_time = xTaskGetTickCount();
				uint8_t timeout_occurred = 1;   // assume timeout first
				while ((xTaskGetTickCount() - start_time) < modbus_data.server_gw_cfg.rs485_rsp_timeout1)
				{
				    if (rtu1_ok == 1)
				    {
				        timeout_occurred = 0; // response received
				        break;                // exit loop immediately
				    }
				    vTaskDelay(10); // prevent 100% CPU load
				}
				if (timeout_occurred == 0 && slave_id == rtu1_buffer[0]) {
					hal_timer_one_cycle_mode_set(SERIAL1_LED);
                    if (rtu1_index >= 4) {
				    	 uint16_t received_crc = rtu1_buffer[rtu1_index - 2] |(rtu1_buffer[rtu1_index - 1] << 8);
				         uint16_t crc_verify = crc16(rtu1_buffer, rtu1_index - 2);
				         PRINTF("CRC:%04X,%04X\r\n", received_crc, crc_verify);
				         if (received_crc == crc_verify) {
				        	 uint16_t len = rtu_to_tcp_response(rtu1_buffer, rtu1_index, tcp_response);
				             tcp_server_transmit(tcp_response, len, modbus_data.server_gw_cfg.rs485_port1);
				             hal_timer_one_cycle_mode_set(TCP_LED);
				         } else {
				        	 uint16_t len = tcp_to_rtu_exception_rsp(SLAVE_DEVICE_FAILURE, tcp_response);
				        	 tcp_server_transmit(tcp_response, len, modbus_data.server_gw_cfg.rs485_port1);
				        	 hal_timer_one_cycle_mode_set(TCP_LED);
				         }
                    }

				} else {
				     uint16_t len = tcp_to_rtu_exception_rsp(GW_TARGET_DEVICE_FAILED_TO_RESPOND, tcp_response);
				     tcp_server_transmit(tcp_response, len, modbus_data.server_gw_cfg.rs485_port1);
				     hal_timer_one_cycle_mode_set(TCP_LED);
				     PRINTF("1.SERVER GW TMT\n");
				}

			} else if (tcp_port == modbus_data.server_gw_cfg.rs485_port2) {
				uint8_t len = tcp_to_rtu_request(tcp_request, rtu2_buffer);
				slave_id = rtu2_buffer[0];
				uart_transmit(UART_5, rtu2_buffer, len, 10);
				hal_timer_one_cycle_mode_set(SERIAL2_LED);
				start_time = xTaskGetTickCount();
				uint8_t timeout_occurred = 1;   // assume timeout first
				while ((xTaskGetTickCount() - start_time) < modbus_data.server_gw_cfg.rs485_rsp_timeout2)
				{
				    if (rtu2_ok == 1)
				    {
				        timeout_occurred = 0; // response received
				        break;                // exit loop immediately
				    }
				    vTaskDelay(10); // prevent 100% CPU load
				}
				if (timeout_occurred == 0 && slave_id == rtu2_buffer[0]) {
					hal_timer_one_cycle_mode_set(SERIAL2_LED);
                    if (rtu2_index >= 4) {
				    	 uint16_t received_crc = rtu2_buffer[rtu2_index - 2] |(rtu2_buffer[rtu2_index - 1] << 8);
				         uint16_t crc_verify = crc16(rtu2_buffer, rtu2_index - 2);
				         if (received_crc == crc_verify) {
				        	 uint16_t len = rtu_to_tcp_response(rtu2_buffer, rtu2_index, tcp_response);
				             tcp_server_transmit(tcp_response, len, modbus_data.server_gw_cfg.rs485_port2);
				             hal_timer_one_cycle_mode_set(TCP_LED);
				         } else {
				        	 uint16_t len = tcp_to_rtu_exception_rsp(SLAVE_DEVICE_FAILURE, tcp_response);
				        	 tcp_server_transmit(tcp_response, len, modbus_data.server_gw_cfg.rs485_port2);
				        	 hal_timer_one_cycle_mode_set(TCP_LED);
				         }
                    }
				} else {
				     uint16_t len = tcp_to_rtu_exception_rsp(GW_TARGET_DEVICE_FAILED_TO_RESPOND, tcp_response);
				     tcp_server_transmit(tcp_response, len, modbus_data.server_gw_cfg.rs485_port2);
				     hal_timer_one_cycle_mode_set(TCP_LED);
				     PRINTF("2.SERVER GW TMT\n");
				}
			}
            clear_tcp_buffer();
		}
		vTaskDelay(10);
	}
}
/******************************************************************************
 * @brief       Modbus Client Gateway task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void modbus_client_gw_task(void *parametrs) {

	uint32_t start_time;
	serial_port_init();
	while(1) {
		if (rtu1_ok) {
			PRINTF("RTU1 CLIENT\n");
	    	 if (rtu1_index >= 4) {
		    	 clear_tcp_buffer();
		    	 tcp_connect_ok = 0;
	    		    hal_timer_one_cycle_mode_set(SERIAL1_LED);
		        	uint8_t slave_id = rtu1_buffer[0];
		            uint16_t received_crc = rtu1_buffer[rtu1_index - 2] |(rtu1_buffer[rtu1_index - 1] << 8);
		            uint16_t crc_verify = crc16(rtu1_buffer, rtu1_index - 2);
		            if (received_crc == crc_verify) {
		            	uint16_t nat_table_num;
		            	tcp_request_len = rtu_to_tcp_request(rtu1_buffer, rtu1_index, tcp_request);
		            	if(get_slave_ip_by_id(slave_id, &nat_table_num) && ethernet_ok) {
		            		tcp_client_init(502);
		            		int8_t status = tcp_client_connect(modbus_data.client_gw_cfg.client_gw[nat_table_num].ip_address, modbus_data.client_gw_cfg.client_gw[nat_table_num].port);
		    				start_time = xTaskGetTickCount();
		    				uint8_t timeout_occurred = 1;   // assume timeout first
		    				while ((xTaskGetTickCount() - start_time) < modbus_data.client_gw_cfg.client_gw[nat_table_num].rsp_timeout)
		    				{
		    				    if (tcp_connect_ok == 1)
		    				    {
		    				        timeout_occurred = 0; // response received
		    				        break;                // exit loop immediately
		    				    }
		    				    vTaskDelay(1); // prevent 100% CPU load
		    				}
//		    				PRINTF("TCP DONE:%u\n\r",xTaskGetTickCount());
		    				if (timeout_occurred == 0) {
		    					PRINTF("TCP CONNECT OK\n\r");
		    					hal_timer_one_cycle_mode_set(TCP_LED);
		    					tcp_client_data_transmit(tcp_request,tcp_request_len);
			    				start_time = xTaskGetTickCount();
			    				uint8_t timeout_occurred = 1;   // assume timeout first
			    				while ((xTaskGetTickCount() - start_time) < modbus_data.client_gw_cfg.client_gw[nat_table_num].rsp_timeout)
			    				{
			    				    if (tcp_ok == 1) {
			    				        timeout_occurred = 0; // response received
			    				        break;                // exit loop immediately
			    				    }
			    				    vTaskDelay(10); // prevent 100% CPU load
			    				}
			    				tcp_client_close();
			    				if (timeout_occurred == 0) {
//			    					PRINTF("RTU RESP\r\n");
			    					hal_timer_one_cycle_mode_set(TCP_LED);
			    					uint8_t len = tcp_to_rtu_response(tcp_response, tcp_response_len, rtu_response);
			    					uart_transmit(UART_4, rtu_response, len, 10);
			    					hal_timer_one_cycle_mode_set(SERIAL1_LED);
//			    					tcp_client_close();
			    				}
		    				} else {
		    					PRINTF("TCP CONNECT FAIL\n\r");
					    		 tcp_client_close();
					    		 uint8_t slave_id = rtu1_buffer[0];
					    		 uint8_t func_code = rtu1_buffer[1];
				                 uint8_t len = rtu_to_tcp_exception_rsp(GW_TARGET_DEVICE_FAILED_TO_RESPOND, rtu_response);
				                 uart_transmit(UART_4, rtu_response, len, 10);
				                 hal_timer_one_cycle_mode_set(SERIAL1_LED);

		    				}
		            	}
		            }
	    	 }
	    	 clear_rtu_buffer();

		} else if (rtu2_ok) {
	    	 if (rtu2_index >= 4) {
	    		 PRINTF("RTU2 CLIENT\n");
		    	 clear_tcp_buffer();
		    	 tcp_connect_ok = 0;
	    		    hal_timer_one_cycle_mode_set(SERIAL2_LED);
		        	uint8_t slave_id = rtu2_buffer[0];
		            uint16_t received_crc = rtu2_buffer[rtu2_index - 2] |(rtu2_buffer[rtu2_index - 1] << 8);
		            uint16_t crc_verify = crc16(rtu2_buffer, rtu2_index - 2);
		            if (received_crc == crc_verify) {
		            	uint16_t nat_table_num;
		            	tcp_request_len = rtu_to_tcp_request(rtu2_buffer, rtu2_index, tcp_request);
		            	if(get_slave_ip_by_id(slave_id, &nat_table_num) && ethernet_ok) {
		            		tcp_client_init(0);
		            		int8_t status = tcp_client_connect(modbus_data.client_gw_cfg.client_gw[nat_table_num].ip_address, modbus_data.client_gw_cfg.client_gw[nat_table_num].port);
		    				start_time = xTaskGetTickCount();
		    				uint8_t timeout_occurred = 1;   // assume timeout first
		    				while ((xTaskGetTickCount() - start_time) < modbus_data.client_gw_cfg.client_gw[nat_table_num].rsp_timeout)
		    				{
		    				    if (tcp_connect_ok == 1)
		    				    {
		    				        timeout_occurred = 0; // response received
		    				        break;                // exit loop immediately
		    				    }
		    				    vTaskDelay(10); // prevent 100% CPU load
		    				}
//		    				PRINTF("TCP DONE:%u\n\r",xTaskGetTickCount());
		    				if (timeout_occurred == 0) {
		    					PRINTF("TCP CONNECT OK\n\r");
		    					hal_timer_one_cycle_mode_set(TCP_LED);
		    					tcp_client_data_transmit(tcp_request,tcp_request_len);
			    				start_time = xTaskGetTickCount();
			    				uint8_t timeout_occurred = 1;   // assume timeout first
			    				while ((xTaskGetTickCount() - start_time) < modbus_data.client_gw_cfg.client_gw[nat_table_num].rsp_timeout)
			    				{
			    				    if (tcp_ok == 1) {
			    				        timeout_occurred = 0; // response received
			    				        break;                // exit loop immediately
			    				    }
			    				    vTaskDelay(10); // prevent 100% CPU load
			    				}
			    				tcp_client_close();
			    				if (timeout_occurred == 0) {
//			    					PRINTF("RTU RESP\r\n");
			    					hal_timer_one_cycle_mode_set(TCP_LED);
			    					uint8_t len = tcp_to_rtu_response(tcp_response, tcp_response_len, rtu_response);
			    					uart_transmit(UART_5, rtu_response, len, 10);
			    					hal_timer_one_cycle_mode_set(SERIAL2_LED);
//			    					tcp_client_close();
			    				}
		    				} else {
		    					PRINTF("TCP CONNECT FAIL\n\r");
					    		 tcp_client_close();
					    		 uint8_t slave_id = rtu2_buffer[0];
					    		 uint8_t func_code = rtu2_buffer[1];
				                 uint8_t len = rtu_to_tcp_exception_rsp(GW_TARGET_DEVICE_FAILED_TO_RESPOND, rtu_response);
				                 uart_transmit(UART_5, rtu_response, len, 10);
				                 hal_timer_one_cycle_mode_set(SERIAL2_LED);

		    				}
		            	}
		            }
	    	 }
	    	 clear_rtu_buffer();
		}
		vTaskDelay(10);
	}
}
/******************************************************************************
 * @brief       create_server_gw_task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void create_server_gw_task(void) {

	if (xTaskCreate((TaskFunction_t)modbus_server_gw_task,"server_gw",2048,NULL,3,&server_gw_handler) != pdPASS) {
		 PRINTF("INFO : modbus_server_gw task could not be created as there was insufficient heap memory remaining.\n");
	} else {
		 PRINTF("INFO: modbus_server_gw task was created successfully.\n");
	}
	if (xTaskCreate((TaskFunction_t)tcp_timeout_handle,"timeout_task",1024,NULL,2,&timeout_handler) != pdPASS) {
		PRINTF("INFO : tcp_timeout_handle task could not be created as there was insufficient heap memory remaining.\n");
    } else {
		 PRINTF("INFO: tcp_timeout_handle task was created successfully.\n");
	}
}
/******************************************************************************
 * @brief       create_client_gw_task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void create_client_gw_task(void) {
	if (xTaskCreate((TaskFunction_t)modbus_client_gw_task,"client_rsp",2048,NULL,3,&client_gw_handler) != pdPASS) {
		 PRINTF("INFO : modbus_client_gw task could not be created as there was insufficient heap memory remaining.\n");
	} else {
		 PRINTF("INFO: modbus_client_gw task was created successfully.\n");
	}
}
/******************************************************************************
 * @brief       Network Task function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void network_task_function(void *pvParameters) {

	while(1) {
		ip_details_t ip_cfg;
   	    fresh_device_config_t read_config;
   	    uint8_t flash_sts = read_fresh_device_config_from_flash(&read_config);
   	    mac_id_set(read_config.mac_address);
		uint8_t mode_state = device_config_mode_get();
		PRINTF("Device mode:%x\n",mode_state);
		if (device_state == FRESH_DEVICE_CONFIG) {
		    if (xTaskCreate((TaskFunction_t)Fresh_dev_task,"fresh_task",512,NULL,2, NULL) != pdPASS) {
			    PRINTF("INFO : fresh dev task could not be created\n");
		    } else {
			    PRINTF("INFO: fresh dev task was created successfully\n");
		    }
		} else {
	   	    if (flash_sts == 0) {
	   	    	PRINTF("FOTA MAC ADDRESS READ FAILED\n");
	   	    	while(1);
	   	    }
			if (mode_state == WORKING_MODE_STATUS) {
				Read_modbus_config();
				device_state = WORKING_MODE;
				led_mode_set(WORKING_MODE);
			} else {
				device_state = FACTORY_CONFIG_MODE;
				led_mode_set(FACTORY_CONFIG_MODE);
			}
			ip_cfg.ip_mode = STATIC_IP; // static ip
			if (device_state == WORKING_MODE) {
				PRINTF("WORK WITH NWK\n");
				ip_cfg.local_ip = modbus_data.nwk_cfg.ipv4_address;
				ip_cfg.local_gw = modbus_data.nwk_cfg.default_gateway;
				ip_cfg.local_mask = modbus_data.nwk_cfg.subnet_mask;
			} else {
				PRINTF("WORK WITH DEFAULT\n");
		        ip_cfg.local_ip = modbus_data.nwk_cfg.ipv4_address;
		        ip_cfg.local_gw = modbus_data.nwk_cfg.default_gateway;
		        ip_cfg.local_mask = modbus_data.nwk_cfg.subnet_mask;
			}
			uint8_t error = hal_rmii_ethernet_init(&ip_cfg);
			if (device_state == WORKING_MODE) {
			    if(modbus_data.gw_type == SERVER_GATEWAY) {
					create_server_gw_task();
			    } else {
					create_client_gw_task();
			    }
			} else {
				httpd_init();
			}
			fill_device_info(read_config.mac_address,modbus_data.nwk_cfg.ipv4_address,modbus_data.nwk_cfg.subnet_mask,
					modbus_data.nwk_cfg.default_gateway, read_config.device_type_id, firmware_version);
		}
	    vTaskDelete(NULL);
	}
}
/******************************************************************************
 * @brief       Start RTOS function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void start_task(void) {

	    if(xTaskCreate((TaskFunction_t)network_task_function,"Network_task",512,NULL,3,&network_handler) != pdPASS) {
			 PRINTF("Network task could not be created \r\n");
	    } else {
			 PRINTF("Network task was created successfully.\r\n");
	    }
		if (xTaskCreate((TaskFunction_t)lwip_periodic_handle,"lwip_looping_task",512,NULL,4,&lwip_loop_handler) != pdPASS) {
			PRINTF("INFO : lwip_recv_task could not be created\n");
	    } else {
			 PRINTF("INFO: lwip_periodic_handle task was created successfully.\n");
		}
	    vTaskStartScheduler();
}
/******************************************************************************
 * @brief       Direction control gpio init function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void uart_dir_control_gpio_init(void) {
	hal_gpio_init(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_OUTPUT, PULL_NONE);
	hal_gpio_write(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_RESET);
	hal_gpio_init(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_OUTPUT, PULL_NONE);
	hal_gpio_write(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_RESET);
	hal_timer_init(TIMER6,1);
}
/******************************************************************************
 * @brief       Watchdog gpio init function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void watchdog_gpio_init(void) {
	hal_gpio_init(PORT_WDI, PIN_WDI, GPIO_OUTPUT, PULL_NONE);
}
/******************************************************************************
 * @brief       led timer initialization
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void led_init(void) {
	hal_timer_one_cycle_mode_init();
}
/******************************************************************************
 * @brief       Pheripheral initialization
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void Peripheral_init(void) {

	watchdog_gpio_init();
	uart_dir_control_gpio_init();
    hal_exint_init();
    uint8_t pin_status = hal_gpio_input_pin_read(GPIO_PORTC, PIN_NUM_0);
	if (pin_status == 0) {
		 uart_print_init(115200, 1);
         device_state = FRESH_DEVICE_CONFIG;
	} else {
		uart_print_init(115200, 0);
		led_init();
	}
    spiflash_init();
	hal_timer_init(TIMER1,10);
	PRINTF("AT32F437RGT7 Board init\r\n");

}
/******************************************************************************
 * @brief       app_main - start of application
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void App_main(void) {

	Peripheral_init();
	ethernet_callback_register(eth_cbk_app);
	tcp_client_callback_reg_fun(tcp_client_cbk);
	tcp_server_callback_reg_fun(tcp_server_cbk);
	timer_callback_register(timer_cbk);
	uart_callback_register(uart_rx_cbk);
	hal_usr_butn_clbk_reg(user_button_cbk);
	http_callback_register(http_cbk_app);
    start_task();
}



 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
