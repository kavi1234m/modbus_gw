/**
  **************************
  * @file    html_to_spi_flash.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Nov 21
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HTML_TO_SPI_FLASH_H_
#define __HTML_TO_SPI_FLASH_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/
 typedef enum {
 	LOGIN_PAGE = 0,
 	DEV_INFO_PAGE,
 	NWK_CFG_PAGE,
 	CLOUD_CFG_PAGE,
 	SERIAL_CFG_PAGE,
 	DATA_MAP_PAGE,
 	RTU1_PAGE,
 	RTU2_PAGE,
 	TCP_PAGE,
	REG_CFG_PAGE,
 	SUCCESS_CFG_PAGE,
 	CSS_PAGE,
 	LOGO_PNG
 }html_page_t;
/* Exported functions --------------------------------------------------------*/
 void html_metadata_read(void);
 void html_page_write_into_flash(uint8_t *write_buf, uint16_t write_len);
 void html_page_read_from_flash(uint8_t *ip_buffer, html_page_t page_type);
 void finalize_last_page_on_eot(void);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __HTML_TO_SPI_FLASH_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
