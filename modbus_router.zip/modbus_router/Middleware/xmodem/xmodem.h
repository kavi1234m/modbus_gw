#ifndef XMODEM_H
#define XMODEM_H

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "hal_uart.h"

#include <stdbool.h>

#define XMODEM_BUFFER_SIZE      128

typedef enum {
    XMODEM_SUCCESS = 0,
    XMODEM_ERROR_TIMEOUT,
    XMODEM_ERROR_CANCEL,
    XMODEM_ERROR_CRC,
    XMODEM_ERROR_SEQUENCE,
    XMODEM_ERROR_MEMORY
} xmodem_result_t;

typedef struct {
    QueueHandle_t rx_queue;
    TaskHandle_t task_handle;
    uart_type uart_port;
    uint32_t baudrate;

    bool transfer_active;
    bool transfer_success;
    xmodem_result_t result;
    uint32_t total_bytes;
    uint32_t total_packets;

    void (*packet_received)(uint8_t *data, size_t len, uint32_t packet_num);
    void (*transfer_complete)(xmodem_result_t result, uint32_t total_bytes);

    bool debug_output_enabled;
} xmodem_context_t;

#define XMODEM_SOH      0x01
#define XMODEM_EOT      0x04
#define XMODEM_ACK      0x06
#define XMODEM_NAK      0x15
#define XMODEM_CAN      0x18
#define XMODEM_C        0x43

void xmodem_callback_register(void *callback);
void transfer_data_to_xmodem(uint8_t data, uart_type uart_port, uint8_t event_type);
xmodem_result_t xmodem_receive(xmodem_context_t *ctx, uint32_t timeout_ms);
void xmodem_cancel(xmodem_context_t *ctx);
void xmodem_enable_debug_output(xmodem_context_t *ctx, bool enable);
bool xmodem_receive_byte(uart_type uart_port, uint8_t *data, uint32_t timeout_ms);
#endif
