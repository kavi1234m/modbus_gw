/**
  **************************
  * @file    server_gw_router.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Aug 6
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "server_gw_router.h"
#include "checksum.h"
#include <string.h>
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint16_t server_modbus_transaction_id;
uint8_t server_unit_id;
uint8_t server_func_code;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/******************************************************************************
 * @brief       Convert Modbus TCP request to RTU Request function
 * @param[in]   tcp_req - incoming Modbus TCP request
 * @param[out]  rtu_req - output RTU request
 * @return      none
 ******************************************************************************/
uint8_t tcp_to_rtu_request(const uint8_t *tcp_req, uint8_t *rtu_req) {

	server_modbus_transaction_id = (tcp_req[0] << 8) | tcp_req[1]; // Extract Transaction ID (first 2 bytes)
    uint16_t rtu_length = (tcp_req[4] << 8) | tcp_req[5];          // Length of PDU + Unit ID (from MBAP header)
    if ((rtu_length + 2) >= 256) {
    	return 0;
    }
	server_unit_id = tcp_req[6];
	server_func_code = tcp_req[7];
    memcpy(rtu_req, tcp_req + 6, rtu_length);               // Copy only actual PDU (unit ID + function code + data)
    uint16_t crc = crc16(rtu_req, rtu_length);              // Append CRC
    rtu_req[rtu_length] = crc & 0xFF;
    rtu_req[rtu_length + 1] = crc >> 8;
    return (rtu_length + 2);                                // Total RTU request length
}
/******************************************************************************
 * @brief       Convert Modbus RTU Response to TCP Response function
 * @param[in]   rtu_resp - incoming Modbus RTU response
 * @param[in]   rtu_len  - length of the incoming rtu response
 * @param[in]   transaction id - Attach this id to MBAP Header
 * @param[out]  tcp_resp - Output TCP Response
 * @return      none
 ******************************************************************************/
uint16_t rtu_to_tcp_response(const uint8_t *rtu_resp, uint8_t rtu_len, uint8_t *tcp_resp) {

	uint16_t len_to_copy = rtu_len - 2;
    tcp_resp[0] = server_modbus_transaction_id >> 8;
    tcp_resp[1] = server_modbus_transaction_id & 0xFF;
    tcp_resp[2] = 0x00;
    tcp_resp[3] = 0x00;
    tcp_resp[4] = len_to_copy >> 8;
    tcp_resp[5] = len_to_copy & 0xFF;
    memcpy(tcp_resp + 6, rtu_resp, len_to_copy); // Copy PDU (starting from Unit ID)
    return (6 + len_to_copy);  // Total TCP response length
}
/*************************************************************************************************
 * Create a Modbus TCP Exception Frame
 * @param unit_id          Slave ID / Unit ID
 * @param function_code    Original function code
 * @param exception_code   Modbus exception code (e.g., 0x04 for CRC/Slave failure)
 * @param out_frame        Buffer to store generated TCP frame
 * @return                 Length of the TCP frame
 ****************************************************************************************************/
uint8_t tcp_to_rtu_exception_rsp(uint8_t exception_code, uint8_t *tcp_resp) {

    uint16_t index = 0;

    // Transaction ID (2 bytes)
    tcp_resp[index++] = (server_modbus_transaction_id >> 8) & 0xFF;
    tcp_resp[index++] = server_modbus_transaction_id & 0xFF;

    // Protocol ID (2 bytes) = 0 for Modbus TCP
    tcp_resp[index++] = 0x00;
    tcp_resp[index++] = 0x00;

    // Length (2 bytes) = 3 (Unit ID + Function + Exception code)
    tcp_resp[index++] = 0x00;
    tcp_resp[index++] = 0x03;

    // Unit ID (Slave ID)
    tcp_resp[index++] = server_unit_id;

    // Function code with MSB set (error)
    tcp_resp[index++] = server_func_code | 0x80;

    // Exception code
    tcp_resp[index++] = exception_code;

    return index; // Total length of frame
}

 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
