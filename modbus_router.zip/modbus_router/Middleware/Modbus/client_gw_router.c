/**
  **************************
  * @file    client_gw_router.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Aug 6
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "client_gw_router.h"
#include "checksum.h"
#include <string.h>
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint16_t modbus_transaction_id;
uint8_t client_slave_id;
uint8_t client_func_code;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************
 * @brief       Convert Modbus RTU request to TCP Request
 * @param[in]   rtu_req  - RTU request buffer
 * @param[in]   rtu_len  - Length of the RTU request
 * @param[out]  tcp_req  - Output TCP request buffer
 * @return      Total TCP request length
 ******************************************************************************/
uint16_t rtu_to_tcp_request(const uint8_t *rtu_req, uint8_t rtu_len, uint8_t *tcp_req) {

    uint8_t pdu_len = rtu_len - 2; // Remove 2-byte CRC
    modbus_transaction_id++;
	client_slave_id = rtu_req[0];
	client_func_code = rtu_req[1];

    tcp_req[0] = modbus_transaction_id >> 8;
    tcp_req[1] = modbus_transaction_id & 0xFF;
    tcp_req[2] = 0; // Protocol ID high
    tcp_req[3] = 0; // Protocol ID low
    tcp_req[4] = pdu_len >> 8;
    tcp_req[5] = pdu_len & 0xFF;
    memcpy(tcp_req+6, rtu_req, pdu_len); // Skip unit_id in RTU

    return (6 + pdu_len);
}
/******************************************************************************
 * @brief       Convert Modbus TCP Response to RTU Response function
 * @param[in]   tcp_resp - incoming Modbus TCP response
 * @param[in]   tcp_len  - length of the incoming TCP response
 * @param[out]  rtu_resp - Output RTU Response
 * @return      none
 ******************************************************************************/
uint8_t tcp_to_rtu_response(const uint8_t *tcp_resp,uint16_t tcp_len, uint8_t *rtu_resp) {

    uint16_t pdu_len = tcp_len - 6; // MBAP header is 6 bytes
    memcpy(rtu_resp, tcp_resp+6, pdu_len);
    uint16_t crc = crc16(rtu_resp, pdu_len);
    rtu_resp[pdu_len] = crc & 0xFF;
    rtu_resp[pdu_len + 1] = crc >> 8;
    return (pdu_len + 2);
}

/*************************************************************************************************
 * @brief   Prepare a Modbus RTU exception response
 * @param   slave_id       - Unit ID / Slave Address
 * @param   function_code  - Original function code from request
 * @param   exception_code - Modbus exception code (e.g., 0x0A or 0x0B)
 * @param   rtu_resp       - Output buffer to hold RTU response
 * @return  Total length of response (always 5 bytes)
 *************************************************************************************************/
uint8_t rtu_to_tcp_exception_rsp(uint8_t exception_code, uint8_t *rtu_resp) {
    rtu_resp[0] = client_slave_id;
    rtu_resp[1] = client_func_code | 0x80;     // Set MSB to indicate exception
    rtu_resp[2] = exception_code;
    uint16_t crc = crc16(rtu_resp, 3);      // Compute CRC over 3 bytes
    rtu_resp[3] = crc & 0xFF;               // CRC low byte
    rtu_resp[4] = crc >> 8;                 // CRC high byte

    return 5;  // Total response length
}

 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
