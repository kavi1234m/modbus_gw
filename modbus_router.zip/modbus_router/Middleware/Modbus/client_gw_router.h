/**
  **************************
  * @file    client_gw_router.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Aug 6
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CLIENT_GW_ROUTER_H_
#define __CLIENT_GW_ROUTER_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/

 uint16_t rtu_to_tcp_request(const uint8_t *rtu_req, uint8_t rtu_len, uint8_t *tcp_req);
 uint8_t tcp_to_rtu_response(const uint8_t *tcp_resp,uint16_t tcp_len, uint8_t *rtu_resp);
 uint8_t rtu_to_tcp_exception_rsp(uint8_t exception_code, uint8_t *rtu_resp);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __CLIENT_GW_ROUTER_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
