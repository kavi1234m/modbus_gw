/**
  **************************
  * @file    epoch_conversion.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 29
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "epoch_conversion.h"
#include "hal_rtc.h"
#include <stdio.h>
#include <time.h>
#include <stdint.h>
#include "modbus_gw_cfg.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

time_t epoch_convertion(uint8_t dd, uint8_t mm, uint8_t yy, uint8_t hr, uint8_t mn, uint8_t sc)
{
   struct tm t;
   int year = 2000 + yy;

    t.tm_year = year - 1900; // year since 1900 -> 2025-1900 = 125
    t.tm_mon  = mm - 1;       // month 0-11 -> September = 8
    t.tm_mday = dd;          // day of month
    t.tm_hour = hr;          // hour
    t.tm_min  = mn;          // minute
    t.tm_sec  = sc;           // second
    t.tm_isdst = -1;         // let system determine if DST applies

    return mktime(&t);
}

uint32_t epoch_time_get(void) {

	calendar_info_t ts;
	hal_rtc_calendar_get(&ts);
    time_t epoch = epoch_convertion(ts.date, ts.month, ts.year, ts.hour, ts.min, ts.sec);
    if (epoch == -1) {
        PRINTF("Failed to convert time.\n");
    } else {
//        PRINTF("Epoch time: %ld\n", (long)epoch);
    }
    return epoch;
}


 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
