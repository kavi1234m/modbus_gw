/**
  **************************
  * @file    spi_flash_partition.c
  * @author  Abhirami , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Oct 6
  * @brief   This file provides functions to manage the external spi flash
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
*/


/* Includes ------------------------------------------------------------------*/
#include "spi_flash_partition.h"

/* Private functions ---------------------------------------------------------*/

uint32_t partitions[]={SFP_PRTN1_STRT_ADDR, SFP_PRTN2_STRT_ADDR, SFP_PRTN3_STRT_ADDR};
uint32_t partition_size[]={SFP_PRTN1_SIZE, SFP_PRTN2_SIZE, SFP_PRTN3_SIZE};

#define LOG_START_INDEX     LOG_START/SFP_SECTOR_SIZE
#define LOG_END_INDEX       LOG_END/SFP_SECTOR_SIZE
#define OVERFLOW            (PTR_R+3)

/****************************************************************************************************************
  * @brief  Check whether the mem_addr is starting of a sector
  * @param  mem_addr: memory address 
  * @retval 1 if staring address, else 0 
  ***************************************************************************************************************/
uint8_t sfp_chk_sctr_strt(uint16_t mem_addr)
{
    if(!(mem_addr%SFP_SECTOR_SIZE))
        return 1;   //Starting
    else
        return 0;
}

/****************************************************************************************************************
  * @brief  find the sector in which the mem_addr belongs to
  * @param  mem_addr: memory address 
  * @retval sector index
  ***************************************************************************************************************/
uint8_t sfp_find_sctr(uint32_t mem_addr)
{
    return (mem_addr/SFP_SECTOR_SIZE);
}

/****************************************************************************************************************
  * @brief  find the no.of sectors in the given partition
  * @param  mem_size: memory size
  * @retval no.of sectors
  ***************************************************************************************************************/
uint8_t sfp_find_part_sctr_cnt(uint32_t mem_size)
{
    if(!(mem_size%SFP_SECTOR_SIZE))
        return (mem_size/SFP_SECTOR_SIZE);
    else
        return (mem_size/SFP_SECTOR_SIZE+1);
}

/****************************************************************************************************************
  * @brief  Clear all the sectors
  * @param  None
  * @retval 1 if success, 0 if failure 
  ***************************************************************************************************************/
uint8_t sfp_clr_all_part(void)
{
    uint8_t partition=0, sector_number, sector_index=0, sectors=0;

    for(partition=0;partition< SFP_PRTN_CNT;partition++)
    {
        sector_number=sfp_find_part_sctr_cnt(partition_size[partition]) ;
        sector_index=sfp_find_sctr(partitions[partition]);

        for(sectors=0;sectors<sector_number;sectors++)
        {
            if(!(spiflash_sector_erase(sector_index+sectors)))
                return 0;
        }
    }
    return 1;
}

/****************************************************************************************************************
  * @brief  Clear a particular partition
  * @param  partition: partition number
  * @retval 1 if success, 0 if failure 
  ***************************************************************************************************************/
uint8_t sfp_clr_part(uint8_t Partition)
{
    if (Partition >= SFP_PRTN_CNT) 
        return 0; 
    uint8_t sector_index=0, sectors=0, sector_number;

    //find no.of sectors in the given partition
    sector_number=sfp_find_part_sctr_cnt(partition_size[Partition]) ;
    sector_index=sfp_find_sctr(partitions[Partition]);

    for(sectors=0;sectors<sector_number;sectors++)
    {
        if(!(spiflash_sector_erase(sector_index+sectors)))
            return 0;
    }
    //clean corresponding required pointers also
    if(Partition==SFP_PRTN1)//configuration
    {
        if(!(spiflash_sector_erase((PART1_W)/(SFP_SECTOR_SIZE))))
            return 0;
    }

    if(Partition==SFP_PRTN2)//fota
    {
        if(!(spiflash_sector_erase((PART2_W)/(SFP_SECTOR_SIZE))))
            return 0;
    }

    if(Partition==SFP_PRTN3)//log
    {
        if(!(spiflash_sector_erase((PTR_W1)/(SFP_SECTOR_SIZE))))
            return 0;
        if(!(spiflash_sector_erase((PTR_W2)/(SFP_SECTOR_SIZE))))
            return 0;
        if(!(spiflash_sector_erase((PTR_R)/(SFP_SECTOR_SIZE))))
            return 0;
        if(!(spiflash_sector_erase((TEMP_LOG_START)/(SFP_SECTOR_SIZE))))
            return 0;
        
        
    }


    
    return 1;
}

/****************************************************************************************************************
  * @brief  write data into particular partition
  * @param  part: partition number/index
  * @param  part_type: type of partition
  * @param  dat: buffer which holds the data
  * @param  dat_len: data length
  * @retval 1 if success, 0 if failure 
  ***************************************************************************************************************/
uint8_t sfp_write_part(uint8_t part, uint8_t part_typ, uint8_t* dat, uint16_t dat_len)
{
    uint8_t addr_buf[3];
    uint8_t sector_index;
    uint16_t write_len;
    uint32_t write_addr, sector_left, pointer_addr, part_start_addr, size_partition, part_end_addr;
    if(part==SFP_PRTN1)
        {
            PRINTF("CONFIGURATION WRITE\n");
            pointer_addr=PART1_W;
            part_start_addr=SFP_PRTN1_STRT_ADDR;
            size_partition=SFP_PRTN1_SIZE;
            part_end_addr=SFP_PRTN1_END_ADDR;
            if(!(spiflash_write_nocheck(dat, CONFG_P1_START, dat_len)))
            {
                PRINTF("1ST CONFIGURATION WRITE  FAILED(WRITE_NOCHECK)\n");
                return 0;
            }
            if(!(spiflash_write_nocheck(dat, CONFG_P2_START, dat_len)))
            {
                PRINTF("2ND CONFIGURATION WRITE FAILED FAILED(WRITE_NOCHECK)\n");
                return 0;
            }
            write_addr=dat_len;
            addr_buf[0] = (uint8_t)(write_addr >> 16);
            addr_buf[1] = (uint8_t)(write_addr >> 8);
            addr_buf[2] = (uint8_t)write_addr;
            if(!(spiflash_write(addr_buf,pointer_addr , 3)))
            {
                PRINTF("WRITING NEW ADDRESS (WRITE ADDRESS) FAILED\n");
            }
            return 1;
        }
    else if(part==SFP_PRTN2)
    {
        PRINTF("FOTA WRITE\n");
        pointer_addr=PART2_W;
        part_start_addr=SFP_PRTN2_STRT_ADDR;
        size_partition=SFP_PRTN2_SIZE;
        part_end_addr=SFP_PRTN2_END_ADDR;
    }
    else if(part==SFP_PRTN3)//log
    {
       if(!(sfp_write_log(dat,dat_len)))
          return 0;
       return 1;
    }
    else
        return 0;

    if(!(spiflash_read((uint8_t *)addr_buf, pointer_addr, 3)))
    {
        PRINTF("FAILED TO READ THE ADDRESS\n");
        return 0;
    }
    write_addr=((uint32_t)addr_buf[0] << 16) | ((uint32_t)addr_buf[1] << 8)  | ((uint32_t)addr_buf[2]);
    if(write_addr==0xffffff)
    {
        write_addr= part_start_addr;
        PRINTF("WRITING FROM  START ADDRESS: 0x%06lX\n",write_addr);
    }

    while(dat_len>0)
    {
        sector_index=write_addr/SFP_SECTOR_SIZE;
        //find bytes in present sector
        sector_left=SFP_SECTOR_SIZE-(write_addr%SFP_SECTOR_SIZE);
        //if reaches the end of allocated memory=>but datalen!=0
        if(sector_index>(part_end_addr/SFP_SECTOR_SIZE))
        {
            PRINTF("NO MORE MEMORY LEFT , REMAINING DATA LENGTH: %d\n",dat_len);
            return 0;
        }
        if(dat_len>sector_left)//have to move to next sector
            write_len=sector_left;
        else
            write_len=dat_len;
        if((write_addr%SFP_SECTOR_SIZE)==0)
        {
            if(!(spiflash_sector_erase(sector_index)))
            {
                PRINTF("SECTOR ERASE WHILE WRITING FAILED\n");
                return 0;
            }
        }
        if(!(spiflash_write_nocheck(dat, write_addr, write_len)))
        {
            PRINTF("WRITING DAT FAILED(WRITE_NOCHECK)\n");
            return 0;
        }
        write_addr+=write_len;
        dat+=write_len;
        dat_len-=write_len;
    }
    PRINTF("CHUNK DATA WRITTEN\n");
    if (write_addr>=(part_start_addr +size_partition))
            write_addr=part_start_addr;
    addr_buf[0] = (uint8_t)(write_addr >> 16);
    addr_buf[1] = (uint8_t)(write_addr >> 8);
    addr_buf[2] = (uint8_t)write_addr;

    if(!(spiflash_write(addr_buf,pointer_addr , 3)))
    {
        PRINTF("WRITING NEW ADDRESS WRITE ADDRESS FAILED\n");
    }
    PRINTF("NEXT WRITE ADDRESS: 0x%06lX\n",write_addr);
    return 1;
}


/****************************************************************************************************************
  * @brief  read data from given partition
  * @param  part: partition number/index
  * @param  part_type: type of partition
  * @param  dat: buffer to hold the data
  * @param  dat_len: data length
  * @retval 1 if success, 0 if failure 
  ***************************************************************************************************************/
uint8_t sfp_read_part(uint8_t part, uint8_t part_typ, uint8_t* dat, uint16_t* dat_len, uint8_t part_no)
{
    uint8_t addr_buf[3], len_buf[2];
    uint16_t read_length=0;
    uint32_t read_addr,pointer_addr, part_start_addr,  limit, size_partition, write_addr_ptr, write_addr;
    /*if(part==SFP_PRTN1)
    {
        PRINTF("Reading configuration\n");
        pointer_addr=PART1_R;
        part_start_addr=SFP_PRTN1_STRT_ADDR;
        limit=SFP_PRTN1_SIZE;
        size_partition=SFP_PRTN1_SIZE;
        write_addr_ptr=PART1_W;
    }*/
   /* if(part==SFP_PRTN1)
        {
            PRINTF("Reading configuration\n");
            pointer_addr=PART1_R;
            part_start_addr=SFP_PRTN1_STRT_ADDR;
            limit=SFP_PRTN1_SIZE;
            size_partition=SFP_PRTN1_SIZE;
            write_addr_ptr=PART1_W;

            //check whether configuration part is empty or not
            spiflash_read((uint8_t *)addr_buf, write_addr_ptr, 3);
            write_addr=((uint32_t)addr_buf[0] << 16) | ((uint32_t)addr_buf[1] << 8)  | ((uint32_t)addr_buf[2]);
            if(write_addr==0xffffff)
            {
                PRINTF("NO CONFIGURATION DATA\n");
                return 0;
            }

            read_addr=part_start_addr;

            if(!(spiflash_read(dat, read_addr, sizeof(uint8_t))))
            {
                PRINTF("FAILED TO READ {\n");
                return 0;
            }
            read_addr++;
            if(dat[0]!='{')
            {
                PRINTF("STARTING IS NOT {\n");
                //is it error/not filled yet(read_addr>write_addr)
                if(write_addr<=read_addr)
                {
                    PRINTF("DATA IS NOT FILLED YET\n");
                    *dat_len=0;
                    return 1;
                }
                PRINTF("ERROR HAPPENED WHILE WRITING\n");
                return 0;
            }
            //read 2byte length
            if(!(spiflash_read(len_buf, read_addr, 2)))
            {
                PRINTF("FAILED TO READ LENGTH TO READ AFTER {\n");
                return 0;
            }
            read_length=((uint16_t)len_buf[0] << 8)  | ((uint16_t)len_buf[1]);
            read_addr+=2;
            if(!(spiflash_read(dat, read_addr, read_length)))
            {
                PRINTF("FAILED TO READ DATA read_length TIMES\n");
                return 0;
            }
            if(dat_len!=NULL)
                *dat_len=read_length;
            return 1;


        }*/
    if(part==SFP_PRTN1)
        {
            PRINTF("Reading configuration\n");
            pointer_addr=PART1_R;
            part_start_addr=SFP_PRTN1_STRT_ADDR;
            limit=SFP_PRTN1_SIZE;
            size_partition=SFP_PRTN1_SIZE;
            write_addr_ptr=PART1_W;

            //check whether configuration part is empty or not
            spiflash_read((uint8_t *)addr_buf, write_addr_ptr, 3);
            write_addr=((uint32_t)addr_buf[0] << 16) | ((uint32_t)addr_buf[1] << 8)  | ((uint32_t)addr_buf[2]);
            if(write_addr==0xffffff)
            {
                PRINTF("NO CONFIGURATION DATA\n");
                return 0;
            }
            if(part_no==1)
                read_addr=part_start_addr;//read from 1st configuration part
            else if(part_no==2)
                read_addr=CONFG_P2_START;//read from 2nd configuration part
            else
            {
                PRINTF("INVALID CONFIGURATION PART NUMBER\n");
                return 0;
            }

            if(!(spiflash_read(dat, read_addr, sizeof(uint8_t))))
            {
                PRINTF("FAILED TO READ {\n");
                return 0;
            }
            read_addr++;
            if(dat[0]!='{')
            {
                PRINTF("STARTING IS NOT {\n");
                //is it error/not filled yet(read_addr>write_addr)
                if(write_addr<=read_addr)
                {
                    PRINTF("DATA IS NOT FILLED YET\n");
                    *dat_len=0;
                    return 1;
                }
                PRINTF("ERROR HAPPENED WHILE WRITING\n");
                return 0;
            }
            //read 2byte length
            if(!(spiflash_read(len_buf, read_addr, 2)))
            {
                PRINTF("FAILED TO READ LENGTH TO READ AFTER {\n");
                return 0;
            }
            read_length=((uint16_t)len_buf[0] << 8)  | ((uint16_t)len_buf[1]);
            read_addr+=2;
            if(!(spiflash_read(dat, read_addr, read_length)))
            {
                PRINTF("FAILED TO READ DATA read_length TIMES\n");
                return 0;
            }
            if(dat_len!=NULL)
                *dat_len=read_length;
            return 1;


        }
    else if(part==SFP_PRTN2)
    {
        PRINTF("Reading FOTA\n");
        pointer_addr=PART2_R;
        part_start_addr=SFP_PRTN2_STRT_ADDR;
        limit=SFP_PRTN2_SIZE;
        size_partition=SFP_PRTN2_SIZE;
        write_addr_ptr=PART2_W;
    }
    else if(part==SFP_PRTN3)
    {
        if(!(sfp_read_log(dat, dat_len)))
            return 0;
        return 1;
    }
    //check whether configuration part is empty or not
    spiflash_read((uint8_t *)addr_buf, write_addr_ptr, 3);
    write_addr=((uint32_t)addr_buf[0] << 16) | ((uint32_t)addr_buf[1] << 8)  | ((uint32_t)addr_buf[2]);
    if(write_addr==0xffffff)
    {
        PRINTF("NO CONFIGURATION DATA\n");
        return 0;
    }

    if(!(spiflash_read((uint8_t *)addr_buf,pointer_addr ,3)))
    {
        PRINTF("READING FROM THE CORRESPONDING READ ADDRESS FAILED\n");
        return 0;
    }
    read_addr=((uint32_t)addr_buf[0] << 16) | ((uint32_t)addr_buf[1] << 8)  | ((uint32_t)addr_buf[2]);
    if(read_addr==0xFFFFFF)
        read_addr=part_start_addr;//corresponding start address
    PRINTF("READ ADDRESS: 0x%06lX\n",read_addr);


    //start read_byte by byte, until '}' found
    if(!(spiflash_read(dat, read_addr, sizeof(uint8_t))))
    {
        PRINTF("FAILED TO READ {\n");
        return 0;
    }
    read_addr++;
    if(dat[0]!='{')
    {
        PRINTF("STARTING IS NOT {\n");
        //is it error/not filled yet(read_addr>write_addr)
        if(write_addr<=read_addr)
        {
            PRINTF("DATA IS NOT FILLED YET\n");
            *dat_len=0;
            return 1;
        }
        PRINTF("ERROR HAPPENED WHILE WRITING\n");
        return 0;
    }
    //read 2byte length
    if(!(spiflash_read(len_buf, read_addr, 2)))
    {
        PRINTF("FAILED TO READ LENGTH TO READ AFTER {\n");
        return 0;
    }
    read_length=((uint16_t)len_buf[0] << 8)  | ((uint16_t)len_buf[1]);
    read_addr+=2;
    if(!(spiflash_read(dat, read_addr, read_length)))
    {
        PRINTF("FAILED TO READ DATA read_length TIMES\n");
        return 0;
    }
    read_addr+=read_length;
    PRINTF("NEW READ ADDRESS: 0x%06lX\n",read_addr);
    if (read_addr>=(part_start_addr +size_partition))
            read_addr=part_start_addr;
    addr_buf[0] = (uint8_t)(read_addr >> 16);
    addr_buf[1] = (uint8_t)(read_addr >> 8);
    addr_buf[2] = (uint8_t)read_addr;
    if(!(spiflash_write((uint8_t *)addr_buf,pointer_addr , 3)))
    {
        PRINTF("NEW ADDRESS WRITING FAILED\n");
        return 0;
    }

    if(dat_len!=NULL)
        *dat_len=read_length;
    PRINTF("read length : %lu\n",read_length);
    for(int i=0;i<read_length;i++)
    {
        PRINTF("%u  ",dat[i]);
    }
    PRINTF("\n");
    return 1;
}

uint16_t l_count,r_count;
uint8_t sfp_write_log(uint8_t *log, uint16_t len)
{
    l_count++;
    PRINTF("LOG Count: %d\n",l_count);
    PRINTF("LOG read count: %d\n",r_count);
    uint8_t temp_sector_buffer[SFP_SECTOR_SIZE],log_start_index_buf[3];
    uint8_t temp_addr_buf[3],read_ptr_buf[3];
    uint8_t sector_index, overflow, log_start_index=LOG_START_INDEX, version;
    uint16_t next_sector_index;
    uint16_t sector_remain;
    uint32_t write_adr, next_ptr,read_addr;
    sfp_active_ptr(&write_adr,&next_ptr);
    sector_index = (write_adr/SFP_SECTOR_SIZE);
    next_sector_index = sector_index + 1;
    PRINTF("1.next_sector_index:%X\n",next_sector_index);
    if(next_sector_index == (LOG_END_INDEX+1)) {
    	next_sector_index = LOG_START_INDEX;
    	PRINTF("2.next_sector_index:%X\n",next_sector_index);
    }
    sector_remain = SFP_SECTOR_SIZE - (write_adr % SFP_SECTOR_SIZE);
    spiflash_read(read_ptr_buf, PTR_R, 3);
    read_addr = ((uint32_t)read_ptr_buf[0] << 16) | ((uint32_t)read_ptr_buf[1] << 8) | read_ptr_buf[2];
    if(read_addr == 0xffffff) {
    	read_addr=LOG_START;
    }
    if(len>sector_remain)
    {
    	PRINTF("1.WRITE ADDR:%06lX\n",write_adr);
    	PRINTF("3.next_sector_index:%X\n",next_sector_index);
        //moving to next sector
        write_adr=(next_sector_index * SFP_SECTOR_SIZE );
        PRINTF("2.WRITE ADDR:%06lX\n",write_adr);
        //if rptr and wptr in same sector means, move rptr to next sector
        if((read_addr/SFP_SECTOR_SIZE) == next_sector_index)
        {
            read_addr=(next_sector_index+1)*SFP_SECTOR_SIZE;
            if(read_addr>=(LOG_END+1))
            {
                read_addr=LOG_START;
            }
            read_ptr_buf[0] = (uint8_t)(read_addr >> 16);
            read_ptr_buf[1] = (uint8_t)(read_addr >> 8);
            read_ptr_buf[2] = (uint8_t)(read_addr);
            spiflash_write(read_ptr_buf, PTR_R, 3);
            //moving to next sector and is going to erase, so copy the contents to temp from rptr until the sector end
            //clear temp(need to keep temp_rptr)
        }
    }

    if(write_adr % SFP_SECTOR_SIZE==0)//write_adr%SFP_SECTOR_SIZE==0 && start byte
    {
        spiflash_sector_erase(write_adr/SFP_SECTOR_SIZE);
    }
    PRINTF("3.WRITE ADDR:%06lX\n",write_adr);
    spiflash_write_nocheck(log, write_adr, len);
    write_adr+=len;
    if (write_adr >= (LOG_START + LOG_SECTORS * SFP_SECTOR_SIZE))//overwrite 1sr sector
    {
        write_adr = LOG_START; // wrap around
        //if rptr is in log 1st index=>move rptr to next sector
        if((read_addr/SFP_SECTOR_SIZE)==LOG_START_INDEX)
        {
            read_addr = (LOG_START_INDEX+1)*SFP_SECTOR_SIZE;
            read_ptr_buf[0] = (uint8_t)(read_addr >> 16);
            read_ptr_buf[1] = (uint8_t)(read_addr >> 8);
            read_ptr_buf[2] = (uint8_t)(read_addr);
            spiflash_write(read_ptr_buf, PTR_R, 3);
            //moving to next sector and is going to erase, so copy the contents to temp from rptr until the sector end
            //clear temp(need to keep temp_rptr)
        }

    }
    temp_addr_buf[0]=(uint8_t)(write_adr >> 16);
    temp_addr_buf[1]=(uint8_t)(write_adr >> 8);
    temp_addr_buf[2]=(uint8_t)(write_adr);
    spiflash_write(temp_addr_buf, next_ptr, 3);
    //write next write address
    //update v value
    if (next_ptr == PTR_W1)
        spiflash_read(&version, PTR_W2+3, 1);
    else
        spiflash_read(&version, PTR_W1+3, 1);

    version=(version+1)%256;
    spiflash_write(&version, next_ptr + 3, 1);
}


uint8_t sfp_read_log(uint8_t *dat, uint16_t *dat_len)
{
    uint8_t addr_buf[3], len_buf[2];
    uint8_t overflow, marker;
    uint16_t read_length;
    uint32_t read_addr, write_addr, next_ptr;
    uint32_t log_area_end = LOG_START + (LOG_SECTORS * SFP_SECTOR_SIZE);
    uint32_t sector_start, next_sector_start;

    // Get write pointer (so we don�t read beyond it)
    sfp_active_ptr(&write_addr, &next_ptr);

    //  Load current read pointer
    spiflash_read(addr_buf, PTR_R, 3);
    read_addr = ((uint32_t)addr_buf[0] << 16) | ((uint32_t)addr_buf[1] << 8) | addr_buf[2];
    if (read_addr == 0xFFFFFF)
    {
        // first time
        read_addr = LOG_START;
    }
//    PRINTF("READ ADDR FROM PTR_R: 0x%06lX\n",read_addr);
    //  No new logs case
    if (read_addr == write_addr)
    {
//        PRINTF("No new logs to read\n");
        *dat_len=0;
        return 0;
    }


    //  Try reading marker '{'
    if (!spiflash_read(&marker, read_addr, 1))
    {
        PRINTF("Failed to read log start marker\n");
        return 0;
    }


    //  If not '{', move to next sector (maybe sector ended)
    if (marker != '{')
    {
        PRINTF("next Write Address: 0x%06lX\n",write_addr);
        PRINTF("MOVING TO NEXT SECTOR\n");
        sector_start = (read_addr/SFP_SECTOR_SIZE)*SFP_SECTOR_SIZE;
        next_sector_start = sector_start + SFP_SECTOR_SIZE;
        if (next_sector_start >= log_area_end)
            next_sector_start = LOG_START;
        read_addr = next_sector_start;
        //if read_addr==write_addr=>no log
        if (read_addr == write_addr)
        {
//            PRINTF("No new logs to read\n");
            *dat_len=0;
            return 0;
        }
        PRINTF("NEXT_SECTOR ADDRESS: 0x%06lX\n",next_sector_start);
        // Read again marker
        spiflash_read(&marker, read_addr, 1);
        if (marker != '{')
        {
            PRINTF("Next sector also invalid, no valid log found\n");
            return 0;
        }
    }

    //  Now read 2-byte length
    read_addr += 1;
    spiflash_read(len_buf, read_addr, 2);
    read_length = ((uint16_t)len_buf[0] << 8) | len_buf[1];
    read_addr += 2;

    if (read_length == 0xFFFF || read_length == 0 || read_length > SFP_SECTOR_SIZE)
    {
        PRINTF("Invalid log length %u at 0x%06lX\n", read_length, read_addr);
        return 0;
    }

    spiflash_read(dat, read_addr, read_length);
    read_addr += read_length;

    // Wrap to start if needed
    if (read_addr >= log_area_end)
        read_addr = LOG_START;

    //  Update PTR_R (next read position)
    addr_buf[0] = (uint8_t)(read_addr >> 16);
    addr_buf[1] = (uint8_t)(read_addr >> 8);
    addr_buf[2] = (uint8_t)(read_addr);
    spiflash_write(addr_buf, PTR_R, 3);
    //print next read_address
    //  Return results
    if (dat_len)
        *dat_len = read_length;

    PRINTF("Read log (len=%u) from 0x%06lX, next PTR_R=0x%06lX\n",
           read_length, (read_addr - read_length - 3), read_addr);
    r_count++;
    return 1;
}



/****************************************************************************************************************
  * @brief finding the active pointer(PTR_W1/PTR_W2), which contain the next address in temp log sector to which we need to write the log
  * @param  current: pointer to hold the temp log sector address
  * @param  next:  pointer to hold the adddress which is going to have the next valid temp log address(PTR_W1/PTR_W2)
  * @retval None
  ***************************************************************************************************************/
void sfp_active_ptr(uint32_t *current, uint32_t *next)
{
    uint8_t buf1[3], buf2[3];
    uint8_t v1,v2;
    uint32_t  ptr1, ptr2;
    spiflash_read(buf1, PTR_W1, sizeof(buf1));
    spiflash_read(buf2, PTR_W2, sizeof(buf2));
    ptr1 = ((uint32_t)buf1[0] << 16) | ((uint32_t)buf1[1] << 8) | buf1[2];
    ptr2 = ((uint32_t)buf2[0] << 16) | ((uint32_t)buf2[1] << 8) | buf2[2];
    spiflash_read(&v1, (PTR_W1+3), sizeof(uint8_t));
    spiflash_read(&v2, (PTR_W2+3), sizeof(uint8_t));

    if(v1==255 && v2==255)
    {
        (*current)=LOG_START;
        (*next)=PTR_W1;
        return;
    }
    else if(v1==0 && v2==255)
    {
        (*current)=ptr1;
        (*next)=PTR_W2;
        return;
    }
    else if(v1>v2)
    {
        (*current)=ptr1;
        (*next)=PTR_W2;
        return;
    }
    else //v2>v1
    {
        (*current)=ptr2;
        (*next)=PTR_W1;
        return;
    }
}
/******************************************************************************
 * @brief       Device mode set function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t device_config_mode_set(uint8_t data) {

	if(spiflash_page_write(&data,(CONFG_P1_START+3),1)) {
		spiflash_page_write(&data,(CONFG_P2_START+3),1);
		return 1;
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       Device mode get function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t device_config_mode_get(void) {
	uint8_t data = 0;
	spiflash_read(&data, (CONFG_P1_START+3), 1);
	return data;
}

