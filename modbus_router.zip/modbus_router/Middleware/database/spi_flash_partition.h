/**
  **************************
  * @file    spi_flash_partition.h
  * @author  Abhirami , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Oct 6
  * @brief   This file contains all the functions prototypes for the external spi flash handling.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SPI_FLASH_PARTITION_H_
#define __SPI_FLASH_PARTITION_H_
/* Includes ------------------------------------------------------------------*/
#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include "spi_flash.h"
/* Private macro -------------------------------------------------------------*/
#define SFP_PAGE_SIZE      256
#define SFP_SECTOR_SIZE    4096
#define SFP_FLASH_SIZE     1048576
#define SFP_FLASH_START    0x000000


#define SFP_PRTN_CNT           3

#define SFP_PRTN1              0x00
#define SFP_PRTN1_TYP          0x00
#define SFP_PRTN1_STRT_ADDR    SFP_FLASH_START
#define SFP_PRTN1_SIZE         163840
#define SFP_PRTN1_END_ADDR     ((SFP_PRTN1_STRT_ADDR+SFP_PRTN1_SIZE)-1)

#define CONFG_P1_START         SFP_PRTN1_STRT_ADDR
#define CONFG_P1_SIZE          81920
#define CONFG_P1_END           (CONFG_P1_START+CONFG_P1_SIZE-1)

#define CONFG_P2_START         (CONFG_P1_END+1)
#define CONFG_P2_SIZE          81920
#define CONFG_P2_END           (CONFG_P2_START+CONFG_P2_SIZE+1)

#define SFP_PRTN2              0x01
#define SFP_PRTN2_TYP          0x01
#define SFP_PRTN2_STRT_ADDR    ((((SFP_PRTN1_END_ADDR)/(SFP_SECTOR_SIZE))+1)*SFP_SECTOR_SIZE)
#define SFP_PRTN2_SIZE         524288
#define SFP_PRTN2_END_ADDR     ((SFP_PRTN2_STRT_ADDR+SFP_PRTN2_SIZE)-1)

#define PART1_W                ((((SFP_PRTN2_END_ADDR)/(SFP_SECTOR_SIZE))+1)*SFP_SECTOR_SIZE)
#define PART1_R                (PART1_W+3)

#define PART2_W                ((((PART1_R+3)/(SFP_SECTOR_SIZE))+1)*SFP_SECTOR_SIZE)
#define PART2_R                (PART2_W+3)

//log
#define PTR_W1                 ((((PART2_R+3)/(SFP_SECTOR_SIZE))+1)*SFP_SECTOR_SIZE)
#define PTR_W2                 ((((PTR_W1+3)/(SFP_SECTOR_SIZE))+1)*SFP_SECTOR_SIZE)
#define PTR_R                  ((((PTR_W2+3)/(SFP_SECTOR_SIZE))+1)*SFP_SECTOR_SIZE)

#define TEMP_LOG_START         ((((PTR_R+3)/(SFP_SECTOR_SIZE))+1)*SFP_SECTOR_SIZE)
#define TEMP_LOG_END           ((TEMP_LOG_START)+SFP_SECTOR_SIZE-1)

#define SFP_PRTN3              0x02
#define SFP_PRTN3_TYP          0x01
#define SFP_PRTN3_STRT_ADDR    ((((TEMP_LOG_END)/(SFP_SECTOR_SIZE))+1)*SFP_SECTOR_SIZE)
#define SFP_PRTN3_SIZE         335872

#define LOG_START              SFP_PRTN3_STRT_ADDR
#define LOG_SECTORS            82 //no.of log sectors
#define LOG_END                (((LOG_START)+((LOG_SECTORS)*SFP_SECTOR_SIZE))-1)
#define ONE_LOG_SIZE           328
#define FOTA_CHUNK_SIZE        250

/* Private function prototypes -----------------------------------------------*/
uint8_t sfp_clr_all_part(void);
uint8_t sfp_clr_part(uint8_t Partition);
uint8_t sfp_write_part(uint8_t part, uint8_t part_typ, uint8_t* dat, uint16_t dat_len);
//uint8_t sfp_read_part(uint8_t part, uint8_t part_typ, uint8_t* dat, uint16_t* dat_len);
uint8_t sfp_read_part(uint8_t part, uint8_t part_typ, uint8_t* dat, uint16_t* dat_len, uint8_t part_no);
//helping functions
uint8_t sfp_chk_sctr_strt(uint16_t mem_addr);
uint8_t sfp_find_sctr(uint32_t mem_addr);
uint8_t sfp_find_part_sctr_cnt(uint32_t mem_size);
uint8_t sfp_write_log(uint8_t *log, uint16_t len);
uint8_t sfp_read_log(uint8_t *dat, uint16_t* dat_len);
void sfp_active_ptr(uint32_t *current, uint32_t *next);

uint8_t device_config_mode_set(uint8_t data);
uint8_t device_config_mode_get(void);

#endif /*__SPI_FLASH_PARTITION_H_*/

/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
