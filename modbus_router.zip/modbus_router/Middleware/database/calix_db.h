/**
  **************************
  * @file    calix_db.h
  * @author  Abhirami , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Oct 6
  * @brief   This file contains all the functions prototypes for the external spi flash handling.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CALIX_DB_H_
#define __CALIX_DB_H_
/* Includes ------------------------------------------------------------------*/
#include "spi_flash_partition.h"

/* Private macro -------------------------------------------------------------*/
#define CDB_CONF_DB    SFP_PRTN1
#define CDB_FOTA_DB    SFP_PRTN2
#define CDB_DATA_DB    SFP_PRTN3

 
/* Private typedef -----------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
uint8_t cdb_clear_db(void);

uint8_t cdb_clear_conf_db(void);
uint8_t cdb_write_conf(uint8_t *conf_dat, uint16_t len); //Add start'{' and end'}' characters during write.
//uint8_t cdb_read_conf(uint8_t *conf_dat, uint16_t* len); //Read start'{' and end'}'characters to identify the Configuration data.
uint8_t cdb_read_conf(uint8_t *conf_dat, uint16_t* len,uint8_t part_no);

uint8_t cdb_clear_fota_db(void);
uint8_t cdb_write_fota(uint8_t *fota_dat);  //Need to finalize
uint8_t cdb_read_fota(uint8_t *fota_dat);   //Need to finalize

uint8_t cdb_clear_data_db(void);
uint8_t cdb_write_data(uint8_t *data_dat, uint16_t len); //Add start'{' and end'}' characters during write. also manage write pointer
uint8_t cdb_read_data(uint8_t *data_dat, uint16_t* len);  //Read start'{' and end'}'characters to identify the data. also manage read pointer


#endif /*__CALIX_DB_H_*/

/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
