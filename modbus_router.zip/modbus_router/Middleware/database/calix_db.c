/**
  **************************
  * @file    calix_db.c
  * @author  Abhirami , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Oct 6
  * @brief   This file provides functions to manage the database
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2025 Calixto Systems Pvt Ltd</center></h2>
  **************************
*/


/* Includes ------------------------------------------------------------------*/
#include "calix_db.h"
#include "spi_flash_partition.h"
#include <stdlib.h>
/* Private functions ---------------------------------------------------------*/

/****************************************************************************************************************
  * @brief  clearing  database
  * @param  None
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_clear_db(void)
{
  if(!(sfp_clr_all_part()))
    return 0;//error
  return 1;
}


/****************************************************************************************************************
  * @brief  clearing  configuration data base
  * @param  None
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_clear_conf_db(void)
{
  if(!(sfp_clr_part(CDB_CONF_DB)))
    return 0;
  return 1;
}

/****************************************************************************************************************
  * @brief  write configuration into the memory
  * @param  conf_dat: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_write_conf(uint8_t *conf_dat, uint16_t len) 
{
		uint8_t* new_log = NULL;
		new_log = (uint8_t*)malloc(len + 3);
		if (new_log == NULL) {
		    PRINTF("Malloc failed!\n");
		    return 0;   // or handle error
		}

		new_log[0] = '{';
		new_log[1] = (len >> 8) & 0xFF;
		new_log[2] = len & 0xFF;

		memcpy(&new_log[3], conf_dat, len);

		int ret = sfp_write_part(CDB_CONF_DB, 0x00, new_log, len + 3);

		free(new_log);  // always free malloc memory!

		if (ret == 0)  // assuming 0 = fail in your API
		    return 0;
		return 1;

}


/****************************************************************************************************************
  * @brief  read configuration from memory
  * @param  conf_dat: buffer to hold  data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_read_conf(uint8_t *conf_dat, uint16_t* len,uint8_t part_no)
{
  //read from '{' until '}'
  if(!(sfp_read_part(CDB_CONF_DB, 0x00, conf_dat, len,part_no)))
  {
    PRINTF("FROM DB: READ CONFIG FAIL\n");
    return 0;
  }
  PRINTF("FROM DB: READ CONFIG SUCCESS\n");
  return 1;
}


//FOTA
/****************************************************************************************************************
  * @brief  clearing  fota database
  * @param  None
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_clear_fota_db(void)
{
  if(!(sfp_clr_part(CDB_FOTA_DB)))
    return 0;
  return 1;
}


/****************************************************************************************************************
  * @brief  write FOTA into the memory
  * @param  conf_dat: buffer holding the FOTA data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_write_fota(uint8_t *fota_dat)
{
  if(!(sfp_write_part(CDB_FOTA_DB, 0x01, fota_dat, FOTA_CHUNK_SIZE)))
    return 0;
  return 1;
}


/****************************************************************************************************************
  * @brief  read FOTA data from memory
  * @param  conf_dat: buffer to hold FOTA data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_read_fota(uint8_t *fota_dat)
{
  if(!(sfp_read_part(CDB_FOTA_DB, 0x01, fota_dat, NULL, 0)))
    return 0;
  return 1;
}


//LOG
/****************************************************************************************************************
  * @brief  clearing data(log) database
  * @param  None
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_clear_data_db(void)
{
//  if(!(sfp_clr_part(CDB_DATA_DB)))
//    return 0;
  return 1;
}


/****************************************************************************************************************
  * @brief  write data(log) into  memory
  * @param  conf_dat: buffer holding the data(log data)
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_write_data(uint8_t *data_dat, uint16_t len)
{
//  uint8_t new_log[len + 3];
//  new_log[0] = '{';
//  new_log[1]=(len>>8) & 0xff;
//  new_log[2]=len & 0xff;
//  memcpy(&new_log[3], data_dat, len);
//  if(!(sfp_write_part(CDB_DATA_DB, 0x01, new_log, len+3)))
//  {
//    PRINTF("WRITING SINGLE LOG FAILED FROM DB\n");
//    return 0;
//  }
//  PRINTF("WRITING SINGLE LOG SUCCESS FROM DB\n");
  return 1;
}


/****************************************************************************************************************
  * @brief  read log datas from memory
  * @param  conf_dat: buffer to hold log data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_read_data(uint8_t *data_dat, uint16_t* len)
{
//  if(!(sfp_read_part(CDB_DATA_DB, 0x01, data_dat, len, 0)))
//  {
////    PRINTF(" READING SINGLE LOG FAILED (FROM DB)\n");
//    return 0;
//  }
//  PRINTF("READING SINGLE LOG SUCCESS(FROM DB)\n");
  return 1;
}

/***********End of function_demo() function****************/

/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
