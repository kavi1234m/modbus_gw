/**
  **************************
  * @file    checksum.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 24
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CHECKSUM_H_
#define __CHECKSUM_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/
uint8_t calculate_checksum_using_xor(uint8_t *buffer, uint16_t buffer_len);
uint8_t calculate_checksum_using_addition(uint8_t *buffer, uint16_t buffer_len);
uint16_t crc16(uint8_t *buffer, uint16_t buffer_length);
/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __CHECKSUM_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
