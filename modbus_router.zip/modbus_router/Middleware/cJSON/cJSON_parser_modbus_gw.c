/**
  **************************
  * @file    cJSON_parser_modbus_gw.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 11
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "cJSON_parser_modbus_gw.h"
#include "cJSON.h"
#include <string.h>
#include <math.h>

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************
 * @brief       parse json single key value function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_json_key_value(const char *json_packet, const char *json_key, uint8_t *value) {
    cJSON *json = cJSON_Parse(json_packet);
    if (!json) return 0;

    cJSON *item = cJSON_GetObjectItemCaseSensitive(json, json_key);
    if (!cJSON_IsString(item) || item->valuestring == NULL) {
        cJSON_Delete(json);
        return 0;
    }

    *value = (uint8_t)atoi(item->valuestring);  // Convert "01" to 1
    cJSON_Delete(json);
    return 1;
}
/******************************************************************************
 * @brief       Parse json config function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_json_for_fresh_config(const char *json, fresh_device_config_t *config) {
    cJSON *root = cJSON_Parse(json);
    if (!root) return 0;

    cJSON *mac = cJSON_GetObjectItemCaseSensitive(root, "MAC");
    cJSON *dvt = cJSON_GetObjectItemCaseSensitive(root, "MID");

    if (!cJSON_IsString(mac) || !cJSON_IsString(dvt)) {
        cJSON_Delete(root);
        return 0;
    }

    const char *mac_str = mac->valuestring;
    size_t len = strlen(mac_str);
    if (len != 12) {  // Must be 12 hex chars for 6 bytes
        cJSON_Delete(root);
        return 0;
    }

    // Convert MAC string (e.g., "020304050607") to 6 bytes
    for (int i = 0; i < 6; i++) {
        char byte_str[3] = { mac_str[i * 2], mac_str[i * 2 + 1], '\0' };
        config->mac_address[i] = (uint8_t)strtoul(byte_str, NULL, 16);
    }

    // Copy device type string
    strncpy(config->device_type_id, dvt->valuestring, sizeof(config->device_type_id) - 1);
    config->device_type_id[sizeof(config->device_type_id) - 1] = '\0';

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Function to create a json packet from the fresh device config structure fields
 * @param  config - config is a fresh device config structure variable
 * @param  seq_no - Sequence number of the json packet
 * @param  output_buffer - used for the storing of json packet
 * @retval Success - 1 Failed - 0
 **********************************************************************************************/
uint8_t prepare_read_back_response_for_fresh_device(fresh_device_config_t fresh_dv_cfg, uint8_t *output_buffer) {

	cJSON* root = cJSON_CreateObject();
    if(root == NULL){
    	return 0;
    }

    // Convert MAC address to hex string
    char mac_str[13];  // 12 hex chars + null
    for (int i = 0; i < 6; i++) {
        sprintf(&mac_str[i * 2], "%02X", fresh_dv_cfg.mac_address[i]);
    }

    // Build JSON
    cJSON_AddStringToObject(root, "MTP", "02");
    cJSON_AddStringToObject(root, "MAC", mac_str);
    cJSON_AddStringToObject(root, "MID", fresh_dv_cfg.device_type_id);

    uint8_t *ptr = cJSON_PrintUnformatted(root);
    strcpy((uint8_t*)output_buffer, (uint8_t*)ptr);
    free(ptr);
    cJSON_Delete(root);
    return 1;
}
/******************************************************************************
 * @brief       function to check valid JSON
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t is_valid_json(const char *json_buffer,uint16_t buffer_length) {

	const char *endptr = NULL;
	cJSON *root = cJSON_ParseWithLengthOpts(json_buffer, buffer_length, &endptr, 0);
	if (root == NULL || (endptr - json_buffer) != buffer_length) {
	    // Either parsing failed OR not all data was consumed
//	    printf("Invalid JSON or extra data\n");
	    return 0;
	} else {
		return 1;
	    // Valid and complete JSON
	}
}
/***********************************************************************************************
 * @brief  Function to create a packet from an input string
 * @param  input_buffer - input_buffer holds the input json packet
 * @param  status -  holds the status of the input packet
 * @param  output_buffer - holds the output string
 * @retval Success 1 failed 0
 **********************************************************************************************/
uint8_t prepare_response_with_status(uint8_t *input_buffer,uint8_t status,uint8_t *output_buffer) {

	cJSON *root = cJSON_CreateObject();    // root points to new packet
	if (root == NULL) {
		return 0;
	}

	cJSON *parse = cJSON_Parse((const char*)input_buffer);  //  parse points to input packet string
	if (!parse) {
		cJSON_Delete(root);
	    return 0;
	}

	cJSON *response = cJSON_CreateObject();
	if (response == NULL) {
		cJSON_Delete(root);
	    cJSON_Delete(parse);
	    return 0;
	}

    cJSON *item = NULL;
	cJSON_ArrayForEach(item, parse) {
		if (cJSON_IsString(item)) {
			cJSON_AddStringToObject(response, item->string, item->valuestring);
		}
	}

	cJSON_AddItemToObject(root, "RESPONSE", response);
    if (status == 1) {
    	cJSON_AddStringToObject(root, "STATUS", "OK");
    } else {
    	cJSON_AddStringToObject(root, "STATUS", "ERR");
    }

    uint8_t* ptr = cJSON_PrintUnformatted(root);
    strcpy((uint8_t*)output_buffer, (uint8_t*)ptr);
    free(ptr);
    cJSON_Delete(root);
    cJSON_Delete(parse);
    return 1;
}

void prepare_gsm_rsp_with_status(const char *gsm_rsp, uint8_t status_ok, uint8_t *output_buffer)
{
    if (output_buffer == NULL) return;

    const char *status = status_ok ? "OK" : "FAIL";

    snprintf((char *)output_buffer, 256,
             "{\"RESPONSE\":{\"AT_RSP\":\"%s\"},\"STATUS\":\"%s\"}",
             gsm_rsp ? gsm_rsp : "",
             status);
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
