/**
  **************************
  * @file    cJSON_parser_modbus_gw.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 11
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CJSON_PARSER_MODBUS_GW_H_
#define __CJSON_PARSER_MODBUS_GW_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "modbus_gw_cfg.h"
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/

 uint8_t parse_json_key_value(const char *json_packet, const char *json_key, uint8_t *value);
 uint8_t parse_json_for_fresh_config(const char *json, fresh_device_config_t *config);
 uint8_t is_valid_json(const char *json_buffer,uint16_t buffer_length);
 uint8_t prepare_read_back_response_for_fresh_device(fresh_device_config_t fresh_dv_cfg, uint8_t *output_buffer);
 uint8_t prepare_response_with_status(uint8_t *input_buffer,uint8_t status,uint8_t *output_buffer);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __CJSON_PARSER_MODBUS_GW_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
