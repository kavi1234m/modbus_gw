/**
  **************************
  * @file    hal_ethernet.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 3
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "hal_ethernet.h"

#include "at32_emac.h"
#include "netconf.h"
#include "lwip/timeouts.h"
#include "lwip/priv/tcp_priv.h"
/* Private typedef -----------------------------------------------------------*/
#define SUCCESS 1
#define FAILED  0

//typedef void (*ethernet_callback_fun)();
//ethernet_callback_fun ethernet_cbk;

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

///****************************************************************************************
//  * @brief  Ethernet callback register function
//  * @param  callback function to register
//  * @retval None
//  ***************************************************************************************/
//void ethernet_callback_register(void *callback) {
//
//	ethernet_cbk = callback;
//}
/****************************************************************************************
  * @brief  Ethernet initialization in RMII mode function
  * @param  ip_details_t - ip details (configure LWIP_DHCP to 1 for enable dynamic ip in lwipopts.h)
  * @retval 1-init success 0-failed
  ***************************************************************************************/
uint8_t hal_rmii_ethernet_init(ip_details_t * ip_details_input) {

	error_status status;
	err_t error;
	status = emac_system_init();
    if (ip_details_input->ip_mode == 1) {
  	    error = set_static_ip(ip_details_input->local_ip,ip_details_input->local_gw,ip_details_input->local_mask);
  	    if (error == FAILED) {
  	    	return FAILED;
  	    }
    } else {
 	    set_ip_using_dhcp();
    }
	error = tcpip_stack_init();
	if (error == FAILED) {
        return FAILED;
	}
//	Printf("STATUS:%d\n",status);
//	ethernet_cbk(ETHERNET_START);
	return SUCCESS;
}
/****************************************************************************************
  * @brief  Ethernet deinitialization in RMII mode function
  * @param  None
  * @retval None
  ***************************************************************************************/
void hal_ethernet_deinit(void) {

	emac_reset();
	crm_periph_clock_enable(CRM_EMAC_PERIPH_CLOCK, FALSE);
//	ethernet_cbk(ETHERNET_STOP);
}
/****************************************************************************************
  * @brief  Handle ethernet connection function
  * @param  None
  * @retval None
  ***************************************************************************************/
void handle_ethernet_connection(void) {
    check_ethernet_link();
//    uint16_t reg_value = link_update();
//	if (reg_value > 0) {
//		ethernet_cbk(ETHERNET_CONNECTED);
//	} else {
//		ethernet_cbk(ETHERNET_DISCONNECTED);
//	}
}
/****************************************************************************************
  * @brief  Read a received packet from the Ethernet buffers and send it to the lwIP for handling
  * @param  None
  * @retval None
  ***************************************************************************************/
void read_ethernet_buffer(void) {

	lwip_pkt_handle();
}
/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
