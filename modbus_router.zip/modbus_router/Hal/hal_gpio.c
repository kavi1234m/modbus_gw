/**
  **************************
  * @file    hal_gpio.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 3
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "hal_gpio.h"

#include "at32f435_437_gpio.h"
/* Private typedef -----------------------------------------------------------*/
typedef void (*ext_int_fn_cb)();
ext_int_fn_cb   ext_int_callback_tmp;
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/****************************************************************************************
  * @brief  gpio port select function.
  * @param  param1: gpio port type (A | B | C | D | E)
  * @retval selected port
  ***************************************************************************************/
gpio_type *gpio_port_select(port_type gpio_port) {

	gpio_type* selected_port;
	switch(gpio_port) {
	    case GPIO_PORTA :
	    	 selected_port = GPIOA;
	    	 break;
	    case GPIO_PORTB :
	    	 selected_port = GPIOB;
	    	 break;
	    case GPIO_PORTC :
	    	 selected_port = GPIOC;
	    	 break;
	    case GPIO_PORTD :
	    	 selected_port = GPIOD;
	    	 break;
	    case GPIO_PORTE :
	    	 selected_port = GPIOE;
	    	 break;
	}
	return selected_port;
}

/****************************************************************************************
  * @brief  gpio pin number select function.
  * @param  param1: gpio pin num (0 to 15)
  * @retval selected pin number
  ***************************************************************************************/
uint16_t gpio_pin_num_select(pin_num gpio_pin_num) {

	uint16_t selected_pin_num;
	switch(gpio_pin_num) {
	    case PIN_NUM_0 :
	    	 selected_pin_num = GPIO_PINS_0;
	    	 break;
	    case PIN_NUM_1 :
	    	 selected_pin_num = GPIO_PINS_1;
	    	 break;
	    case PIN_NUM_2 :
	    	 selected_pin_num = GPIO_PINS_2;
	    	 break;
	    case PIN_NUM_3 :
	    	 selected_pin_num = GPIO_PINS_3;
	    	 break;
	    case PIN_NUM_4 :
	    	 selected_pin_num = GPIO_PINS_4;
	    	 break;
	    case PIN_NUM_5 :
	    	 selected_pin_num = GPIO_PINS_5;
	    	 break;
	    case PIN_NUM_6 :
	    	 selected_pin_num = GPIO_PINS_6;
	    	 break;
	    case PIN_NUM_7 :
	    	 selected_pin_num = GPIO_PINS_7;
	    	 break;
	    case PIN_NUM_8 :
	    	 selected_pin_num = GPIO_PINS_8;
	    	 break;
	    case PIN_NUM_9 :
	    	 selected_pin_num = GPIO_PINS_9;
	    	 break;
	    case PIN_NUM_10 :
	    	 selected_pin_num = GPIO_PINS_10;
	    	 break;
	    case PIN_NUM_11 :
	    	 selected_pin_num = GPIO_PINS_11;
	    	 break;
	    case PIN_NUM_12 :
	    	 selected_pin_num = GPIO_PINS_12;
	    	 break;
	    case PIN_NUM_13 :
	    	 selected_pin_num = GPIO_PINS_13;
	    	 break;
	    case PIN_NUM_14 :
	    	 selected_pin_num = GPIO_PINS_14;
	    	 break;
	    case PIN_NUM_15 :
	    	 selected_pin_num = GPIO_PINS_15;
	    	 break;
	}
	return selected_pin_num;
}
/****************************************************************************************
  * @brief  gpio initialization function.
  * @param  param1: gpio port type (A | B | C | D | E)
  * @param  param2: gpio pin number (0 to 15)
  * @param  param3: io_type (input or output)
  * @param  param4: Resistor type (pull up, pull down, pull none)
  * @retval None
  ***************************************************************************************/
void hal_gpio_init(port_type port_type, pin_num pin_num, io_type gpio_io_type, pull_type gpio_resistor_type) {

	gpio_init_type gpio_init_struct;

	gpio_type *gpio_port = gpio_port_select(port_type);
	uint16_t gpio_pin_num = gpio_pin_num_select(pin_num);

	/* set default parameter */
	gpio_default_para_init(&gpio_init_struct);
    /* configure pin */
	gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
	gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;

	if(gpio_io_type) {
		gpio_init_struct.gpio_mode = GPIO_MODE_OUTPUT;
	} else {
		gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
	}

	switch (gpio_resistor_type) {
	    case PULL_NONE :
	    	 gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	    	 break;
	    case PULL_UP :
	    	 gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	 break;
	    case PULL_DOWN :
	    	 gpio_init_struct.gpio_pull = GPIO_PULL_DOWN;
	    	 break;
	}

	gpio_init_struct.gpio_pins = gpio_pin_num;
	gpio_init(gpio_port, &gpio_init_struct);
}
/****************************************************************************************
  * @brief  gpio deinitialization function.
  * @param  param1: gpio port type (A | B | C | D | E)
  * @retval None
  ***************************************************************************************/
void hal_gpio_deinit(port_type port_type) {
	gpio_type *gpio_port = gpio_port_select(port_type);
	gpio_reset(gpio_port);
}
/****************************************************************************************
  * @brief  Read gpio input pin status function.
  * @param  param1: gpio port type (A | B | C | D | E)
  * @param  param2: gpio pin number (0 to 15)
  * @retval gpio_state
  ***************************************************************************************/
uint8_t hal_gpio_input_pin_read(port_type port_type, pin_num pin_num) {

	gpio_type *gpio_port = gpio_port_select(port_type);
	uint16_t gpio_pin_num = gpio_pin_num_select(pin_num);
	uint8_t gpio_state = gpio_input_data_bit_read(gpio_port, gpio_pin_num);
	return gpio_state;
}
/****************************************************************************************
  * @brief  Read gpio output pin status function.
  * @param  param1: gpio port type (A | B | C | D | E)
  * @param  param2: gpio pin number (0 to 15)
  * @retval gpio_state
  ***************************************************************************************/
uint8_t hal_gpio_output_pin_read(port_type port_type, pin_num pin_num) {

	gpio_type *gpio_port = gpio_port_select(port_type);
	uint16_t gpio_pin_num = gpio_pin_num_select(pin_num);
	uint8_t gpio_state = gpio_output_data_bit_read(gpio_port, gpio_pin_num);
	return gpio_state;

}
/****************************************************************************************
  * @brief  write gpio pin function.
  * @param  param1: gpio port type (A | B | C | D | E)
  * @param  param2: gpio pin number (0 to 15)
  * @param  param3: gpio_level (SET or RESET)
  * @retval None
  ***************************************************************************************/
void hal_gpio_write(port_type port_type, pin_num pin_num, gpio_level gpio_state) {

	gpio_type *gpio_port = gpio_port_select(port_type);
	uint16_t gpio_pin_num = gpio_pin_num_select(pin_num);
	gpio_bits_write(gpio_port,gpio_pin_num,gpio_state);
}
/****************************************************************************************
  * @brief  Toggle output state of a pin function.
  * @param  param1: gpio port type (A | B | C | D | E)
  * @param  param2: gpio pin number (0 to 15)
  * @retval None
  ***************************************************************************************/
void hal_gpio_toggle(port_type port_type, pin_num pin_num) {

	gpio_type *gpio_port = gpio_port_select(port_type);
	uint16_t gpio_pin_num = gpio_pin_num_select(pin_num);
	gpio_port->odt ^= gpio_pin_num;

}

/****************************************************************************************************************/
/**
 * @brief callback register function using the gpio callback function
 *
 * @param   (*callback_fun)  function pointer
 *
 * @retval  None
 */
void hal_usr_butn_clbk_reg(void (*callback_fun))
{
    ext_int_callback_tmp = callback_fun;
}
/****************************************************************************************************************/

/****************************************************************************************************************/
/**
  * @brief  exint0 interrupt handler
  * @param  none
  * @retval none
  */
void EXINT0_IRQHandler(void) {

	if(exint_interrupt_flag_get(EXINT_LINE_0) != RESET) {
		ext_int_callback_tmp();
		exint_flag_clear(EXINT_LINE_0);
	}
}
/****************************************************************************************************************/

/**
  * @brief  init exint function.
  * @param  none
  * @retval none
  */
void hal_exint_init(void) {

	gpio_init_type gpio_init_struct;
	exint_init_type exint_init_struct;
	crm_periph_clock_enable(CRM_GPIOC_PERIPH_CLOCK, TRUE);
	crm_periph_clock_enable(CRM_SCFG_PERIPH_CLOCK, TRUE);
	/* configure the EXINT0 */
	gpio_default_para_init(&gpio_init_struct);
	gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
	gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;
	gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
	gpio_init_struct.gpio_pins = GPIO_PINS_0;
	gpio_init_struct.gpio_pull = GPIO_PULL_DOWN;
	gpio_init(GPIOC, &gpio_init_struct);

	scfg_exint_line_config(SCFG_PORT_SOURCE_GPIOC, SCFG_PINS_SOURCE0);

	exint_default_para_init(&exint_init_struct);
	exint_init_struct.line_enable = TRUE;
	exint_init_struct.line_mode = EXINT_LINE_INTERRUPUT;
	exint_init_struct.line_select = EXINT_LINE_0;
	exint_init_struct.line_polarity = EXINT_TRIGGER_BOTH_EDGE;
	exint_init(&exint_init_struct);
	nvic_priority_group_config(NVIC_PRIORITY_GROUP_4);
	nvic_irq_enable(EXINT0_IRQn, 1, 0);
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
