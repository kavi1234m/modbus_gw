/**
  ******************************************************************************
  * @file    hal_uart.h
  * @author  Kaviyarasan, Calixto Firmware Team
  * @version V1.0.0
  * @date    29-08-2024
  * @brief   This file contains all the functions prototypes for the ____.
  ******************************************************************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HAL_UART_H
#define __HAL_UART_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <string.h>
#include <stdio.h>
/* Exported types ------------------------------------------------------------*/

typedef enum {
	USART_1 = 0,
	USART_2 = 1,
	USART_3 = 2,
	UART_4  = 3,
	UART_5  = 4,
	USART_6 = 5,
	UART_7  = 6,
	UART_8  = 7,
}uart_type;

typedef enum {
	FLOW_NONE               = 0x00, /*!< usart without hardware flow */
	FLOW_RTS                = 0x01, /*!< usart hardware flow only rts */
	FLOW_CTS                = 0x02, /*!< usart hardware flow only cts */
	FLOW_RTS_CTS            = 0x03  /*!< usart hardware flow both rts and cts */
}flow_control_type;

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

void uart_init(uart_type uart_x, uint32_t baud_rate, uint8_t parity, uint8_t data_bit, uint8_t stop_bit);
void uart_deinit(uart_type uart_x);
void usart_flow_control_set(uart_type uart_x, flow_control_type flow_state);
void uart_interrupt_enable(uart_type uart_x, uint8_t status);
void uart_idle_interrupt_enable_disable(uart_type uart_x, uint8_t status);
void uart_enable_disable(uart_type uart_x,uint8_t status);
void uart_callback_register(void *cbk);
//int8_t uart_transmit(uart_type uart_x,const uint8_t *data_buf,uint8_t data_len);

void uart_init_without_flow(uart_type uart_x, uint32_t baud_rate, uint8_t parity, uint8_t data_bit, uint8_t stop_bit);
int8_t uart_transmit(uart_type uart_x,const uint8_t *req,uint16_t req_length, uint16_t us);
void uart_receive(uart_type uart_x,uint8_t *rsp, uint16_t rsp_length);
void clear_uart_buffer(uart_type uart_x);
uint8_t uart_receive_check(uint8_t uart_x, uint8_t length);
void uart_transmit_using_dma(uint8_t uart_type, uint8_t *buffer, uint16_t len);
void uart_dma_init(void);

/*  Functions used to ___________________________________________________ *****/


/* Initialization and Configuration functions *********************************/
//void uart_print_init(uint32_t baudrate);


#ifdef __cplusplus
}
#endif

#endif /*__CS_HAL_UART_H */




/************** (C) COPYRIGHT 2024 Calixto Systems Pvt Ltd *****END OF FILE****/
