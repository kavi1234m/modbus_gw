/**
  **************************
  * @file    hal_gpio.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 3
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HAL_GPIO_H_
#define __HAL_GPIO_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
/* Exported types ------------------------------------------------------------*/
typedef enum {
  	GPIO_PORTA = 0,
  	GPIO_PORTB = 1,
  	GPIO_PORTC = 2,
  	GPIO_PORTD = 3,
  	GPIO_PORTE = 4,
}port_type;

typedef enum {
  	PIN_NUM_0  = 0,
  	PIN_NUM_1  = 1,
  	PIN_NUM_2  = 2,
  	PIN_NUM_3  = 3,
  	PIN_NUM_4  = 4,
  	PIN_NUM_5  = 5,
  	PIN_NUM_6  = 6,
  	PIN_NUM_7  = 7,
  	PIN_NUM_8  = 8,
  	PIN_NUM_9  = 9,
  	PIN_NUM_10 = 10,
  	PIN_NUM_11 = 11,
  	PIN_NUM_12 = 12,
  	PIN_NUM_13 = 13,
  	PIN_NUM_14 = 14,
  	PIN_NUM_15 = 15,
}pin_num;

typedef enum {
  	GPIO_INPUT  = 0,
  	GPIO_OUTPUT = 1,
}io_type;

typedef enum {
    PULL_NONE  = 0,
    PULL_UP    = 1,
    PULL_DOWN  = 2,
}pull_type;

typedef enum {
	GPIO_RESET = 0,
	GPIO_SET   = 1,
}gpio_level;

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/
void hal_gpio_init(port_type port_type, pin_num pin_num, io_type gpio_io_type, pull_type gpio_resistor_type);
void hal_gpio_deinit(port_type port_type);
void hal_gpio_write(port_type port_type, pin_num pin_num, gpio_level gpio_state);
void hal_gpio_toggle(port_type port_type, pin_num pin_num);
uint8_t hal_gpio_input_pin_read(port_type port_type, pin_num pin_num);
uint8_t hal_gpio_output_pin_read(port_type port_type, pin_num pin_num);

void hal_usr_butn_clbk_reg(void (*callback_fun));
void hal_exint_init(void);

void exint_polarity_change(uint8_t status);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __HAL_GPIO_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
