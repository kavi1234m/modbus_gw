/**
  **************************
  * @file    hal_rtc.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 9
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HAL_RTC_H_
#define __HAL_RTC_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
/* Exported types ------------------------------------------------------------*/
typedef struct {
    uint8_t year;       /*!< specifies the years of calendar.   */
	uint8_t  month;      /*!< specifies the months of calendar.  */
	uint8_t  date;       /*!< specifies the date of calendar.    */
	uint8_t  hour;       /*!< specifies the hours of calendar.   */
	uint8_t  min;        /*!< specifies the minutes of calendar. */
	uint8_t  sec;        /*!< specifies the second of calendar.  */
	uint8_t  week;       /*!< specifies the weeks of calendar.   */
	uint8_t am_pm_type;
}calendar_info_t;
/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/
void rtc_callback_register(void *callback);
void hal_rtc_calendar_get(calendar_info_t *calendar_info);
void hal_rtc_init(void);
uint8_t hal_rtc_calendar_set(calendar_info_t *calendar_info);
void rtc_time_show(void);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __HAL_RTC_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
