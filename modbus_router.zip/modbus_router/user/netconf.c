/**
  **************************
  * @file    hal_netconf.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    26-03-2025
   * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "lwip/memp.h"
#include "lwip/tcp.h"
#include "lwip/priv/tcp_priv.h"
#include "lwip/udp.h"
#include "netif/etharp.h"
#include "lwip/dhcp.h"
#include "ethernetif.h"
#include "netconf.h"
#include "stdio.h"
#include "at32_emac.h"
#include "lwip/tcpip.h"
#include <string.h>
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define MAC_ADDR_LENGTH                  (6)
#define ADDR_LENGTH                      (4)
#define SYSTEMTICK_PERIOD_MS             10
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
struct netif netif;
TaskHandle_t link_status_handler;
static uint8_t mac_address[MAC_ADDR_LENGTH] = {0, 0, 0x44, 0x45, 0x56, 1};;

ip_addr_t ipaddr;
ip_addr_t netmask;
ip_addr_t gw;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

void mac_id_set(uint8_t *mac) {
	memcpy(mac_address, mac, MAC_ADDR_LENGTH);
}
/******************************************************************************
 * @brief       to check valid ip
 * @param[in]   none
 * @return      none
 ******************************************************************************/
int is_valid_ip(ip_addr_t *ip,ip_addr_t *gw,ip_addr_t *netmask)
{

	if(ip->addr !=0 && gw->addr !=0 && netmask->addr !=0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
/*************************************************************************************
  * @brief  set_static_ip
  * @param  local_ip,local_gw,local_mask
  * @retval 0- success -1 failure
  ************************************************************************************/
int8_t set_static_ip(uint32_t local_ip, uint32_t local_gw, uint32_t subnet_mask)
{
//	  IP4_ADDR(&ipaddr, local_ip[0], local_ip[1], local_ip[2], local_ip[3]);
//	  IP4_ADDR(&gw, local_gw[0], local_gw[1], local_gw[2], local_gw[3]);
//	  IP4_ADDR(&netmask, local_mask[0], local_mask[1], local_mask[2], local_mask[3]);
	  ipaddr.addr = local_ip;
	  gw.addr = local_gw;
	  netmask.addr = subnet_mask;

	  if(is_valid_ip(&ipaddr,&gw,&netmask))
	  {
		  return 1;
	  }
	  else
	  {
		  return 0;
	  }

}
/*************************************************************************************
  * @brief  set dynamic ip using dhcp
  * @param  none
  * @retval 0- success -1 failure
  ************************************************************************************/
int8_t set_ip_using_dhcp(void)
{
	err_t err;
  #if LWIP_DHCP
    err = dhcp_start(&netif);
  #endif
    return err;
}

/**
  * @brief  initializes the lwip stack
  * @param  none
  * @retval none
  */
err_t tcpip_stack_init(void) {

	tcpip_init(NULL,NULL);

    lwip_set_mac_address(mac_address);

    /* - netif_add(struct netif *netif, struct ip_addr *ipaddr,
            struct ip_addr *netmask, struct ip_addr *gw,
            void *state, err_t (* init)(struct netif *netif),
            err_t (* input)(struct pbuf *p, struct netif *netif))

     Adds your network interface to the netif_list. Allocate a struct
     netif and pass a pointer to this structure as the first argument.
     Give pointers to cleared ip_addr structures when using DHCP,
     or fill them with sane numbers otherwise. The state pointer may be NULL.

     The init function pointer must point to a initialization function for
     your ethernet netif interface. The following code illustrates it's use.*/

    if(netif_add(&netif, &ipaddr, &netmask, &gw, NULL, &ethernetif_init,  &tcpip_input) == NULL) {
    	return 0; // netif_input
    }

    /*  Registers the default network interface.*/
    netif_set_default(&netif);

#if LWIP_DHCP
  /*  Creates a new DHCP client for this interface on the first call.
  Note: you must call dhcp_fine_tmr() and dhcp_coarse_tmr() at
  the predefined regular intervals after starting the client.
  You can peek in the netif->dhcp struct for the actual DHCP status.*/
  dhcp_start(&netif);
#endif

    /*  When the netif is fully configured this function must be called.*/
    netif_set_up(&netif);

    /* Set the link callback function, this function is called on change of link status*/
    netif_set_link_callback(&netif, ethernetif_update_config);

    return 1;

}

/*************************************************************************************
  * @brief  called when a frame is received
  * @param  none
  * @retval none
  ************************************************************************************/
void lwip_pkt_handle(void)
{
  /* Read a received packet from the Ethernet buffers and send it to the lwIP for handling */
  ethernetif_input(&netif);
}
/*************************************************************************************
  * @brief  ethernet link check
  * @param  none
  * @retval none
  ************************************************************************************/
void check_ethernet_link(void)
{
	ethernetif_set_link(&netif);
}


 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2024 Calixto Systems Pvt Ltd ***END OF FILE*/
