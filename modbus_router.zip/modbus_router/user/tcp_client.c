/**
  **************************
  * @file    hal_tcp_client.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    26-03-2025
   * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "tcp_client.h"
#include "lwip/err.h"
#include "lwip/tcp.h"
#include "hal_gpio.h"
#include "lwip/priv/tcp_priv.h"
#include "lwip/timeouts.h"
#include "ethernetif.h"
#include "modbus_gw_cfg.h"
/* Private typedef -----------------------------------------------------------*/

typedef void (*cbk_fun)();
cbk_fun tcp_client_callback;

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

extern struct tcp_pcb *tcp_active_pcbs;
struct tcp_pcb *tcp_client_pcb = NULL;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**************************************************************************************
  * @brief  tcp_client_callback_reg_fun
  * @param  callback - function to register for callback
  * @retval error value
  ***************************************************************************************/
void tcp_client_callback_reg_fun(void *callback) {

	tcp_client_callback = callback;
}
/****************************************************************************************
  * @brief  report connection is establish
  * @param  arg: user supplied argument
  * @param  pcb: the tcp_pcb which accepted the connection
  * @param  err: error value
  * @retval err_t: it will response error code
  ***************************************************************************************/
static err_t tcp_connected(void *arg,struct tcp_pcb *pcb,err_t err) {

    tcp_client_callback(0,0,2);
	return ERR_OK;
}
/****************************************************************************************
  * @brief  receiving callback funtion for TCP client
  * @param  arg: the user argument
  * @param  pcb: the tcp_pcb that has received the data
  * @param  p: the packet buffer
  * @param  err: the error value linked with the received data
  * @retval error value
  ***************************************************************************************/
static err_t tcp_client_recv(void *arg, struct tcp_pcb *pcb, struct pbuf *p, err_t err) {

    if (p != NULL) {
	    tcp_client_callback((uint8_t*)p->payload, p->tot_len, 1);
	    tcp_recved(pcb, p->tot_len);
//	    pbuf_free(p);
    } else {
    	tcp_close(pcb);
    }
    pbuf_free(p);
    return ERR_OK;
}
/*************************************************************************************
  * @brief  receive response from server
  * @param  arg: the user argument
  * @param  pcb: the tcp_pcb that has received the data
  * @param  len: Reponse length
  * @retval error value
  *************************************************************************************/
static err_t tcp_rsp_from_server(void *arg, struct tcp_pcb *pcb, uint16_t len) {

//	PRINTF("ACK:%u\n",len);
    return ERR_OK;
}
/****************************************************************************************
 * @brief  TCP client err function
 * @param  arg: the user argument
 * @param  err : type of error
 * @retval None
 ***************************************************************************************/
static void tcp_client_err(void *arg, err_t err) {

	PRINTF("ERROR : %d\n",err);
//    tcp_client_close();
}
/****************************************************************************************
  * @brief  check tcp connection
  * @param  none
  * @retval the tcp_pcb which accepted the connection
  ***************************************************************************************/
struct tcp_pcb *check_tcp_connect(void) {

	uint8_t connect_flag = 0;
	struct tcp_pcb *cpcb = NULL;
    for(cpcb = tcp_active_pcbs;cpcb != NULL; cpcb = cpcb->next) {
    	if(cpcb -> state == ESTABLISHED) {
    		connect_flag = 1;
    		break;
    	}
    }
    if( connect_flag == 0 ) {
	  cpcb = 0;
    }
    return cpcb;
}
/****************************************************************************************
  * @brief  Initialize tcp client
  * @param  local port
  * @retval err_t
  ***************************************************************************************/
err_t tcp_client_init(uint16_t local_port) {

	err_t err;
    tcp_client_pcb = tcp_new();
    if (tcp_client_pcb == NULL) {
    	PRINTF("TCP NEW\n");
    	return ERR_MEM;
    }
    err = tcp_bind(tcp_client_pcb, IP_ADDR_ANY, local_port);  // TCP_MSL  MSL
    if(err != ERR_OK) {
    	PRINTF("TCP BIND:%d\n",err);
    	return err;
    }
    PRINTF("INIT\n");
    return ERR_OK;
}
/****************************************************************************************
  * @brief  connect tcp client
  * @param  server_ip
  * @param  remote_port: remote port
  * @retval none
  ***************************************************************************************/
err_t tcp_client_connect(uint32_t server_ip, uint16_t remote_port) {

	err_t err;
	ip_addr_t ipaddr;
	ipaddr.addr = server_ip;
//	IP4_ADDR(&ipaddr, server_ip[0], server_ip[1], server_ip[2], server_ip[3]);
//	PRINTF("PCB:%u\n",tcp_client_pcb->state);
	err = tcp_connect(tcp_client_pcb, &ipaddr, remote_port, tcp_connected);
	if(err != ERR_OK) {
		PRINTF("CT:%d\n",err);
		return err;
	}
	tcp_arg(tcp_client_pcb, NULL);
    tcp_recv(tcp_client_pcb, tcp_client_recv);
    tcp_err(tcp_client_pcb, tcp_client_err);
    tcp_sent(tcp_client_pcb, tcp_rsp_from_server); // low_level_output  low_level_input TCP_OUTPUT_DEBUG LWIP_DBG_ON
    return ERR_OK;
}
/******************************************************************************
 * @brief       function transmit data through tcp
 * @param       buffer - transfer buffer
 * @param       buffer_len - transfer buffer length
 * @return      none
 ******************************************************************************/
err_t tcp_client_data_transmit(uint8_t *buffer,uint16_t length)
{
	err_t err;
	struct tcp_pcb* pcb = NULL;
	pcb = check_tcp_connect();
	if(pcb != NULL) {
	    uint16_t send_buf_len = tcp_sndbuf(pcb);
	  	if(send_buf_len >= length) {
	  		tcp_write(pcb, buffer, length, 1);
	  		tcp_output(pcb);
		}
	}
    return 0;
}
/******************************************************************************
 * @brief       function for closing tcp connection
 * @param[in]   none
 * @return      none
 ******************************************************************************/
int8_t tcp_client_close(void) {

	err_t err;
	if (tcp_client_pcb != NULL) {
//		tcp_buffer_clear();
		PRINTF("CLOSE STATE : %d\n",tcp_client_pcb->state);
	    tcp_arg(tcp_client_pcb, NULL);
	    tcp_sent(tcp_client_pcb, NULL);
	    tcp_recv(tcp_client_pcb, NULL);
	    tcp_err(tcp_client_pcb, NULL);
	    if (tcp_client_pcb->state != CLOSED) {
		    err = tcp_close(tcp_client_pcb);
			if (err != ERR_OK) {
				tcp_abort(tcp_client_pcb);
			}
			PRINTF("TCP CLOSE:%p,%d,%d\n", tcp_client_pcb, tcp_client_pcb->state, err); // tcp_slowtmr
	    }
		tcp_client_pcb = NULL;
	}
	return err;
}

 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2024 Calixto Systems Pvt Ltd ***END OF FILE*/

