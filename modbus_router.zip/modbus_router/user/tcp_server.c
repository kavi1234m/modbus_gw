/**
  **************************************************************************
  * @file     tcp_server.c
  * @brief    implement tcp server
  **************************************************************************
  *                       Copyright notice & Disclaimer
  *
  * The software Board Support Package (BSP) that is made available to
  * download from Artery official website is the copyrighted work of Artery.
  * Artery authorizes customers to use, copy, and distribute the BSP
  * software and its related documentation for the purpose of design and
  * development in conjunction with Artery microcontrollers. Use of the
  * software is governed by this copyright notice and the following disclaimer.
  *
  * THIS SOFTWARE IS PROVIDED ON "AS IS" BASIS WITHOUT WARRANTIES,
  * GUARANTEES OR REPRESENTATIONS OF ANY KIND. ARTERY EXPRESSLY DISCLAIMS,
  * TO THE FULLEST EXTENT PERMITTED BY LAW, ALL EXPRESS, IMPLIED OR
  * STATUTORY OR OTHER WARRANTIES, GUARANTEES OR REPRESENTATIONS,
  * INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
  *
  **************************************************************************
  */

#include "tcp_server.h"
#include "lwip/err.h"
#include "lwip/tcp.h"
#include "lwip/priv/tcp_priv.h"
#include "string.h"
#include "hal_gpio.h"
#include "task.h"
#include "modbus_gw_cfg.h"

extern uint32_t tcp_socket_timeout;
#define GET_TIME_IN_MS()                     xTaskGetTickCount()

typedef struct {
    volatile struct tcp_pcb *pcb;
    volatile uint32_t last_activity_tick;
} tcp_client_t;

typedef void (*tcp_server_cbk)();
tcp_server_cbk tcp_server_clbk_tmp;

extern struct tcp_pcb *tcp_active_pcbs;

struct tcp_pcb *pcb1 = NULL;
struct tcp_pcb *pcb2 = NULL;

/******************************************************************************
 * @brief       callback Register for TCP server
 * @param[in]   event type
 * @return      none
 ******************************************************************************/
void tcp_server_callback_reg_fun(void (*callbkfun)) {

	tcp_server_clbk_tmp = callbkfun;
}

/******************************************************************************
 * @brief       TCP Timeout monitor for idle connection
 * @param[in]   event type
 * @return      none
 ******************************************************************************/
void tcp_timeout_monitor(void) {

	struct tcp_pcb *cpcb;
	TickType_t now = GET_TIME_IN_MS();
    for (cpcb = tcp_active_pcbs;cpcb != NULL; cpcb = cpcb->next) {
    	tcp_client_t *client = (tcp_client_t *)cpcb->callback_arg;
    	if (client != NULL) {
    		TickType_t elapsed = now - client->last_activity_tick;
    	    if (elapsed > tcp_socket_timeout) {
    	    	PRINTF("3.TMT:%u,%u\n",now, client->last_activity_tick);
    	    	PRINTF("Closing idle connection %p\n", cpcb);
    	        tcp_abort(cpcb);  // Force close
//    	        free(client);
    	    }
    	}
    }
}
/******************************************************************************************
  * @brief  receive and receive tcp data
  * @param  arg: the user argument
  * @param  pcb: the tcp_pcb that has received the data
  * @param  p: the packet buffer
  * @param  err: the error value linked with the received data
  * @retval error value
  ****************************************************************************************/
static err_t tcp_server_recv(void *arg, struct tcp_pcb *pcb,struct pbuf *p,err_t err) {

	tcp_client_t *client = (tcp_client_t *)arg;
    if(p != NULL) {
    	tcp_recved(pcb, p->tot_len);
        tcp_server_clbk_tmp(p->payload, p->tot_len,pcb->local_port);
//        pbuf_free(p);                                               /* free the TCP segment */
        client->last_activity_tick = GET_TIME_IN_MS();
    } else {
    	free(client);
    	tcp_close(pcb);                                           /* TCP server shouldn't close this session actively */
    }
    pbuf_free(p);
    err = ERR_OK;
    return err;
}
/**
  * @brief  receive response from client
  * @param  arg: the user argument
  * @param  pcb: the tcp_pcb that has received the data
  * @param  len: Reponse length
  * @retval error value
  */
err_t tcp_rsp_from_client(void *arg, struct tcp_pcb *pcb, uint16_t len) {

	PRINTF("ACK:%u\n",len);
    return ERR_OK;
}
/**
  * @brief  TCP server err function
  * @param  arg: the user argument
  * @param  err : type of error
  * @retval None
  */
void tcp_server_err(void *arg, err_t err) {

	tcp_client_t *client = (tcp_client_t *)arg;
	if (client != NULL) {
		free(client);
	}
	PRINTF("SOCKET CLOSED : %d\n",err);
}
/**
  * @brief  callback function for receiving data
  * @param  arg: user supplied argument
  * @param  pcb: the tcp_pcb which accepted the connection
  * @param  err: error value
  * @retval error value
  */
static err_t tcp_server_accept(void *arg,struct tcp_pcb *pcb,err_t err) {

	PRINTF("ACCEPT : %p\n", pcb);
    tcp_client_t *client = malloc(sizeof(tcp_client_t));
    client->pcb = pcb;
    client->last_activity_tick = GET_TIME_IN_MS();
//    PRINTF("1.TMT:%u\n",client->last_activity_tick);
    tcp_arg(pcb, client);
	tcp_setprio(pcb, TCP_PRIO_MIN);        /* set the priority of callback function, if there are multiple session exist, this function must be called */
    tcp_recv(pcb,tcp_server_recv);         /* set callback function for TCP segments come in */
    tcp_sent(pcb, tcp_rsp_from_client);
    tcp_err(pcb, tcp_server_err);
    err = ERR_OK;
    return err;

}
/****************************************************************************************
  * @brief  check connection
  * @param  none
  * @retval the tcp_pcb which accepted the connection
  ***************************************************************************************/
struct tcp_pcb *check_tcp_server_connection(uint16_t port) {

	struct tcp_pcb *cpcb = 0;
    uint8_t connection_flag = 0;
    for (cpcb = tcp_active_pcbs;cpcb != NULL; cpcb = cpcb->next) {
    	if(cpcb -> state == ESTABLISHED && cpcb->local_port == port) {
    		connection_flag = 1;
            break;
    	}
    }
    if (connection_flag == 0) {
    	cpcb = 0;
    }
    return cpcb;
}
/****************************************************************************************
  * @brief  Transmit Retry function
  * @param  None
  * @retval None
  ***************************************************************************************/
void tcp_transmit_retry(void) {
	tcp_slowtmr();
}
/**********************************************************************************
  * @brief  tcp server data transmit function
  * @param  buffer - transfer buffer
  * @param  buffer_len - transfer buffer length
  * @retval none
  *********************************************************************************/
int8_t tcp_server_transmit(uint8_t *buffer,uint16_t buffer_len, uint16_t port) {

	err_t err;
	struct tcp_pcb *server_pcb = NULL;
	server_pcb = check_tcp_server_connection(port);
    uint16_t send_buf_len = tcp_sndbuf(server_pcb);
    if(send_buf_len >= buffer_len) {
        if(server_pcb != NULL) {
            if(tcp_write(server_pcb, buffer, buffer_len, 1) == ERR_OK) {
            	if(tcp_output(server_pcb) == ERR_OK) {
            	}
            }
        }
    }
    return 1;
}
/***************************************************************************************
  * @brief  Close tcp server
  * @param  none
  * @retval none
  *************************************************************************************/
int8_t tcp_server_close(uint16_t port1, uint16_t port2) {

	err_t err = 0;
	struct tcp_pcb *cpcb = NULL;
	cpcb = check_tcp_server_connection(port1);
	if (cpcb != NULL) {
		tcp_client_t *client = (tcp_client_t *)cpcb->callback_arg;
	    tcp_abort(cpcb);
	    free(client);
	}
	cpcb = check_tcp_server_connection(port2);
	if (cpcb != NULL) {
		tcp_client_t *client = (tcp_client_t *)cpcb->callback_arg;
	    tcp_abort(cpcb);
	    free(client);
	}
	if (pcb1 != NULL) {
	    err = tcp_close(pcb1);
		PRINTF("1.TCP Server closed : %d\n",err);
		pcb1 = NULL;
	}
	if (pcb2 != NULL) {
	    err = tcp_close(pcb2);
		PRINTF("2.TCP Server closed : %d\n",err);
		pcb2 = NULL;
	}
	return err;

}
/*********************************************************************************
  * @brief  initialize tcp server
  * @param  none
  * @retval none
  *******************************************************************************/
void tcp_server_init(uint16_t port1, uint16_t port2) {

    err_t err;
    pcb1 = tcp_new();
    if (!pcb1) {
        return;
    }
    err = tcp_bind(pcb1, IP_ADDR_ANY, port1);
    if (err != ERR_OK) {
        tcp_close(pcb1);
        return;
    }
    pcb1 = tcp_listen(pcb1);
    if (!pcb1) {
        return;
    }
    tcp_accept(pcb1, tcp_server_accept);

    // Create and bind for port2
    pcb2 = tcp_new();
    if (!pcb2) {
        return;
    }
    err = tcp_bind(pcb2, IP_ADDR_ANY, port2);
    if (err != ERR_OK) {
        tcp_close(pcb2);
        return;
    }
    pcb2 = tcp_listen(pcb2);
    if (!pcb2) {
        return;
    }
    tcp_accept(pcb2, tcp_server_accept);
    PRINTF("server init: %u,%u\n",port1,port2);
}
