/**
  **************************
  * @file    http_parser.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 26
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "http_parser.h"
#include <stdlib.h>
#include <string.h>
#include "fsdata.c"
#include <stdio.h>
#include <ctype.h>
#include "lwip/inet.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define PARSE_DEV_BUF_SIZE	2080
#define USERNAME "admin"
#define PASSWORD "1234"

#define LOGIN_SUCCESS                   1
#define LOGIN_INVALID_CREDENTIALS       2
#define LOGIN_NO_PARAMS                 3
/* Private macro -------------------------------------------------------------*/
#define ERROR_PLACEHOLDER "<!--%LOGIN_ERROR%-->"
#define ERROR_SNIPPET \
    "<script>\n" \
    "  window.addEventListener(\"load\", function() {\n" \
    "    alert(\"User Name or Password is Incorrect!!!\");\n" \
    "  });\n" \
    "</script>\n"
/* Private variables ---------------------------------------------------------*/
//static char out_buf[30000];
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*********************************************************************************
 * @brief Convert 32-bit IP (e.g., 0xC0A80101) to string (e.g., "192.168.1.1")
 ***********************************************************************************/
void ip_to_string(uint32_t ip, char *out) {
    sprintf(out, "%u.%u.%u.%u",
            (ip & 0xFF) ,
            (ip >> 8) & 0xFF,
            (ip >> 16) & 0xFF,
            (ip >> 24)& 0xFF);
}

/******************************************************************************
 * @brief       Html open
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t html_open(struct html_file *file, const char *name) {

  const struct htmldata_file *f;

  if ((file == NULL) || (name == NULL)) {
    return 0;
  }

  for (f = FS_ROOT; f != NULL; f = f->next) {
    if (!strcmp(name, (const char *)f->name)) {
      file->data = (const char *)f->data;
      file->len = f->len;
      file->index = f->len;
      file->pextension = NULL;
      file->flags = f->flags;
      return 1;
    }
  }
  /* file not found */
  return 0;
}


/******************************************************************************
 * @brief       Html close
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void html_close(struct html_file *file)
{
  (void)file;
}
/******************************************************************************
 * @brief       html bytes left
 * @param[in]   none
 * @return      none
 ******************************************************************************/
int html_bytes_left(struct html_file *file)
{
  return file->len - file->index;
}
/******************************************************************************
 * @brief       Verify login request function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t verify_login_request(const char *http_buf) {
    const char *user_key = "user=";
    const char *pass_key = "passw=";
    const char *param_start = strchr(http_buf, '?');
    if (!param_start) {
        return LOGIN_NO_PARAMS;
    }

    // 3. Parse user
    const char *user_pos = strstr(param_start, user_key);
    const char *pass_pos = strstr(param_start, pass_key);
    if (!user_pos || !pass_pos) {
        return LOGIN_INVALID_CREDENTIALS;
    }

    user_pos += strlen(user_key);
    const char *user_end = strchr(user_pos, '&');
    if (!user_end || user_end - user_pos >= 32) return LOGIN_INVALID_CREDENTIALS;
    char username[32] = {0};
    strncpy(username, user_pos, user_end - user_pos);

    pass_pos += strlen(pass_key);
    const char *pass_end = strpbrk(pass_pos, " \r\n");
    if (!pass_end || pass_end - pass_pos >= 32) return LOGIN_INVALID_CREDENTIALS;
    char password[32] = {0};
    strncpy(password, pass_pos, pass_end - pass_pos);

    // 4. Compare
    if (strcmp(username, USERNAME) == 0 && strcmp(password, PASSWORD) == 0) {
        return LOGIN_SUCCESS;
    }

    return LOGIN_INVALID_CREDENTIALS;
}
/******************************************************************************
 * @brief       Replace ERROR placeholder inside the existing HTML in output_buf
 * @param[in]   output_buf : Buffer that already contains the full HTML page
 * @return      Total length of updated HTML
 ******************************************************************************/
uint16_t build_login_error_page(uint8_t *output_buf)
{
	strcpy(output_buf, data_login_html);
    char *placeholder = strstr((char *)output_buf, ERROR_PLACEHOLDER);
    const char *insert = ERROR_SNIPPET;

    if (!placeholder)
    {
        // No placeholder found return existing length
        uint16_t len = strlen((char *)output_buf);
        return len;
    }

    // Calculate lengths
    size_t placeholder_len = strlen(ERROR_PLACEHOLDER);
    size_t insert_len = strlen(insert);
    size_t original_len = strlen((char *)output_buf);

    // Move the suffix part to make space or close the gap
    char *suffix_src  = placeholder + placeholder_len;
    char *suffix_dest = placeholder + insert_len;
    size_t suffix_len = strlen(suffix_src);

    // memmove handles overlapping memory correctly
    memmove(suffix_dest, suffix_src, suffix_len + 1);

    // Copy the error snippet in place of placeholder
    memcpy(placeholder, insert, insert_len);

    // New total length
    uint16_t total_len = original_len - placeholder_len + insert_len;

    return total_len;
}

/******************************************************************************
 * @brief       Parse parity string to enum/value
 * @param[in]   parity_str - Parity string
 * @return      Parity value as uint8_t
 ******************************************************************************/
uint8_t parse_parity(const char *parity_str) {
    if (strcmp(parity_str, "None") == 0) {
        return 'N';
    } else if (strcmp(parity_str, "Even") == 0) {
        return 'E';
    } else if (strcmp(parity_str, "Odd") == 0) {
        return 'O';
    }
    return 'N';
}

// URL decoding helper function
void url_decode(const char *src, char *dst, size_t dst_size) {
    char a, b;
    size_t i = 0, j = 0;

    while (src[i] && j < dst_size - 1) {
        if (src[i] == '%') {
            if (src[i+1] && src[i+2]) {
                a = src[i+1];
                b = src[i+2];

                if (isxdigit(a) && isxdigit(b)) {
                    if (a >= '0' && a <= '9') a -= '0';
                    else if (a >= 'a' && a <= 'f') a = a - 'a' + 10;
                    else if (a >= 'A' && a <= 'F') a = a - 'A' + 10;

                    if (b >= '0' && b <= '9') b -= '0';
                    else if (b >= 'a' && b <= 'f') b = b - 'a' + 10;
                    else if (b >= 'A' && b <= 'F') b = b - 'A' + 10;

                    dst[j++] = (a << 4) | b;
                    i += 3;
                    continue;
                }
            }
        } else if (src[i] == '+') {
            dst[j++] = ' ';
            i++;
            continue;
        }
        dst[j++] = src[i++];
    }
    dst[j] = '\0';
}


/******************************************************************************
 * @brief      Replace the placeholder function
 * @param[in]   parity_str - Parity string ("None", "Odd", "Even")
 * @return      Parity value as uint8_t
 ******************************************************************************/
void replace_all(char *str, const char *placeholder, const char *replacement)
{
	size_t placeholder_len = strlen(placeholder);
	size_t replacement_len = strlen(replacement);
	char *pos = str;
	while ((pos = strstr(pos, placeholder)) != NULL)
	{
		size_t tail_len = strlen(pos + placeholder_len);

		// Shift the tail to make space (or close the gap)
		memmove(pos + replacement_len, pos + placeholder_len, tail_len + 1);
		// Copy replacement
		memcpy(pos, replacement, replacement_len);
		// Advance pointer
		pos += replacement_len;
	}
}
/******************************************************************************
 * @brief       prepare device info page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_device_info_page(char *output, const device_info_t *info) {
    // Perform all placeholder replacements
	strcpy(output, data_device_info_html);
    replace_all(output, "%SYS_NAM%", info->system_name);
    replace_all(output, "%FWR_VER%", info->firmware_version);
    replace_all(output, "%DEV_HEL%", info->device_health);
    replace_all(output, "%MAC_ADS%", info->mac_address);
    replace_all(output, "%IPV4%", info->ipv4_address);
    replace_all(output, "%SUBNET%", info->subnet_mask);
    replace_all(output, "%GATEWAY%", info->default_gateway);
}

/******************************************************************************
 * @brief       prepare network cfg page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_nwk_info_page(const char *html_pg, char *output, const network_config_t *info) {

	strcpy(output, html_pg);

    char ip_str[16], def_gw_str[16], sm_str[16];

    ip4addr_ntoa_r((const ip4_addr_t *)&info->ipv4_address, ip_str, sizeof(ip_str));
    ip4addr_ntoa_r((const ip4_addr_t *)&info->default_gateway,def_gw_str, sizeof(def_gw_str));
    ip4addr_ntoa_r((const ip4_addr_t *)&info->subnet_mask, sm_str, sizeof(sm_str));

    replace_all(output, "%IP_ADDR%", ip_str);
    replace_all(output, "%DEF_GW_ADDR%", def_gw_str);
    replace_all(output, "%SM_ADDR%", sm_str);


}

/******************************************************************************
 * @brief       prepare serial cfg page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_serial_info_page(const char *html_pg, char *output, const serial_config_t *info) {
	strcpy(output, html_pg);
    char tmp[32];

    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 2400) ? "selected" : "");
    replace_all(output, "%BR1_2400%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 4800) ? "selected" : "");
    replace_all(output, "%BR1_4800%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 9600) ? "selected" : "");
    replace_all(output, "%BR1_9600%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 19200) ? "selected" : "");
    replace_all(output, "%BR1_19200%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 38400) ? "selected" : "");
    replace_all(output, "%BR1_38400%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 57600) ? "selected" : "");
    replace_all(output, "%BR1_57600%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 115200) ? "selected" : "");
    replace_all(output, "%BR1_115200%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 128000) ? "selected" : "");
    replace_all(output, "%BR1_128000%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 256000) ? "selected" : "");
    replace_all(output, "%BR1_256000%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 921600) ? "selected" : "");
    replace_all(output, "%BR1_921600%", tmp);

    snprintf(tmp, sizeof(tmp), (info->channel1.data_bits == 7) ? "selected" : "");
    replace_all(output, "%DB1_7%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.data_bits == 8) ? "selected" : "");
    replace_all(output, "%DB1_8%", tmp);


    snprintf(tmp, sizeof(tmp), (info->channel1.parity == 'N') ? "selected" : "");
    replace_all(output, "%PB1_None%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.parity == 'O') ? "selected" : "");
    replace_all(output, "%PB1_Odd%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.parity == 'E') ? "selected" : "");
    replace_all(output, "%PB1_Even%", tmp);

    snprintf(tmp, sizeof(tmp), (info->channel1.stop_bits == 1) ? "selected" : "");
    replace_all(output, "%SB1_1%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.stop_bits == 2) ? "selected" : "");
    replace_all(output, "%SB1_2%", tmp);


    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 2400) ? "selected" : "");
    replace_all(output, "%BR2_2400%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 4800) ? "selected" : "");
    replace_all(output, "%BR2_4800%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 9600) ? "selected" : "");
    replace_all(output, "%BR2_9600%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 19200) ? "selected" : "");
    replace_all(output, "%BR2_19200%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 38400) ? "selected" : "");
    replace_all(output, "%BR2_38400%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 57600) ? "selected" : "");
    replace_all(output, "%BR2_57600%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 115200) ? "selected" : "");
    replace_all(output, "%BR2_115200%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 128000) ? "selected" : "");
    replace_all(output, "%BR2_128000%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 256000) ? "selected" : "");
    replace_all(output, "%BR2_256000%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 921600) ? "selected" : "");
    replace_all(output, "%BR2_921600%", tmp);


    snprintf(tmp, sizeof(tmp), (info->channel2.data_bits == 7) ? "selected" : "");
    replace_all(output, "%DB2_7%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.data_bits == 8) ? "selected" : "");
    replace_all(output, "%DB2_8%", tmp);


    snprintf(tmp, sizeof(tmp), (info->channel2.parity == 'N') ? "selected" : "");
    replace_all(output, "%PB2_None%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.parity == 'O') ? "selected" : "");
    replace_all(output, "%PB2_Odd%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.parity == 'E') ? "selected" : "");
    replace_all(output, "%PB2_Even%", tmp);


    snprintf(tmp, sizeof(tmp), (info->channel2.stop_bits == 1) ? "selected" : "");
    replace_all(output, "%SB2_1%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.stop_bits == 2) ? "selected" : "");
    replace_all(output, "%SB2_2%", tmp);

}

void prepare_server_page(const char *html_pg, char *send_html_buf, const server_gw_t *mapping){
    strcpy(send_html_buf, html_pg);
    char value[10];

    if(mapping->connection_tmt != 0){
    sprintf(value, "%u", (mapping->connection_tmt));
    replace_all(send_html_buf, "%PUSH_TIME%", value);
    sprintf(value, "%u", (mapping->rs485_port1));
    replace_all(send_html_buf, "%RS485_1_PORT%", value);
    sprintf(value, "%u", (mapping->rs485_rsp_timeout1));
    replace_all(send_html_buf, "%RS485_1_TIMEOUT%", value);
    sprintf(value, "%u", (mapping->rs485_port2));
    replace_all(send_html_buf, "%RS485_2_PORT%",value);
    sprintf(value, "%u", ( mapping->rs485_rsp_timeout2));
    replace_all(send_html_buf, "%RS485_2_TIMEOUT%",value);
    } else{
        replace_all(send_html_buf, "%PUSH_TIME%", "");
        replace_all(send_html_buf, "%RS485_1_PORT%", "");
        replace_all(send_html_buf, "%RS485_1_TIMEOUT%", "");
        replace_all(send_html_buf, "%RS485_2_PORT%","");
        replace_all(send_html_buf, "%RS485_2_TIMEOUT%", "");
    }
}

void prepare_client_nat_table(const char *html_pg, char *send_html_buf, const client_gw_t *mapping)
{
	strcpy(send_html_buf, html_pg);
    char placeholder[64];
    char value[20];

    for (int i = 0; i < mapping->nat_table_count ; i++) {
        int row = i + 1;
        client_data_t cl_gw_temp = mapping->client_gw[i];

        /* %ROWx_CHECKED% */
        sprintf(placeholder, "%%ROW%d_CHECKED%%", row);
        replace_all(send_html_buf, placeholder, "checked" );

        /* ROWx_SLAVEID */
        sprintf(placeholder, "%%ROW%d_SLAVEID%%", row);
        sprintf(value, "%u", (cl_gw_temp.slave_id));
        replace_all(send_html_buf, placeholder, value);

        /* %ROWx_IP% */
        snprintf(placeholder, sizeof(placeholder), "%%ROW%d_IP%%", row);
        ip_to_string(cl_gw_temp.ip_address, value);
        replace_all(send_html_buf, placeholder, value);

        /* ROWx_PORT*/
        sprintf(placeholder, "%%ROW%d_PORT%%", row);
        sprintf(value, "%u", (cl_gw_temp.port));
        replace_all(send_html_buf, placeholder, value);

        /* ROWx_TIMEOUT */
        sprintf(placeholder, "%%ROW%d_TIMEOUT%%", row);
        sprintf(value, "%u", (cl_gw_temp.rsp_timeout));
        replace_all(send_html_buf, placeholder, value);

    }

    for (int i = mapping->nat_table_count; i < MAX_NAT_TABLE_COUNT; i++) {
        int row = i + 1;

        sprintf(placeholder, "%%ROW%d_CHECKED%%", row);
        replace_all(send_html_buf, placeholder, "");

        sprintf(placeholder, "%%ROW%d_SLAVEID%%", row);
        replace_all(send_html_buf, placeholder, "");

        snprintf(placeholder, sizeof(placeholder), "%%ROW%d_IP%%", row);
        replace_all(send_html_buf, placeholder, "");

        sprintf(placeholder, "%%ROW%d_PORT%%", row);
        replace_all(send_html_buf, placeholder, "");

        sprintf(placeholder, "%%ROW%d_TIMEOUT%%", row);
        replace_all(send_html_buf, placeholder, "");
    }
}

/******************************************************************************
 * @brief       Network config parsing function (safe for MCU)
 * @param[in]   query_string : full HTTP GET query string
 * @param[out]  nwk_cfg      : pointer to network config struct
 * @return      none
 ******************************************************************************/
void parse_gw_network_config(const char *query_string, network_config_t *nwk_cfg) {
    if (!query_string || !nwk_cfg) return;

    char temp[512];
    const char *q = strchr(query_string, '?');

    if (q) q++; else q = query_string;

    size_t len = 0;
    while (q[len] && q[len] != ' ' && len < sizeof(temp) - 1) {
        temp[len] = q[len];
        len++;
    }
    temp[len] = '\0';

    const char *p = temp;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = eq - p;
        if (key_len == 0) break;

        char key[32];
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        char value[128];
        if (val_len >= sizeof(value)) val_len = sizeof(value) - 1;
        memcpy(value, val_start, val_len);
        value[val_len] = '\0';

        if (strcmp(key, "ipv4_ads") == 0) {
            nwk_cfg->ipv4_address = inet_addr(value);
        } else if (strcmp(key, "sub_mask") == 0) {
            nwk_cfg->subnet_mask = inet_addr(value);
        } else if (strcmp(key, "def_gwy") == 0) {
            nwk_cfg->default_gateway = inet_addr(value);
        }

        if (!amp) break;
        p = amp + 1;
    }
}

/******************************************************************************
 * @brief       Serial config parsing function
 * @param[in]   query_string - The query string from POST request
 * @param[out]  out_cfg - Pointer to serial_config_t structure to fill
 * @return      none
 ******************************************************************************/
void parse_gw_serial_config(const char *query_string, char *buff, serial_config_t *out_cfg) {
    if (!query_string || !buff || !out_cfg) return;

    const char *params = strchr(query_string, '?');
    if (params) params++; else params = query_string;

    memset(buff, 0, 150);

    const char *end = strchr(params, ' ');
    size_t copy_len = end ? (size_t)(end - params) : strlen(params);
    if (copy_len > 149) copy_len = 149;

    strncpy(buff, params, copy_len);
    buff[copy_len] = '\0';

    const char *p = buff;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = eq - p;
        char key[64];
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        char val[64];
        if (val_len >= sizeof(val)) val_len = sizeof(val) - 1;
        memcpy(val, val_start, val_len);
        val[val_len] = '\0';

        /*
         * baud-rate-1=9600&data-bits-1=8&parity-1=None&stop-bits-1=1&baud-rate-2=9600&data-bits-2=8&parity-2=None&stop-bits-2=1
         */
        if (strcmp(key, "b_rate_1") == 0) {
            out_cfg->channel1.baud_rate = (uint32_t)atoi(val);
        } else if (strcmp(key, "data_bits_1") == 0) {
            out_cfg->channel1.data_bits = (uint8_t)atoi(val);
        } else if (strcmp(key, "parity_1") == 0) {
            out_cfg->channel1.parity = parse_parity(val);
        } else if (strcmp(key, "stop_bits_1") == 0) {
            out_cfg->channel1.stop_bits = (uint8_t)atoi(val);
        } else if (strcmp(key, "b_rate_2") == 0) {
            out_cfg->channel2.baud_rate = (uint32_t)atoi(val);
        } else if (strcmp(key, "data_bits_2") == 0) {
            out_cfg->channel2.data_bits = (uint8_t)atoi(val);
        } else if (strcmp(key, "parity_2") == 0) {
            out_cfg->channel2.parity = parse_parity(val);
        } else if (strcmp(key, "stop_bits_2") == 0) {
            out_cfg->channel2.stop_bits = (uint8_t)atoi(val);
        }

        if (!amp) break;
        p = amp + 1;
    }
}

void parse_nat_table_data(const char *query_string, client_gw_t *client_gw_cfg)
{
    /*
     * configure.html?
     * totalSelected=1&
     * row0_slaveId=12&
     * row0_ipAddress=12.36.34.11&
     * row0_port=7802&
     * row0_timeout=700
     */
    if (!query_string || !client_gw_cfg) {
        PRINTF("ERROR: Null parameters\n");
        return;
    }

    client_gw_t temp_cfg;
    memset(&temp_cfg, 0, sizeof(temp_cfg));

    const char *q = strchr(query_string, '?');
    if (q) {
        q++; // Skip the '?'
    } else {
        q = query_string;
    }

    char *temp =(char *) malloc(1024 * 3);
    if (temp == NULL) {
        PRINTF("Failed to allocate memory\r\n");
        return;
    }

    size_t len = 0;
    const char *end = q;
    while (*end && *end != ' ' && *end != '\n' && *end != '\r' && *end != '\0') {
        end++;
    }
    len = end - q;

    if (len >= 1024 * 3) {
        len = (1024 * 3) - 1;
    }
    memcpy(temp, q, len);
    temp[len] = '\0';

    const char *p = temp;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = (size_t)(eq - p);
        char key[128];
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        char val[256];
        if (val_len >= sizeof(val)) val_len = sizeof(val) - 1;
        memcpy(val, val_start, val_len);
        val[val_len] = '\0';

        char decoded_val[256];
        url_decode(val, decoded_val, sizeof(decoded_val));

        if(strcmp(key,"totalSelected")==0){
            temp_cfg.nat_table_count = (uint8_t)atoi(decoded_val);
        }else if (strncmp(key, "row", 3) == 0) {
            int point_num = -1;
            char field[64] = {0};

            if (sscanf(key, "row%d_%63s", &point_num, field) == 2) {
                if (point_num >= 0 && point_num < MAX_NAT_TABLE_COUNT) {
                    PRINTF("Found point %d field '%s' = '%s'\r\n", point_num, field, decoded_val);

                    if (strcmp(field, "slaveId") == 0) {
                        temp_cfg.client_gw[point_num].slave_id = (uint8_t)atoi(decoded_val);
                    }
                    else if (strcmp(field, "ipAddress") == 0) {
                        uint32_t ip = inet_addr(decoded_val);
                        if (ip != INADDR_NONE) {
                            temp_cfg.client_gw[point_num].ip_address = ip;
                        } else {
                            PRINTF("ERROR: Invalid IP address format: %s\r\n", decoded_val);
                        }
                  } else if (strcmp(field, "port") == 0) {
                        temp_cfg.client_gw[point_num].port = (uint16_t)atoi(decoded_val);
                    }
                    else if (strcmp(field, "timeout") == 0) {
                        temp_cfg.client_gw[point_num].rsp_timeout = (uint16_t)atoi(decoded_val);
                    }
                } else {
                    PRINTF("WARNING: Invalid point number %d\r\n", point_num);
                }
            } else {
                PRINTF("WARNING: Failed to parse row field: %s\r\n", key);
            }
        }

        if (!amp) break;
        p = amp + 1;
    }

    free(temp);
    temp = NULL;

    memcpy(client_gw_cfg, &temp_cfg, sizeof(client_gw_t));

    PRINTF("Parsed configuration:\r\n");
    PRINTF("  total_selected: %d\r\n", client_gw_cfg->nat_table_count);

    for (int i = 0; i < client_gw_cfg->nat_table_count && i < MAX_NAT_TABLE_COUNT; i++) {
        PRINTF("  Row %d:\r\n", i);
        PRINTF("    slave_id: %u\r\n", client_gw_cfg->client_gw[i].slave_id);

        char ip_addr[15];
        ip_to_string(client_gw_cfg->client_gw[i].ip_address, ip_addr);
        PRINTF("    ip_address: %s\r\n", ip_addr);
        PRINTF("    port: %u\r\n", client_gw_cfg->client_gw[i].port);
        PRINTF("    rsp_timeout: %u\r\n", client_gw_cfg->client_gw[i].rsp_timeout);
    }
}

void parse_modbus_dev_config(const char *query_string, server_gw_t *server_gw_cfg)
{
    /*
     * modbus_device_cfg?
     * push-time=5656
     * &rs485-1=502
     * &rs485_1_tout=78
     * &rs485-2=410
     * &rs485_2_tout=52
     */
    if (!query_string || !server_gw_cfg) {
        PRINTF("ERROR: Null parameters\n");
        return;
    }

    server_gw_t temp_cfg;
    memset(&temp_cfg, 0, sizeof(temp_cfg));

    const char *q = strchr(query_string, '?');
    if (q) {
        q++; // Skip the '?'
    } else {
        q = query_string;
    }

    char temp[1024];
    size_t len = 0;
    const char *end = q;
    while (*end && *end != ' ' && *end != '\n' && *end != '\r' && *end != '\0') {
        end++;
    }
    len = end - q;

    if (len >= sizeof(temp)) {
        len = sizeof(temp) - 1;
    }
    memcpy(temp, q, len);
    temp[len] = '\0';

    const char *p = temp;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = (size_t)(eq - p);
        char key[128];
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        char val[256];
        if (val_len >= sizeof(val)) val_len = sizeof(val) - 1;
        memcpy(val, val_start, val_len);
        val[val_len] = '\0';

        char decoded_val[256];
        url_decode(val, decoded_val, sizeof(decoded_val));

        if (strcmp(key, "push-time") == 0) {
            temp_cfg.connection_tmt = (uint16_t)atoi(decoded_val);
        }
        else if (strcmp(key, "rs485-1") == 0) {
            temp_cfg.rs485_port1 = (uint16_t)atoi(decoded_val);
        }
        else if (strcmp(key, "rs485_1_tout") == 0) {
            temp_cfg.rs485_rsp_timeout1 = (uint16_t)atoi(decoded_val);
        }
        else if (strcmp(key, "rs485-2") == 0) {
            temp_cfg.rs485_port2 = (uint16_t)atoi(decoded_val);
        }
        else if (strcmp(key, "rs485_2_tout") == 0) {
            temp_cfg.rs485_rsp_timeout2 = (uint16_t)atoi(decoded_val);
        }

        if (!amp) break;
        p = amp + 1;
    }

    memcpy(server_gw_cfg, &temp_cfg, sizeof(server_gw_t));

    PRINTF("Parsed modbus device configuration:\r\n");
    PRINTF("push-time: %u\r\n", server_gw_cfg->connection_tmt);
    PRINTF("rs485_port1: %u\r\n", server_gw_cfg->rs485_port1);
    PRINTF("rs485_rsp_timeout1: %u\r\n", server_gw_cfg->rs485_rsp_timeout1);
    PRINTF("rs485_port2: %u\r\n", server_gw_cfg->rs485_port2);
    PRINTF("rs485_rsp_timeout2: %u\r\n", server_gw_cfg->rs485_rsp_timeout2);
}

/******************************************************************************
 * @brief       prepare success cfg page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_cfg_success_page(char* output, uint8_t cfg_status) {

	strcpy(output, system_config_success_html);
    if (cfg_status) {
    	replace_all(output, "%STATUS_MSG%", "System Configuration Completed Successfully");
    } else {
    	replace_all(output, "%STATUS_MSG%", "System Configuration Failed");
    }
}

void prepare_modbus_config(const char* html_pg, char *send_html_buf, uint8_t gw_type) {
    strcpy(send_html_buf, html_pg);
    if(gw_type == GW_TYPE_SERVER){
        replace_all(send_html_buf, "%SRV_SEL%", "selected");
        replace_all(send_html_buf, "%CLI_SEL%", "");
    }else{
        replace_all(send_html_buf, "%SRV_SEL%", "");
        replace_all(send_html_buf, "%CLI_SEL%", "selected");
    }
}
/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
