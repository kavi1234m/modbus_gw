/**
 * @file
 * LWIP HTTP server implementation
 */

/*
 * Copyright (c) 2001-2003 Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * This file is part of the lwIP TCP/IP stack.
 *
 * Author: Adam Dunkels <adam@sics.se>
 *         Simon Goldschmidt
 *
 */

//#include <modbus_router_cfg.h>
#include "lwip/init.h"
#include "lwip/apps/httpd.h"
#include "lwip/debug.h"
#include "lwip/stats.h"
#include "lwip/apps/fs.h"
#include "httpd_structs.h"
#include "lwip/def.h"
#include <strings.h>
#include <string.h>

#include "task.h"

#include "lwip/altcp.h"
#include "lwip/altcp_tcp.h"

#include <string.h> /* memset */
#include <stdlib.h> /* atoi */
#include <stdio.h>

//#include "at32f435_437_board.h"

#include "http_parser.h"
#include "spi_flash.h"
#include "html_to_spi_flash.h"

#define HTML_BUFFER_SIZE     84320
//#define HTML_CSS_SIZE        11264
#define HTTP_RX_BUF_SIZE     4096  // Large enough for long GET/POST requests

uint8_t login_status;
char *html_read_buff = NULL;
char *http_rx_buf = NULL;
//uint8_t *html_css = NULL;


extern modbus_router_t modbus_data;

//#if LWIP_TCP && LWIP_CALLBACK_API

/** Minimum length for a valid HTTP/0.9 request: "GET /\r\n" -> 7 bytes */
#define MIN_REQ_LEN   7

#define CRLF "\r\n"
#define HTTP_IS_DYNAMIC_FILE(hs) 0

/* This defines checks whether tcp_write has to copy data or not */

#ifndef HTTP_IS_DATA_VOLATILE
/** tcp_write does not have to copy data when sent from rom-file-system directly */
#define HTTP_IS_DATA_VOLATILE(hs)       (HTTP_IS_DYNAMIC_FILE(hs) ? TCP_WRITE_FLAG_COPY : 0)
#endif
/** Default: dynamic headers are sent from ROM (non-dynamic headers are handled like file data) */
#ifndef HTTP_IS_HDR_VOLATILE
#define HTTP_IS_HDR_VOLATILE(hs, ptr)   0
#endif

/* Return values for http_send_*() */
#define HTTP_DATA_TO_SEND_FREED    3
#define HTTP_DATA_TO_SEND_BREAK    2
#define HTTP_DATA_TO_SEND_CONTINUE 1
#define HTTP_NO_DATA_TO_SEND       0

#define CUSTOM_HTTP_SERVER

extern struct tcp_pcb *tcp_listen_pcbs;

device_info_t device_info_details;

#if LWIP_HTTPD_SUPPORT_REQUESTLIST
/** HTTP request is copied here from pbufs for simple parsing */
//volatile static char httpd_req_buf[LWIP_HTTPD_MAX_REQ_LENGTH + 1];
#endif /* LWIP_HTTPD_SUPPORT_REQUESTLIST */


#ifndef LWIP_HTTPD_URI_BUF_LEN
#define LWIP_HTTPD_URI_BUF_LEN LWIP_HTTPD_MAX_REQUEST_URI_LEN

struct http_state {
  struct html_file file_handle;
  struct html_file *handle;
  const char *file;       /* Pointer to first unsent byte in buf. */

  struct altcp_pcb *pcb;
#if LWIP_HTTPD_SUPPORT_REQUESTLIST
  struct pbuf *req;
#endif /* LWIP_HTTPD_SUPPORT_REQUESTLIST */
  uint32_t left;       /* Number of unsent bytes in buf. */
  uint8_t retries;
#if LWIP_HTTPD_CGI
  char *params[LWIP_HTTPD_MAX_CGI_PARAMETERS]; /* Params extracted from the request URI */
  char *param_vals[LWIP_HTTPD_MAX_CGI_PARAMETERS]; /* Values for each extracted param */
#endif /* LWIP_HTTPD_CGI */
};

#define HTTP_ALLOC_HTTP_STATE() (struct http_state *)mem_malloc(sizeof(struct http_state))
#define HTTP_FREE_HTTP_STATE(x) mem_free(x)

static err_t http_close_conn(struct altcp_pcb *pcb, struct http_state *hs);
static err_t http_close_or_abort_conn(struct altcp_pcb *pcb, struct http_state *hs, uint8_t abort_conn);
static err_t http_poll(void *arg, struct altcp_pcb *pcb);
static u8_t http_check_eof(struct altcp_pcb *pcb, struct http_state *hs);

/* CGI handler information */
#define http_cgi_params     hs->params
#define http_cgi_param_vals hs->param_vals

#define http_add_connection(hs)
#define http_remove_connection(hs)

typedef uint8_t (*cbk_fun)();
cbk_fun http_cbk;
/*************************************************************************************************
  * @brief  uart callback register
  * @param  none
  * @retval none
  ************************************************************************************************/
void http_callback_register(void *cbk)
{
     http_cbk = cbk;
}

static void ip_to_str(uint32_t ip_net_order, char *out_str, size_t max_len)
{
    uint8_t bytes[4];
    bytes[0] = (ip_net_order >> 24) & 0xFF;
    bytes[1] = (ip_net_order >> 16) & 0xFF;
    bytes[2] = (ip_net_order >> 8) & 0xFF;
    bytes[3] = ip_net_order & 0xFF;

    snprintf(out_str, max_len, "%u.%u.%u.%u", bytes[0], bytes[1], bytes[2], bytes[3]);
}

/**
 * @brief Convert MAC (6-byte) to string (e.g., 00:11:22:33:44:55)
 */
static void mac_to_str(uint8_t mac[6], char *out_str, size_t max_len)
{
    snprintf(out_str, max_len, "%02X:%02X:%02X:%02X:%02X:%02X",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

/**
 * @brief Fill global device_info_details_t structure
 */
void fill_device_info(uint8_t mac[6], uint32_t ip_net, uint32_t subnet_net, uint32_t gw_net, uint8_t *system_name, uint8_t *firmware_version) {

    // Convert and store strings
    mac_to_str(mac, device_info_details.mac_address, sizeof(device_info_details.mac_address));
    ip_to_str(ntohl(ip_net),    device_info_details.ipv4_address,    sizeof(device_info_details.ipv4_address));
    ip_to_str(ntohl(subnet_net),device_info_details.subnet_mask,     sizeof(device_info_details.subnet_mask));
    ip_to_str(ntohl(gw_net),    device_info_details.default_gateway, sizeof(device_info_details.default_gateway));

    // Copy system name and firmware version
    strncpy(device_info_details.system_name, system_name, sizeof(device_info_details.system_name) - 1);
    device_info_details.system_name[sizeof(device_info_details.system_name) - 1] = '\0';

    strncpy(device_info_details.firmware_version, firmware_version, sizeof(device_info_details.firmware_version) - 1);
    device_info_details.firmware_version[sizeof(device_info_details.firmware_version) - 1] = '\0';

    // Set device health to default (optional)
    strncpy(device_info_details.device_health, "Working", sizeof(device_info_details.device_health) - 1);
    device_info_details.device_health[sizeof(device_info_details.device_health) - 1] = '\0';
}
/*************************************************************************************************
 * @brief  http_state_init
 * @param Initialize a struct http_state.
 * @retval none
 *************************************************************************************************/
static void
http_state_init(struct http_state *hs)
{
  /* Initialize the structure. */
  memset(hs, 0, sizeof(struct http_state));
}

/** Allocate a struct http_state. */
static struct http_state *
http_state_alloc(void)
{
  struct http_state *ret = HTTP_ALLOC_HTTP_STATE();
  if (ret != NULL) {
    http_state_init(ret);
    http_add_connection(ret);
  }
  return ret;
}

/** Free a struct http_state.
 * Also frees the file data if dynamic.
 */
static void
http_state_eof(struct http_state *hs)
{
  if (hs->handle) {
//    fs_close(hs->handle);
	  html_close(hs->handle);
    hs->handle = NULL;
  }
#if LWIP_HTTPD_SUPPORT_REQUESTLIST
  if (hs->req) {
    pbuf_free(hs->req);
    hs->req = NULL;
  }
#endif /* LWIP_HTTPD_SUPPORT_REQUESTLIST */
}

/** Free a struct http_state.
 * Also frees the file data if dynamic.
 */
static void
http_state_free(struct http_state *hs)
{
  if (hs != NULL) {
    http_state_eof(hs);
    http_remove_connection(hs);
    HTTP_FREE_HTTP_STATE(hs);
  }
}

/** Call tcp_write() in a loop trying smaller and smaller length
 *
 * @param pcb altcp_pcb to send
 * @param ptr Data to send
 * @param length Length of data to send (in/out: on return, contains the
 *        amount of data sent)
 * @param apiflags directly passed to tcp_write
 * @return the return value of tcp_write
 */
static err_t
http_write(struct altcp_pcb *pcb, const void *ptr, uint16_t *length, uint8_t apiflags)
{
  uint16_t len, max_len;
  err_t err;
  LWIP_ASSERT("length != NULL", length != NULL);
  len = *length;
  if (len == 0) {
    return ERR_OK;
  }
  /* We cannot send more data than space available in the send buffer. */
  max_len = altcp_sndbuf(pcb);
  if (max_len < len) {
    len = max_len;
  }
#ifdef HTTPD_MAX_WRITE_LEN
  /* Additional limitation: e.g. don't enqueue more than 2*mss at once */
  max_len = HTTPD_MAX_WRITE_LEN(pcb);
  if (len > max_len) {
    len = max_len;
  }
#endif /* HTTPD_MAX_WRITE_LEN */
  do {
    LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("Trying to send %d bytes\n", len));
    err = altcp_write(pcb, ptr, len, apiflags);
    if (err == ERR_MEM) {
      if ((altcp_sndbuf(pcb) == 0) ||
          (altcp_sndqueuelen(pcb) >= TCP_SND_QUEUELEN)) {
        /* no need to try smaller sizes */
        len = 1;
      } else {
        len /= 2;
      }
      LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE,
                  ("Send failed, trying less (%d bytes)\n", len));
    }
  } while ((err == ERR_MEM) && (len > 1));

  if (err == ERR_OK) {
    LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("Sent %d bytes\n", len));
    *length = len;
  } else {
    LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("Send failed with err %d (\"%s\")\n", err, lwip_strerr(err)));
    *length = 0;
  }

  return err;
}

/**
 * The connection shall be actively closed (using RST to close from fault states).
 * Reset the sent- and recv-callbacks.
 *
 * @param pcb the tcp pcb to reset callbacks
 * @param hs connection state to free
 */
static err_t
http_close_or_abort_conn(struct altcp_pcb *pcb, struct http_state *hs, uint8_t abort_conn)
{
  err_t err;
  LWIP_DEBUGF(HTTPD_DEBUG, ("Closing connection %p\n", (void *)pcb));

  altcp_arg(pcb, NULL);
  altcp_recv(pcb, NULL);
  altcp_err(pcb, NULL);
  altcp_poll(pcb, NULL, 0);
  altcp_sent(pcb, NULL);
  if (hs != NULL) {
    http_state_free(hs);
  }

  if (abort_conn) {
    altcp_abort(pcb);
    return ERR_OK;
  }
  err = altcp_close(pcb);
  if (err != ERR_OK) {
    LWIP_DEBUGF(HTTPD_DEBUG, ("Error %d closing %p\n", err, (void *)pcb));
    /* error closing, try again later in poll */
    altcp_poll(pcb, http_poll, HTTPD_POLL_INTERVAL);
  }
  return err;
}

/**
 * The connection shall be actively closed.
 * Reset the sent- and recv-callbacks.
 *
 * @param pcb the tcp pcb to reset callbacks
 * @param hs connection state to free
 */
static err_t
http_close_conn(struct altcp_pcb *pcb, struct http_state *hs)
{
  return http_close_or_abort_conn(pcb, hs, 0);
}

/** End of file: either close the connection (Connection: close) or
 * close the file (Connection: keep-alive)
 */
static void
http_eof(struct altcp_pcb *pcb, struct http_state *hs)
{
    http_close_conn(pcb, hs);
}

/** Sub-function of http_send(): end-of-file (or block) is reached,
 * either close the file or read the next block (if supported).
 *
 * @returns: 0 if the file is finished or no data has been read
 *           1 if the file is not finished and data has been read
 */
static uint8_t
http_check_eof(struct altcp_pcb *pcb, struct http_state *hs)
{
  int bytes_left;

  /* Do we have a valid file handle? */
  if (hs->handle == NULL) {
    /* No - close the connection. */
    http_eof(pcb, hs);
    return 0;
  }
//  bytes_left = fs_bytes_left(hs->handle);
  bytes_left = html_bytes_left(hs->handle);
  if (bytes_left <= 0) {
    /* We reached the end of the file so this request is done. */
    LWIP_DEBUGF(HTTPD_DEBUG, ("End of file.\n"));
    http_eof(pcb, hs);
    return 0;
  }
  LWIP_ASSERT("SSI and DYNAMIC_HEADERS turned off but eof not reached", 0);
  return 1;
}

/** Sub-function of http_send(): This is the normal send-routine for non-ssi files
 *
 * @returns: - 1: data has been written (so call tcp_ouput)
 *           - 0: no data has been written (no need to call tcp_output)
 */
static uint8_t
http_send_data_nonssi(struct altcp_pcb *pcb, struct http_state *hs)
{
  err_t err;
  uint16_t len;
  uint8_t data_to_send = 0;

  /* We are not processing an SHTML file so no tag checking is necessary.
   * Just send the data as we received it from the file. */
  len = (uint16_t)LWIP_MIN(hs->left, 0xffff);

  err = http_write(pcb, hs->file, &len, HTTP_IS_DATA_VOLATILE(hs));
  if (err == ERR_OK) {
    data_to_send = 1;
    hs->file += len;
    hs->left -= len;
  }

  return data_to_send;
}

/**
 * Try to send more data on this pcb.
 *
 * @param pcb the pcb to send data
 * @param hs connection state
 */
static uint8_t
http_send(struct altcp_pcb *pcb, struct http_state *hs)
{
  uint8_t data_to_send = HTTP_NO_DATA_TO_SEND;

  LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("http_send: pcb=%p hs=%p left=%d\n", (void *)pcb,
              (void *)hs, hs != NULL ? (int)hs->left : 0));

  /* If we were passed a NULL state structure pointer, ignore the call. */
  if (hs == NULL) {
    return 0;
  }

  /* Have we run out of file data to send? If so, we need to read the next
   * block from the file. */
  if (hs->left == 0) {
    if (!http_check_eof(pcb, hs)) {
      return 0;
    }
  }
  {
    data_to_send = http_send_data_nonssi(pcb, hs);
  }

  if ((hs->left == 0) && (html_bytes_left(hs->handle) <= 0)) {
    /* We reached the end of the file so this request is done.
     * This adds the FIN flag right into the last data segment. */
    LWIP_DEBUGF(HTTPD_DEBUG, ("End of file.\n"));
    http_eof(pcb, hs);
    return 0;
  }
  LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("send_data end.\n"));
  return data_to_send;
}

#define http_find_error_file(hs, error_nr) ERR_ARG

/**
 * The pcb had an error and is already deallocated.
 * The argument might still be valid (if != NULL).
 */
static void
http_err(void *arg, err_t err)
{
  struct http_state *hs = (struct http_state *)arg;
  LWIP_UNUSED_ARG(err);

  LWIP_DEBUGF(HTTPD_DEBUG, ("http_err: %s", lwip_strerr(err)));

  if (hs != NULL) {
    http_state_free(hs);
  }
}

/**
 * Data has been sent and acknowledged by the remote host.
 * This means that more data can be sent.
 */
static err_t
http_sent(void *arg, struct altcp_pcb *pcb, uint16_t len)
{

  struct http_state *hs = (struct http_state *)arg;

  LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("http_sent %p\n", (void *)pcb));

  LWIP_UNUSED_ARG(len);

  if (hs == NULL) {
    return ERR_OK;
  }

  hs->retries = 0;

  http_send(pcb, hs);

  return ERR_OK;
}



/**
 * The  function is called every 2nd second.
 * If there has been no data sent (which resets the retries) in 8 seconds, close.
 * If the last portion of a file has not been sent in 2 seconds, close.
 *
 * This could be increased, but we don't want to waste resources for bad connections.
 */
static err_t
http_poll(void *arg, struct altcp_pcb *pcb)
{
  struct http_state *hs = (struct http_state *)arg;
  LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("http_poll: pcb=%p hs=%p pcb_state=%s\n",
              (void *)pcb, (void *)hs, tcp_debug_state_str(altcp_dbg_get_tcp_state(pcb))));

  if (hs == NULL) {
    err_t closed;
    /* arg is null, close. */
    LWIP_DEBUGF(HTTPD_DEBUG, ("http_poll: arg is NULL, close\n"));
    closed = http_close_conn(pcb, NULL);
    LWIP_UNUSED_ARG(closed);
    return ERR_OK;
  } else {
    hs->retries++;
    if (hs->retries == HTTPD_MAX_RETRIES) {
      LWIP_DEBUGF(HTTPD_DEBUG, ("http_poll: too many retries, close\n"));
      http_close_conn(pcb, hs);
      return ERR_OK;
    }

    /* If this connection has a file open, try to send some more data. If
     * it has not yet received a GET request, don't do this since it will
     * cause the connection to close immediately. */
    if (hs->handle) {
      LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("http_poll: try to send more data\n"));
      if (http_send(pcb, hs)) {
        /* If we wrote anything to be sent, go ahead and send it now. */
        LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("tcp_output\n"));
        altcp_output(pcb);
      }
    }
  }

  return ERR_OK;
}

err_t http_recv(void *arg, struct altcp_pcb *pcb, struct pbuf *p, err_t err)
{
    struct html_file file = {0, 0};
    struct http_state *hs = (struct http_state *)arg;
    static uint8_t row;
    static uint16_t http_rx_len = 0;

    if (err == ERR_OK && p != NULL){
        tcp_recved(pcb, p->tot_len);

        struct pbuf *q = p;
        while (q && (http_rx_len + q->len < HTTP_RX_BUF_SIZE))
        {
            memcpy(http_rx_buf + http_rx_len, q->payload, q->len);
            http_rx_len += q->len;
            q = q->next;
        }

        pbuf_free(p);

        // Check if full request line has arrived
        if (strstr(http_rx_buf, "HTTP/1.1") != NULL || strstr(http_rx_buf, "\r\n\r\n") != NULL)
        {
            // Null-terminate accumulated data
            http_rx_buf[http_rx_len] = '\0';

            PRINTF("\n=== Full HTTP Request Received (%d bytes) ===\n%s\n===============================\n", http_rx_len, http_rx_buf);

            char *data = http_rx_buf;
//            memset(html_read_buff, 0, HTML_BUFFER_SIZE);
            if (hs->file == NULL) {
                if (strncmp(data, "GET /style.css", 14) == 0) {
                    PRINTF("Style\n");
                    html_open(&file, "/style.css");
                    hs->file = file.data;
                    hs->left = file.len;
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if (strncmp(data, "GET /logo.png", 13) == 0) {
                    PRINTF("LOGO.png\n");
                    html_open(&file, "/logo.png");
                    hs->file = file.data;
                    hs->left = file.len;
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                }else if (strncmp(data, "GET /favicon.ico", 16) == 0) {
                    html_open(&file, "/logo.png");
                    hs->file = file.data;
                    hs->left = file.len;
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if (strncmp(data, "GET /login", 10) == 0) {
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    uint8_t status = verify_login_request((char*)data);
                    switch (status) {
                        case 1 :
                                PRINTF(">>>>>Login Verify\n");
                                prepare_device_info_page(html_read_buff, &device_info_details);
                                hs->file = html_read_buff;
                                hs->left = strlen(html_read_buff);
                                http_send(pcb, hs);
                                tcp_sent(pcb, http_sent);
                              login_status = 1;
                              break;
                        case 2 :
                              PRINTF("INVALID LOGIN CREDENTIALS\n");
                              html_open(&file, "/login.html");
                              uint16_t err_pg_len = build_login_error_page(html_read_buff);
                              hs->file = html_read_buff;
                              hs->left = err_pg_len;
                              http_send(pcb, hs);
                              tcp_sent(pcb, http_sent);
                              break;
                        case 3 :
                              PRINTF(">>>>>Login page\n");
                              html_open(&file, "/login.html");
                              hs->file = file.data;
                              hs->left = file.len;
                              PRINTF("LOGIN LEN: %u\n",hs->left);
                              http_send(pcb, hs);
                              tcp_sent(pcb, http_sent);
                              break;
                    }
                } else if (login_status == 0) {
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    PRINTF(">>>>>Not logged in. Sending login page.\n");
                    html_open(&file, "/login.html");
                    hs->file = file.data;
                    hs->left = file.len;
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if (strncmp(data, "GET /dev_info", 13) == 0)  {
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    prepare_device_info_page(html_read_buff, &device_info_details);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if(strncmp(data, "GET /nwk_configure", 18) == 0){
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    parse_gw_network_config(data, &modbus_data.nwk_cfg);
                    html_open(&file, "/serial_cfg.html");
                    prepare_serial_info_page(file.data, html_read_buff, &modbus_data.serial_cfg);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if(strncmp(data, "GET /serial_configure", 21) == 0){
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    parse_gw_serial_config(data,html_read_buff, &modbus_data.serial_cfg);
                    html_open(&file, "/modbus_cfg.html");
                    prepare_modbus_config(file.data, html_read_buff, modbus_data.gw_type);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                }  else if (strncmp(data, "GET /nwk_cfg", 12) == 0) {
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    html_open(&file, "/nwk_cfg.html");
                    prepare_nwk_info_page(file.data, html_read_buff, &modbus_data.nwk_cfg);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if (strncmp(data, "GET /serial_cfg", 15) == 0) {
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    html_open(&file, "/serial_cfg.html");
                    prepare_serial_info_page(file.data, html_read_buff, &modbus_data.serial_cfg);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if(strncmp(data,"GET /modbus_dev_cfg?modbus_gwy_mode=modbus-server-gateway", 57) == 0){
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    html_open(&file, "/modbus_server_cfg.html");
                    prepare_server_page(file.data, html_read_buff, &modbus_data.server_gw_cfg);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if(strncmp(data,"GET /modbus_dev_cfg?modbus_gwy_mode=modbus-client-gateway", 57) == 0){
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    html_open(&file, "/modbus_client_cfg.html");
                    prepare_client_nat_table(file.data, html_read_buff, &modbus_data.client_gw_cfg);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if(strncmp(data,"GET /modbus_cfg", 15) == 0){
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    html_open(&file, "/modbus_cfg.html");
                    prepare_modbus_config(file.data, html_read_buff, modbus_data.gw_type);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                }  else if(strncmp(data,"GET /modbus_server_gw_configure", 31) == 0){
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                	modbus_data.gw_type = GW_TYPE_SERVER;
                    parse_modbus_dev_config(data, &modbus_data.server_gw_cfg);
                    html_open(&file, "/cfg_success.html");
                    uint8_t status = http_cbk(1);
                    prepare_cfg_success_page(html_read_buff, status);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                } else if(strncmp(data, "GET /modbus_client_gw_configure", 31) == 0){
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                	modbus_data.gw_type = GW_TYPE_CLIENT;
                    parse_nat_table_data(data, &modbus_data.client_gw_cfg);
                    html_open(&file, "/cfg_success.html");
                    uint8_t status = http_cbk(1);
                    prepare_cfg_success_page(html_read_buff, status);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                }  else if (strncmp(data, "POST /device/reset", 18) == 0) {
                	PRINTF("DEVICE RESET");
                    http_cbk(DEVICE_RESET);
                } else if (strncmp(data, "POST /device/factory-default", 28) == 0) {
                	PRINTF("FACTORY DEFAULT");
                    http_cbk(FACTORY_DEFAULT);// CONFIG_DONE
                } else if (strncmp(data, "POST /reboot", 12) == 0) {
                    http_cbk(4);
                }
            }
            http_rx_len = 0;
            memset(http_rx_buf, 0, (HTTP_RX_BUF_SIZE-1));
      }
    }
    if (err == ERR_OK && p == NULL)
    {
        PRINTF("HTTP CLOSE\n");
        http_close_conn(pcb, hs);
    }
    return ERR_OK;
}
/**
 * A new incoming connection has been accepted.
 */
static
err_t http_accept(void *arg, struct altcp_pcb *pcb, err_t err){
//	PRINTF("http_accept %p / %p\n", (void *)pcb, arg);
  struct http_state *hs;
  LWIP_UNUSED_ARG(err);
  LWIP_UNUSED_ARG(arg);
  LWIP_DEBUGF(HTTPD_DEBUG, ("http_accept %p / %p\n", (void *)pcb, arg));

  if ((err != ERR_OK) || (pcb == NULL)) {
    return ERR_VAL;
  }

  /* Set priority */
  altcp_setprio(pcb, HTTPD_TCP_PRIO);

  /* Allocate memory for the structure that holds the state of the
     connection - initialized by that function. */
  hs = http_state_alloc();
  if (hs == NULL) {
    LWIP_DEBUGF(HTTPD_DEBUG, ("http_accept: Out of memory, RST\n"));
    return ERR_MEM;
  }
  hs->pcb = pcb;

  /* Tell TCP that this is the structure we wish to be passed for our
     callbacks. */
  altcp_arg(pcb, hs);

  /* Set up the various callback functions */
  altcp_recv(pcb, http_recv);
  altcp_err(pcb, http_err);
  altcp_poll(pcb, http_poll, HTTPD_POLL_INTERVAL);
  altcp_sent(pcb, http_sent);

  return ERR_OK;
}

static void
httpd_init_pcb(struct altcp_pcb *pcb, uint16_t port)
{
  err_t err;

  if (pcb) {
    altcp_setprio(pcb, HTTPD_TCP_PRIO);
    /* set SOF_REUSEADDR here to explicitly bind httpd to multiple interfaces */
    err_t err = altcp_bind(pcb, IP_ANY_TYPE, HTTPD_SERVER_PORT);
    LWIP_UNUSED_ARG(err); /* in case of LWIP_NOASSERT */
    PRINTF("BIND :%d\n",err);
    LWIP_ASSERT("httpd_init: tcp_bind failed", err == ERR_OK);
    pcb = altcp_listen(pcb);
    LWIP_ASSERT("httpd_init: tcp_listen failed", pcb != NULL);
    altcp_accept(pcb, http_accept);
    PRINTF("HTTP Init Success\n");
  }
}

/**
 * @ingroup httpd
 * Initialize the httpd: set up a listening PCB and bind it to the defined port
 */
void
httpd_init(void)
{
  struct altcp_pcb *pcb;
  LWIP_DEBUGF(HTTPD_DEBUG, ("httpd_init\n"));

  /* LWIP_ASSERT_CORE_LOCKED(); is checked by tcp_new() */

  pcb = altcp_tcp_new_ip_type(IPADDR_TYPE_ANY);
  LWIP_ASSERT("httpd_init: tcp_new failed", pcb != NULL);
  httpd_init_pcb(pcb, HTTPD_SERVER_PORT);

//  html_metadata_read();
  if (html_read_buff == NULL) {
	  html_read_buff = (char*)malloc(HTML_BUFFER_SIZE);
  }
//  if (html_css == NULL) {
//	  html_css = (uint8_t*)malloc(HTML_CSS_SIZE);
//	  if (html_css == NULL) {
//		  PRINTF("HTML CSS MALLOC FAILED\n");
//	  } else {
//		  html_page_read_from_flash(html_css, CSS_PAGE);
//	  }
//  }
  if (http_rx_buf == NULL) {
	  http_rx_buf = (char*)malloc(HTTP_RX_BUF_SIZE);
  }

}

void http_close(void) {

	struct tcp_pcb *cpcb;
    for (cpcb = tcp_listen_pcbs;cpcb != NULL; cpcb = cpcb->next) {
    	PRINTF("PCB :%p\n",cpcb);
    	if(cpcb -> state == LISTEN && cpcb->local_port == 80) {
    		altcp_close(cpcb);
            PRINTF("PCB LISTEN>>>>\n");
            login_status = 0;
    	}
    }
    if (html_read_buff != NULL) {
    	free(html_read_buff);
    	html_read_buff = NULL;
    	free(http_rx_buf);
    	http_rx_buf = NULL;
    }
}

#endif /* LWIP_TCP && LWIP_CALLBACK_API */
