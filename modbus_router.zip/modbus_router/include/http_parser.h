/**
  **************************
  * @file    http_parser.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 26
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HTTP_PARSER_H_
#define __HTTP_PARSER_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>
#include "modbus_gw_cfg.h"

#define FS_FILE_FLAGS_HEADER_INCLUDED     0x01
#define FS_FILE_FLAGS_HEADER_PERSISTENT   0x02
#define FS_FILE_FLAGS_HEADER_HTTPVER_1_1  0x04
#define FS_FILE_FLAGS_SSI                 0x08

typedef void html_file_extension;

 struct html_file {
   const char *data;
   int len;
   int index;
   html_file_extension *pextension;
   uint8_t flags;
 };

 struct htmldata_file {
   const struct htmldata_file *next;
   const unsigned char *name;
   const unsigned char *data;
   int len;
   uint8_t flags;
 };

uint8_t html_open(struct html_file *file, const char *name);
int html_bytes_left(struct html_file *file);
void html_close(struct html_file *file);

uint8_t verify_login_request(const char *http_buf);
uint16_t build_login_error_page(uint8_t *output_buf);
uint8_t verify_login_request(const char *http_buf);


void parse_gw_network_config(const char *query_string, network_config_t *nwk_cfg);
void parse_gw_serial_config(const char *query_string,char * buff, serial_config_t *out_cfg);
void parse_nat_table_data(const char *query_string, client_gw_t *client_gw_cfg);
void parse_modbus_dev_config(const char *query_string, server_gw_t *server_gw_cfg);

void prepare_device_info_page(char *output, const device_info_t *info);
void prepare_serial_info_page(const char *html_pg, char *output, const serial_config_t *info);
void prepare_nwk_info_page(const char *html_pg, char *output, const network_config_t *info);
void prepare_server_page(const char *html_pg, char *send_html_buf, const server_gw_t *mapping);
void prepare_client_nat_table(const char *html_pg, char *send_html_buf, const client_gw_t *mapping);
void prepare_cfg_success_page(char* output, uint8_t cfg_status);
void prepare_modbus_config(const char* html_pg, char *send_html_buf, uint8_t gw_type);
/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __HTTP_PARSER_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
