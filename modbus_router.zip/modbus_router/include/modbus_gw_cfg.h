/**
  **************************
  * @file    modbus_gw_cfg.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 12
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MODBUS_GW_CFG_H_
#define __MODBUS_GW_CFG_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>

#define LONG_PRESS_TIME_MS                          5000
#define MODIFY_CONFIG_TIMEOUT_IN_MS                 600000 // 2 min

//#define TCP_SERVER_CONNECTION_TIMEOUT_IN_MS         60000 // 1 min
#define DOUBLE_PRESS_WINDOW_MS                      400

#define PORT_UART4_DIR                 GPIO_PORTC
#define PIN_UART4_DIR                  PIN_NUM_13
#define PORT_UART5_DIR                 GPIO_PORTB
#define PIN_UART5_DIR                  PIN_NUM_6

#define PORT_WDI                       GPIO_PORTC
#define PIN_WDI                        PIN_NUM_8

#define PORT_3V8                       GPIO_PORTB
#define PIN_3V8                        PIN_NUM_10
#define PORT_GSM_ON_OFF                GPIO_PORTB
#define PIN_GSM_ON_OFF                 PIN_NUM_9
#define PORT_GSM_RESET                 GPIO_PORTC
#define PIN_GSM_RESET                  PIN_NUM_2

#define ENABLE_PRINTF_ALL              1
#define ENABLE_PRINTF_MODBUS           2
#define DISABLE_ALL_PRINTF             3

#define DEBUG_PRINTF                  DISABLE_ALL_PRINTF//ENABLE_PRINTF_ALL


#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
    #define PRINTF(fmt, ...)            printf(fmt, ##__VA_ARGS__);printf("\r")
    #define MODBUS_PRINTF(fmt, ...)     printf(fmt, ##__VA_ARGS__)
#elif (DEBUG_PRINTF == ENABLE_PRINTF_CRITICAL)
    #define PRINTF(fmt, ...)             // Empty, disabled
    #define MODBUS_PRINTF(fmt, ...)   printf(fmt, ##__VA_ARGS__)
#else
    #define PRINTF(fmt, ...)             // Empty, disabled
    #define MODBUS_PRINTF(fmt, ...)    // Empty, disabled
#endif

#define CONFIG_DONE                1
#define DEVICE_RESET               2
#define FACTORY_DEFAULT            3

#define MAX_NAT_TABLE_COUNT        32

 enum{
     GW_TYPE_SERVER = 0,
     GW_TYPE_CLIENT
 };
 typedef struct {
 	uint8_t mac_address[6];
 	uint8_t device_type_id[10];
 	uint8_t checksum;
 }fresh_device_config_t;

 typedef struct {
   uint8_t major;
   uint8_t minor;
   uint8_t patch;
   uint8_t checksum;
 }firmware_version_t;

 /***** Device info struct *****/
 typedef struct {
     char system_name[32];
     char firmware_version[16];
     char device_health[16];
     char mac_address[20];
     char ipv4_address[16];
     char subnet_mask[16];
     char default_gateway[16];
 } device_info_t;

 /***** Network & GSM config *****/
 typedef struct {
     uint32_t ipv4_address;
     uint32_t subnet_mask;
     uint32_t default_gateway;
 } network_config_t;  // 144 bytes

 /***** Serial port config *****/
 typedef struct {
     uint32_t baud_rate;
     uint8_t data_bits;   // usually 8
     uint8_t stop_bits;   // 1 or 2
     uint8_t parity;      // "N", "E", "O"
 } serial_channel_t;

 typedef struct {
     serial_channel_t channel1;
     serial_channel_t channel2;
 } serial_config_t;  // 20 bytes

 typedef struct {
     uint16_t connection_tmt;
     uint16_t rs485_port1;
     uint16_t rs485_rsp_timeout1;
     uint16_t rs485_port2;
     uint16_t rs485_rsp_timeout2;
 } server_gw_t;

 typedef struct {
      uint8_t slave_id;
      uint32_t ip_address;
      uint16_t port;
      uint16_t rsp_timeout;
 }client_data_t;
 typedef struct {
      uint8_t nat_table_count;
      client_data_t client_gw[MAX_NAT_TABLE_COUNT];
 } client_gw_t;

 typedef struct {
      uint8_t cfg_flg;
      uint8_t gw_type;
      network_config_t nwk_cfg;
      serial_config_t  serial_cfg;
      server_gw_t      server_gw_cfg;
      client_gw_t      client_gw_cfg;
      uint8_t          checksum;
 }modbus_router_t;
/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __MODBUS_GW_CFG_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
