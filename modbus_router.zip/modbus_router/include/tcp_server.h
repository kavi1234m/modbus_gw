/**
  **************************************************************************
  * @file     tcp_server.h
  * @brief    tcp server header
  **************************************************************************
  *                       Copyright notice & Disclaimer
  *
  * The software Board Support Package (BSP) that is made available to
  * download from Artery official website is the copyrighted work of Artery.
  * Artery authorizes customers to use, copy, and distribute the BSP
  * software and its related documentation for the purpose of design and
  * development in conjunction with Artery microcontrollers. Use of the
  * software is governed by this copyright notice and the following disclaimer.
  *
  * THIS SOFTWARE IS PROVIDED ON "AS IS" BASIS WITHOUT WARRANTIES,
  * GUARANTEES OR REPRESENTATIONS OF ANY KIND. ARTERY EXPRESSLY DISCLAIMS,
  * TO THE FULLEST EXTENT PERMITTED BY LAW, ALL EXPRESS, IMPLIED OR
  * STATUTORY OR OTHER WARRANTIES, GUARANTEES OR REPRESENTATIONS,
  * INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
  *
  **************************************************************************
  */

#ifndef _TCP_SERVER_H_
#define _TCP_SERVER_H_

#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>

void tcp_server_init(uint16_t port1, uint16_t port2);
void tcp_server_callback_reg_fun(void (*callbkfun));
int8_t tcp_server_transmit(uint8_t *buffer,uint16_t buffer_len,uint16_t port);
int8_t tcp_server_close(uint16_t port1, uint16_t port2);
void tcp_transmit_retry(void);
void tcp_timeout_monitor(void);

#ifdef __cplusplus
}
#endif

#endif
