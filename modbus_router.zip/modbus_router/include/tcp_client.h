/**
  **************************
  * @file    hal_tcp_client.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    26-03-2025
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __TCP_CLIENT_H_
#define __TCP_CLIENT_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include "lwip/err.h"
#include "lwip/tcp.h"
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

err_t tcp_client_init(uint16_t local_port);
err_t tcp_client_data_transmit(uint8_t *buffer,uint16_t length);
err_t tcp_client_connect(uint32_t server_ip, uint16_t remote_port);
int8_t tcp_client_close(void);
void tcp_client_callback_reg_fun(void *callback);

/*  Functions used to _________________ ***/


/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __TCP_CLIENT_H_ */

/***** (C) COPYRIGHT 2022 Calixto Systems Pvt Ltd ***END OF FILE*/
