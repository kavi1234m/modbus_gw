Middleware/cJSON/cJSON_parser_modbus_gw.o: \
 ../Middleware/cJSON/cJSON_parser_modbus_gw.c \
 ../Middleware/cJSON/cJSON_parser_modbus_gw.h ../include/modbus_gw_cfg.h \
 ../Middleware/cJSON/cJSON.h
../Middleware/cJSON/cJSON_parser_modbus_gw.h:
../include/modbus_gw_cfg.h:
../Middleware/cJSON/cJSON.h:
