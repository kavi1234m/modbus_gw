Middleware/Modbus/server_gw_router.o: \
 ../Middleware/Modbus/server_gw_router.c \
 ../Middleware/Modbus/server_gw_router.h \
 D:\AT32F437_WORKSPACE\modbus_router\Middleware\checksum/checksum.h
../Middleware/Modbus/server_gw_router.h:
D:\AT32F437_WORKSPACE\modbus_router\Middleware\checksum/checksum.h:
