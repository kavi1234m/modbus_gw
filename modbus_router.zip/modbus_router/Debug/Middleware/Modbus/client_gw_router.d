Middleware/Modbus/client_gw_router.o: \
 ../Middleware/Modbus/client_gw_router.c \
 ../Middleware/Modbus/client_gw_router.h \
 D:\AT32F437_WORKSPACE\modbus_router\Middleware\checksum/checksum.h
../Middleware/Modbus/client_gw_router.h:
D:\AT32F437_WORKSPACE\modbus_router\Middleware\checksum/checksum.h:
