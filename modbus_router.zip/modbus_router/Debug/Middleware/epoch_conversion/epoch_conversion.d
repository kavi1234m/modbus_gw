Middleware/epoch_conversion/epoch_conversion.o: \
 ../Middleware/epoch_conversion/epoch_conversion.c \
 ../Middleware/epoch_conversion/epoch_conversion.h \
 D:\AT32F437_WORKSPACE\modbus_router\Hal/hal_rtc.h \
 ../include/modbus_gw_cfg.h
../Middleware/epoch_conversion/epoch_conversion.h:
D:\AT32F437_WORKSPACE\modbus_router\Hal/hal_rtc.h:
../include/modbus_gw_cfg.h:
