Middleware/checksum/checksum.o: ../Middleware/checksum/checksum.c \
 ../Middleware/checksum/checksum.h
../Middleware/checksum/checksum.h:
