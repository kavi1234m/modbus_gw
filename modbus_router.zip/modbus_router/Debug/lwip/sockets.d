lwip/sockets.o: ../lwip/sockets.c \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h \
 ../include/FreeRTOSConfig.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/portable.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h \
 D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/sockets.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/netif.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/err.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/pbuf.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/stats.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/mem.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/memp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/memp_std.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/memp_priv.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/mem_priv.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/inet.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/errno.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/sockets_priv.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/sys.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/sys_arch.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/task.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/list.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/queue.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/task.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/semphr.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/queue.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/api.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/netbuf.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/igmp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcpbase.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/ip4.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/bpstruct.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/epstruct.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/ip.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/icmp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/icmp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/raw.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/udp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/udp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/tcpip_priv.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcpip.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/timeouts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/mld6.h
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h:
D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h:
../include/FreeRTOSConfig.h:
D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h:
D:\AT32F437\lwip_rtos\freertos\source\include/portable.h:
D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h:
D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h:
D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/sockets.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/netif.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/err.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/pbuf.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/stats.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/mem.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/memp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/memp_std.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/memp_priv.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/mem_priv.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/inet.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/errno.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/sockets_priv.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/sys.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/sys_arch.h:
D:\AT32F437\lwip_rtos\freertos\source\include/task.h:
D:\AT32F437\lwip_rtos\freertos\source\include/list.h:
D:\AT32F437\lwip_rtos\freertos\source\include/queue.h:
D:\AT32F437\lwip_rtos\freertos\source\include/task.h:
D:\AT32F437\lwip_rtos\freertos\source\include/semphr.h:
D:\AT32F437\lwip_rtos\freertos\source\include/queue.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/api.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/netbuf.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/igmp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcpbase.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/ip4.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/bpstruct.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/epstruct.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/ip.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/icmp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/icmp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/raw.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/udp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/udp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/tcpip_priv.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcpip.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/timeouts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/mld6.h:
