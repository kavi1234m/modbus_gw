user/main.o: ../user/main.c \
 D:\AT32F437_WORKSPACE\modbus_router\Hal/hal_system_init.h \
 D:\AT32F437_WORKSPACE\modbus_router\Application/application.h
D:\AT32F437_WORKSPACE\modbus_router\Hal/hal_system_init.h:
D:\AT32F437_WORKSPACE\modbus_router\Application/application.h:
