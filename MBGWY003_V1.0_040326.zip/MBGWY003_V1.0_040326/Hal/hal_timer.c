/**
  **************************
  * @file    hal_timer.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 3
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "hal_timer.h"
#include "at32f435_437_tmr.h"
/* Private typedef -----------------------------------------------------------*/
typedef void (*tmr_func_cb)();
tmr_func_cb timer_callback1,timer_callback2;

#define ONE_CYCLE_TIMEOUT         100
#define ONE_CYCLE_DUTY_CYCLE      90
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/****************************************************************************************
  * @brief  Timer callback function.
  * @param  param1: register function for callback
  * @retval None
  ***************************************************************************************/
void timer_callback_register(void *callback_function) {
	timer_callback1 = callback_function;
}
///****************************************************************************************
//  * @brief  Timer callback function.
//  * @param  param1: register function for callback
//  * @retval None
//  ***************************************************************************************/
//void timer2_callback_register(void *callback_function) {
//	timer_callback2 = callback_function;
//}
/****************************************************************************************
  * @brief  function for timer interrupt handler.
  * @param  None
  * @retval None
  ****************************************************************************************/
void TMR1_OVF_TMR10_IRQHandler(void)
{
	if(tmr_interrupt_flag_get(TMR1, TMR_OVF_FLAG) != RESET)
	{
		timer_callback1(TIMER1);
	   // reset the interrupt flag, otherwise continously called by NVIC
	   tmr_flag_clear(TMR1, TMR_OVF_FLAG);
	}
}
/****************************************************************************************
  * @brief  function for timer interrupt handler.
  * @param  None
  * @retval None
  ****************************************************************************************/
void TMR2_GLOBAL_IRQHandler(void)
{
	if(tmr_interrupt_flag_get(TMR2, TMR_OVF_FLAG) != RESET)
	{
		timer_callback1(TIMER2);
	   // reset the interrupt flag, otherwise continously called by NVIC
	   tmr_flag_clear(TMR2, TMR_OVF_FLAG);
	}
}
/****************************************************************************************
  * @brief  function for timer interrupt handler.
  * @param  None
  * @retval None
  ****************************************************************************************/
void TMR3_GLOBAL_IRQHandler(void)
{
	if(tmr_interrupt_flag_get(TMR3, TMR_OVF_FLAG) != RESET)
	{
		timer_callback1(TIMER3);
	   // reset the interrupt flag, otherwise continously called by NVIC
	   tmr_flag_clear(TMR3, TMR_OVF_FLAG);
	}
}
/****************************************************************************************
  * @brief  Timer select function.
  * @param  param1: tmr_x (1 to 14)
  * @retval selected timer -timer_type
  ***************************************************************************************/
tmr_type *timer_select(timer_type tmr_x) {

	tmr_type *selected_tmr;
	switch (tmr_x) {
	    case TIMER1 :
	    	 selected_tmr = TMR1;
	    	 break;
	    case TIMER2 :
	    	 selected_tmr = TMR2;
	    	 break;
	    case TIMER3 :
	    	 selected_tmr = TMR3;
	    	 break;
	    case TIMER4 :
	    	 selected_tmr = TMR4;
	    	 break;
	    case TIMER5 :
	    	 selected_tmr = TMR5;
	    	 break;
	    case TIMER6 :
	    	 selected_tmr = TMR6;
	    	 break;
	    case TIMER7 :
	    	 selected_tmr = TMR7;
	    	 break;
	    case TIMER8 :
	    	 selected_tmr = TMR8;
	    	 break;
	    case TIMER9 :
	    	 selected_tmr = TMR9;
	    	 break;
	    case TIMER10 :
	    	 selected_tmr = TMR10;
	    	 break;
	    case TIMER11 :
	    	 selected_tmr = TMR11;
	    	 break;
	    case TIMER12 :
	    	 selected_tmr = TMR12;
	    	 break;
	    case TIMER13 :
	    	 selected_tmr = TMR13;
	    	 break;
	    case TIMER14 :
	    	 selected_tmr = TMR14;
	    	 break;
	}
	return selected_tmr;
}
/****************************************************************************************
  * @brief  Timer interrupt set function.
  * @param  param1: tmr_x (1 to 14)
  * @retval None
  ***************************************************************************************/
void timer_interrupt_set(timer_type tmr_x) {

	switch (tmr_x) {
	    case TIMER1 :
		     nvic_irq_enable(TMR1_OVF_TMR10_IRQn, 0, 0);
		     break;
		case TIMER2 :
		     nvic_irq_enable(TMR2_GLOBAL_IRQn, 0, 0);
		     break;
		case TIMER3 :
		     nvic_irq_enable(TMR3_GLOBAL_IRQn, 3, 0);
		     break;
		case TIMER4 :
		     nvic_irq_enable(TMR4_GLOBAL_IRQn, 0, 0);
		     break;
		case TIMER5 :
		     nvic_irq_enable(TMR5_GLOBAL_IRQn, 0, 0);
		     break;
		case TIMER6 :
		     nvic_irq_enable(TMR6_DAC_GLOBAL_IRQn, 0, 0);
		     break;
		case TIMER7 :
		     nvic_irq_enable(TMR7_GLOBAL_IRQn, 0, 0);
		     break;
		case TIMER8 :
		     nvic_irq_enable(TMR8_OVF_TMR13_IRQn, 0, 0);
		     break;
		case TIMER9 :
		     nvic_irq_enable(TMR1_BRK_TMR9_IRQn, 0, 0);
		     break;
		case TIMER10 :
		     nvic_irq_enable(TMR1_OVF_TMR10_IRQn, 0, 0);
		     break;
		case TIMER11 :
		     nvic_irq_enable(TMR1_TRG_HALL_TMR11_IRQn, 0, 0);
		     break;
		case TIMER12 :
		     nvic_irq_enable(TMR8_BRK_TMR12_IRQn, 0, 0);
		     break;
		case TIMER13 :
		     nvic_irq_enable(TMR8_OVF_TMR13_IRQn, 0, 0);
		     break;
		case TIMER14 :
		     nvic_irq_enable(TMR8_TRG_HALL_TMR14_IRQn, 0, 0);
		     break;
		}
}
/****************************************************************************************
  * @brief  Timer clock enable function.
  * @param  param1: tmr_x (1 to 14)
  * @retval None
  ***************************************************************************************/
void timer_clock_enable(timer_type tmr_x) {

	switch (tmr_x) {
	    case TIMER1 :
	    	 crm_periph_clock_enable(CRM_TMR1_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER2 :
			 crm_periph_clock_enable(CRM_TMR2_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER3 :
			 crm_periph_clock_enable(CRM_TMR3_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER4 :
			 crm_periph_clock_enable(CRM_TMR4_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER5 :
			 crm_periph_clock_enable(CRM_TMR5_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER6 :
			 crm_periph_clock_enable(CRM_TMR6_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER7 :
		   	 crm_periph_clock_enable(CRM_TMR7_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER8 :
			 crm_periph_clock_enable(CRM_TMR8_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER9 :
			 crm_periph_clock_enable(CRM_TMR9_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER10 :
			 crm_periph_clock_enable(CRM_TMR10_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER11 :
			 crm_periph_clock_enable(CRM_TMR11_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER12 :
			 crm_periph_clock_enable(CRM_TMR12_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER13 :
			 crm_periph_clock_enable(CRM_TMR13_PERIPH_CLOCK, TRUE);
		     break;
		case TIMER14 :
			 crm_periph_clock_enable(CRM_TMR14_PERIPH_CLOCK, TRUE);
		     break;
		}
}
/****************************************************************************************
  * @brief  Timer Enable disable.
  * @param  param1: tmr_x (1 to 14)
  * @param  param2: new_state (1-enable 0-disable)
  * @retval None
  ***************************************************************************************/
void hal_timer_enable_disable(timer_type tmr_x,uint8_t new_state) {

	tmr_type *timer = timer_select(tmr_x);
	tmr_interrupt_enable(timer, TMR_OVF_INT, new_state);
	tmr_counter_enable(timer, new_state);
}
/****************************************************************************************
  * @brief  Timer interrupt enable disable function.
  * @param  param1: tmr_x (1 to 14)
  * @param  param2: new_state (1-enable 0-disable)
  * @retval None
  ***************************************************************************************/
void hal_timer_interrupt_enable(timer_type tmr_x, uint8_t new_state) {

	tmr_type *timer = timer_select(tmr_x);
	tmr_interrupt_enable(timer, TMR_OVF_INT, new_state);
}
/****************************************************************************************
  * @brief  Timer init function.
  * @param  param1: tmr_pr  - Period register
  * @param  param2: tmr_div - Divider register
  * @retval None
  ***************************************************************************************/
void hal_timer_init(timer_type tmr_x, uint32_t time_in_ms) {

	crm_clocks_freq_type crm_clocks_freq_struct = {0};
	crm_clocks_freq_get(&crm_clocks_freq_struct);
	time_in_ms = time_in_ms * 10;
	tmr_type *timer = timer_select(tmr_x);
	timer_clock_enable(tmr_x);
	tmr_base_init(timer, (time_in_ms-1), ((crm_clocks_freq_struct.apb2_freq * 2 / 10000) - 1));
	tmr_cnt_dir_set(timer, TMR_COUNT_UP);
	tmr_flag_clear(timer, TMR_OVF_FLAG);
	/**** tmr interrupt******/
	tmr_interrupt_enable(timer, TMR_OVF_INT, FALSE);
	timer_interrupt_set(tmr_x);
	tmr_counter_enable(timer, FALSE);
}
/****************************************************************************************
  * @brief  Timer Pwm init function
  * @param  param1: tmr_pr  - Period register
  * @param  param2: tmr_div - Divider register
  * @retval None
  ***************************************************************************************/
void hal_timer_pwm_cfg(timer_type tmr_x, uint32_t time_in_ms, float duty_cycle) {

	tmr_type *timer = timer_select(tmr_x);
	tmr_reset(timer);
	gpio_init_type gpio_init_struct;
	gpio_default_para_init(&gpio_init_struct);
	gpio_init_struct.gpio_pins = GPIO_PINS_7;
	gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
    gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
	gpio_init(GPIOB, &gpio_init_struct);
	gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE7, GPIO_MUX_2);

	crm_clocks_freq_type crm_clocks_freq_struct = {0};
	tmr_output_config_type  tmr_output_struct = {0};
	crm_clocks_freq_get(&crm_clocks_freq_struct);
	uint16_t channel1pulse = 0;
	time_in_ms = time_in_ms * 10;
	timer_clock_enable(tmr_x);
	  /* tmr1 configuration ---------------------------------------------------
	   generate 7 pwm signals with 4 different duty cycles:
	   prescaler = 0, tmr1 counter clock = apb2_freq *2

	   the objective is to generate 7 pwm signal at 17.57 khz:
	     - tim1_period = (apb2_freq * 2 / 17570) - 1
	   the channel 1 and channel 1n duty cycle is set to 50%
	   the channel 2 and channel 2n duty cycle is set to 37.5%
	   the channel 3 and channel 3n duty cycle is set to 25%
	   the channel 4 duty cycle is set to 12.5%
	   the timer pulse is calculated as follows:
	     - channelxpulse = dutycycle * (tim1_period - 1) / 100
	  ----------------------------------------------------------------------- */
     channel1pulse = (uint16_t) (((uint32_t) (float) duty_cycle * (time_in_ms - 1)) / 100); // 85.7%
//     printf("Channel 1 pulse :%u\n",channel1pulse);
     tmr_base_init(timer, (time_in_ms-1), (((crm_clocks_freq_struct.apb1_freq * 2) / 10000 ) - 1));
     tmr_cnt_dir_set(timer, TMR_COUNT_UP);

     tmr_output_default_para_init(&tmr_output_struct);
     tmr_output_struct.oc_mode = TMR_OUTPUT_CONTROL_PWM_MODE_B;
     tmr_output_struct.oc_output_state = TRUE;
     tmr_output_struct.oc_polarity = TMR_OUTPUT_ACTIVE_LOW;
     tmr_output_struct.oc_idle_state = TRUE;
     tmr_output_struct.occ_output_state = TRUE;
     tmr_output_struct.occ_polarity = TMR_OUTPUT_ACTIVE_HIGH;
     tmr_output_struct.occ_idle_state = FALSE;

     tmr_output_channel_config(timer, TMR_SELECT_CHANNEL_2, &tmr_output_struct);
     tmr_channel_value_set(timer, TMR_SELECT_CHANNEL_2, channel1pulse);

     tmr_output_enable(timer, TRUE);
     tmr_counter_enable(timer, TRUE);
}
/****************************************************************************************
  * @brief  Timer init one cycle mode
  * @param  None
  * @retval None
  ***************************************************************************************/
void hal_timer_one_cycle_mode_init(void) {

	crm_periph_clock_enable(CRM_TMR12_PERIPH_CLOCK, TRUE);
	crm_periph_clock_enable(CRM_TMR3_PERIPH_CLOCK, TRUE);
	crm_periph_clock_enable(CRM_TMR8_PERIPH_CLOCK, TRUE);
	gpio_init_type gpio_init_struct;
	gpio_default_para_init(&gpio_init_struct);
	gpio_init_struct.gpio_pins = GPIO_PINS_9;
	gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
    gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
	gpio_init(GPIOC, &gpio_init_struct);

	gpio_init_struct.gpio_pins = GPIO_PINS_14 | GPIO_PINS_15;
	gpio_init(GPIOB, &gpio_init_struct);
	gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE9, GPIO_MUX_2);
	gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE14, GPIO_MUX_3);
	gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE15, GPIO_MUX_9);

	crm_clocks_freq_type crm_clocks_freq_struct = {0};
	tmr_output_config_type  tmr_output_struct = {0};
	crm_clocks_freq_get(&crm_clocks_freq_struct);
	uint16_t channel1pulse = 0;
	uint16_t time_in_ms = ONE_CYCLE_TIMEOUT * 10;

     channel1pulse = (uint16_t) (((float) ONE_CYCLE_DUTY_CYCLE * (time_in_ms - 1)) / 100); // 85.7%
//     printf("Channel 1 pulse :%u\n",channel1pulse);
     tmr_base_init(TMR12, (time_in_ms-1), (((crm_clocks_freq_struct.apb1_freq * 2) / 10000 ) - 1));
     tmr_cnt_dir_set(TMR12, TMR_COUNT_UP);

     tmr_base_init(TMR3, (time_in_ms-1), (((crm_clocks_freq_struct.apb1_freq * 2) / 10000 ) - 1));
     tmr_cnt_dir_set(TMR3, TMR_COUNT_UP);

     tmr_base_init(TMR8, (time_in_ms-1), (((crm_clocks_freq_struct.apb1_freq * 2) / 10000 ) - 1));
     tmr_cnt_dir_set(TMR8, TMR_COUNT_UP);

     tmr_output_default_para_init(&tmr_output_struct);

     tmr_output_struct.oc_mode = TMR_OUTPUT_CONTROL_PWM_MODE_B;
     tmr_output_struct.oc_idle_state = FALSE;
     tmr_output_struct.oc_polarity = TMR_OUTPUT_ACTIVE_HIGH;
     tmr_output_struct.oc_output_state = TRUE;

     tmr_output_channel_config(TMR12, TMR_SELECT_CHANNEL_2, &tmr_output_struct);
     tmr_channel_value_set(TMR12, TMR_SELECT_CHANNEL_2, channel1pulse);

     tmr_output_channel_config(TMR3, TMR_SELECT_CHANNEL_4, &tmr_output_struct);
     tmr_channel_value_set(TMR3, TMR_SELECT_CHANNEL_4, channel1pulse);

     tmr_output_struct.occ_idle_state = FALSE;
     tmr_output_struct.occ_polarity = TMR_OUTPUT_ACTIVE_LOW;
     tmr_output_struct.occ_output_state = TRUE;

     tmr_output_channel_config(TMR8, TMR_SELECT_CHANNEL_2, &tmr_output_struct);
     tmr_channel_value_set(TMR8, TMR_SELECT_CHANNEL_2, channel1pulse);

     tmr_output_enable(TMR8, TRUE);
     /* one cycle mode selection */
     tmr_one_cycle_mode_enable(TMR3, TRUE);
     tmr_one_cycle_mode_enable(TMR8, TRUE);
     tmr_one_cycle_mode_enable(TMR12, TRUE);

     tmr_counter_enable(TMR3, TRUE);
     tmr_counter_enable(TMR8, TRUE);
     tmr_counter_enable(TMR12, TRUE);
}
/****************************************************************************************
  * @brief  Timer one cycle mode
  * @param  param1: tmr_x (1 to 14)
  * @retval None
  ***************************************************************************************/
void hal_timer_one_cycle_mode_set(uint8_t pin_type) {

	switch (pin_type) {
        case 1 : tmr_counter_enable(TMR3,TRUE);
    	         break;
	    case 2 : tmr_counter_enable(TMR8,TRUE);
		         break;
	    case 3 : tmr_counter_enable(TMR12,TRUE);
	    	     break;
	    default:
	    	break;
	}
}
/****************************************************************************************
  * @brief  Timer deinitialization function.
  * @param  param1: tmr_x (1 to 14)
  * @retval None
  ***************************************************************************************/
void hal_timer_deinit(timer_type tmr_x) {
	tmr_type *timer = timer_select(tmr_x);
	tmr_reset(timer);
}
/****************************************************************************************
  * @brief  Timer counter value get function.
  * @param  param1: tmr_x (1 to 14)
  * @retval counter value
  ***************************************************************************************/
uint32_t hal_timer_counter_value_get(timer_type tmr_x) {
	tmr_type *timer = timer_select(tmr_x);
	 return tmr_counter_value_get(timer);
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
