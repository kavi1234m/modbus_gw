/**
  **************************
  * @file    hal_rtc.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 9
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "hal_rtc.h"

#include <stdio.h>
#include "at32f435_437_ertc.h"
/* Private typedef -----------------------------------------------------------*/
typedef void(*rtc_cbk_fun)();
rtc_cbk_fun rtc_callback;
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
#define ERTC_CLOCK_SOURCE_LEXT           /* select lext as the ertc clock */
//#define ERTC_CLOCK_SOURCE_LICK         /* select lick as the ertc clock */
/* Private variables ---------------------------------------------------------*/
__IO uint16_t ertc_clk_div_a = 0;
__IO uint16_t ertc_clk_div_b = 0;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/***************************************************************************************
  * @brief  configure the ertc peripheral by selecting the clock source.
  * @param  none
  * @retval none
  **************************************************************************************/
void ertc_config(void)
{
  /* enable the pwc clock interface */
  crm_periph_clock_enable(CRM_PWC_PERIPH_CLOCK, TRUE);

  /* allow access to ertc */
  pwc_battery_powered_domain_access(TRUE);

  /* reset ertc domain */
  crm_battery_powered_domain_reset(TRUE);
  crm_battery_powered_domain_reset(FALSE);

#if defined (ERTC_CLOCK_SOURCE_LICK)
  /* enable the lick osc */
  crm_clock_source_enable(CRM_CLOCK_SOURCE_LICK, TRUE);

  /* wait till lick is ready */
  while(crm_flag_get(CRM_LICK_STABLE_FLAG) == RESET)
  {
  }

  /* select the ertc clock source */
  crm_ertc_clock_select(CRM_ERTC_CLOCK_LICK);

  /* ertc second(1hz) = ertc_clk(lick) / (ertc_clk_div_a + 1) * (ertc_clk_div_b + 1) */
  ertc_clk_div_b = 255;
  ertc_clk_div_a = 127;
#elif defined (ERTC_CLOCK_SOURCE_LEXT)
  /* enable the lext osc */
  crm_clock_source_enable(CRM_CLOCK_SOURCE_LEXT, TRUE);

  /* wait till lext is ready */
  while(crm_flag_get(CRM_LEXT_STABLE_FLAG) == RESET)
  {
  }

  /* select the ertc clock source */
  crm_ertc_clock_select(CRM_ERTC_CLOCK_LEXT);

  /* ertc second(1hz) = ertc_clk / (ertc_clk_div_a + 1) * (ertc_clk_div_b + 1) */
  ertc_clk_div_b = 255;
  ertc_clk_div_a = 127;
#endif

  /* enable the ertc clock */
  crm_ertc_clock_enable(TRUE);

  /* deinitializes the ertc registers */
  ertc_reset();

  /* wait for ertc registers update */
  ertc_wait_update();

  /* configure the ertc divider */
  ertc_divider_set(ertc_clk_div_a, ertc_clk_div_b);

  /* configure the ertc hour mode */
  ertc_hour_mode_set(ERTC_HOUR_MODE_24);

  /* set date: 2021-05-01-week */
  ertc_date_set(26, 3, 4, 1);

  /* set time: 12:00:00 */
  ertc_time_set(11, 35, 0, ERTC_AM);

  /* indicator for the ertc configuration */
  ertc_bpr_data_write(ERTC_DT1, 0x1234);
}
/*******************************************************************************
  * @brief  function to get the rtc time and date.
  * @param  calendar_info_t structure, to get time and date info
  * @retval None
  ******************************************************************************/
void hal_rtc_calendar_get(calendar_info_t *calendar_info) {
	ertc_time_type calendar;
	ertc_calendar_get(&calendar);
	calendar_info->year       = calendar.year;
	calendar_info->month      = calendar.month;
	calendar_info->date       = calendar.day;
	calendar_info->hour       = calendar.hour;
	calendar_info->min        = calendar.min;
	calendar_info->sec        = calendar.sec;
	calendar_info->week       = calendar.week;
	calendar_info->am_pm_type = calendar.ampm;
}

/*******************************************************************************
  * @brief  function to set the rtc time and date.
  * @param  calendar_info_t structure, with time and date info
  * @retval 0: set time right.
  *         1: set time failed.
  *******************************************************************************/
uint8_t hal_rtc_calendar_set(calendar_info_t *calendar_info) {
	ertc_time_type calendar;
	calendar.year  = calendar_info->year;
	calendar.month = calendar_info->month;
	calendar.day   = calendar_info->date;
	calendar.hour  = calendar_info->hour;
	calendar.min   = calendar_info->min;
	calendar.sec   = calendar_info->sec;
	calendar.ampm  = calendar_info->am_pm_type;
	calendar.week  = calendar_info->week;
	if (ertc_time_set(calendar.hour, calendar.min, calendar.sec, ERTC_24H)) {
		if (ertc_date_set(calendar.year, calendar.month, calendar.day, calendar.week)) {
			return 1;
		} else {
			return 0;
		}
	} else {
		return 0;
	}
}
/***************************************************************************************
  * @brief  function for initializing the rtc.
  * @param  calendar_info_t structure, with time and date info
  * @retval 1 for rtc is unintialized so updated with new rtc date and time.
  * 		0 for rtc is already initialized.
  ***************************************************************************************/
void hal_rtc_init(void) {
	/* enable the pwc clock interface */
	crm_periph_clock_enable(CRM_PWC_PERIPH_CLOCK, TRUE);
    /* allow access to ertc */
	pwc_battery_powered_domain_access(TRUE);
    if (ertc_bpr_data_read(ERTC_DT1) != 0x1234) {
    	/* printf ertc status */
//	    printf("ertc has not been initialized\r\n\r\n");
	    /* ertc configuration */
	    ertc_config();
    } else {

	    /* printf ertc status */
//	    printf("ertc has been initialized\r\n\r\n");

	    /* wait for ertc registers update */
	    ertc_wait_update();
    }

}
/*****************************************************************************
  * @brief  display the current time.
  * @param  none
  * @retval none
  ******************************************************************************/
void rtc_time_show(void)
{
  ertc_time_type time;

  /* get the current time */
  ertc_calendar_get(&time);

  /* display date format : year-month-day */
//  printf("Time:  %02d-%02d-%02d ",time.year, time.month, time.day);
//
//  /* display time format : hour:min:sec */
//  printf("%02d:%02d:%02d\r\n",time.hour, time.min, time.sec);
}


 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
