/**
  **************************
  * @file    hal_ethernet.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 3
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HAL_ETHERNET_H_
#define __HAL_ETHERNET_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
/* Exported types ------------------------------------------------------------*/

#define STATIC_IP         1
#define DYNAMIC_IP        0

typedef struct{
 	uint8_t ip_mode; // 0 - dyamic, 1 - static
 	uint32_t local_ip;
 	uint32_t local_gw;
 	uint32_t local_mask;
}ip_details_t;

enum {
	ETHERNET_CONNECTED    = 0,
	ETHERNET_DISCONNECTED = 1,
	ETHERNET_START        = 2,
	ETHERNET_STOP         = 3,
};

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/*  Functions used to _________________ ***/

uint8_t hal_rmii_ethernet_init(ip_details_t * ip_details_input);
void hal_ethernet_deinit(void);
void handle_ethernet_connection(void);
void read_ethernet_buffer(void);
/* Initialization and Configuration functions ***********/

#ifdef __cplusplus
}
#endif

#endif /* __HAL_ETHERNET_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
