/**
  **************************************************************************
  * @file     at32_emac.c
  * @version  v2.0.6
  * @date     2022-03-11
  * @brief    emac config program
  **************************************************************************
  *                       Copyright notice & Disclaimer
  *
  * The software Board Support Package (BSP) that is made available to
  * download from Artery official website is the copyrighted work of Artery.
  * Artery authorizes customers to use, copy, and distribute the BSP
  * software and its related documentation for the purpose of design and
  * development in conjunction with Artery microcontrollers. Use of the
  * software is governed by this copyright notice and the following disclaimer.
  *
  * THIS SOFTWARE IS PROVIDED ON "AS IS" BASIS WITHOUT WARRANTIES,
  * GUARANTEES OR REPRESENTATIONS OF ANY KIND. ARTERY EXPRESSLY DISCLAIMS,
  * TO THE FULLEST EXTENT PERMITTED BY LAW, ALL EXPRESS, IMPLIED OR
  * STATUTORY OR OTHER WARRANTIES, GUARANTEES OR REPRESENTATIONS,
  * INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
  *
  **************************************************************************
  */

/* includes ------------------------------------------------------------------*/
#include "at32f435_437_board.h"
#include "lwip/dhcp.h"
#include "at32_emac.h"
#include "FreeRTOS.h"
#include "task.h"
#include "netconf.h"

/** @addtogroup AT32F437_periph_examples
  * @{
  */

/** @addtogroup 437_EMAC_tcp_server
  * @{
  */

typedef void (*ethernet_callback_fun)();
ethernet_callback_fun ethernet_cbk;
/****************************************************************************************
  * @brief  Ethernet callback register function
  * @param  callback function to register
  * @retval None
  ***************************************************************************************/
void ethernet_callback_register(void *callback) {

	ethernet_cbk = callback;
}

/*****************************************************************
  * @brief  this function handles emac handler.
  * @param  none
  * @retval none
  *****************************************************************/
void EMAC_IRQHandler(void)
{
	while(emac_received_packet_size_get() != 0) {
         lwip_pkt_handle();
    }
    /* clear the emac dma rx it pending bits */
    emac_dma_flag_clear(EMAC_DMA_RI_FLAG);
    emac_dma_flag_clear(EMAC_DMA_NIS_FLAG);
}
/** @addtogroup 437_EMAC_tcp_client
  * @{
  */

emac_control_config_type mac_control_para;

/**
  * @brief  enable emac clock and gpio clock
  * @param  none
  * @retval success or error
  */
error_status emac_system_init(void)
{
  error_status status;

  emac_nvic_configuration();

  /* emac periph clock enable */
  crm_periph_clock_enable(CRM_EMAC_PERIPH_CLOCK, TRUE);
  crm_periph_clock_enable(CRM_EMACTX_PERIPH_CLOCK, TRUE);
  crm_periph_clock_enable(CRM_EMACRX_PERIPH_CLOCK, TRUE);

  emac_pins_configuration();
  uint16_t id1 = 0, id2 = 0, id3 = 0, id4 = 0,id5 = 0;

  status = emac_layer2_configuration();

  return status;
}

/**
  * @brief  configures emac irq channel.
  * @param  none
  * @retval none
  */
void emac_nvic_configuration(void)
{

   nvic_irq_enable(EMAC_IRQn, 4, 0);

}

/**
  * @brief  configures emac required pins.
  * @param  none
  * @retval none
  */
void emac_pins_configuration(void)
{
  gpio_init_type gpio_init_struct = {0};

  /* emac pins clock enable */
  crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);
  crm_periph_clock_enable(CRM_GPIOB_PERIPH_CLOCK, TRUE);
  crm_periph_clock_enable(CRM_GPIOC_PERIPH_CLOCK, TRUE);

  /* pa2 -> mdio */
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE2, GPIO_MUX_11);
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
  gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_pins = GPIO_PINS_2;
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init(GPIOA, &gpio_init_struct);

  /* pc1 -> mdc */
  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE1, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_1;
  gpio_init(GPIOC, &gpio_init_struct);

  #ifdef MII_MODE
  /*
    pb12 -> tx_d0
    pb13 -> tx_d1
    pc2  -> tx_d2
    pb8  -> tx_d3
    pb11 -> tx_en
    pc3  -> tx_clk
  */
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE8, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE11, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE12, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE13, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_8 | GPIO_PINS_11 | GPIO_PINS_12 | GPIO_PINS_13;
  gpio_init(GPIOB, &gpio_init_struct);

  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE2, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE3, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_2 | GPIO_PINS_3;
  gpio_init(GPIOC, &gpio_init_struct);

  /*
    pd8  -> rx_dv
    pd9  -> rx_d0
    pd10 -> rx_d1
    pd11 -> rx_d2
    pd12 -> rx_d3
  */
  gpio_pin_mux_config(GPIOD, GPIO_PINS_SOURCE8, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOD, GPIO_PINS_SOURCE9, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOD, GPIO_PINS_SOURCE10, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOD, GPIO_PINS_SOURCE11, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOD, GPIO_PINS_SOURCE12, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_8 | GPIO_PINS_9 | GPIO_PINS_10 | GPIO_PINS_11 | GPIO_PINS_12;
  gpio_init(GPIOD, &gpio_init_struct);

  /*
    pa1  -> rx_clk
    pa0  -> crs
    pa3  -> col
    pb10 -> rx_er
  */
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE0, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE1, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE3, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_0 | GPIO_PINS_1 | GPIO_PINS_3;
  gpio_init(GPIOA, &gpio_init_struct);

  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE10, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_10;
  gpio_init(GPIOB, &gpio_init_struct);
  #endif  /* MII_MODE */

  #ifdef RMII_MODE
  /*
    pb12 -> tx_d0
    pb13 -> tx_d1
    pb11 -> tx_en
  */
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE11, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE12, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE13, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_11 | GPIO_PINS_12 | GPIO_PINS_13;
  gpio_init(GPIOB, &gpio_init_struct);

  /*
    pa7  -> crs_dv
    pc4  -> rx_d0
    pc5  -> rx_d1
  */
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE7, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_7;
  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
  gpio_init(GPIOA, &gpio_init_struct);

  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE4, GPIO_MUX_11);
  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE5, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_4 | GPIO_PINS_5;
  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
  gpio_init(GPIOC, &gpio_init_struct);


  #endif  /* RMII_MODE */
  /*
    pa1  -> ref_clk
  */
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE1, GPIO_MUX_11);
  gpio_init_struct.gpio_pins = GPIO_PINS_1;
  gpio_init(GPIOA, &gpio_init_struct);

  #if !CRYSTAL_ON_PHY
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE8, GPIO_MUX_0);
  gpio_init_struct.gpio_pins = GPIO_PINS_8;
  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
  gpio_init(GPIOA, &gpio_init_struct);
  #endif
}

/**
  * @brief  configures emac layer2
  * @param  none
  * @retval error or success
  */
error_status emac_layer2_configuration(void)
{
  emac_dma_config_type dma_control_para;
  crm_periph_clock_enable(CRM_SCFG_PERIPH_CLOCK, TRUE);
  #ifdef MII_MODE
  scfg_emac_interface_set(SCFG_EMAC_SELECT_MII);
  #elif defined RMII_MODE
  scfg_emac_interface_set(SCFG_EMAC_SELECT_RMII);
  #endif
#if !CRYSTAL_ON_PHY
  crm_clock_out1_set(CRM_CLKOUT1_PLL);
  crm_clkout_div_set(CRM_CLKOUT_INDEX_1, CRM_CLKOUT_DIV1_5, CRM_CLKOUT_DIV2_1);
#endif

  /* reset phy */
//  reset_phy();
//  if(emac_phy_register_write(PHY_ADDRESS, PHY_CONTROL_REG, PHY_RESET_BIT) == ERROR)
//  {
////    printf("Reset Error\n");
//  }
  /* reset emac ahb bus */
  emac_reset();

  /* software reset emac dma */
  emac_dma_software_reset_set();

  while(emac_dma_software_reset_get() == SET);

  emac_control_para_init(&mac_control_para);

  mac_control_para.auto_nego = EMAC_AUTO_NEGOTIATION_ON;
#ifdef CHECKSUM_BY_HARDWARE
  mac_control_para.ipv4_checksum_offload = TRUE;
#else
  mac_control_para.ipv4_checksum_offload = FALSE;
#endif

  if(emac_phy_init(&mac_control_para) == ERROR)
  {
    return ERROR;
  }

  emac_dma_para_init(&dma_control_para);

  dma_control_para.rsf_enable = TRUE;
  dma_control_para.tsf_enable = TRUE;
  dma_control_para.osf_enable = TRUE;
  dma_control_para.aab_enable = TRUE;
  dma_control_para.usp_enable = TRUE;
  dma_control_para.fb_enable = TRUE;
  dma_control_para.flush_rx_disable = TRUE;
  dma_control_para.rx_dma_pal = EMAC_DMA_PBL_32;
  dma_control_para.tx_dma_pal = EMAC_DMA_PBL_32;
  dma_control_para.priority_ratio = EMAC_DMA_2_RX_1_TX;

  emac_dma_config(&dma_control_para);
  emac_dma_interrupt_enable(EMAC_DMA_INTERRUPT_NORMAL_SUMMARY, TRUE);
  emac_dma_interrupt_enable(EMAC_DMA_INTERRUPT_RX, TRUE);

  return SUCCESS;
}

/**
  * @brief  reset phy register
  * @param  none
  * @retval SUCCESS or ERROR
  */
error_status emac_phy_register_reset(void)
{
  uint16_t data = 0;
  uint32_t timeout = 0;
  uint32_t i = 0;

  if(emac_phy_register_write(PHY_ADDRESS, PHY_CONTROL_REG, PHY_RESET_BIT) == ERROR)
  {
    return ERROR;
  }
  for(i = 0; i < 0x000FFFFF; i++);

  do
  {
    timeout++;
    if(emac_phy_register_read(PHY_ADDRESS, PHY_CONTROL_REG, &data) == ERROR)
    {
      return ERROR;
    }
  } while((data & PHY_RESET_BIT) && (timeout < PHY_TIMEOUT));

  for(i = 0; i < 0x00FFFFF; i++);
  if(timeout == PHY_TIMEOUT)
  {
    return ERROR;
  }
  return SUCCESS;
}

/**
  * @brief  set mac speed related parameters
  * @param  nego: auto negotiation on or off.
  *         this parameter can be one of the following values:
  *         - EMAC_AUTO_NEGOTIATION_OFF
  *         - EMAC_AUTO_NEGOTIATION_ON.
  * @param  mode: half-duplex or full-duplex.
  *         this parameter can be one of the following values:
  *         - EMAC_HALF_DUPLEX
  *         - EMAC_FULL_DUPLEX.
  * @param  speed: 10 mbps or 100 mbps
  *         this parameter can be one of the following values:
  *         - EMAC_SPEED_10MBPS
  *         - EMAC_SPEED_100MBPS.
  * @retval none
  */
error_status emac_speed_config(emac_auto_negotiation_type nego, emac_duplex_type mode, emac_speed_type speed)
{
  uint16_t data = 0;
  uint32_t timeout = 0;
  if(nego == EMAC_AUTO_NEGOTIATION_ON)
  {
    do
    {
      timeout++;
      if(emac_phy_register_read(PHY_ADDRESS, PHY_STATUS_REG, &data) == ERROR)
      {
        return ERROR;
      }
    } while(!(data & PHY_LINKED_STATUS_BIT) && (timeout < PHY_TIMEOUT));

    if(timeout == PHY_TIMEOUT)
    {
      return ERROR;
    }

    timeout = 0;

    if(emac_phy_register_write(PHY_ADDRESS, PHY_CONTROL_REG, PHY_AUTO_NEGOTIATION_BIT) == ERROR)
    {
      return ERROR;
    }


    do
    {
      timeout++;
      if(emac_phy_register_read(PHY_ADDRESS, PHY_STATUS_REG, &data) == ERROR)
      {
        return ERROR;
      }
    } while(!(data & PHY_NEGO_COMPLETE_BIT) && (timeout < PHY_TIMEOUT));

    if(timeout == PHY_TIMEOUT)
    {
      return ERROR;
    }

    if(emac_phy_register_read(PHY_ADDRESS, PHY_SPECIFIED_CS_REG, &data) == ERROR)
    {
      return ERROR;
    }
    #ifdef DM9162
    if(data & PHY_FULL_DUPLEX_100MBPS_BIT)
    {
      emac_fast_speed_set(EMAC_SPEED_100MBPS);
      emac_duplex_mode_set(EMAC_FULL_DUPLEX);
    }
    else if(data & PHY_HALF_DUPLEX_100MBPS_BIT)
    {
      emac_fast_speed_set(EMAC_SPEED_100MBPS);
      emac_duplex_mode_set(EMAC_HALF_DUPLEX);
    }
    else if(data & PHY_FULL_DUPLEX_10MBPS_BIT)
    {
      emac_fast_speed_set(EMAC_SPEED_10MBPS);
      emac_duplex_mode_set(EMAC_FULL_DUPLEX);
    }
    else if(data & PHY_HALF_DUPLEX_10MBPS_BIT)
    {
      emac_fast_speed_set(EMAC_SPEED_10MBPS);
      emac_duplex_mode_set(EMAC_HALF_DUPLEX);
    }
    #else
    if(data & PHY_DUPLEX_MODE)
    {
      emac_duplex_mode_set(EMAC_FULL_DUPLEX);
    }
    else
    {
      emac_duplex_mode_set(EMAC_HALF_DUPLEX);
    }
    if(data & PHY_SPEED_MODE)
    {
      emac_fast_speed_set(EMAC_SPEED_10MBPS);
    }
    else
    {
      emac_fast_speed_set(EMAC_SPEED_100MBPS);
    }
    #endif
  }
  else
  {
    if(emac_phy_register_write(PHY_ADDRESS, PHY_CONTROL_REG, (uint16_t)((mode << 8) | (speed << 13))) == ERROR)
    {
      return ERROR;
    }
    if(speed == EMAC_SPEED_100MBPS)
    {
      emac_fast_speed_set(EMAC_SPEED_100MBPS);
    }
    else
    {
      emac_fast_speed_set(EMAC_SPEED_10MBPS);
    }
    if(mode == EMAC_FULL_DUPLEX)
    {
      emac_duplex_mode_set(EMAC_FULL_DUPLEX);
    }
    else
    {
      emac_duplex_mode_set(EMAC_HALF_DUPLEX);
    }
  }

  return SUCCESS;
}

/**
  * @brief  initialize emac phy
  * @param  none
  * @retval SUCCESS or ERROR
  */
error_status emac_phy_init(emac_control_config_type *control_para)
{
  emac_clock_range_set();
  if(emac_phy_register_reset() == ERROR)
  {
    return ERROR;
  }

  emac_control_config(control_para);
  return SUCCESS;
}

/**
  * @brief  updates the link states
  * @param  none
  * @retval link state 0: disconnect, 1: connection
  */
uint16_t link_update(void)
{
  uint16_t link_data, link_state;
  if(emac_phy_register_read(PHY_ADDRESS, PHY_STATUS_REG, &link_data) == ERROR)
  {
    return ERROR;
  }
  
  link_state = (link_data & PHY_LINKED_STATUS_BIT)>>2;
  return link_state;
}

/**
  * @brief  this function sets the netif link status.
  * @param  netif: the network interface
  * @retval none
  */  
void ethernetif_set_link(void const *argument)
{
  uint16_t regvalue = 0;
  struct netif *netif = (struct netif *)argument;
  
  /* read phy_bsr*/
  regvalue = link_update();

  /* check whether the netif link down and the phy link is up */
  if(!netif_is_link_up(netif) && (regvalue))
  {
//	  printf("link up\n");
    /* network cable is connected */
      netif_set_link_up(netif);
      ethernet_cbk(1);
  }
  else if(netif_is_link_up(netif) && (!regvalue))
  {
//	  printf("link down\n");
    /* network cable is dis-connected */
    netif_set_link_down(netif); // netif_is_up();
    ethernet_cbk(0);
  }
}

/**
  * @brief  this function notify user about link status changement.
  * @param  netif: the network interface
  * @retval none
  */
void ethernetif_notify_conn_changed(struct netif *netif)
{
  /* note : this is function could be implemented in user file 
            when the callback is needed,
  */

  if (netif_is_link_up(netif)) {
    netif_set_up(netif);

#if LWIP_DHCP
    /*  creates a new dhcp client for this interface on the first call.
    note: you must call dhcp_fine_tmr() and dhcp_coarse_tmr() at
    the predefined regular intervals after starting the client.
    you can peek in the netif->dhcp struct for the actual dhcp status.*/
    dhcp_start(netif);
#endif
  }
  else
    netif_set_down(netif);
}

/**
  * @brief  link callback function, this function is called on change of link status
  *         to update low level driver configuration.
  * @param  netif: the network interface
  * @retval none
  */
void ethernetif_update_config(struct netif *netif)
{
  if(netif_is_link_up(netif))
  { 
    emac_speed_config(mac_control_para.auto_nego, mac_control_para.duplex_mode, mac_control_para.fast_ethernet_speed);
    
    vTaskDelay(300);
    /* enable mac and dma transmission and reception */
    emac_start();
  }
  else
  {
    /* disable mac and dma transmission and reception */
    emac_stop(); 
  }

  ethernetif_notify_conn_changed(netif);
}
