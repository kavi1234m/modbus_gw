/**
 * @file
 * LWIP HTTP server implementation
 */

/*
 * Copyright (c) 2001-2003 Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * This file is part of the lwIP TCP/IP stack.
 *
 * Author: Adam Dunkels <adam@sics.se>
 *         Simon Goldschmidt
 *
 */

//#include <modbus_router_cfg.h>
#include "lwip/init.h"
#include "lwip/apps/httpd.h"
#include "lwip/debug.h"
#include "lwip/stats.h"
#include "lwip/apps/fs.h"
#include "httpd_structs.h"
#include "lwip/def.h"
#include <strings.h>
#include <string.h>

#include "task.h"

#include "lwip/altcp.h"
#include "lwip/altcp_tcp.h"

#include <string.h> /* memset */
#include <stdlib.h> /* atoi */
#include <stdio.h>

//#include "at32f435_437_board.h"
#include "cs_db.h"
#include "http_parser.h"
#include "spi_flash.h"
#include "checksum.h"
#include "hal_uart.h"
#include "html_to_spi_flash.h"

//#define BUFFER_SIZE 110000
#define HTML_BUFFER_SIZE     102400
#define HTML_CSS_SIZE        11264
#define HTTP_RX_BUF_SIZE     9216  // Large enough for long GET/POST requests

uint8_t login_status;
char *html_read_buff = NULL;
char *http_rx_buf = NULL;
uint8_t *html_css = NULL;
uint8_t http_ok;
uint16_t calculated_length;
uint8_t http_req_type;

typedef enum {
    HTTP_REQ_INVALID = 0,
    HTTP_REQ_GET,
    HTTP_REQ_POST,
    HTTP_REQ_POST_UPLOAD
} http_req_type_t;

extern modbus_cfg_t modbus_data;


const unsigned char logo_png[] = {
  0x48, 0x54, 0x54, 0x50, 0x2F, 0x31, 0x2E, 0x30, 0x20, 0x32, 0x30, 0x30,
  0x20, 0x4F, 0x4B, 0x0D, 0x0A,
  0x43, 0x6F, 0x6E, 0x74, 0x65, 0x6E, 0x74, 0x2D, 0x54, 0x79, 0x70, 0x65,
  0x3A, 0x20, 0x74, 0x65, 0x78, 0x74, 0x2F, 0x68, 0x74, 0x6D, 0x6C, 0x0D,
  0x0A, 0x0D, 0x0A,
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
  0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0xba, 0x00, 0x00, 0x00, 0x42,
  0x08, 0x03, 0x00, 0x00, 0x00, 0xd7, 0x11, 0x3c, 0xb7, 0x00, 0x00, 0x00,
  0x3c, 0x50, 0x4c, 0x54, 0x45, 0x00, 0x00, 0x00, 0x3e, 0x3e, 0x40, 0x1d,
  0x1e, 0x70, 0x3a, 0x3b, 0x42, 0x09, 0xaf, 0x4e, 0x7a, 0xc4, 0x42, 0x0d,
  0x39, 0x85, 0x57, 0x58, 0x59, 0x39, 0x39, 0x3f, 0x5a, 0xbb, 0x48, 0x39,
  0x39, 0x3e, 0x01, 0x5a, 0xa5, 0x39, 0x39, 0x3f, 0x38, 0x38, 0x41, 0x56,
  0x57, 0x59, 0x33, 0xb6, 0x4a, 0x57, 0x58, 0x5a, 0x33, 0x76, 0x69, 0x32,
  0xb2, 0x48, 0x07, 0x60, 0xa2, 0x50, 0x16, 0xcf, 0x77, 0x00, 0x00, 0x00,
  0x14, 0x74, 0x52, 0x4e, 0x53, 0x00, 0xfc, 0xfe, 0x0f, 0xfe, 0xfe, 0xfe,
  0x22, 0x3a, 0xfd, 0xc5, 0xfd, 0x8c, 0x62, 0x74, 0xfe, 0xb6, 0xff, 0x57,
  0x4a, 0x53, 0xdf, 0x89, 0xaa, 0x00, 0x00, 0x06, 0xb9, 0x49, 0x44, 0x41,
  0x54, 0x78, 0x9c, 0xed, 0x9a, 0x8b, 0x72, 0xf2, 0x2a, 0x10, 0x80, 0xa3,
  0x6b, 0x05, 0x29, 0xc4, 0x44, 0xdf, 0xff, 0x5d, 0x7f, 0xf6, 0xc2, 0x35,
  0x90, 0x60, 0x6b, 0xe7, 0xb4, 0x33, 0x67, 0xa7, 0xd5, 0x24, 0xdc, 0x3e,
  0x96, 0x65, 0x59, 0x88, 0xd3, 0xd4, 0x91, 0xc7, 0xe3, 0xc3, 0xcb, 0xa3,
  0x97, 0xfc, 0x7b, 0x85, 0xc1, 0x09, 0xfe, 0xf9, 0x5f, 0xb3, 0xbc, 0x22,
  0x2a, 0x72, 0x33, 0xfc, 0x9f, 0x51, 0xfd, 0xa3, 0x04, 0xf7, 0x72, 0xbb,
  0xfd, 0x09, 0xf8, 0xc7, 0xad, 0x06, 0x17, 0xf8, 0x5f, 0x4e, 0xff, 0xe8,
  0x81, 0xa3, 0xfc, 0x66, 0xf8, 0x07, 0x23, 0x76, 0xd9, 0xef, 0xf7, 0xdf,
  0x09, 0xff, 0x78, 0xdc, 0xbb, 0xe4, 0x11, 0xdd, 0xc3, 0xbf, 0x93, 0x5e,
  0xc3, 0x1b, 0x2a, 0xf1, 0xe0, 0xf7, 0x21, 0xf4, 0xfb, 0x65, 0x0b, 0xaf,
  0x9d, 0x45, 0x71, 0x5a, 0x0d, 0x12, 0x1b, 0xa3, 0xf1, 0xdb, 0x9e, 0x4e,
  0xae, 0x9b, 0x49, 0x69, 0xa7, 0x47, 0xb8, 0x2f, 0x97, 0x7b, 0x03, 0x3d,
  0xbb, 0xce, 0xd0, 0xbd, 0xe4, 0xf0, 0x60, 0xcd, 0x29, 0x8a, 0x1d, 0x68,
  0x6d, 0x9a, 0x1c, 0x23, 0x6b, 0x2c, 0xd1, 0xd5, 0x3b, 0x9c, 0x4e, 0x66,
  0x04, 0xbc, 0x85, 0x7e, 0xfb, 0xf4, 0xb2, 0xde, 0x6a, 0xb5, 0x5f, 0x4a,
  0x76, 0x7b, 0x2a, 0xc5, 0x0e, 0xd8, 0xc0, 0xdb, 0xd0, 0x2f, 0x81, 0xfc,
  0x9e, 0x91, 0xdf, 0xd6, 0xcf, 0x20, 0x44, 0xdf, 0x41, 0x07, 0xd6, 0xb8,
  0xb7, 0x15, 0xed, 0xad, 0x86, 0x6f, 0x8e, 0x15, 0x2f, 0xe8, 0x58, 0xd8,
  0x76, 0x33, 0x7d, 0x11, 0xfd, 0xb6, 0x5e, 0xaf, 0x9f, 0x99, 0x20, 0x7d,
  0x0b, 0x9d, 0xf4, 0x66, 0x5c, 0xd4, 0x9c, 0xa6, 0x31, 0xe8, 0xdb, 0x6f,
  0x89, 0xee, 0x2f, 0x76, 0xba, 0xf9, 0x3a, 0x3a, 0x73, 0xb3, 0x14, 0xf0,
  0x0d, 0x74, 0x20, 0x8d, 0x17, 0x95, 0x69, 0x33, 0xc0, 0xee, 0x06, 0xba,
  0xf7, 0x1a, 0x3a, 0x91, 0x27, 0xf0, 0x0d, 0xfd, 0x9d, 0xd8, 0x33, 0x74,
  0xd3, 0x30, 0x0f, 0x65, 0x8e, 0x9b, 0xfc, 0x11, 0xf4, 0xf5, 0x7a, 0x3e,
  0x9f, 0xaf, 0x95, 0xe4, 0xf4, 0x39, 0xba, 0x6d, 0x1b, 0xb6, 0x31, 0xd5,
  0xd4, 0x53, 0xf5, 0x54, 0x1c, 0x42, 0x9f, 0x5a, 0xe8, 0x50, 0x56, 0x95,
  0xd0, 0xd7, 0x73, 0x94, 0x1e, 0xfe, 0x7a, 0x89, 0xde, 0x11, 0x36, 0xd6,
  0x22, 0xa4, 0x45, 0x5b, 0xce, 0xe0, 0x30, 0xf0, 0x7c, 0xd0, 0x8e, 0xa7,
  0x45, 0x40, 0xe7, 0x7b, 0x6d, 0x5d, 0xd6, 0x11, 0xff, 0xcc, 0xf1, 0x27,
  0xce, 0x22, 0xe7, 0xd2, 0x44, 0x2a, 0xaa, 0xaa, 0xd0, 0xcf, 0x95, 0x74,
  0xe9, 0x19, 0xdd, 0x0e, 0x8c, 0xa8, 0x4b, 0x5e, 0xd3, 0x91, 0x81, 0x15,
  0xe8, 0x96, 0x46, 0x0d, 0xf2, 0xc1, 0x83, 0x98, 0x33, 0x88, 0x80, 0x3e,
  0x6d, 0x51, 0x55, 0x89, 0xbe, 0xd6, 0xe8, 0x7d, 0xe5, 0x13, 0xba, 0x39,
  0x1e, 0x76, 0x6e, 0xce, 0x18, 0xc3, 0xf3, 0xd9, 0x36, 0xd1, 0xc9, 0x4f,
  0x41, 0x2a, 0x61, 0xa7, 0x62, 0xb5, 0xe0, 0x14, 0xf6, 0xc2, 0x52, 0xd3,
  0x29, 0x98, 0xe4, 0x1e, 0xfa, 0x16, 0x9f, 0xd9, 0x9f, 0x65, 0x83, 0x1d,
  0xc1, 0x76, 0x78, 0xc9, 0xf7, 0x83, 0xed, 0x99, 0x6a, 0x74, 0x27, 0xea,
  0x4e, 0xe3, 0x17, 0x2a, 0x05, 0x2f, 0x48, 0x08, 0x62, 0xdc, 0x90, 0x96,
  0x6a, 0x72, 0xc0, 0x66, 0x0c, 0x7d, 0x83, 0xff, 0x7c, 0x02, 0xb7, 0x7b,
  0x60, 0x2f, 0xe5, 0x34, 0xb6, 0x49, 0x87, 0x35, 0x7a, 0x1c, 0xc0, 0xc2,
  0x76, 0xf2, 0xfa, 0x0b, 0x5f, 0xa6, 0xe3, 0x24, 0x1b, 0x41, 0x0f, 0xf0,
  0xf6, 0x19, 0x15, 0x6d, 0xf7, 0x96, 0xc2, 0xd0, 0x42, 0xee, 0x80, 0x6c,
  0x1f, 0x1d, 0x24, 0x25, 0x5f, 0x5e, 0x73, 0xe7, 0xe8, 0xca, 0x11, 0x8e,
  0x35, 0x8f, 0xa1, 0x9f, 0x8d, 0x2d, 0x43, 0xd4, 0xdd, 0xb0, 0x4f, 0x34,
  0xe5, 0xea, 0x07, 0x1d, 0x74, 0x19, 0xc2, 0x62, 0x20, 0x33, 0x74, 0xa8,
  0x94, 0x10, 0x33, 0x0e, 0xa0, 0x1b, 0xb7, 0x8d, 0xac, 0x8f, 0xd0, 0xf5,
  0xc6, 0xa0, 0x74, 0x1f, 0x9d, 0xfa, 0x09, 0x85, 0x6e, 0x33, 0x74, 0xb7,
  0x19, 0x60, 0xc3, 0x25, 0x8f, 0xd0, 0x3b, 0x81, 0xc6, 0x11, 0x7a, 0x63,
  0xdd, 0xa9, 0x9d, 0x63, 0x86, 0x0e, 0x95, 0xdb, 0x2b, 0xd0, 0xcd, 0x66,
  0xe9, 0x93, 0xce, 0x1c, 0xa0, 0xf7, 0xf8, 0x8e, 0x6c, 0xdd, 0x6e, 0x97,
  0xda, 0x9e, 0x87, 0x41, 0xe1, 0x48, 0x2e, 0xcb, 0x5c, 0xa2, 0x57, 0x35,
  0x49, 0xe2, 0x17, 0xd1, 0x8f, 0x3c, 0x8c, 0xd9, 0xfa, 0xce, 0x3d, 0x74,
  0x9a, 0xc5, 0x79, 0x81, 0x84, 0xde, 0x88, 0x66, 0xbe, 0x87, 0x8e, 0x43,
  0xfc, 0x22, 0xba, 0xdb, 0x41, 0x87, 0x3a, 0xe4, 0xfc, 0x41, 0xf4, 0x86,
  0x05, 0x1e, 0xa1, 0xef, 0x69, 0xdd, 0xe4, 0xab, 0x7e, 0x09, 0xac, 0xde,
  0x8e, 0x7e, 0x10, 0xc3, 0x34, 0x6c, 0x7d, 0x67, 0x9a, 0x52, 0xb0, 0x55,
  0x54, 0x58, 0xda, 0x7a, 0xa5, 0x05, 0xbd, 0x3f, 0x4d, 0xd7, 0x8f, 0x0f,
  0x8c, 0x81, 0xbb, 0xe8, 0xb0, 0xbf, 0xa9, 0xd0, 0x9b, 0x69, 0xac, 0xfa,
  0xce, 0x91, 0xfd, 0x62, 0xb1, 0xe1, 0xcb, 0xd0, 0xb7, 0xce, 0x4c, 0x9e,
  0x44, 0xf4, 0xeb, 0xb5, 0x04, 0xf7, 0xe8, 0x1c, 0xae, 0x74, 0xa4, 0x13,
  0xaf, 0x5b, 0x97, 0xd1, 0xe4, 0xe2, 0xfa, 0xe8, 0xbc, 0x7c, 0xd5, 0x31,
  0x64, 0x40, 0xdf, 0x2c, 0x11, 0x41, 0x09, 0x19, 0x7a, 0x80, 0x0f, 0xe7,
  0x00, 0xbc, 0xb7, 0x7e, 0xf6, 0xe8, 0x5b, 0xbb, 0xa4, 0xe4, 0x34, 0x6b,
  0x83, 0x82, 0x7e, 0x20, 0x10, 0xb2, 0xe6, 0x21, 0x5d, 0x3e, 0x39, 0xeb,
  0x85, 0x39, 0xb4, 0x51, 0xa0, 0x7b, 0xf6, 0xeb, 0x1a, 0x4f, 0x5f, 0xe2,
  0xb1, 0x40, 0x1b, 0x5e, 0x6f, 0x37, 0xd1, 0xe4, 0x28, 0x6c, 0x44, 0xb5,
  0x55, 0x4a, 0x1b, 0x3d, 0x11, 0xdb, 0x62, 0xf5, 0x8f, 0xe8, 0x55, 0x38,
  0x14, 0x87, 0xaf, 0x44, 0x5f, 0xf3, 0xd3, 0xaf, 0x35, 0x6d, 0xee, 0x9a,
  0xaa, 0xe7, 0x75, 0x24, 0x55, 0x0a, 0x2e, 0xdf, 0x68, 0xeb, 0x2c, 0xb2,
  0xe6, 0x9b, 0x36, 0x7a, 0x6e, 0x27, 0x49, 0xbf, 0x85, 0x4b, 0xc4, 0x7a,
  0xad, 0x6c, 0xbf, 0x20, 0x19, 0x6a, 0xdc, 0x25, 0x7d, 0x56, 0xe0, 0x88,
  0x7e, 0xdd, 0x87, 0xd7, 0x1c, 0xf9, 0x5b, 0xad, 0x01, 0xb4, 0xb3, 0xd5,
  0x62, 0xae, 0x39, 0xca, 0xc6, 0x24, 0xb2, 0xad, 0x8e, 0x73, 0xcc, 0xd7,
  0xe5, 0xa4, 0xdf, 0xd2, 0x9b, 0x5b, 0xae, 0x4a, 0x4b, 0x23, 0xd2, 0x46,
  0x3a, 0xcc, 0xb8, 0xd7, 0x47, 0x8e, 0xeb, 0xb9, 0xdc, 0x57, 0x6f, 0xe9,
  0xa1, 0x3e, 0xfd, 0x32, 0xb9, 0xf1, 0xeb, 0x3c, 0x45, 0x77, 0x76, 0x49,
  0x65, 0x44, 0x1b, 0xef, 0xaa, 0x85, 0xc8, 0x95, 0x55, 0x55, 0xe8, 0xdb,
  0xd3, 0xd2, 0xd3, 0x39, 0x04, 0xea, 0x7d, 0x78, 0x6d, 0x7b, 0xe0, 0x5e,
  0x54, 0x4c, 0x74, 0x84, 0xca, 0xf6, 0xa3, 0x73, 0xad, 0x43, 0xb5, 0xb4,
  0x05, 0x0f, 0xe9, 0x9f, 0x97, 0xb3, 0x3c, 0x56, 0x95, 0xce, 0x06, 0x9b,
  0x07, 0x77, 0xa2, 0x74, 0x96, 0x4a, 0xf5, 0x35, 0x7c, 0x3a, 0xe9, 0x6d,
  0x6d, 0xf8, 0x70, 0x73, 0xbf, 0x7b, 0xca, 0x35, 0x7c, 0x50, 0x0d, 0x9b,
  0xaa, 0x2a, 0xf4, 0x5b, 0x0d, 0x7e, 0x1e, 0x50, 0xfd, 0xd7, 0x04, 0xb2,
  0xa3, 0x8a, 0x4c, 0xc6, 0x4f, 0xdd, 0x2f, 0x2d, 0x8b, 0xb9, 0x6d, 0xc2,
  0x82, 0x12, 0xfe, 0x1d, 0xe4, 0x3a, 0x37, 0xdb, 0x4c, 0x46, 0xce, 0x97,
  0xba, 0xe8, 0x5b, 0xf0, 0x4a, 0xf5, 0x6f, 0x41, 0xf7, 0xb6, 0x0c, 0xa6,
  0x11, 0x06, 0x99, 0xaf, 0xa2, 0x73, 0xe4, 0xd2, 0x91, 0x00, 0xff, 0x0e,
  0x74, 0x60, 0xa7, 0x1e, 0x8c, 0x1d, 0xbf, 0x34, 0x9e, 0x28, 0x81, 0xb1,
  0xc0, 0x67, 0x65, 0xfc, 0x96, 0x04, 0x9f, 0xf3, 0xe1, 0x19, 0x8f, 0x90,
  0x76, 0xe5, 0x34, 0x4d, 0xc6, 0xbe, 0x03, 0x9e, 0xe0, 0xdf, 0xa2, 0x75,
  0xd1, 0xb8, 0xe3, 0xb0, 0xdf, 0xeb, 0x1a, 0xcf, 0xe5, 0x40, 0x5e, 0x18,
  0xf0, 0xe2, 0xeb, 0x28, 0x81, 0x16, 0x05, 0x90, 0x5d, 0xb9, 0xad, 0x9d,
  0xa3, 0x68, 0xfd, 0x7e, 0x00, 0x1e, 0xe8, 0xdf, 0x82, 0x0e, 0xec, 0x2b,
  0x41, 0x5e, 0x71, 0xf8, 0xa5, 0xd8, 0x3b, 0x53, 0x84, 0x46, 0xb5, 0x1a,
  0xf4, 0x9b, 0x0e, 0x21, 0x8d, 0xf7, 0x86, 0xde, 0xc9, 0xfa, 0xae, 0xa1,
  0x79, 0x81, 0xc7, 0x77, 0x5b, 0xf4, 0x3c, 0x02, 0xdb, 0x87, 0x1f, 0xb6,
  0xc6, 0x03, 0x76, 0x5e, 0x4d, 0x51, 0xfb, 0xc6, 0x4e, 0x4e, 0xec, 0x1e,
  0x6d, 0x5d, 0x86, 0x02, 0xbf, 0x68, 0x70, 0x80, 0x9c, 0xbd, 0x3e, 0x11,
  0x7a, 0x94, 0x80, 0x1e, 0x0e, 0xd6, 0x07, 0xd0, 0xfb, 0x41, 0xfc, 0x8b,
  0x62, 0xf8, 0xbc, 0x54, 0xcb, 0x3f, 0x5b, 0x02, 0xa2, 0xdb, 0x13, 0x2d,
  0x15, 0x06, 0xa3, 0x78, 0x7a, 0x79, 0x23, 0xa7, 0x93, 0xe0, 0x53, 0x52,
  0xe3, 0x8c, 0xbe, 0x7e, 0x5e, 0x5f, 0x40, 0x7f, 0xc7, 0xfb, 0x4e, 0x61,
  0x57, 0xa4, 0x57, 0xd2, 0xbc, 0x37, 0x67, 0x2b, 0xe8, 0xc6, 0x58, 0x5e,
  0xe6, 0x36, 0xe8, 0x7e, 0x24, 0x62, 0x4c, 0x87, 0x6f, 0xf0, 0xbc, 0xd3,
  0xb8, 0xbe, 0x80, 0x3e, 0xf4, 0x8a, 0x71, 0x48, 0x08, 0xc9, 0x13, 0xc9,
  0xcc, 0xd3, 0x64, 0xdc, 0x4e, 0x8c, 0x48, 0x7a, 0x57, 0xa1, 0x8b, 0xf1,
  0xb0, 0x3c, 0x9f, 0xcf, 0xcf, 0x04, 0x7f, 0xc4, 0x3d, 0xf2, 0x7a, 0x71,
  0x44, 0x88, 0x4e, 0xcb, 0x59, 0x23, 0x5e, 0x2b, 0xe1, 0xc4, 0x7f, 0x2d,
  0x67, 0xc0, 0xa6, 0x81, 0x9e, 0xf7, 0x8b, 0xf1, 0x87, 0xb4, 0x3e, 0xf6,
  0x4e, 0x77, 0x48, 0xb4, 0x0f, 0xd6, 0x5c, 0xd8, 0x1d, 0x51, 0x74, 0x66,
  0x7c, 0x28, 0xa7, 0x65, 0x35, 0xf5, 0x26, 0xad, 0xb5, 0x89, 0xb7, 0x11,
  0xdd, 0xf7, 0x49, 0x6f, 0x97, 0x5b, 0xa1, 0xdf, 0xe1, 0x76, 0x6f, 0xfd,
  0x79, 0x43, 0x7a, 0x6f, 0xca, 0xda, 0xd4, 0x12, 0x43, 0xb2, 0x7a, 0x9c,
  0x91, 0x8d, 0x0a, 0xdd, 0x82, 0xe1, 0x4f, 0x80, 0xde, 0xa9, 0x1b, 0xb8,
  0x2e, 0xbc, 0x69, 0x86, 0x4a, 0xdf, 0x84, 0x97, 0x2a, 0x8d, 0xc0, 0x94,
  0x2d, 0xbc, 0xdc, 0x1e, 0x38, 0xdb, 0x00, 0xff, 0x01, 0xee, 0x24, 0xfa,
  0xe8, 0xf5, 0xc8, 0xb8, 0x28, 0x5d, 0xd2, 0xbf, 0xd1, 0xc0, 0x9b, 0x62,
  0xf7, 0x8e, 0xa2, 0x5e, 0x97, 0x48, 0xff, 0x13, 0x86, 0x52, 0xc9, 0xfb,
  0x1b, 0xd0, 0xee, 0x87, 0x0d, 0xe5, 0x7f, 0x79, 0x49, 0xd4, 0x3c, 0x30,
  0x18, 0x4a, 0x4d, 0xf3, 0xf6, 0x67, 0x49, 0xf3, 0xdc, 0x78, 0x48, 0x99,
  0xf9, 0x53, 0xed, 0xfe, 0x92, 0x49, 0x35, 0x0b, 0xbf, 0x22, 0x6a, 0x51,
  0xa0, 0xbc, 0x4c, 0xfc, 0x49, 0x8d, 0x2a, 0x5e, 0x0e, 0xa9, 0x75, 0x92,
  0x65, 0xe6, 0x87, 0xf2, 0x21, 0x4c, 0x8b, 0x4f, 0xa0, 0x2c, 0x54, 0x96,
  0x4b, 0x2a, 0xf0, 0x3d, 0xc2, 0x8b, 0x79, 0x51, 0xf3, 0x1c, 0xd3, 0x94,
  0x14, 0x0d, 0xff, 0xea, 0xa9, 0x60, 0x89, 0x85, 0xbe, 0x8c, 0x3e, 0xcd,
  0xcb, 0xec, 0x1b, 0x02, 0xff, 0x89, 0xad, 0xe2, 0xcd, 0x3c, 0xf9, 0x3f,
  0xac, 0x1b, 0x9f, 0xd1, 0x97, 0xe2, 0x1b, 0xff, 0x98, 0x73, 0x13, 0x7a,
  0x48, 0x53, 0xa9, 0x28, 0x13, 0x63, 0x7e, 0x7f, 0x41, 0x05, 0x42, 0x06,
  0xac, 0x54, 0xe1, 0x50, 0xe1, 0x68, 0xcd, 0xcb, 0x32, 0x51, 0x6e, 0xe8,
  0x0c, 0xdd, 0x28, 0xfa, 0x8c, 0x35, 0x02, 0x56, 0xbc, 0x28, 0xa2, 0x42,
  0x22, 0x5f, 0xe9, 0x24, 0x37, 0x68, 0x2d, 0x31, 0x85, 0x72, 0x2f, 0x82,
  0x8e, 0x98, 0x72, 0x91, 0x8a, 0x9e, 0x16, 0x60, 0xc4, 0x85, 0x06, 0x75,
  0x99, 0x42, 0x3d, 0x8c, 0x8e, 0x0f, 0xb0, 0x59, 0x6e, 0x8f, 0x4b, 0x7d,
  0x17, 0x3d, 0x92, 0x61, 0x75, 0xa8, 0x17, 0xd4, 0x3d, 0xdd, 0xd0, 0x9f,
  0xa4, 0xf0, 0xd7, 0xc4, 0x7d, 0x12, 0x32, 0xb4, 0x0c, 0x54, 0x2f, 0x67,
  0x58, 0x50, 0x91, 0xa4, 0xdd, 0x88, 0x2e, 0x57, 0x73, 0xb4, 0xb2, 0x39,
  0xa0, 0x4f, 0x54, 0xe1, 0xd7, 0xd0, 0x67, 0x9a, 0x81, 0x7e, 0xb6, 0x62,
  0x0d, 0x9e, 0x61, 0x16, 0x7b, 0xc0, 0xa7, 0xc0, 0xea, 0xc4, 0xeb, 0x59,
  0x41, 0xbc, 0xc6, 0x42, 0x88, 0xbe, 0xa0, 0xc1, 0x20, 0x15, 0xa9, 0x9f,
  0xbf, 0x16, 0xc0, 0x1a, 0xb1, 0x1e, 0x46, 0x9f, 0x43, 0x06, 0xea, 0xe8,
  0xcc, 0xbd, 0x22, 0x83, 0x41, 0xff, 0x30, 0xab, 0x6f, 0x18, 0x4c, 0xa3,
  0x33, 0x6a, 0xe8, 0xa6, 0xb8, 0x97, 0xab, 0xf8, 0x60, 0x73, 0x0e, 0x96,
  0x65, 0xc0, 0xc9, 0x30, 0x2f, 0x75, 0xd1, 0xbf, 0x21, 0x38, 0xb2, 0x35,
  0xef, 0x3f, 0x5a, 0x7c, 0x73, 0x9e, 0x27, 0x55, 0xde, 0x41, 0x00, 0x00,
  0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
};

//#if LWIP_TCP && LWIP_CALLBACK_API

/** Minimum length for a valid HTTP/0.9 request: "GET /\r\n" -> 7 bytes */
#define MIN_REQ_LEN   7

#define CRLF "\r\n"
#define HTTP_IS_DYNAMIC_FILE(hs) 0

/* This defines checks whether tcp_write has to copy data or not */

#ifndef HTTP_IS_DATA_VOLATILE
/** tcp_write does not have to copy data when sent from rom-file-system directly */
#define HTTP_IS_DATA_VOLATILE(hs)       (HTTP_IS_DYNAMIC_FILE(hs) ? TCP_WRITE_FLAG_COPY : 0)
#endif
/** Default: dynamic headers are sent from ROM (non-dynamic headers are handled like file data) */
#ifndef HTTP_IS_HDR_VOLATILE
#define HTTP_IS_HDR_VOLATILE(hs, ptr)   0
#endif

/* Return values for http_send_*() */
#define HTTP_DATA_TO_SEND_FREED    3
#define HTTP_DATA_TO_SEND_BREAK    2
#define HTTP_DATA_TO_SEND_CONTINUE 1
#define HTTP_NO_DATA_TO_SEND       0

#define CUSTOM_HTTP_SERVER

extern struct tcp_pcb *tcp_listen_pcbs;

device_info_t device_info_details;

#if LWIP_HTTPD_SUPPORT_REQUESTLIST
/** HTTP request is copied here from pbufs for simple parsing */
//volatile static char httpd_req_buf[LWIP_HTTPD_MAX_REQ_LENGTH + 1];
#endif /* LWIP_HTTPD_SUPPORT_REQUESTLIST */


#ifndef LWIP_HTTPD_URI_BUF_LEN
#define LWIP_HTTPD_URI_BUF_LEN LWIP_HTTPD_MAX_REQUEST_URI_LEN

struct http_state {
  struct html_file file_handle;
  struct html_file *handle;
  const char *file;       /* Pointer to first unsent byte in buf. */

  struct altcp_pcb *pcb;
#if LWIP_HTTPD_SUPPORT_REQUESTLIST
  struct pbuf *req;
#endif /* LWIP_HTTPD_SUPPORT_REQUESTLIST */
  uint32_t left;       /* Number of unsent bytes in buf. */
  uint8_t retries;
#if LWIP_HTTPD_CGI
  char *params[LWIP_HTTPD_MAX_CGI_PARAMETERS]; /* Params extracted from the request URI */
  char *param_vals[LWIP_HTTPD_MAX_CGI_PARAMETERS]; /* Values for each extracted param */
#endif /* LWIP_HTTPD_CGI */
};

#define HTTP_ALLOC_HTTP_STATE() (struct http_state *)mem_malloc(sizeof(struct http_state))
#define HTTP_FREE_HTTP_STATE(x) mem_free(x)

static err_t http_close_conn(struct altcp_pcb *pcb, struct http_state *hs);
static err_t http_close_or_abort_conn(struct altcp_pcb *pcb, struct http_state *hs, uint8_t abort_conn);
static err_t http_poll(void *arg, struct altcp_pcb *pcb);
static u8_t http_check_eof(struct altcp_pcb *pcb, struct http_state *hs);

/* CGI handler information */
#define http_cgi_params     hs->params
#define http_cgi_param_vals hs->param_vals

#define http_add_connection(hs)
#define http_remove_connection(hs)

typedef uint8_t (*cbk_fun)();
cbk_fun http_cbk;
/*************************************************************************************************
  * @brief  uart callback register
  * @param  none
  * @retval none
  ************************************************************************************************/
void http_callback_register(void *cbk)
{
     http_cbk = cbk;
}
/*************************************************************************************************
  * @brief  convert ip address to string format
  * @param  none
  * @retval none
  ************************************************************************************************/
static void ip_to_str(uint32_t ip_net_order, char *out_str, size_t max_len)
{
    uint8_t bytes[4];
    bytes[0] = (ip_net_order >> 24) & 0xFF;
    bytes[1] = (ip_net_order >> 16) & 0xFF;
    bytes[2] = (ip_net_order >> 8) & 0xFF;
    bytes[3] = ip_net_order & 0xFF;

    snprintf(out_str, max_len, "%u.%u.%u.%u", bytes[0], bytes[1], bytes[2], bytes[3]);
}

/*************************************************************************************************
  * @brief  convert mac address to string format
  * @param  none
  * @retval none
  ************************************************************************************************/
static void mac_to_str(uint8_t mac[6], char *out_str, size_t max_len)
{
    snprintf(out_str, max_len, "%02X:%02X:%02X:%02X:%02X:%02X",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

/*************************************************************************************************
  * @brief  Set device info details
  * @param  none
  * @retval none
  ************************************************************************************************/
void fill_device_info(uint8_t mac[6], uint32_t ip_net, uint32_t subnet_net, uint32_t gw_net, uint8_t *system_name, uint8_t *firmware_version) {

    // Convert and store strings
    mac_to_str(mac, device_info_details.mac_address, sizeof(device_info_details.mac_address));
    ip_to_str(ntohl(ip_net),    device_info_details.ipv4_address,    sizeof(device_info_details.ipv4_address));
    ip_to_str(ntohl(subnet_net),device_info_details.subnet_mask,     sizeof(device_info_details.subnet_mask));
    ip_to_str(ntohl(gw_net),    device_info_details.default_gateway, sizeof(device_info_details.default_gateway));

    // Copy system name and firmware version
    strncpy(device_info_details.system_name, system_name, sizeof(device_info_details.system_name) - 1);
    device_info_details.system_name[sizeof(device_info_details.system_name) - 1] = '\0';

    strncpy(device_info_details.firmware_version, firmware_version, sizeof(device_info_details.firmware_version) - 1);
    device_info_details.firmware_version[sizeof(device_info_details.firmware_version) - 1] = '\0';

    // Set device health to default (optional)
    strncpy(device_info_details.device_health, "Working", sizeof(device_info_details.device_health) - 1);
    device_info_details.device_health[sizeof(device_info_details.device_health) - 1] = '\0';
}
/*************************************************************************************************
 * @brief  http_state_init
 * @param Initialize a struct http_state.
 * @retval none
 *************************************************************************************************/
static void
http_state_init(struct http_state *hs)
{
  /* Initialize the structure. */
  memset(hs, 0, sizeof(struct http_state));
}

/*************************************************************************************************
  * @brief  http_state_alloc
  * @param  none
  * @retval none
  ************************************************************************************************/
static struct http_state *
http_state_alloc(void)
{
  struct http_state *ret = HTTP_ALLOC_HTTP_STATE();
  if (ret != NULL) {
    http_state_init(ret);
    http_add_connection(ret);
  }
  return ret;
}

/****************************************************************************************************
 *  Free a struct http_state.
 * Also frees the file data if dynamic.
 ***************************************************************************************************/
static void
http_state_eof(struct http_state *hs)
{
  if (hs->handle) {
//    fs_close(hs->handle);
	  html_close(hs->handle);
    hs->handle = NULL;
  }
#if LWIP_HTTPD_SUPPORT_REQUESTLIST
  if (hs->req) {
    pbuf_free(hs->req);
    hs->req = NULL;
  }
#endif /* LWIP_HTTPD_SUPPORT_REQUESTLIST */
}

/****************************************************************************************************
 *  Free a struct http_state.
 * Also frees the file data if dynamic.
 ***************************************************************************************************/
static void
http_state_free(struct http_state *hs)
{
  if (hs != NULL) {
    http_state_eof(hs);
    http_remove_connection(hs);
    HTTP_FREE_HTTP_STATE(hs);
  }
}

/****************************************************************************************************
 *  Call tcp_write() in a loop trying smaller and smaller length
 *
 * @param pcb altcp_pcb to send
 * @param ptr Data to send
 * @param length Length of data to send (in/out: on return, contains the
 *        amount of data sent)
 * @param apiflags directly passed to tcp_write
 * @return the return value of tcp_write
 ***************************************************************************************************/
static err_t
http_write(struct altcp_pcb *pcb, const void *ptr, uint16_t *length, uint8_t apiflags)
{
  uint16_t len, max_len;
  err_t err;
  LWIP_ASSERT("length != NULL", length != NULL);
  len = *length;
  if (len == 0) {
    return ERR_OK;
  }
  /* We cannot send more data than space available in the send buffer. */
  max_len = altcp_sndbuf(pcb);
  if (max_len < len) {
    len = max_len;
  }
#ifdef HTTPD_MAX_WRITE_LEN
  /* Additional limitation: e.g. don't enqueue more than 2*mss at once */
  max_len = HTTPD_MAX_WRITE_LEN(pcb);
  if (len > max_len) {
    len = max_len;
  }
#endif /* HTTPD_MAX_WRITE_LEN */
  do {
    LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("Trying to send %d bytes\n", len));
    err = altcp_write(pcb, ptr, len, apiflags);
    if (err == ERR_MEM) {
      if ((altcp_sndbuf(pcb) == 0) ||
          (altcp_sndqueuelen(pcb) >= TCP_SND_QUEUELEN)) {
        /* no need to try smaller sizes */
        len = 1;
      } else {
        len /= 2;
      }
      LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE,
                  ("Send failed, trying less (%d bytes)\n", len));
    }
  } while ((err == ERR_MEM) && (len > 1));

  if (err == ERR_OK) {
    LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("Sent %d bytes\n", len));
    *length = len;
  } else {
    LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("Send failed with err %d (\"%s\")\n", err, lwip_strerr(err)));
    *length = 0;
  }

  return err;
}

/****************************************************************************************************
 * The connection shall be actively closed (using RST to close from fault states).
 * Reset the sent- and recv-callbacks.
 *
 * @param pcb the tcp pcb to reset callbacks
 * @param hs connection state to free
 ***************************************************************************************************/
static err_t
http_close_or_abort_conn(struct altcp_pcb *pcb, struct http_state *hs, uint8_t abort_conn)
{
  err_t err;
  LWIP_DEBUGF(HTTPD_DEBUG, ("Closing connection %p\n", (void *)pcb));

  altcp_arg(pcb, NULL);
  altcp_recv(pcb, NULL);
  altcp_err(pcb, NULL);
  altcp_poll(pcb, NULL, 0);
  altcp_sent(pcb, NULL);
  if (hs != NULL) {
    http_state_free(hs);
  }

  if (abort_conn) {
    altcp_abort(pcb);
    return ERR_OK;
  }
  err = altcp_close(pcb);
  if (err != ERR_OK) {
    LWIP_DEBUGF(HTTPD_DEBUG, ("Error %d closing %p\n", err, (void *)pcb));
    /* error closing, try again later in poll */
    altcp_poll(pcb, http_poll, HTTPD_POLL_INTERVAL);
  }
  return err;
}

/****************************************************************************************************
 * The connection shall be actively closed.
 * Reset the sent- and recv-callbacks.
 *
 * @param pcb the tcp pcb to reset callbacks
 * @param hs connection state to free
 ***************************************************************************************************/
static err_t
http_close_conn(struct altcp_pcb *pcb, struct http_state *hs)
{
  return http_close_or_abort_conn(pcb, hs, 0);
}

/****************************************************************************************************
 *  End of file: either close the connection (Connection: close) or
 * close the file (Connection: keep-alive)
 ***************************************************************************************************/
static void
http_eof(struct altcp_pcb *pcb, struct http_state *hs)
{
    http_close_conn(pcb, hs);
}

/****************************************************************************************************
 *  Sub-function of http_send(): end-of-file (or block) is reached,
 * either close the file or read the next block (if supported).
 *
 * @returns: 0 if the file is finished or no data has been read
 *           1 if the file is not finished and data has been read
 ***************************************************************************************************/
static uint8_t
http_check_eof(struct altcp_pcb *pcb, struct http_state *hs)
{
  int bytes_left;

  /* Do we have a valid file handle? */
  if (hs->handle == NULL) {
    /* No - close the connection. */
    http_eof(pcb, hs);
    return 0;
  }
//  bytes_left = fs_bytes_left(hs->handle);
  bytes_left = html_bytes_left(hs->handle);
  if (bytes_left <= 0) {
    /* We reached the end of the file so this request is done. */
    LWIP_DEBUGF(HTTPD_DEBUG, ("End of file.\n"));
    http_eof(pcb, hs);
    return 0;
  }
  LWIP_ASSERT("SSI and DYNAMIC_HEADERS turned off but eof not reached", 0);
  return 1;
}

/****************************************************************************************************
 *  Sub-function of http_send(): This is the normal send-routine for non-ssi files
 *
 * @returns: - 1: data has been written (so call tcp_ouput)
 *           - 0: no data has been written (no need to call tcp_output)
 ***************************************************************************************************/
static uint8_t
http_send_data_nonssi(struct altcp_pcb *pcb, struct http_state *hs)
{
  err_t err;
  uint16_t len;
  uint8_t data_to_send = 0;

  /* We are not processing an SHTML file so no tag checking is necessary.
   * Just send the data as we received it from the file. */
  len = (uint16_t)LWIP_MIN(hs->left, 0xffff);

  err = http_write(pcb, hs->file, &len, HTTP_IS_DATA_VOLATILE(hs));
  if (err == ERR_OK) {
    data_to_send = 1;
    hs->file += len;
    hs->left -= len;
  }

  return data_to_send;
}

/****************************************************************************************************
 * Try to send more data on this pcb.
 *
 * @param pcb the pcb to send data
 * @param hs connection state
 ***************************************************************************************************/
static uint8_t
http_send(struct altcp_pcb *pcb, struct http_state *hs)
{
  uint8_t data_to_send = HTTP_NO_DATA_TO_SEND;

  LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("http_send: pcb=%p hs=%p left=%d\n", (void *)pcb,
              (void *)hs, hs != NULL ? (int)hs->left : 0));

  /* If we were passed a NULL state structure pointer, ignore the call. */
  if (hs == NULL) {
    return 0;
  }

  /* Have we run out of file data to send? If so, we need to read the next
   * block from the file. */
  if (hs->left == 0) {
    if (!http_check_eof(pcb, hs)) {
      return 0;
    }
  }
  {
    data_to_send = http_send_data_nonssi(pcb, hs);
  }

  if ((hs->left == 0) && (html_bytes_left(hs->handle) <= 0)) {
    /* We reached the end of the file so this request is done.
     * This adds the FIN flag right into the last data segment. */
    LWIP_DEBUGF(HTTPD_DEBUG, ("End of file.\n"));
    http_eof(pcb, hs);
    return 0;
  }
  LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("send_data end.\n"));
  return data_to_send;
}

#define http_find_error_file(hs, error_nr) ERR_ARG

/****************************************************************************************************
 * The pcb had an error and is already deallocated.
 * The argument might still be valid (if != NULL).
 ***************************************************************************************************/
static void
http_err(void *arg, err_t err)
{
  struct http_state *hs = (struct http_state *)arg;
  LWIP_UNUSED_ARG(err);

  LWIP_DEBUGF(HTTPD_DEBUG, ("http_err: %s", lwip_strerr(err)));

  if (hs != NULL) {
    http_state_free(hs);
  }
}

/****************************************************************************************************
 * Data has been sent and acknowledged by the remote host.
 * This means that more data can be sent.
 ***************************************************************************************************/
static err_t
http_sent(void *arg, struct altcp_pcb *pcb, uint16_t len)
{

  struct http_state *hs = (struct http_state *)arg;

  LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("http_sent %p\n", (void *)pcb));

  LWIP_UNUSED_ARG(len);

  if (hs == NULL) {
    return ERR_OK;
  }

  hs->retries = 0;

  http_send(pcb, hs);

  return ERR_OK;
}



/*************************************************************************************************
 * The  function is called every 2nd second.
 * If there has been no data sent (which resets the retries) in 8 seconds, close.
 * If the last portion of a file has not been sent in 2 seconds, close.
 *
 * This could be increased, but we don't want to waste resources for bad connections.
 **************************************************************************************************/
static err_t
http_poll(void *arg, struct altcp_pcb *pcb)
{
  struct http_state *hs = (struct http_state *)arg;
  LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("http_poll: pcb=%p hs=%p pcb_state=%s\n",
              (void *)pcb, (void *)hs, tcp_debug_state_str(altcp_dbg_get_tcp_state(pcb))));

  if (hs == NULL) {
    err_t closed;
    /* arg is null, close. */
    LWIP_DEBUGF(HTTPD_DEBUG, ("http_poll: arg is NULL, close\n"));
    closed = http_close_conn(pcb, NULL);
    LWIP_UNUSED_ARG(closed);
    return ERR_OK;
  } else {
    hs->retries++;
    if (hs->retries == HTTPD_MAX_RETRIES) {
      LWIP_DEBUGF(HTTPD_DEBUG, ("http_poll: too many retries, close\n"));
      http_close_conn(pcb, hs);
      return ERR_OK;
    }

    /* If this connection has a file open, try to send some more data. If
     * it has not yet received a GET request, don't do this since it will
     * cause the connection to close immediately. */
    if (hs->handle) {
      LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("http_poll: try to send more data\n"));
      if (http_send(pcb, hs)) {
        /* If we wrote anything to be sent, go ahead and send it now. */
        LWIP_DEBUGF(HTTPD_DEBUG | LWIP_DBG_TRACE, ("tcp_output\n"));
        altcp_output(pcb);
      }
    }
  }

  return ERR_OK;
}

/******************************************************************************
 * @brief       Build modbus RTU request for modbus test
 * @param[in]   req - input structure with details modbus parameters
 * @param[in]   tx_buf - output modbus request
 * @return      none
 ******************************************************************************/
uint8_t build_modbus_rtu_request(modbus_test_req_t *req, uint8_t *tx_buf)
{
    uint16_t crc;

    tx_buf[0] = req->slave_id;
    tx_buf[1] = req->function_code;
    tx_buf[2] = (req->start_address >> 8) & 0xFF;
    tx_buf[3] = (req->start_address) & 0xFF;
    tx_buf[4] = (req->quantity >> 8) & 0xFF;
    tx_buf[5] = (req->quantity) & 0xFF;

    crc = crc16(tx_buf, 6);

    tx_buf[6] = crc & 0xFF;         // CRC Low
    tx_buf[7] = (crc >> 8) & 0xFF;  // CRC High

    return 8;   // length of Modbus RTU request
}
/******************************************************************************
 * @brief       Get http content length
 * @param[in]   http_header
 * @return      none
 ******************************************************************************/
int http_get_content_length(const char *http_header)
{
    if (http_header == NULL) return -1;

    const char *cl = strstr(http_header, "Content-Length:");
    if (cl == NULL) return -1;  // no content length found

    cl += strlen("Content-Length:");

    // Skip spaces
    while (*cl == ' ') cl++;

    return atoi(cl);
}
/******************************************************************************
 * @brief       HTTP detect Request type
 * @param[in]   buf
 * @param[in]   buffer length
 * @return      none
 ******************************************************************************/
http_req_type_t http_detect_request_type(const uint8_t *buf, uint16_t len)
{
    if (buf == NULL || len < 5) {
        return HTTP_REQ_INVALID;
    }

    /* GET / */
    if (!strncmp(buf, "GET /", 5)) {
        return HTTP_REQ_GET;
    }

    /* POST /upload */
    if (!strncmp(buf, "POST /upload", 12)) {
        return HTTP_REQ_POST_UPLOAD;
    }

    /* POST / (any other POST) */
    if (!strncmp(buf, "POST /", 6)) {
        return HTTP_REQ_POST;
    }

    return HTTP_REQ_INVALID;
}
/******************************************************************************
 * @brief       HTTP RECV CALLBACK
 * @param[in]   arg
 * @param[in]   pcb
 * @param[in]   pbuf
 * @param[in]   error flag
 * @return      none
 ******************************************************************************/
err_t http_recv(void *arg, struct altcp_pcb *pcb, struct pbuf *p, err_t err)
{
//    struct html_file file = {0, 0};
    struct http_state *hs = (struct http_state *)arg;
    static uint8_t row;
    static uint16_t http_rx_len = 0;

    if (err == ERR_OK && p != NULL)
    {
        tcp_recved(pcb, p->tot_len);
        // --- Accumulate incoming data ---
        struct pbuf *q = p;
        while (q && (http_rx_len + q->len < HTTP_RX_BUF_SIZE))
        {
            memcpy(http_rx_buf + http_rx_len, q->payload, q->len);
            http_rx_len += q->len;
            q = q->next;
        }
        pbuf_free(p);
        if (strstr(http_rx_buf, "\r\n\r\n") != NULL) {
        	uint8_t sts = http_detect_request_type(http_rx_buf, http_rx_len);
        	if (sts == HTTP_REQ_GET) {
        		http_req_type = 1;
        	} else if (sts == HTTP_REQ_POST) {
        		http_req_type = 1;
        	} else if (sts == HTTP_REQ_POST_UPLOAD && !http_req_type) {
            	http_req_type = 2;
                uint16_t rx_length = http_get_content_length(http_rx_buf);
                PRINTF("CALCULATED LENGTH :%u\n",rx_length);
                if (rx_length != -1) {
                	calculated_length = rx_length;
                }
        	} else if (http_req_type == 2) {
        		http_req_type = 3;
        	}
            if (http_req_type == 1) {
                http_ok = 1;
            }
        }
        if (http_ok) {
        	http_ok = 0;
        	http_req_type = 0;
            http_rx_buf[http_rx_len] = '\0';
            char *data = http_rx_buf;

    	    if (hs->file == NULL) {
    	    	PRINTF("\r\n=== Full HTTP Request Received (%d bytes) ===\n%s\n===============================\r\n", http_rx_len, http_rx_buf);
    		    if (strncmp(data, "GET /style.css", 14) == 0) {
    		    	PRINTF("Style\n");
    		        hs->file = html_css;
    		        hs->left = strlen(html_css);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);
    		    } else if (strncmp(data, "GET /logo.png", 13) == 0) {
    		    	PRINTF("LOGO.png\n");
    		        hs->file = logo_png;
    		        hs->left = 1926;
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);
    		    } else if (strncmp(data, "GET /favicon.ico", 16) == 0) {
    		        hs->file = logo_png;
    		        hs->left = 1926;
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);
    		    } else if (strncmp(data, "GET /login", 10) == 0) {
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	uint8_t status = verify_login_request((char*)data);
    		    	switch (status) {
    		    	    case 1 :
    		              	  PRINTF(">>>>>Login Verify\n");
    		              	  html_page_read_from_flash(html_read_buff, DEV_INFO_PAGE);
    		  		    	  prepare_device_info_page(html_read_buff, &device_info_details);
    		  		          hs->file = html_read_buff;
    		  		          hs->left = strlen(html_read_buff);
    		  		          http_send(pcb, hs);
    		  		          tcp_sent(pcb, http_sent);
    		                  login_status = 1;
    		                  break;
    		    	    case 2 :
    		                  PRINTF("INVALID LOGIN CREDENTIALS\n");
    		                  html_page_read_from_flash(html_read_buff, LOGIN_PAGE);
    		                  uint16_t err_pg_len = build_login_error_page(html_read_buff);
    		                  hs->file = html_read_buff;
    		                  hs->left = err_pg_len;
    		                  http_send(pcb, hs);
    		                  tcp_sent(pcb, http_sent);
    		                  break;
    		    	    case 3 :
    		    	          PRINTF(">>>>>Login page\n");
    		    	          html_page_read_from_flash(html_read_buff, LOGIN_PAGE);
    		  		          hs->file = html_read_buff;
    		  		          hs->left = strlen(html_read_buff);
    		    	          http_send(pcb, hs);
    		    	          tcp_sent(pcb, http_sent);
    		    	          break;
    		    	}
    		    } else if (login_status == 0) {

    		    	PRINTF(">>>>>Not logged in. Sending login page.\n");
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
	    	        html_page_read_from_flash(html_read_buff, LOGIN_PAGE);
	  		        hs->file = html_read_buff;
	  		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if (strncmp(data, "GET /dev_info", 13) == 0)  {
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	html_page_read_from_flash(html_read_buff, DEV_INFO_PAGE);
	  		    	prepare_device_info_page(html_read_buff, &device_info_details);
	  		        hs->file = html_read_buff;
	  		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);
    		    } else if (strncmp(data, "GET /nwk_cfg", 12) == 0) {
    		    	PRINTF("NWK PAGE\n");
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	html_page_read_from_flash(html_read_buff, NWK_CFG_PAGE);
    		        prepare_nwk_info_page(html_read_buff, &modbus_data.network_data);
	  		        hs->file = html_read_buff;
	  		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if (strncmp(data, "GET /serial_cfg", 15) == 0) {

    		    	PRINTF("SERIAL PAGE\n");
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	html_page_read_from_flash(html_read_buff, SERIAL_CFG_PAGE);
    		    	prepare_serial_info_page(html_read_buff, &modbus_data.serial_data);
	  		        hs->file = html_read_buff;
	  		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if (strncmp(data, "GET /cloud_cfg", 14) == 0) {

    		        PRINTF("CLOUD PAGE\n");
    		        memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	html_page_read_from_flash(html_read_buff, CLOUD_CFG_PAGE);
    		    	prepare_cloud_info_page(html_read_buff, &modbus_data.cloud_data);
	  		        hs->file = html_read_buff;
	  		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if (strncmp(data, "GET /data_mapping", 16) == 0) {

    		    	PRINTF("DATA MAPPING PAGE\n");
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	html_page_read_from_flash(html_read_buff, DATA_MAP_PAGE);
    		    	prepare_data_mapping_page(html_read_buff, &modbus_data);
	  		        hs->file = html_read_buff;
	  		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if (strncmp(data, "GET /rtu_channel_1", 18) == 0) {

                    PRINTF("RTU1 CHANNEL PAGE\n");
                    memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    parse_pollinterval(data, &modbus_data);
                    html_page_read_from_flash(html_read_buff, RTU1_PAGE);
                    replace_row_placeholders(html_read_buff, &modbus_data.rtu_port_1);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);


                } else if (strncmp(data, "GET /rtu_channel_2", 18) == 0) {

                    PRINTF("RTU2 CHANNEL PAGE\n");
                    memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    parse_pollinterval(data, &modbus_data);
                    html_page_read_from_flash(html_read_buff, RTU2_PAGE);
                    replace_row_placeholders(html_read_buff, &modbus_data.rtu_port_2);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);

                } else if (strncmp(data, "GET /modbus_slave_cfg", 21) == 0) {

                    PRINTF("MODBUS SLAVE CFG PAGE\r\n");
                    memset(html_read_buff, 0, HTML_BUFFER_SIZE);
                    html_page_read_from_flash(html_read_buff, REG_CFG_PAGE);
                    const char *row_ptr = strstr(data, "rowNumber=");
                    if (row_ptr != NULL) {
                        row_ptr += strlen("rowNumber=");
                        row = (uint8_t)atoi(row_ptr);
                        if (row < 1 || row > 32) {
                            PRINTF("Invalid row number %d (must be 1�32)\r\n", row);
                            row = 0;
                        } else {
                            PRINTF("Requested Row Number: %d\r\n", row);
                        }
                    } else {
                        PRINTF("Row number not found in request\r\n");
                    }
                    uint8_t requested_slave_id = 0;
                    const char *slave_id_ptr = strstr(data, "slaveId=");
                    if (slave_id_ptr) {
                        requested_slave_id = (uint8_t)atoi(slave_id_ptr + strlen("slaveId="));
                        PRINTF("Requested Slave ID: %d\r\n", requested_slave_id);
                    }
                    if (strstr(data, "rtuchannel=1") != NULL) {
                        for (uint8_t i = 0; i < 32; i++) {

                        	if (row == (i+1)) {
                        		PRINTF("ROW:%u\n",modbus_data.rtu_port_1.devices[i].num_points);
                        	}
                        	if (row == (i+1) && (modbus_data.rtu_port_1.devices[i].num_points >= 1)) {
                        		PRINTF("1.ROW:%u\n",row);
                                replace_reg_cfg_placeholders(
                                    html_read_buff,
                                    modbus_data.rtu_port_1.devices[i].num_points,
                                    modbus_data.rtu_port_1.devices[i].points
                                );
                                break;
                        	} else if (row == (i+1) && (modbus_data.rtu_port_1.devices[i].num_points <= 1)) {
                        		PRINTF("2.ROW:%u\n",row);
                                replace_reg_cfg_placeholders(
                                        html_read_buff,
    									modbus_data.rtu_port_1.devices[i].num_points,
    									modbus_data.rtu_port_1.devices[i].points
                                );
                                break;
                        	}
                        }
                    } else if (strstr(data, "rtuchannel=2") != NULL) {
                        for (uint8_t i = 0; i < 32; i++) {

                        	if (row == (i+1) && (modbus_data.rtu_port_2.devices[i].num_points >= 1)) {
                        		PRINTF("1.ROW:%u\n",row);
                                replace_reg_cfg_placeholders(
                                    html_read_buff,
                                    modbus_data.rtu_port_2.devices[i].num_points,
                                    modbus_data.rtu_port_2.devices[i].points
                                );
                                break;
                        	} else if (row == (i+1) && (modbus_data.rtu_port_2.devices[i].num_points <= 1)) {
                        		PRINTF("2.ROW:%u\n",row);
                                replace_reg_cfg_placeholders(
                                        html_read_buff,
    									modbus_data.rtu_port_2.devices[i].num_points,
    									modbus_data.rtu_port_2.devices[i].points
                                );
                                break;
                        	}
                        }

                    }
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
                    http_send(pcb, hs);
                    tcp_sent(pcb, http_sent);
                }  else if(strncmp(data, "GET /network_Configure", 22) == 0){
                	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	parse_gw_network_config(data, &modbus_data.network_data);
    		    	html_page_read_from_flash(html_read_buff, CLOUD_CFG_PAGE);
    		        prepare_cloud_info_page(html_read_buff, &modbus_data.cloud_data);
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if(strncmp(data, "GET /cloud_Configure", 20) == 0){
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	parse_cloud_config(data, &modbus_data.cloud_data);
    		    	html_page_read_from_flash(html_read_buff, SERIAL_CFG_PAGE);
    		        prepare_serial_info_page(html_read_buff, &modbus_data.serial_data);
    		        hs->file = html_read_buff;
    		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if(strncmp(data, "GET /serial_Configure", 20) == 0){
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	parse_gw_serial_config(data, html_read_buff, &modbus_data.serial_data);
    		    	html_page_read_from_flash(html_read_buff, DATA_MAP_PAGE);
    		    	prepare_data_mapping_page(html_read_buff, &modbus_data);
    		        hs->file = html_read_buff;
    		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if(strncmp(data, "GET /configure.html?", 20) == 0) {

                    const char *redirect_response = NULL;
                    if (strstr(data, "rtuchannel=1") != NULL) {
                        parse_device_config_data(data, &modbus_data,row-1);
                        redirect_response =
                                "HTTP/1.1 303 See Other\r\n"
                                "Location: /rtu_channel_1.html\r\n"
                                "Content-Length: 0\r\n"
                                "Connection: close\r\n"
                                "\r\n";
                    } else if (strstr(data, "rtuchannel=2") != NULL) {
                        parse_device_config_data(data, &modbus_data, row-1);
                        redirect_response =
                                "HTTP/1.1 303 See Other\r\n"
                                "Location: /rtu_channel_2.html\r\n"
                                "Content-Length: 0\r\n"
                                "Connection: close\r\n"
                                "\r\n";
                    } else {
                        redirect_response =
                                "HTTP/1.1 303 See Other\r\n"
                                "Location: /data_mapping.html\r\n"
                                "Content-Length: 0\r\n"
                                "Connection: close\r\n"
                                "\r\n";
                    }
                    if (redirect_response) {
                        tcp_write(pcb, redirect_response, strlen(redirect_response), TCP_WRITE_FLAG_COPY);
                        tcp_output(pcb);
                    }
    		    } else if(strncmp(data, "GET /save?",10)== 0){
                    PRINTF("inside GET /save?\r\n");
                    uint8_t rtu_channel = 0, tcp_channel = 0;
                    get_channels_from_query(data, &rtu_channel, &tcp_channel);
                    PRINTF("rtu_channel :%d\r\ntcp_channel: %d\r\n",rtu_channel, tcp_channel);
                    rearrange_devices(data, &modbus_data, rtu_channel, tcp_channel);
    		    } else if(strncmp(data, "POST /finish-config", 19) == 0){
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	html_page_read_from_flash(html_read_buff, SUCCESS_CFG_PAGE);
    		        uint8_t sts = http_cbk(CONFIG_DONE);
    		        PRINTF("HTTP STATUS:%d\n",sts);
    		        prepare_cfg_success_page(html_read_buff, sts);
    		        hs->file = html_read_buff;
    		        hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);
    		        PRINTF("FINISH DONE");

    		    } else if (strncmp(data, "GET /modbus_test_configure", 26) == 0) {
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	modbus_test_req_t req;
    		    	uint8_t expected_len = 0;
    		    	uint8_t modbus_req[20];
    		    	uint8_t modbus_rx[32];
    		    	uint8_t uart_type;
    		    	char modbus_rx_str[64] = "TIMEOUT";
    		    	char modbus_tx_str[64] = "TIMEOUT";
    		    	parse_modbus_test_request(data, &req);
    		        PRINTF("PORT=%d SID=%d FC=%d ADDR=%d QTY=%d\r\n", req.port, req.slave_id, req.function_code,
    		        		req.start_address, req.quantity);
    		        if (req.function_code == 1 || req.function_code == 2) {
    		        	expected_len = 6;
    		        } else {
    		        	expected_len = (req.quantity * 2) + 5;
    		        }
    		        uint8_t len = build_modbus_rtu_request(&req, modbus_req);
    		        PRINTF("MODBUS TX:%u\n",len);
    		        for (uint16_t i = 0; i < len; i++) {
    		            printf("%02X ", modbus_req[i]);
    		        }
    		        PRINTF("\r\n");
    		        if (req.port == 1) {
    		        	uart_type = UART_4;
    		        } else {
    		        	uart_type = UART_5;
    		        }
    		        clear_uart_buffer(uart_type);
    		        uart_transmit_for_modbus_test(uart_type, modbus_req, len, 10);
    		        uint32_t start = xTaskGetTickCount();
		            while ((xTaskGetTickCount() - start) < 1000)
		            {
		                if (uart_receive_check(uart_type, expected_len))
		                {
		                	break;
		                }
		            }
		            expected_len = uart_receive_check_for_modbus_test(uart_type);
		            uart_rx_for_modbus_test(uart_type, modbus_rx, expected_len);
        		    PRINTF("MODBUS RX:%u\n",len);
        		    for (uint16_t i = 0; i < expected_len; i++) {
        		        printf("%02X ", modbus_rx[i]);
        		    }
        		    PRINTF("\r\n");
        		    if (expected_len > 0) {
            		    modbus_bytes_to_hex_string(modbus_req, len, modbus_tx_str, sizeof(modbus_tx_str));
            		    modbus_bytes_to_hex_string(modbus_rx, expected_len, modbus_rx_str, sizeof(modbus_rx_str));
        		    }
    		    	html_page_read_from_flash(html_read_buff, MODBUS_TEST_PAGE);
    		    	char str[10];
    		    	snprintf(str, sizeof(str), "%u", req.slave_id);
    		    	replace_all(html_read_buff, "%SID%", str);
    		    	snprintf(str, sizeof(str), "%u", req.start_address);
    		    	replace_all(html_read_buff, "%REG_ADDR%", str);
    		    	snprintf(str, sizeof(str), "%u", req.quantity);
    		    	replace_all(html_read_buff, "%REG_CNT%", str);
    		    	if (req.function_code == 4) {
    		    		replace_all(html_read_buff, "%FC4%", "selected");
    		    	}
    		    	if (req.function_code == 3) {
    		    		replace_all(html_read_buff, "%FC3%", "selected");
    		    	}
    		    	if (req.function_code == 2) {
    		    		replace_all(html_read_buff, "%FC2%", "selected");
    		    	}
    		    	if (req.function_code == 1) {
    		    		replace_all(html_read_buff, "%FC1%", "selected");
    		    	}
    		    	replace_all(html_read_buff, "%%MODBUS_TX%%", modbus_tx_str);
    		    	replace_all(html_read_buff, "%%MODBUS_RX%%", modbus_rx_str);
    		    	hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);

    		    } else if (strncmp(data, "GET /modbus_test", 16) == 0) {
    		    	memset(html_read_buff, 0, HTML_BUFFER_SIZE);
    		    	html_page_read_from_flash(html_read_buff, MODBUS_TEST_PAGE);
    		    	replace_all(html_read_buff, "%SID%", "1");
    		    	replace_all(html_read_buff, "%REG_ADDR%", "1000");
    		    	replace_all(html_read_buff, "%REG_CNT%", "2");
    		    	replace_all(html_read_buff, "%FC3%", "selected");
    		    	replace_all(html_read_buff, "%%MODBUS_TX%%", " ");
    		    	replace_all(html_read_buff, "%%MODBUS_RX%%", " ");
                    hs->file = html_read_buff;
                    hs->left = strlen(html_read_buff);
    		        http_send(pcb, hs);
    		        tcp_sent(pcb, http_sent);
    		    } else if (strncmp(data, "POST /device/reset", 18) == 0) {
    		    	http_cbk(DEVICE_RESET);
    		    } else if (strncmp(data, "POST /device/factory-default", 28) == 0) {
    		    	http_cbk(FACTORY_DEFAULT);// CONFIG_DONE
    		    } else if (strncmp(data, "POST /reboot", 12) == 0) {
    		    	http_cbk(REBOOT);
    		    }
    	    }
    	    http_rx_len = 0;
    	    memset(http_rx_buf, 0, (HTTP_RX_BUF_SIZE-1));
      }
    }
    if (err == ERR_OK && p == NULL)
    {
    	PRINTF("HTTP CLOSE\n");
        http_close_conn(pcb, hs);
    }
    return ERR_OK;
}

/**
 * A new incoming connection has been accepted.
 */
static err_t
http_accept(void *arg, struct altcp_pcb *pcb, err_t err)
{
//	PRINTF("http_accept %p / %p\n", (void *)pcb, arg);
  struct http_state *hs;
  LWIP_UNUSED_ARG(err);
  LWIP_UNUSED_ARG(arg);
  LWIP_DEBUGF(HTTPD_DEBUG, ("http_accept %p / %p\n", (void *)pcb, arg));

  if ((err != ERR_OK) || (pcb == NULL)) {
    return ERR_VAL;
  }

  /* Set priority */
  altcp_setprio(pcb, HTTPD_TCP_PRIO);

  /* Allocate memory for the structure that holds the state of the
     connection - initialized by that function. */
  hs = http_state_alloc();
  if (hs == NULL) {
    LWIP_DEBUGF(HTTPD_DEBUG, ("http_accept: Out of memory, RST\n"));
    return ERR_MEM;
  }
  hs->pcb = pcb;

  /* Tell TCP that this is the structure we wish to be passed for our
     callbacks. */
  altcp_arg(pcb, hs);

  /* Set up the various callback functions */
  altcp_recv(pcb, http_recv);
  altcp_err(pcb, http_err);
  altcp_poll(pcb, http_poll, HTTPD_POLL_INTERVAL);
  altcp_sent(pcb, http_sent);

  return ERR_OK;
}

static void
httpd_init_pcb(struct altcp_pcb *pcb, uint16_t port)
{
  err_t err;

  if (pcb) {
    altcp_setprio(pcb, HTTPD_TCP_PRIO);
    /* set SOF_REUSEADDR here to explicitly bind httpd to multiple interfaces */
    err_t err = altcp_bind(pcb, IP_ANY_TYPE, HTTPD_SERVER_PORT);
    LWIP_UNUSED_ARG(err); /* in case of LWIP_NOASSERT */
    PRINTF("BIND :%d\n",err);
    LWIP_ASSERT("httpd_init: tcp_bind failed", err == ERR_OK);
    pcb = altcp_listen(pcb);
    LWIP_ASSERT("httpd_init: tcp_listen failed", pcb != NULL);
    altcp_accept(pcb, http_accept);
    PRINTF("HTTP Init Success\n");
  }
}

/**
 * @ingroup httpd
 * Initialize the httpd: set up a listening PCB and bind it to the defined port
 */
void
httpd_init(void)
{
  struct altcp_pcb *pcb;
  LWIP_DEBUGF(HTTPD_DEBUG, ("httpd_init\n"));

  /* LWIP_ASSERT_CORE_LOCKED(); is checked by tcp_new() */

  html_metadata_read();
  if (html_read_buff == NULL) {
	  html_read_buff = (char*)malloc(HTML_BUFFER_SIZE);
	  if (html_read_buff == NULL) {
		  return;
	  }
  }
  if (html_css == NULL) {
	  html_css = (uint8_t*)malloc(HTML_CSS_SIZE);
	  if (html_css == NULL) {
		  PRINTF("HTML CSS MALLOC FAILED\n");
		  return;
	  } else {
		  html_page_read_from_flash(html_css, CSS_PAGE);
	  }
  }
  if (http_rx_buf == NULL) {
	  http_rx_buf = (char*)malloc(HTTP_RX_BUF_SIZE);
	  if (http_rx_buf == NULL) {
		  return;
	  }
  }
  pcb = altcp_tcp_new_ip_type(IPADDR_TYPE_ANY);
  LWIP_ASSERT("httpd_init: tcp_new failed", pcb != NULL);
  httpd_init_pcb(pcb, HTTPD_SERVER_PORT);

}

void http_close(void) {

	struct tcp_pcb *cpcb;
    for (cpcb = tcp_listen_pcbs;cpcb != NULL; cpcb = cpcb->next) {
    	PRINTF("PCB :%p\n",cpcb);
    	if(cpcb -> state == LISTEN && cpcb->local_port == 80) {
    		altcp_close(cpcb);
            PRINTF("PCB LISTEN>>>>\n");
            login_status = 0;
    	}
    }
    if (html_read_buff != NULL) {
    	free(html_read_buff);
    	html_read_buff = NULL;
    	free(http_rx_buf);
    	http_rx_buf = NULL;
    }
}

#endif /* LWIP_TCP && LWIP_CALLBACK_API */
