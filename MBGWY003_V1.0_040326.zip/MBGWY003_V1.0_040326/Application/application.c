/**
  **************************
  * @file    application.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 30
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */
/* Includes ------------------------------------------------------------------*/
#include <dns_client.h>
#include "tcp_client.h"
#include "application.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"
#include "httpd_structs.h"
#include "at32f435_437_board.h"
#include "modbus_gw_cfg.h"

#include "hal_ethernet.h"
#include "hal_gpio.h"
#include "hal_system_init.h"
#include "hal_timer.h"
#include "hal_uart.h"
#include "hal_exint.h"

#include "spi_flash.h"
#include "modbus-rtu.h"
#include <time.h>
#include "hal_rtc.h"
#include "cJSON_parser_modbus_gw.h"
#include "epoch_conversion.h"
#include "cs_db.h"
#include "checksum.h"
#include "flash.h"
#include "netconf.h"
#include "xmodem.h"
#include "html_to_spi_flash.h"
#include "mqtt_client.h"
#include "http_client.h"
#include "at32_emac.h"
#include "sntp_time.h"
#include "fota_parser.h"
#include "ping.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#define WORKING_MODE_STATUS                   0X0A
#define CONFIG_MODE_STATUS                    0X0B

#define SUSPEND_MODE_SET                      0XAA

#define WORKING_MODE                         1
#define MODIFY_CONFIG_MODE                   2
#define FACTORY_RESET                        3
#define FACTORY_CONFIG_MODE                  4
#define FRESH_DEVICE_CONFIG                  5
#define MODIFY_CONFIG_STOP                   6
#define MODIFY_CONFIG_CHANGE                 7
#define SPI_ERROR_MODE                       8


#define BUTTON_STATE_IDLE                    1
#define BUTTON_STATE_FIRST_PRESS_DETECTED    2
#define BUTTON_STATE_WAIT_SECOND_PRESS       3
#define BUTTON_STATE_LONG_PRESS_ACTIVE       4
#define BUTTON_STATE_DOUBLE_PRESS            5
#define BUTTON_STATE_FACTORY_TMT             6

#define SERIAL1_LED                          1
#define SERIAL2_LED                          2
#define TCP_LED                              3

#define FRESH_DEV_CFG_BUF                    1024
#define HTML_STORAGE_LEN                     4096

#define FOTA_TEST                            0
#define FOTA_TIMEOUT                         5000

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/


uint8_t *fresh_dev_ptr = NULL;

TaskHandle_t modbus_task_handler = NULL;
TaskHandle_t cloud_comm_task_handler = NULL;
TaskHandle_t cfg_task_handler = NULL;

static volatile uint8_t suspend_task = 0;
volatile uint8_t button_state = BUTTON_STATE_IDLE;
volatile uint8_t button_is_down = 0;
volatile uint32_t press_start_time = 0;
volatile uint16_t tmr_count;
static uint16_t data_len;

cloud_data_t gw_cloud_data;


modbus_cfg_t modbus_data = {
    .cfg_flg = 0xFF,
    .network_data = {
    	.ipv4_address = 0XFA01A8C0,
    	.default_gateway = 0X0101A8C0,
    	.subnet_mask = 0X00FFFFFF,
    },
};
uint8_t firmware_version[5] = "1.0";
uint8_t msg_type;
log_send_t log_snd_info;
log_store_t log_store_info;

uint8_t *html_storage_buf = NULL;
uint16_t html_storage_length;
uint8_t xmodem_start;
extern xmodem_context_t xmodem_ctx;
volatile uint8_t ethernet_ok;

const char fota_get_url[] = "http://192.168.1.9/Firmware_fota/fota_mbgwy003_%d.txt";//116.74.252.6
#define FOTA_URL_LEN      64

extern char *fota_buf;
uint8_t fota_reset;
uint8_t fota_current_part_num;
uint16_t fota_current_len;
uint16_t global_crc = 0xFFFF;
fota_meta_t fota_meta_data;
uint8_t cloud_init_ok;
uint8_t cloud_gw_ok;
uint32_t cloud_seq_num;
volatile uint8_t device_state;
//volatile uint8_t cloud_task_start;
SemaphoreHandle_t ResourceMutex;

uint8_t cloud_rtu1_start;
uint8_t cloud_rtu2_start;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

void factory_reset(void);

/******************************************************************************
 * @brief       xmodem callback
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void xModem_cbk(uint8_t *ip_buf, uint8_t buf_len) {

	memcpy((html_storage_buf + html_storage_length), ip_buf, buf_len);
	html_storage_length += buf_len;
	if (html_storage_length == HTML_STORAGE_LEN) {
		html_page_write_into_flash(html_storage_buf, HTML_STORAGE_LEN);
		html_storage_length = 0;
	}
}
/******************************************************************************
 * @brief       GSM FOTA GET
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_fota_get(void) {

	if (!fota_current_part_num) {
		fota_meta_t ft;
		uint8_t fota_dt[256];
		uint8_t sts = extract_json_block(fota_buf, fota_dt, 256);
		if (sts && parse_fota_metadata_cjson(fota_dt, &ft)) {
        	if (compare_version(fota_meta_data.fw_version, ft.fw_version)) {
        		fota_reset = 0;
        		fota_meta_data = ft;
        		PRINTF("LATEST VERSION FOUND\n");
    			fota_current_part_num = 1;
        	} else {
        		PRINTF("LATEST VERSION NOT FOUND\n");
#if FOTA_TEST
        		fota_meta_data = ft;
        		fota_current_part_num = 1;
#else
        		fota_meta_data.epoch_time = epoch_time_get();
        		fota_status_set(&fota_meta_data);
        		return 0;
#endif
        	}
    		PRINTF("1.FOTA INFO:%u,%u\n", ft.size, ft.chunks);
    		PRINTF("2.FOTA INFO:%s,%04X\n", ft.fw_version, ft.crc);
		} else {
			if (fota_reset >= 5) {
        		fota_meta_data.epoch_time = epoch_time_get();
        		fota_status_set(&fota_meta_data);
        		PRINTF("1.FOTA TIMEOUT\n");
        		return 0;
			} else {
				fota_reset++;
				fota_current_part_num = 0;
			}
		}
	} else {

	    uint16_t incoming_crc = (uint16_t)(fota_buf[fota_current_len - 2] |
	                                      (fota_buf[fota_current_len - 1] << 8));
	    uint16_t calc_crc = crc16(fota_buf, (fota_current_len - 2));
	    PRINTF("%u<<%04X:%04X>>,%u\n", fota_current_part_num, incoming_crc, calc_crc, fota_current_len - 2);
	    if (calc_crc == incoming_crc) {
	    	global_crc = crc16_update(global_crc, fota_buf, (fota_current_len - 2));
	    	PRINTF("CRC OK\n");
        	if (cdb_write_fota(fota_buf, fota_current_len - 2)) {
        		fota_reset = 0;
        		fota_current_part_num++;
        	}
	        if (fota_current_part_num > fota_meta_data.chunks) {
	        	fota_meta_data.epoch_time = epoch_time_get();
	        	fota_status_set(&fota_meta_data);
	        	PRINTF("FINAL FOTA PART\r\n");
	        	PRINTF("GLOBAL CRC:%04X\r\n",global_crc);
	        	write_firmware_flag(FOTA_SET);
	        }
	    } else {
	    	if (fota_reset >= 5) {
	    		fota_meta_data.epoch_time = epoch_time_get();
	    	    fota_status_set(&fota_meta_data);
	    	    hal_system_reset();
	    	    PRINTF("2.FOTA TIMEOUT\n");
	    	} else {
	    		fota_reset++;
	    	}
	    	PRINTF("CRC FAILURE");
	    }
	}
    return 1;
}
/******************************************************************************
 * @brief       xmodem transfer complete function
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void xmodem_transfer_complete(xmodem_result_t result, uint32_t total_bytes)
{
    if (result == XMODEM_SUCCESS) {
    	printf("\r\n[XMODEM] File received successfully!\r\n");
    	printf("[XMODEM] File size: %lu bytes\r\n", total_bytes);
        printf("[XMODEM] Ready for next transfer...\r\n");
        if (html_storage_length > 0) {
        	html_page_write_into_flash(html_storage_buf, html_storage_length);
        }
        finalize_last_page_on_eot();
        free(html_storage_buf);
        hal_system_reset();
    } else {
    	printf("\r\n[XMODEM] Transfer failed: %d\r\n", result);
    }
}
/******************************************************************************
 * @brief       xModem Task
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void xmodem_task(void *pvParameters)
{
	if (html_storage_buf == NULL) {
		html_storage_buf = (uint8_t*)malloc(HTML_STORAGE_LEN * 2);
	}
	xmodem_ctx.uart_port = USART_6;
    xmodem_ctx.transfer_complete = xmodem_transfer_complete;
    xmodem_ctx.debug_output_enabled = 0;

    printf("\r\n=== XMODEM Receiver Ready ===\r\n");
    printf("Waiting for XMODEM transfer...\r\n");
    xmodem_start = 1;
    while (1) {
        xmodem_result_t result = xmodem_receive(&xmodem_ctx, 600000);
        if (result == XMODEM_SUCCESS) {
        	PRINTF("Transfer completed successfully!\r\n");
        } else {
        	PRINTF("Transfer failed with error: %d\r\n", result);
        }

        vTaskDelay(1000);
    }
}
/******************************************************************************
 * @brief       handle fresh device config
 * @param[in]   buffer
 * @param[in]   buffer_length
 * @return      none
 ******************************************************************************/
void handle_fresh_dev_config(uint8_t *buffer, uint16_t buffer_length) {

	if (is_valid_json(buffer, buffer_length)) {
		PRINTF("VALID PACKET\n");
		parse_json_key_value(buffer,"MTP",&msg_type);
		printf("MSG TYPE : %u\n",msg_type);
	} else {
		fresh_dev_ptr[data_len] = '\0';
		msg_type = 5;
	}

}
/******************************************************************************
 * @brief       lwip periodic handle
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void Fresh_dev_task(void *pvParameters) {

	if (fresh_dev_ptr == NULL) {
		fresh_dev_ptr = (uint8_t*)malloc(FRESH_DEV_CFG_BUF);
	}
	uint8_t output_buffer[256];
	printf("FRESH DEV TASK START\n");
	while(1) {
		switch (msg_type) {
		    case 1 :
		             {
		    	         fresh_device_config_t write_config;
		                 parse_json_for_fresh_config(fresh_dev_ptr,&write_config);
		    	         write_fresh_device_config_into_flash(&write_config);
		    	         prepare_response_with_status(fresh_dev_ptr, 1, output_buffer);
		    	         uint8_t len = strlen(output_buffer);
		    	         uart_transmit(USART_6, output_buffer, len, 1000);
		    	    	 printf("WRITE CONFIG SUCCESS\n");
		    	    	 data_len = 0;
		    	    	 msg_type = 0;
		             }
		             break;
		    case 2 :
		             {
		            	 fresh_device_config_t read_config;
		            	 read_fresh_device_config_from_flash(&read_config);
		    	         prepare_read_back_response_for_fresh_device(read_config, output_buffer);
		    	         uint8_t  ip[256];
		    	         prepare_response_with_status(output_buffer, 1, ip);
		    	         uint8_t len = strlen(ip);
		    	         uart_transmit(USART_6, ip, len,1000);
                         printf("READ SUCCESS\n");
                         data_len = 0;
                         msg_type = 0;
		             }
		    	     break;
		    case 4 : printf("<<<CONFIG DONE>>>\n");
		    	     hal_system_reset();
		    	     data_len = 0;
		    	     break;
		    case 6 :
			        if(xTaskCreate(xmodem_task, "XMODEM", 2048, NULL, 3, NULL) != pdPASS){
			        	printf("ERROR: xmodem task creation failed!\r\n");
			        } else {
			        	printf("INFO: xmodem task created successfully\r\n");
			        }
  	                msg_type = 0;
  	                data_len = 0;
			        break;
		    default:
		    	break;
		}
		vTaskDelay(500);
	}
}
/******************************************************************************
 * @brief       FOTA Engine
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void fota_engine(void) {

	while (1) {
		uint8_t fota_sts = 1;
		fota_current_len = 0;
		char url[FOTA_URL_LEN];
		if (fota_current_part_num) {
			snprintf(url, sizeof(url), fota_get_url, 1);
		} else {
			snprintf(url, sizeof(url), fota_get_url, 0);
		}
		http_client_fota_get(url);
		TickType_t start_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
		while ( !fota_current_len) {
			if (((xTaskGetTickCount() - start_time) >= FOTA_TIMEOUT)) {
				fota_sts = 0;
				break;
			}
			vTaskDelay(1);
		}
		if (fota_sts) {
			PRINTF("FOTA FOUND\n");
			if (gsm_fota_get()) {
		    	 if ((fota_current_part_num > fota_meta_data.chunks)) {
		    		 hal_system_reset();
		    	 }
	    	 } else {
	    		 hal_system_reset();;
	    	 }
		} else {
			fota_reset++;
			if (fota_reset >= 5) {
        		fota_meta_data.epoch_time = epoch_time_get();
        		fota_status_set(&fota_meta_data);
        		hal_system_reset();
				break;
			}
			PRINTF("NO FOTA FOUND\n");
		}
		vTaskDelay(FOTA_TIMEOUT);
	}
}
/******************************************************************************
 * @brief       Cloud init engine
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void cloud_init_engine(void) {

	if (!cloud_init_ok) {
	    if (modbus_data.cloud_data.mode == CLOUD_MODE_MQTT) {
	    	mqtt_client_init();
	    } else if (modbus_data.cloud_data.mode == CLOUD_MODE_HTTP) {
	    	cloud_init_ok = 2;
	    } else {
            tcp_client_initialization();
	    }
	}
}
/******************************************************************************
 * @brief       led mode set - device mode
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void led_mode_set(uint8_t mode) {

	switch(mode) {
	    case WORKING_MODE :
	    	 hal_timer_pwm_cfg(TIMER4, 3500, 85.7); // total_time, dutycycle
	    	 break;
	    case FACTORY_RESET:
	    	 hal_timer_pwm_cfg(TIMER4, 1000, 50);
	    	 break;
	    case FACTORY_CONFIG_MODE:
	    	 hal_timer_pwm_cfg(TIMER4, 2000, 50);
	    	 break;
	    case SPI_ERROR_MODE:
	    	 hal_timer_pwm_cfg(TIMER4, 500, 50);
	    	 break;
        default:
	         break;
    }
}
/******************************************************************************
 * @brief       Read modbus config from spi flash
 * @param[in]   data
 * @return      none
 ******************************************************************************/
void Read_modbus_config(void) {

	memset((uint8_t*)&modbus_data, 0, sizeof(modbus_cfg_t));
	if (!cdb_read_mb_conf((uint8_t*)&modbus_data, sizeof(modbus_cfg_t))) {
		cdb_read_mb_conf((uint8_t*)&modbus_data, sizeof(modbus_cfg_t));
	}
	uint8_t *rx_start = ((uint8_t *)&modbus_data) + offsetof(modbus_cfg_t, data_poll_interval);
	uint8_t *rx_end   = ((uint8_t *)&modbus_data) + offsetof(modbus_cfg_t, checksum);
	uint8_t rx_cs = calculate_checksum_using_addition(rx_start, rx_end - rx_start);
	if (rx_cs != modbus_data.checksum) {
		PRINTF("READ CHECKSUM ERROR:%04X,%04X\n",rx_cs, modbus_data.checksum);
		led_mode_set(SPI_ERROR_MODE);
	}
}
/******************************************************************************
 * @brief       write modbus config into spi flash
 * @param[in]   data
 * @return      none
 ******************************************************************************/
uint8_t write_modbus_config(void) {

	cdb_erase_mb_conf();
	cdb_erase_data_log();
	modbus_data.cfg_flg = 0xFF;
	uint8_t *tx_start = ((uint8_t *)&modbus_data) + offsetof(modbus_cfg_t, data_poll_interval);
	uint8_t *tx_end   = ((uint8_t *)&modbus_data) + offsetof(modbus_cfg_t, checksum);
	uint8_t tx_cs = calculate_checksum_using_addition(tx_start, tx_end - tx_start);
	modbus_data.checksum = tx_cs;
	PRINTF("TX checksum:%04X\n",tx_cs);
	if(cdb_write_mb_conf((uint8_t*)&modbus_data, sizeof(modbus_cfg_t))){
		PRINTF("MODBUS CONFIG WRITE DONE\n");
		device_config_mode_set(0x0A);
		return 1;
	} else {
		led_mode_set(SPI_ERROR_MODE);
		return 0;
	}
}
/******************************************************************************
 * @brief       timer callback function
 * @param[in]   timer_type - which timer triggers interrupt
 * @return      none
 ******************************************************************************/
void timer_cbk(uint8_t timer_type) {

     if (timer_type == TIMER1) {
        tmr_count++;
        switch (button_state) {
             case BUTTON_STATE_FIRST_PRESS_DETECTED:
                  if (button_is_down && (tmr_count >= LONG_PRESS_TIME_MS/10)) {
                	  device_state = FACTORY_RESET;
                	  PRINTF("LONG PRESS\n");
                	  tmr_count = 0;
                	  led_mode_set(FACTORY_RESET);
                      button_state = BUTTON_STATE_FACTORY_TMT;
                  }
                  break;
             case BUTTON_STATE_FACTORY_TMT:
            	  if (tmr_count >= 300) {
            		  button_state = BUTTON_STATE_IDLE;
            		  factory_reset();
            	  }
            	  break;
             case BUTTON_STATE_WAIT_SECOND_PRESS:
                  if (!button_is_down && (tmr_count >= DOUBLE_PRESS_WINDOW_MS/10)) {
                      PRINTF("SINGLE PRESS\n");
                      hal_timer_enable_disable(TIMER1,0);
                      button_state = BUTTON_STATE_IDLE;
                  }
                  break;
             case BUTTON_STATE_DOUBLE_PRESS:
                 if (!button_is_down && (tmr_count >= MODIFY_CONFIG_TIMEOUT_IN_MS/10)) {
                     PRINTF("MODIFY CONFIG TIMEOUT\n");
                     device_state = MODIFY_CONFIG_STOP;
                     button_state = BUTTON_STATE_IDLE;
                     hal_timer_enable_disable(TIMER1, 0);
                     hal_system_reset();
                 }
                 break;
        }
	}
}
/******************************************************************************
 * @brief       Timer callback function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void uart_cbk_app(uint8_t uart_type, uint8_t event_type, uint8_t data) {
	if (uart_type == USART_6) {
		if (event_type == 1) {
			if (xmodem_start) {
				transfer_data_to_xmodem(data, USART_6, 1);
			} else {
				fresh_dev_ptr[data_len++] = data;
			}
		} else {
			if (xmodem_start) {
				transfer_data_to_xmodem(data, USART_6, 2);
			} else {
				fresh_dev_ptr[data_len] = '\0';
				handle_fresh_dev_config(fresh_dev_ptr, data_len);
			}
		}
	}
}
/******************************************************************************
 * @brief       User button callback function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void user_button_cbk(void) {

	uint8_t state = hal_gpio_input_pin_read(USER_BTN_PRT, USER_BTN_PIN);
    if (!state && !button_is_down) {
    	PRINTF("HIGH:%u,%u\n", device_state, button_state);
    	button_is_down = 1;
        if (button_state == BUTTON_STATE_IDLE || button_state == BUTTON_STATE_DOUBLE_PRESS) {
            button_state  = BUTTON_STATE_FIRST_PRESS_DETECTED;
            tmr_count     = 0;
            hal_timer_enable_disable(TIMER1, 1);
        }
    } else if (state && button_is_down){
    	PRINTF("LOW:%u,%u\n", device_state, button_state);
        button_is_down = 0;
        if (button_state == BUTTON_STATE_FIRST_PRESS_DETECTED) {
            button_state = BUTTON_STATE_WAIT_SECOND_PRESS;
        } else if (button_state == BUTTON_STATE_WAIT_SECOND_PRESS) {
        	if (device_state == WORKING_MODE) {
                PRINTF("Double press\n");
                suspend_task = SUSPEND_MODE_SET;
                device_state = MODIFY_CONFIG_MODE;
                button_state = BUTTON_STATE_DOUBLE_PRESS;
        	} else if (device_state == MODIFY_CONFIG_MODE) {
        		hal_system_reset();
        	}
        }
    }
}
/******************************************************************************
 * @brief       HTTP server callback
 * @param[in]   event
 * @return      none
 ******************************************************************************/
void factory_reset(void) {
	cdb_erase_mb_conf();
	cdb_erase_data_log();
    device_config_mode_set(CONFIG_MODE_STATUS);
	hal_system_reset();
}
/******************************************************************************
 * @brief       HTTP server callback
 * @param[in]   event
 * @return      none
 ******************************************************************************/
uint8_t http_cbk_app(uint8_t event_type) {

	switch(event_type) {
	    case 1: if (write_modbus_config()) {
	    	       PRINTF("FRESH CFG SPI\n");
	    	       return 1;
	            } else {
	            	return 0;
	            }
		        break;
	    case 2: hal_system_reset();
	    	    break;
	    case 3: factory_reset();
	    	    break;
	    case 4 :
	    	     hal_system_reset();
	    	     break;
	}
	return 1;
}
/******************************************************************************
 * @brief       TCP client connection callback
 * @param[in]   event
 * @return      none
 ******************************************************************************/
void ethernet_cbk_app(uint8_t event_type) {

	ethernet_ok = event_type;
}
/******************************************************************************
 * @brief       TCP client connection callback
 * @param[in]   event
 * @return      none
 ******************************************************************************/
void tcp_client_conn_cbk_app(uint8_t event_type, uint8_t data) {

	if (event_type == CONNECTION_EVENT) {
		cloud_init_ok = data;
	} else {
		cloud_gw_ok = data;
	}
}
/******************************************************************************
 * @brief       MQTT connection callback
 * @param[in]   event
 * @return      none
 ******************************************************************************/
void mqtt_conn_cbk_app(uint8_t event_type, uint8_t data) {

	if (event_type == CONNECTION_EVENT) {
		cloud_init_ok = data;
	} else {
		cloud_gw_ok = data;
	}
}
/******************************************************************************
 * @brief       MQTT connection callback
 * @param[in]   event
 * @return      none
 ******************************************************************************/
void http_conn_cbk_app(uint8_t event_type, uint16_t len) {

	if (event_type == CONNECTION_EVENT) {
		fota_current_len = len;
	} else {
		cloud_gw_ok = len;
	}
}
uint32_t mcu_status;
/******************************************************************************
 * @brief       MODBUS task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void Modbus_Task(void *pvParameters) {

	int rc = -1;
	uint16_t data_poll_interval_ms = modbus_data.data_poll_interval;
	static modbus_t *ctx_uart1 = NULL;
	static modbus_t *ctx_uart2 = NULL;
	static modbus_t *ctx_tcp = NULL;
	uint8_t coil_buf[32];
    uint16_t reg_data[128];
    ctx_uart1 = modbus_new_rtu("uart4", modbus_data.serial_data.channel1.baud_rate, modbus_data.serial_data.channel1.parity,
    		modbus_data.serial_data.channel1.data_bits, modbus_data.serial_data.channel1.stop_bits);
    ctx_uart2 = modbus_new_rtu("uart5", modbus_data.serial_data.channel2.baud_rate, modbus_data.serial_data.channel2.parity,
    		modbus_data.serial_data.channel2.data_bits, modbus_data.serial_data.channel2.stop_bits);
    modbus_connect(ctx_uart1);
    modbus_connect(ctx_uart2);
    while (1) {

    	mcu_status++;
    	PRINTF("MODBUS stack: %lu words:%u\n", (unsigned long int)uxTaskGetStackHighWaterMark(NULL), mcu_status);
        /* --- Process RTU Channel 1 --- */
        for (uint8_t i = 0; i < modbus_data.rtu_port_1.num_devices; i++) {
            rtu_device_t *dev = &modbus_data.rtu_port_1.devices[i];
            modbus_set_debug(ctx_uart1, 0);
            modbus_set_slave(ctx_uart1, dev->slave_id);
            uint32_t to_sec  = dev->response_timeout_ms / 1000;
            uint32_t to_usec = (dev->response_timeout_ms % 1000) * 1000;
            modbus_set_response_timeout(ctx_uart1, to_sec, to_usec);

            for (int p = 0; p < dev->num_points; p++) {
            	memset(reg_data, 0, sizeof(reg_data));
            	int start_address = dev->points[p].start_address;
            	int reg_count = dev->points[p].reg_count;
            	uint8_t reg_type = dev->points[p].reg_type;
                rc = -1;

                if (reg_type == REG_COIL) {
                    rc = modbus_read_bits(ctx_uart1, start_address, reg_count, coil_buf);
                } else if (reg_type == REG_DISCRETE_INPUT) {
                    rc = modbus_read_input_bits(ctx_uart1, start_address, reg_count, coil_buf);
                } else if (reg_type == REG_INPUT_REGISTER) {
                    rc = modbus_read_input_registers(ctx_uart1, start_address, reg_count, reg_data);
                } else {
                    rc = modbus_read_registers(ctx_uart1, start_address, reg_count, reg_data);
                }

//                xSemaphoreGive(UartMutex);
                if (rc == -1) {
                    PRINTF("RTU1 Slave Read Failed\n");
                } else {
                	hal_timer_one_cycle_mode_set(SERIAL1_LED);
                    xSemaphoreTake(ResourceMutex, portMAX_DELAY);
                    if ((dev->points[p].reg_type == REG_COIL) || (dev->points[p].reg_type == REG_DISCRETE_INPUT)) {
                   	  memcpy(gw_cloud_data.rtu1[i].points[p].data,(uint8_t *)coil_buf, rc);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                        printf("[RTU1][%d][%d] Coils: ", i, p);
                        for (int j = 0; j < rc; j++) {
                            uint8_t val =
                                gw_cloud_data.rtu1[i].points[p].data[j];
                            printf("%02X ", val);
                        }
                         printf("\n");
#endif
                    } else {
                    	memcpy(gw_cloud_data.rtu1[i].points[p].data,(uint8_t *)reg_data, rc * 2);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                        printf("[RTU1][%d][%d]: ", i, p);
                        for (int j = 0; j < rc; j++) {
                            uint16_t val =
                                gw_cloud_data.rtu1[i].points[p].data[j * 2] |
                               (gw_cloud_data.rtu1[i].points[p].data[j * 2 + 1] << 8);
                            printf("%04X ", val);
                        }
                        printf("\n");
#endif
                    }
                    xSemaphoreGive(ResourceMutex);
                }
                vTaskDelay(100);
            }
            xSemaphoreTake(ResourceMutex, portMAX_DELAY);
            gw_cloud_data.rtu1[i].timestamp = epoch_time_get();
            xSemaphoreGive(ResourceMutex);
        }

        if (!cloud_rtu1_start) {
        	cloud_rtu1_start = 1;
        }

        /* --- Process RTU Channel 2 --- */
        for (uint8_t i = 0; i < modbus_data.rtu_port_2.num_devices; i++) {
            rtu_device_t *dev = &modbus_data.rtu_port_2.devices[i];
            modbus_set_debug(ctx_uart2, 0);
            modbus_set_slave(ctx_uart2, dev->slave_id);
            uint32_t to_sec  = dev->response_timeout_ms / 1000;
            uint32_t to_usec = (dev->response_timeout_ms % 1000) * 1000;
            modbus_set_response_timeout(ctx_uart2, to_sec, to_usec);

            for (int p = 0; p < dev->num_points; p++) { // dev->num_points
            	memset(reg_data, 0, sizeof(reg_data));
            	int start_address = dev->points[p].start_address;
            	int reg_count = dev->points[p].reg_count;
            	uint8_t reg_type = dev->points[p].reg_type;
                rc = -1;
                if (reg_type == REG_COIL) {
                    rc = modbus_read_bits(ctx_uart2, start_address, reg_count, coil_buf);
                } else if (reg_type == REG_DISCRETE_INPUT) {
                    rc = modbus_read_input_bits(ctx_uart2, start_address, reg_count, coil_buf);
                } else if (reg_type == REG_INPUT_REGISTER) {
                    rc = modbus_read_input_registers(ctx_uart2, start_address, reg_count, reg_data);
                } else {
                    rc = modbus_read_registers(ctx_uart2, start_address, reg_count, reg_data);
                }
                if (rc == -1) {
                    PRINTF("RTU2 Slave Read Failed\n");
                } else {
//                	at32_led_on(LED4);
                	hal_timer_one_cycle_mode_set(SERIAL2_LED);
                    xSemaphoreTake(ResourceMutex, portMAX_DELAY);
                    if ((dev->points[p].reg_type == REG_COIL) || (dev->points[p].reg_type == REG_DISCRETE_INPUT)) {
                  	  memcpy(gw_cloud_data.rtu2[i].points[p].data, (uint8_t *)coil_buf, rc);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                        printf("[RTU2][%d][%d] Coils: ", i, p);
                         for (int j = 0; j < rc; j++) {
                             uint8_t val =
                                 gw_cloud_data.rtu2[i].points[p].data[j];
                             printf("%02X ", val);
                         }
                         printf("\n");
#endif
                    } else {
                    	memcpy(gw_cloud_data.rtu2[i].points[p].data,(uint8_t *)reg_data, rc * 2);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                        printf("[RTU2][%d][%d]: ", i, p);
                        for (int j = 0; j < rc; j++) {
                            uint16_t val =
                                gw_cloud_data.rtu2[i].points[p].data[j * 2] |
                               (gw_cloud_data.rtu2[i].points[p].data[j * 2 + 1] << 8);
                            printf("%04X ", val);
                        }
                        printf("\n");
#endif
                    }
                    xSemaphoreGive(ResourceMutex);
                }
                vTaskDelay(100);
//                at32_led_off(LED4);
            }
            xSemaphoreTake(ResourceMutex, portMAX_DELAY);
            gw_cloud_data.rtu2[i].timestamp = epoch_time_get();
            xSemaphoreGive(ResourceMutex);
        }
        if (!cloud_rtu2_start) {
        	cloud_rtu2_start = 1;
        }
        vTaskDelay(data_poll_interval_ms);
    }
}

/******************************************************************************
 * @brief       Send data to cloud
 * @param[in]   None
 * @return      None
 ******************************************************************************/
int8_t send_cloud_data(uint8_t cloud_type, uint8_t *json_out) {

	int8_t status = 1;
	uint16_t json_len = strlen(json_out);
	if (json_len == 0 || !ethernet_ok) {
		return 0;
	}
	switch(cloud_type) {
	     case TCP_MODE:
	    	  status = tcp_client_data_transmit(json_out, json_len);
		      break;
	     case HTTP_MODE:
	    	  status = http_client_post(json_out, json_len);
		      break;
	     case MQTT_MODE:
	    	  status = cs_mqtt_publish(modbus_data.cloud_data.cfg.mqtt.topic, json_out, json_len, modbus_data.cloud_data.cfg.mqtt.qos, 0);
		      break;
	     default:
		      break;
	}
	vTaskDelay(1000);
	return status;
}
/******************************************************************************
 * @brief       Check Frame complete within tmt
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t check_cloud_response(uint32_t tmt) {

	uint8_t status = 0;
	uint32_t start_time = xTaskGetTickCount();
	while ((xTaskGetTickCount() - start_time) <= tmt ) {
		if (cloud_gw_ok == 1) {
			PRINTF("CLOUD RSP OK\n");
			status = 1;
			break;
		}
		vTaskDelay(10);
	}
	return status;
}
/******************************************************************************
 * @brief       Cloud Communication Task
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void Cloud_communication_Task(void *pvParameters) {

	uint8_t json_out[JSON_OUT_BUF_SIZE];
//	uint32_t start_time;
	uint8_t cloud_mode = modbus_data.cloud_data.mode;
	uint32_t cloud_rsp_tmt_ms = modbus_data.cloud_data.cloud_rsp_timeout * 1000;
	cdb_data_log_pointer_get();
    uint32_t cloud_interval_ms = modbus_data.cloud_data.publish_interval_sec * 1000;
    uint32_t elapsed = cloud_interval_ms; // Force live data on first run
    fota_status_get(&fota_meta_data);
	uint32_t epoch_tmt = epoch_time_get();
	uint8_t fota_sts = is_daily_fota_check_due(epoch_tmt, fota_meta_data.epoch_time);
	 if (fota_sts) {
		 taskENTER_CRITICAL();
		 vTaskSuspend(modbus_task_handler);
		 taskEXIT_CRITICAL();
		 fota_init();
		 fota_engine();
		 PRINTF("FOTA>>\n");
	 } else {
#if FOTA_TEST
		 fota_init();
		 fota_engine();
#endif
		 PRINTF("NORMAL OP>>\n");
	 }
     sntp_time_init();
     dns_initialization();
	 while (1) {
		 if (elapsed >= cloud_interval_ms) {
			 PRINTF("\r\nCLOUD COMM stack: %lu ,%u,%u\n", (unsigned long int)uxTaskGetStackHighWaterMark(NULL), cloud_init_ok, ethernet_ok);
	     	 cloud_init_engine();
		 }
	     uint8_t gsm_online =
	             ((cloud_init_ok == TCP_MODE || cloud_init_ok == HTTP_MODE || cloud_init_ok == MQTT_MODE) && ethernet_ok);

	     /* =====  Check if interval is complete  SEND LIVE DATA ===== */
	     if (elapsed >= cloud_interval_ms) {
	    	 if (gsm_online) {
	    		 for (uint8_t i = 0; i < modbus_data.rtu_port_1.num_devices && cloud_rtu1_start; i++) {
	    			 cloud_gw_ok = 0;
	                 memset(json_out, 0, JSON_OUT_BUF_SIZE);
	                 rtu_device_t *dev = &modbus_data.rtu_port_1.devices[i];
	                 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	 #if CUSTOM_CLOUD_PACKET
	                 create_custom_json_packet("RTU1", dev, &gw_cloud_data.rtu1[i], json_out);
	 #else
	                 create_rtu_json_packet("RTU1", dev, &gw_cloud_data.rtu1[i], json_out);
	 #endif
	                 xSemaphoreGive(ResourceMutex);
	                 PRINTF("RTU1 CLOUD PKT:%s>>%u\r\n",json_out, strlen(json_out));
	                 send_cloud_data(cloud_mode, json_out);
	                 if (check_cloud_response(cloud_rsp_tmt_ms)) {
	                	 hal_timer_one_cycle_mode_set(3);
	                 } else {
	                	 log_store_t log_str;
	                     log_str.dev_no = i;
	                 	 log_str.channel_type = 1;
	                 	 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	                 	 log_str.timestamp = gw_cloud_data.rtu1[i].timestamp;
	                  	 for (uint8_t p = 0; p < modbus_data.rtu_port_1.devices[i].num_points; p++) {
	                  		    memcpy(log_str.log_data[p], gw_cloud_data.rtu1[i].points[p].data, MAX_PAYLOAD);
	                  	 }
	                     cdb_write_data_log((uint8_t*)&log_str);
	                     xSemaphoreGive(ResourceMutex);
	                 }
	                 vTaskDelay(1000);
	    		 }
	             /* ---------- RTU2 DEVICES ---------- */
	             for (uint8_t i = 0; i < modbus_data.rtu_port_2.num_devices && cloud_rtu2_start; i++) {
	            	 cloud_gw_ok = 0;
	                 memset(json_out, 0, JSON_OUT_BUF_SIZE);
	                 rtu_device_t *dev = &modbus_data.rtu_port_2.devices[i];
	                 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	 #if CUSTOM_CLOUD_PACKET
	                 create_custom_json_packet("RTU2", dev, &gw_cloud_data.rtu2[i], json_out);
	 #else
	                 create_rtu_json_packet("RTU2", dev, &gw_cloud_data.rtu2[i], json_out);
	 #endif
	                 xSemaphoreGive(ResourceMutex);
	                 PRINTF("RTU2 CLOUD PKT:%s>>%u\r\n",json_out, strlen(json_out));
	                 send_cloud_data(cloud_mode, json_out);
	                 if (check_cloud_response(cloud_rsp_tmt_ms)) {
	                	 hal_timer_one_cycle_mode_set(3);
	                 } else {
	                	 log_store_t log_str;
	                     log_str.dev_no = i;
	                     log_str.channel_type = 2;
	                  	 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	                  	 log_str.timestamp = gw_cloud_data.rtu2[i].timestamp;
	                  	 for (uint8_t p = 0; p < modbus_data.rtu_port_2.devices[i].num_points; p++) {
	                  		  memcpy(log_str.log_data[p], gw_cloud_data.rtu2[i].points[p].data, MAX_PAYLOAD);
	                  	 }
	                     cdb_write_data_log((uint8_t*)&log_str);
	                     xSemaphoreGive(ResourceMutex);
	                 }
	                 vTaskDelay(1000);
	             }
	    	 } else {
	    		 for (uint8_t i = 0; i < modbus_data.rtu_port_1.num_devices && cloud_rtu1_start; i++) {
	    			 log_store_t log_str;
	                 rtu_device_t *dev = &modbus_data.rtu_port_1.devices[i];
	                 log_str.dev_no = i;
	                 log_str.channel_type = 1;
	                 log_str.log_flg = 0xABAB;
                     xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	            	 log_str.timestamp = gw_cloud_data.rtu1[i].timestamp;
	             	 for (uint8_t p = 0; p < modbus_data.rtu_port_1.devices[i].num_points; p++) {
	             		 memcpy(log_str.log_data[p], gw_cloud_data.rtu1[i].points[p].data, MAX_PAYLOAD);
	             	 }
	                 cdb_write_data_log((uint8_t*)&log_str);
	                 xSemaphoreGive(ResourceMutex);
	    		 }
	             for (uint8_t i = 0; i < modbus_data.rtu_port_2.num_devices && cloud_rtu2_start; i++) {

	            	 log_store_t log_str;
	                 rtu_device_t *dev = &modbus_data.rtu_port_2.devices[i];
	                 log_str.dev_no = i;
	                 log_str.channel_type = 2;
	                 log_str.log_flg = 0xABAB;
                     xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	             	 log_str.timestamp = gw_cloud_data.rtu2[i].timestamp;
	             	 for (uint8_t p = 0; p < modbus_data.rtu_port_2.devices[i].num_points; p++) {
	             		    memcpy(log_str.log_data[p], gw_cloud_data.rtu2[i].points[p].data, MAX_PAYLOAD);
	             	 }
                     cdb_write_data_log((uint8_t*)&log_str);
                     xSemaphoreGive(ResourceMutex);
	             }
	    	 }
	         elapsed = 0; // Restart interval counter
	     }
	         /* ===== 2 Every cycle: Send STORED LOGS if GSM is ready ===== */
         if (gsm_online) {
        	 memset(&log_store_info, 0, sizeof(log_store_t));
	 	     uint8_t log_sts = cdb_read_data_log((uint8_t*)&log_store_info);
	 	     if (log_store_info.log_flg == 0xABAB && log_store_info.timestamp != 0) {
	 			PRINTF("LOG FLAG:%04X, %u\n",log_store_info.log_flg, log_store_info.timestamp);
	 			log_sts = log_sts & 1;
	 	     } else {
	 				log_sts = log_sts & 0;
	 	     }
	 		 if (log_sts) {
	 			 memset(json_out, 0, JSON_OUT_BUF_SIZE);
	 			 if (log_store_info.channel_type == 1) {
	 				 rtu_device_t *dev = &modbus_data.rtu_port_1.devices[log_store_info.dev_no];
	 				 copy_rtu_log(dev, 1, log_store_info.timestamp, log_store_info.log_data, &log_snd_info);
	 			 } else {
	 				 rtu_device_t *dev = &modbus_data.rtu_port_2.devices[log_store_info.dev_no];
	 				 copy_rtu_log(dev, 2, log_store_info.timestamp, log_store_info.log_data, &log_snd_info);
	 			 }
	 #if CUSTOM_CLOUD_PACKET
	 			 create_custom_data_log_json_packet(&log_snd_info, json_out);
	 #else
	 			 create_data_log_json_packet(&log_snd_info, json_out);
	 #endif
	 			 PRINTF("CLOUD LOG PKT:%s>>%u\r\n",json_out, strlen(json_out));
	 			 cloud_gw_ok = 0;
	 			 send_cloud_data(cloud_mode, json_out);
                 if (check_cloud_response(cloud_rsp_tmt_ms)) {
                	 hal_timer_one_cycle_mode_set(3);
                 }
	 			 vTaskDelay(1000);
	 			 elapsed += 1000;
	 		 }
         }
	     elapsed += 100;
	     vTaskDelay(100);
	 }
}
/******************************************************************************
 * @brief       lwip periodic handle
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void lwip_periodic_handle(void *pvParameters) {

	while(1) {
		hal_gpio_toggle(PORT_WDI, PIN_WDI);
	    handle_ethernet_connection();
	    if (suspend_task == SUSPEND_MODE_SET) {
	    	PRINTF("SUSPEND TASK\n");
	    	printf("LWIP TASK stack: %lu words\n", (unsigned long int)uxTaskGetStackHighWaterMark(NULL));
	    	printf("MODBUS TASK stack: %lu words\n", (unsigned long int)uxTaskGetStackHighWaterMark(modbus_task_handler));
	    	printf("cloud TASK stack: %lu words\n", (unsigned long int)uxTaskGetStackHighWaterMark(cloud_comm_task_handler));
	    	taskENTER_CRITICAL();
	    	vTaskDelete(modbus_task_handler);
	    	vTaskDelete(cloud_comm_task_handler);
	    	taskEXIT_CRITICAL();
	    	httpd_init();
	    	led_mode_set(FACTORY_CONFIG_MODE);
	    	suspend_task = 0;
	    }
	    vTaskDelay(200);
	}
}
/******************************************************************************
 * @brief       Network Task function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void network_task_function(void *pvParameters) {

	while(1) {
		ip_details_t ip_cfg;
   	    fresh_device_config_t read_config;
   	    uint8_t flash_sts = read_fresh_device_config_from_flash(&read_config);
   	    mac_id_set(read_config.mac_address);
   	    mac_devid_set_for_cloud(read_config.mac_address, read_config.device_type_id);
		uint8_t mode_state = device_config_mode_get();
		PRINTF("Device mode:%x\n", mode_state);
		if (device_state == FRESH_DEVICE_CONFIG) {
		    if (xTaskCreate((TaskFunction_t)Fresh_dev_task, "fresh_task", 512, NULL, 2, NULL) != pdPASS) {
			    PRINTF("INFO : fresh dev task could not be created\n");
		    } else {
			    PRINTF("INFO: fresh dev task was created successfully\n");
		    }

		} else {
	   	    if (flash_sts == 0) {
	   	    	PRINTF("FOTA MAC ADDRESS READ FAILED\n");
	   	    	while(1);
	   	    }
			if (mode_state == WORKING_MODE_STATUS) {
				Read_modbus_config();
				device_state = WORKING_MODE;
				led_mode_set(WORKING_MODE);
			} else {
				device_state = FACTORY_CONFIG_MODE;
				led_mode_set(FACTORY_CONFIG_MODE);
			}
			ip_cfg.ip_mode = STATIC_IP; // static ip
			if (device_state == WORKING_MODE) {
				PRINTF("WORK WITH NWK\n");
				ip_cfg.local_ip = modbus_data.network_data.ipv4_address;
				ip_cfg.local_gw = modbus_data.network_data.default_gateway;
				ip_cfg.local_mask = modbus_data.network_data.subnet_mask;
			} else {
				PRINTF("WORK WITH DEFAULT\n");
		        ip_cfg.local_ip = modbus_data.network_data.ipv4_address;
		        ip_cfg.local_gw = modbus_data.network_data.default_gateway;
		        ip_cfg.local_mask = modbus_data.network_data.subnet_mask;
			}
			uint8_t error = hal_rmii_ethernet_init(&ip_cfg);
			if (device_state == WORKING_MODE) {
			    if(xTaskCreate((TaskFunction_t)Modbus_Task,"Modbus task", 1024, NULL, tskIDLE_PRIORITY + 2, &modbus_task_handler) != pdPASS) {
					 PRINTF("Modbus task could not be created\r\n");
			    } else {
					 PRINTF("Modbus task was created successfully.\r\n");
			    }
			    if(xTaskCreate((TaskFunction_t)Cloud_communication_Task, "cloud_task", 2048, NULL, tskIDLE_PRIORITY + 3, &cloud_comm_task_handler) != pdPASS) {
					 PRINTF("Cloud communication task could not be created\r\n");
			    } else {
					 PRINTF("Cloud communication task was created successfully.\r\n");
			    }
			} else {
			    uart_init(UART_4, 9600, 'N', 8, 1);
			    uart_init(UART_5, 9600, 'N', 8, 1);
				httpd_init();
			}
			fill_device_info(read_config.mac_address,modbus_data.network_data.ipv4_address,modbus_data.network_data.subnet_mask,
					modbus_data.network_data.default_gateway, read_config.device_type_id, firmware_version);
		}
	    vTaskDelete(NULL);
	}
}
/******************************************************************************
 * @brief       Start RTOS function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void start_task(void) {

	    ResourceMutex = xSemaphoreCreateMutex();
	    if (ResourceMutex != NULL) {
            PRINTF("SEMAPHORE CRESTED SUCCESSFULLY\n");
	    }
	    if(xTaskCreate((TaskFunction_t)network_task_function,"Network_task", 512, NULL, tskIDLE_PRIORITY + 4, NULL) != pdPASS) {
			 PRINTF("Network task could not be created \r\n");
	    } else {
			 PRINTF("Network task was created successfully.\r\n");
	    }
		if (xTaskCreate((TaskFunction_t)lwip_periodic_handle,"lwip_looping_task", 512, NULL, tskIDLE_PRIORITY + 4, NULL) != pdPASS) {
			PRINTF("INFO : lwip_recv_task could not be created\n");
	    } else {
			 PRINTF("INFO: lwip_periodic_handle task was created successfully.\n");
		}
	    vTaskStartScheduler(); //configMINIMAL_STACK_SIZE
}
/******************************************************************************
 * @brief       Direction control gpio init function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void uart_dir_control_gpio_init(void) {
	hal_gpio_init(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_OUTPUT, PULL_NONE);
	hal_gpio_write(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_RESET);
	hal_gpio_init(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_OUTPUT, PULL_NONE);
	hal_gpio_write(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_RESET);
	hal_timer_init(TIMER6,1);
}
/******************************************************************************
 * @brief       Watchdog gpio init function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void watchdog_gpio_init(void) {
	hal_gpio_init(PORT_WDI, PIN_WDI, GPIO_OUTPUT, PULL_NONE);
}
/******************************************************************************
 * @brief       led timer initialization
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void led_init(void) {
	hal_timer_one_cycle_mode_init();
}
/******************************************************************************
 * @brief       Pheripheral initialization
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void Peripheral_init(void) {

	watchdog_gpio_init();
	uart_dir_control_gpio_init();
	hal_exint_init(USER_BTN_PRT, USER_BTN_PIN);
    uint8_t pin_status = hal_gpio_input_pin_read(USER_BTN_PRT, USER_BTN_PIN);
	if (pin_status == 0) {
		 uart_print_init(115200, 1);
         device_state = FRESH_DEVICE_CONFIG;
	} else {
		uart_print_init(115200, 0);
		led_init();
	}
    spiflash_init();
    uint16_t id = spiflash_read_id();
    PRINTF("SPI ID:%04X\n",id);
	hal_timer_init(TIMER1,10);
	hal_rtc_init();
	PRINTF("AT32F437RGT7 Board init\r\n");
}
/******************************************************************************
 * @brief       app_main - start of application
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void App_main(void) {

	Peripheral_init();
	ethernet_callback_register(ethernet_cbk_app);
	timer_callback_register(timer_cbk);
	http_callback_register(http_cbk_app);
	hal_usr_butn_clbk_reg(user_button_cbk);
	uart_callback_register(uart_cbk_app);
	mqtt_callback_register(mqtt_conn_cbk_app);
	tcp_client_callback_register(tcp_client_conn_cbk_app);
	http_client_callback_register(http_conn_cbk_app);
	xmodem_callback_register(xModem_cbk);
    start_task();
}



 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
