################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
../cmsis/startup_at32f435_437.s 

C_SRCS += \
../cmsis/system_at32f435_437.c 

OBJS += \
./cmsis/startup_at32f435_437.o \
./cmsis/system_at32f435_437.o 

S_DEPS += \
./cmsis/startup_at32f435_437.d 

C_DEPS += \
./cmsis/system_at32f435_437.d 


# Each subdirectory must supply rules for building sources it contributes
cmsis/%.o: ../cmsis/%.s cmsis/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross Assembler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

cmsis/%.o: ../cmsis/%.c cmsis/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\http" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\xmodem" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\user" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\database" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cJSON" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus" -I"D:\AT32F437\lwip_rtos\freertos\source\include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\memmang" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


