Application/application.o: ../Application/application.c \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/dns_client.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/tcp_client.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/err.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h \
 ../include/FreeRTOSConfig.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/portable.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h \
 D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h \
 ../Application/application.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/semphr.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/queue.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/task.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/list.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/task.h \
 ../include/httpd_structs.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/httpd.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/httpd_opts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/iana.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/pbuf.h \
 ../include/at32f435_437_board.h \
 ../include/libraries/cmsis/cm4/device_support/at32f435_437.h \
 ../include/libraries/cmsis/cm4/core_support/core_cm4.h \
 ../include/libraries/cmsis/cm4/core_support/cmsis_version.h \
 ../include/libraries/cmsis/cm4/core_support/cmsis_compiler.h \
 ../include/libraries/cmsis/cm4/core_support/cmsis_gcc.h \
 ../include/libraries/cmsis/cm4/core_support/mpu_armv7.h \
 ../include/libraries/cmsis/cm4/device_support/system_at32f435_437.h \
 ../include/libraries/drivers/inc/at32f435_437_def.h \
 ../include/at32f435_437_conf.h \
 ../include/libraries/drivers/inc/at32f435_437_crm.h \
 ../include/libraries/drivers/inc/at32f435_437_tmr.h \
 ../include/libraries/drivers/inc/at32f435_437_ertc.h \
 ../include/libraries/drivers/inc/at32f435_437_gpio.h \
 ../include/libraries/drivers/inc/at32f435_437_i2c.h \
 ../include/libraries/drivers/inc/at32f435_437_usart.h \
 ../include/libraries/drivers/inc/at32f435_437_pwc.h \
 ../include/libraries/drivers/inc/at32f435_437_can.h \
 ../include/libraries/drivers/inc/at32f435_437_adc.h \
 ../include/libraries/drivers/inc/at32f435_437_dac.h \
 ../include/libraries/drivers/inc/at32f435_437_spi.h \
 ../include/libraries/drivers/inc/at32f435_437_dma.h \
 ../include/libraries/drivers/inc/at32f435_437_debug.h \
 ../include/libraries/drivers/inc/at32f435_437_flash.h \
 ../include/libraries/drivers/inc/at32f435_437_crc.h \
 ../include/libraries/drivers/inc/at32f435_437_wwdt.h \
 ../include/libraries/drivers/inc/at32f435_437_wdt.h \
 ../include/libraries/drivers/inc/at32f435_437_exint.h \
 ../include/libraries/drivers/inc/at32f435_437_sdio.h \
 ../include/libraries/drivers/inc/at32f435_437_xmc.h \
 ../include/libraries/drivers/inc/at32f435_437_acc.h \
 ../include/libraries/drivers/inc/at32f435_437_misc.h \
 ../include/libraries/drivers/inc/at32f435_437_edma.h \
 ../include/libraries/drivers/inc/at32f435_437_qspi.h \
 ../include/libraries/drivers/inc/at32f435_437_scfg.h \
 ../include/libraries/drivers/inc/at32f435_437_emac.h \
 ../include/libraries/drivers/inc/at32f435_437_dvp.h \
 ../include/libraries/drivers/inc/at32f435_437_usb.h \
 ../include/modbus_gw_cfg.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_rtc.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_ethernet.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_gpio.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_system_init.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_timer.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_uart.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_exint.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash/spi_flash.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc/modbus-rtu.h \
 d:\at32f437_workspace\mbgwy003_v1.0_040326\hal\hal_uart.h \
 d:\at32f437_workspace\mbgwy003_v1.0_040326\middleware\modbus\modbus.h \
 d:\at32f437_workspace\mbgwy003_v1.0_040326\middleware\modbus\modbus_rtu/inc/modbus-rtu.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc/modbus-rtu-private.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cJSON/cJSON_parser_modbus_gw.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion/epoch_conversion.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\database/cs_db.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum/checksum.h \
 ../include/flash.h ../include/at32f435_437_board.h \
 ../include/modbus_gw_cfg.h ../include/netconf.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\xmodem/xmodem.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/queue.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash/html_to_spi_flash.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/mqtt_client.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/mqtt.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/mqtt_opts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/mqtt_priv.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/altcp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcpbase.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/mem.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/netif.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/stats.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/memp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/memp_std.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/memp_priv.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/mem_priv.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/ip4.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/bpstruct.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/epstruct.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/ip.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/icmp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/icmp.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/http_client.h \
 ../include/at32_emac.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/sntp_time.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/fota_parser.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/ping.h
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/dns_client.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/tcp_client.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/err.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h:
D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h:
../include/FreeRTOSConfig.h:
D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h:
D:\AT32F437\lwip_rtos\freertos\source\include/portable.h:
D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h:
D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h:
D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h:
../Application/application.h:
D:\AT32F437\lwip_rtos\freertos\source\include/semphr.h:
D:\AT32F437\lwip_rtos\freertos\source\include/queue.h:
D:\AT32F437\lwip_rtos\freertos\source\include/task.h:
D:\AT32F437\lwip_rtos\freertos\source\include/list.h:
D:\AT32F437\lwip_rtos\freertos\source\include/task.h:
../include/httpd_structs.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/httpd.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/httpd_opts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/iana.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/pbuf.h:
../include/at32f435_437_board.h:
../include/libraries/cmsis/cm4/device_support/at32f435_437.h:
../include/libraries/cmsis/cm4/core_support/core_cm4.h:
../include/libraries/cmsis/cm4/core_support/cmsis_version.h:
../include/libraries/cmsis/cm4/core_support/cmsis_compiler.h:
../include/libraries/cmsis/cm4/core_support/cmsis_gcc.h:
../include/libraries/cmsis/cm4/core_support/mpu_armv7.h:
../include/libraries/cmsis/cm4/device_support/system_at32f435_437.h:
../include/libraries/drivers/inc/at32f435_437_def.h:
../include/at32f435_437_conf.h:
../include/libraries/drivers/inc/at32f435_437_crm.h:
../include/libraries/drivers/inc/at32f435_437_tmr.h:
../include/libraries/drivers/inc/at32f435_437_ertc.h:
../include/libraries/drivers/inc/at32f435_437_gpio.h:
../include/libraries/drivers/inc/at32f435_437_i2c.h:
../include/libraries/drivers/inc/at32f435_437_usart.h:
../include/libraries/drivers/inc/at32f435_437_pwc.h:
../include/libraries/drivers/inc/at32f435_437_can.h:
../include/libraries/drivers/inc/at32f435_437_adc.h:
../include/libraries/drivers/inc/at32f435_437_dac.h:
../include/libraries/drivers/inc/at32f435_437_spi.h:
../include/libraries/drivers/inc/at32f435_437_dma.h:
../include/libraries/drivers/inc/at32f435_437_debug.h:
../include/libraries/drivers/inc/at32f435_437_flash.h:
../include/libraries/drivers/inc/at32f435_437_crc.h:
../include/libraries/drivers/inc/at32f435_437_wwdt.h:
../include/libraries/drivers/inc/at32f435_437_wdt.h:
../include/libraries/drivers/inc/at32f435_437_exint.h:
../include/libraries/drivers/inc/at32f435_437_sdio.h:
../include/libraries/drivers/inc/at32f435_437_xmc.h:
../include/libraries/drivers/inc/at32f435_437_acc.h:
../include/libraries/drivers/inc/at32f435_437_misc.h:
../include/libraries/drivers/inc/at32f435_437_edma.h:
../include/libraries/drivers/inc/at32f435_437_qspi.h:
../include/libraries/drivers/inc/at32f435_437_scfg.h:
../include/libraries/drivers/inc/at32f435_437_emac.h:
../include/libraries/drivers/inc/at32f435_437_dvp.h:
../include/libraries/drivers/inc/at32f435_437_usb.h:
../include/modbus_gw_cfg.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_rtc.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_ethernet.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_gpio.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_system_init.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_timer.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_uart.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_exint.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash/spi_flash.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc/modbus-rtu.h:
d:\at32f437_workspace\mbgwy003_v1.0_040326\hal\hal_uart.h:
d:\at32f437_workspace\mbgwy003_v1.0_040326\middleware\modbus\modbus.h:
d:\at32f437_workspace\mbgwy003_v1.0_040326\middleware\modbus\modbus_rtu/inc/modbus-rtu.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc/modbus-rtu-private.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cJSON/cJSON_parser_modbus_gw.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion/epoch_conversion.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\database/cs_db.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum/checksum.h:
../include/flash.h:
../include/at32f435_437_board.h:
../include/modbus_gw_cfg.h:
../include/netconf.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\xmodem/xmodem.h:
D:\AT32F437\lwip_rtos\freertos\source\include/queue.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash/html_to_spi_flash.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/mqtt_client.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/mqtt.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/mqtt_opts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/mqtt_priv.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/altcp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/tcpbase.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/mem.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/netif.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/stats.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/memp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/memp_std.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/memp_priv.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/priv/mem_priv.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/ip4.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/bpstruct.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/epstruct.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/ip.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/icmp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/icmp.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/http_client.h:
../include/at32_emac.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/sntp_time.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/fota_parser.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet/ping.h:
