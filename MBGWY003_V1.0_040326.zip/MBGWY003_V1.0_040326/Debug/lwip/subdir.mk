################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lwip/api_lib.c \
../lwip/api_msg.c \
../lwip/autoip.c \
../lwip/def.c \
../lwip/dhcp.c \
../lwip/dns.c \
../lwip/err.c \
../lwip/etharp.c \
../lwip/ethernet.c \
../lwip/ethernetif.c \
../lwip/fs.c \
../lwip/icmp.c \
../lwip/igmp.c \
../lwip/inet_chksum.c \
../lwip/init.c \
../lwip/ip.c \
../lwip/ip4.c \
../lwip/ip4_addr.c \
../lwip/ip4_frag.c \
../lwip/mem.c \
../lwip/memp.c \
../lwip/mqtt.c \
../lwip/netbuf.c \
../lwip/netdb.c \
../lwip/netif.c \
../lwip/netifapi.c \
../lwip/pbuf.c \
../lwip/raw.c \
../lwip/sntp.c \
../lwip/sockets.c \
../lwip/stats.c \
../lwip/sys.c \
../lwip/sys_arch.c \
../lwip/tcp.c \
../lwip/tcp_in.c \
../lwip/tcp_out.c \
../lwip/tcpip.c \
../lwip/timeouts.c \
../lwip/udp.c 

OBJS += \
./lwip/api_lib.o \
./lwip/api_msg.o \
./lwip/autoip.o \
./lwip/def.o \
./lwip/dhcp.o \
./lwip/dns.o \
./lwip/err.o \
./lwip/etharp.o \
./lwip/ethernet.o \
./lwip/ethernetif.o \
./lwip/fs.o \
./lwip/icmp.o \
./lwip/igmp.o \
./lwip/inet_chksum.o \
./lwip/init.o \
./lwip/ip.o \
./lwip/ip4.o \
./lwip/ip4_addr.o \
./lwip/ip4_frag.o \
./lwip/mem.o \
./lwip/memp.o \
./lwip/mqtt.o \
./lwip/netbuf.o \
./lwip/netdb.o \
./lwip/netif.o \
./lwip/netifapi.o \
./lwip/pbuf.o \
./lwip/raw.o \
./lwip/sntp.o \
./lwip/sockets.o \
./lwip/stats.o \
./lwip/sys.o \
./lwip/sys_arch.o \
./lwip/tcp.o \
./lwip/tcp_in.o \
./lwip/tcp_out.o \
./lwip/tcpip.o \
./lwip/timeouts.o \
./lwip/udp.o 

C_DEPS += \
./lwip/api_lib.d \
./lwip/api_msg.d \
./lwip/autoip.d \
./lwip/def.d \
./lwip/dhcp.d \
./lwip/dns.d \
./lwip/err.d \
./lwip/etharp.d \
./lwip/ethernet.d \
./lwip/ethernetif.d \
./lwip/fs.d \
./lwip/icmp.d \
./lwip/igmp.d \
./lwip/inet_chksum.d \
./lwip/init.d \
./lwip/ip.d \
./lwip/ip4.d \
./lwip/ip4_addr.d \
./lwip/ip4_frag.d \
./lwip/mem.d \
./lwip/memp.d \
./lwip/mqtt.d \
./lwip/netbuf.d \
./lwip/netdb.d \
./lwip/netif.d \
./lwip/netifapi.d \
./lwip/pbuf.d \
./lwip/raw.d \
./lwip/sntp.d \
./lwip/sockets.d \
./lwip/stats.d \
./lwip/sys.d \
./lwip/sys_arch.d \
./lwip/tcp.d \
./lwip/tcp_in.d \
./lwip/tcp_out.d \
./lwip/tcpip.d \
./lwip/timeouts.d \
./lwip/udp.d 


# Each subdirectory must supply rules for building sources it contributes
lwip/%.o: ../lwip/%.c lwip/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\http" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\xmodem" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\user" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\database" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cJSON" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus" -I"D:\AT32F437\lwip_rtos\freertos\source\include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\memmang" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


