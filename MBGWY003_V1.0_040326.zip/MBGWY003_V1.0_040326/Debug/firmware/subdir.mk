################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../firmware/at32f435_437_acc.c \
../firmware/at32f435_437_adc.c \
../firmware/at32f435_437_can.c \
../firmware/at32f435_437_crc.c \
../firmware/at32f435_437_crm.c \
../firmware/at32f435_437_dac.c \
../firmware/at32f435_437_debug.c \
../firmware/at32f435_437_dma.c \
../firmware/at32f435_437_dvp.c \
../firmware/at32f435_437_edma.c \
../firmware/at32f435_437_emac.c \
../firmware/at32f435_437_ertc.c \
../firmware/at32f435_437_exint.c \
../firmware/at32f435_437_flash.c \
../firmware/at32f435_437_gpio.c \
../firmware/at32f435_437_i2c.c \
../firmware/at32f435_437_misc.c \
../firmware/at32f435_437_pwc.c \
../firmware/at32f435_437_qspi.c \
../firmware/at32f435_437_scfg.c \
../firmware/at32f435_437_sdio.c \
../firmware/at32f435_437_spi.c \
../firmware/at32f435_437_tmr.c \
../firmware/at32f435_437_usart.c \
../firmware/at32f435_437_usb.c \
../firmware/at32f435_437_wdt.c \
../firmware/at32f435_437_wwdt.c \
../firmware/at32f435_437_xmc.c 

OBJS += \
./firmware/at32f435_437_acc.o \
./firmware/at32f435_437_adc.o \
./firmware/at32f435_437_can.o \
./firmware/at32f435_437_crc.o \
./firmware/at32f435_437_crm.o \
./firmware/at32f435_437_dac.o \
./firmware/at32f435_437_debug.o \
./firmware/at32f435_437_dma.o \
./firmware/at32f435_437_dvp.o \
./firmware/at32f435_437_edma.o \
./firmware/at32f435_437_emac.o \
./firmware/at32f435_437_ertc.o \
./firmware/at32f435_437_exint.o \
./firmware/at32f435_437_flash.o \
./firmware/at32f435_437_gpio.o \
./firmware/at32f435_437_i2c.o \
./firmware/at32f435_437_misc.o \
./firmware/at32f435_437_pwc.o \
./firmware/at32f435_437_qspi.o \
./firmware/at32f435_437_scfg.o \
./firmware/at32f435_437_sdio.o \
./firmware/at32f435_437_spi.o \
./firmware/at32f435_437_tmr.o \
./firmware/at32f435_437_usart.o \
./firmware/at32f435_437_usb.o \
./firmware/at32f435_437_wdt.o \
./firmware/at32f435_437_wwdt.o \
./firmware/at32f435_437_xmc.o 

C_DEPS += \
./firmware/at32f435_437_acc.d \
./firmware/at32f435_437_adc.d \
./firmware/at32f435_437_can.d \
./firmware/at32f435_437_crc.d \
./firmware/at32f435_437_crm.d \
./firmware/at32f435_437_dac.d \
./firmware/at32f435_437_debug.d \
./firmware/at32f435_437_dma.d \
./firmware/at32f435_437_dvp.d \
./firmware/at32f435_437_edma.d \
./firmware/at32f435_437_emac.d \
./firmware/at32f435_437_ertc.d \
./firmware/at32f435_437_exint.d \
./firmware/at32f435_437_flash.d \
./firmware/at32f435_437_gpio.d \
./firmware/at32f435_437_i2c.d \
./firmware/at32f435_437_misc.d \
./firmware/at32f435_437_pwc.d \
./firmware/at32f435_437_qspi.d \
./firmware/at32f435_437_scfg.d \
./firmware/at32f435_437_sdio.d \
./firmware/at32f435_437_spi.d \
./firmware/at32f435_437_tmr.d \
./firmware/at32f435_437_usart.d \
./firmware/at32f435_437_usb.d \
./firmware/at32f435_437_wdt.d \
./firmware/at32f435_437_wwdt.d \
./firmware/at32f435_437_xmc.d 


# Each subdirectory must supply rules for building sources it contributes
firmware/%.o: ../firmware/%.c firmware/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\http" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\xmodem" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\user" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\database" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cJSON" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus" -I"D:\AT32F437\lwip_rtos\freertos\source\include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\memmang" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


