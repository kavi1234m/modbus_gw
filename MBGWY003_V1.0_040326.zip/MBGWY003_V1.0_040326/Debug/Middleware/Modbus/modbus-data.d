Middleware/Modbus/modbus-data.o: ../Middleware/Modbus/modbus-data.c \
 ../Middleware/Modbus/modbus.h \
 ../Middleware/Modbus/modbus_rtu/inc/modbus-rtu.h \
 d:\at32f437_workspace\mbgwy003_v1.0_040326\hal\hal_uart.h \
 ../Middleware/Modbus/modbus_rtu/inc/../../modbus.h \
 ../Middleware/Modbus/modbus_rtu/inc/modbus-rtu-private.h
../Middleware/Modbus/modbus.h:
../Middleware/Modbus/modbus_rtu/inc/modbus-rtu.h:
d:\at32f437_workspace\mbgwy003_v1.0_040326\hal\hal_uart.h:
../Middleware/Modbus/modbus_rtu/inc/../../modbus.h:
../Middleware/Modbus/modbus_rtu/inc/modbus-rtu-private.h:
