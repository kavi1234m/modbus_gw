Middleware/cloud_ethernet/sntp_time.o: \
 ../Middleware/cloud_ethernet/sntp_time.c \
 ../Middleware/cloud_ethernet/sntp_time.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_rtc.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/sntp.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/sntp_opts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h \
 ../include/FreeRTOSConfig.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/portable.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h \
 D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/iana.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h \
 ../include/modbus_gw_cfg.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion/epoch_conversion.h
../Middleware/cloud_ethernet/sntp_time.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_rtc.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/sntp.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/apps/sntp_opts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h:
D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h:
../include/FreeRTOSConfig.h:
D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h:
D:\AT32F437\lwip_rtos\freertos\source\include/portable.h:
D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h:
D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h:
D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/prot/iana.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h:
../include/modbus_gw_cfg.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion/epoch_conversion.h:
