Middleware/cloud_ethernet/fota_parser.o: \
 ../Middleware/cloud_ethernet/fota_parser.c \
 ../Middleware/cloud_ethernet/fota_parser.h ../include/modbus_gw_cfg.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_rtc.h
../Middleware/cloud_ethernet/fota_parser.h:
../include/modbus_gw_cfg.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_rtc.h:
