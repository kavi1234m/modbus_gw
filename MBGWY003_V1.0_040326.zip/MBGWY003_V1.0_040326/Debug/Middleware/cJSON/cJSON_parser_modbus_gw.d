Middleware/cJSON/cJSON_parser_modbus_gw.o: \
 ../Middleware/cJSON/cJSON_parser_modbus_gw.c \
 ../Middleware/cJSON/cJSON_parser_modbus_gw.h ../include/modbus_gw_cfg.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_rtc.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion/epoch_conversion.h \
 ../Middleware/cJSON/cJSON.h
../Middleware/cJSON/cJSON_parser_modbus_gw.h:
../include/modbus_gw_cfg.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_rtc.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion/epoch_conversion.h:
../Middleware/cJSON/cJSON.h:
