################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Middleware/spi_flash/html_to_spi_flash.c \
../Middleware/spi_flash/spi_flash.c 

OBJS += \
./Middleware/spi_flash/html_to_spi_flash.o \
./Middleware/spi_flash/spi_flash.o 

C_DEPS += \
./Middleware/spi_flash/html_to_spi_flash.d \
./Middleware/spi_flash/spi_flash.d 


# Each subdirectory must supply rules for building sources it contributes
Middleware/spi_flash/%.o: ../Middleware/spi_flash/%.c Middleware/spi_flash/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\http" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cloud_ethernet" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\xmodem" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\user" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\database" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\epoch_conversion" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\cJSON" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus" -I"D:\AT32F437\lwip_rtos\freertos\source\include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\memmang" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus\modbus_rtu\inc" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\Modbus" -I"D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Middleware\spi_flash" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


