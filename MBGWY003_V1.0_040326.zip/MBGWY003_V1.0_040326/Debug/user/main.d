user/main.o: ../user/main.c \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application/application.h \
 D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_system_init.h
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Application/application.h:
D:\AT32F437_WORKSPACE\MBGWY003_V1.0_040326\Hal/hal_system_init.h:
