/**
  **************************
  * @file    netconf.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    26-03-2025
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __NETCONF_H_
#define __NETCONF_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/
int8_t tcpip_stack_init(void);
void lwip_pkt_handle(void);
int8_t set_ip_using_dhcp(void);
int8_t set_static_ip(uint32_t local_ip, uint32_t local_gw, uint32_t subnet_mask);
void check_ethernet_link(void);
void mac_id_set(uint8_t *mac);
//uint8_t is_gateway_reachable(void);

/*  Functions used to _________________ ***/


/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* _NETCONF_H_ */

/***** (C) COPYRIGHT 2022 Calixto Systems Pvt Ltd ***END OF FILE*/
