/*
 * Copyright � St�phane Raimbault <stephane.raimbault@gmail.com>
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#ifndef MODBUS_RTU_PRIVATE_H
#define MODBUS_RTU_PRIVATE_H

#ifndef _MSC_VER
#include <stdint.h>
#else
#include "stdint.h"
#endif

#include "../../../../Hal/hal_uart.h"

#define _MODBUS_RTU_HEADER_LENGTH     1
#define _MODBUS_RTU_PRESET_REQ_LENGTH 6
#define _MODBUS_RTU_PRESET_RSP_LENGTH 2

#define _MODBUS_RTU_CHECKSUM_LENGTH 2

#define PY_BUF_SIZE 512


typedef struct uart_fun_backend{
	  void (*connect)(uart_type uart_x,uint32_t baud, uint8_t parity, uint8_t data_bit, uint8_t stop_bit);
	  int8_t (*tx)(uart_type uart_x,const uint8_t *req,uint16_t req_length, uint16_t us);
	  void (*rx)(uart_type uart_x,uint8_t *rsp, uint16_t rsp_length);
	  void (*close)(uart_type uart_x);
	  void (*reset_buff)(uart_type uart_x);
}uart_backend_t;


typedef struct _modbus_rtu {
    char *device;

    int device_type;
    /* Bauds: 9600, 19200, 57600, 115200, etc */
    int baud;
    /* Data bit */
    uint8_t data_bit;
    /* Stop bit */
    uint8_t stop_bit;
    /* Parity: 'N', 'O', 'E' */
    char parity;

    int serial_mode;

    /* To handle many slaves on the same link */
    int confirmation_to_ignore;

    /* usart function */
   const uart_backend_t *uart_backend;

} modbus_rtu_t;


#endif /* MODBUS_RTU_PRIVATE_H */
