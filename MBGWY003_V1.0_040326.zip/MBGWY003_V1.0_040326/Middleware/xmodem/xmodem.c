#include "xmodem.h"
#include "task.h"
#include "timers.h"
#include <string.h>
#include "at32f435_437_board.h"
#include "modbus_gw_cfg.h"

uint8_t xmodem_rx_buffer[260];
uint16_t xmodem_rx_index = 0;
bool xmodem_transfer_active = false;

xmodem_context_t xmodem_ctx;

typedef void (*xmodem_cbk_fun)();
xmodem_cbk_fun xmodem_app;
uint8_t xmodem_yes;


void transfer_data_to_xmodem(uint8_t data, uart_type uart_port, uint8_t event_type)
{
	if (event_type == 1) {
	    if ( xmodem_transfer_active && uart_port == USART_6) {
	        if (xmodem_rx_index < sizeof(xmodem_rx_buffer)) {
	            xmodem_rx_buffer[xmodem_rx_index++] = data;
	        }
	    }
	} else if (event_type == 2) {
		xmodem_yes = 1;
	}
}

void xmodem_callback_register(void *callback) {
	xmodem_app = callback;
}

static uint16_t xmodem_crc16(const uint8_t *data, size_t length)
{
    uint16_t crc = 0;

    while (length--) {
        crc = crc ^ ((uint16_t)*data++ << 8);
        for (uint8_t i = 0; i < 8; i++) {
            if (crc & 0x8000) {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc = crc << 1;
            }
        }
    }

    return crc;
}

static void xmodem_send_byte(uart_type uart_port, uint8_t data)
{
//    uint8_t temp_buf[1] = {data};
    uart_transmit(uart_port, &data, 1, 100);
}

static void xmodem_flush_rx_buffer(void)
{
    xmodem_rx_index = 0;
    memset(xmodem_rx_buffer, 0, sizeof(xmodem_rx_buffer));
}


void xmodem_enable_debug_output(xmodem_context_t *ctx, bool enable)
{
    if (ctx) {
        ctx->debug_output_enabled = enable;
    }
}


bool xmodem_receive_byte(uart_type uart_port, uint8_t *data, uint32_t timeout_ms)
{
    TickType_t start_time = xTaskGetTickCount();

    while ((xTaskGetTickCount() - start_time) < timeout_ms) {
        if (xmodem_rx_index > 0) {
            *data = xmodem_rx_buffer[0];

            memmove(xmodem_rx_buffer, xmodem_rx_buffer + 1, xmodem_rx_index - 1);
            xmodem_rx_index--;
            return true;
        }

        vTaskDelay(1);

        if (&xmodem_ctx && !&xmodem_ctx.transfer_active) {
            return false;
        }
    }

    return false;
}
xmodem_result_t xmodem_receive(xmodem_context_t *ctx, uint32_t timeout_ms)
{
    if (!ctx) {
        return XMODEM_ERROR_MEMORY;
    }

    ctx->transfer_active = true;
    ctx->transfer_success = false;
    ctx->total_bytes = 0;
    ctx->total_packets = 0;
    xmodem_transfer_active = true;

    uint8_t packet_data[XMODEM_BUFFER_SIZE];
    uint8_t expected_packet = 1;
    uint8_t eot_received = 0;

    // Flush any existing data
    xmodem_flush_rx_buffer();

    if (ctx->debug_output_enabled) {
        printf("\r\n[XMODEM] Waiting for transmission... Send file now!\r\n");
    }

    xmodem_send_byte(ctx->uart_port, XMODEM_C);

    TickType_t start_time = xTaskGetTickCount();
    uint32_t consecutive_timeouts = 0;
    uint32_t nak_count = 0;

    while (ctx->transfer_active && !eot_received) {
        uint8_t header;
        if (xmodem_yes && xmodem_receive_byte(ctx->uart_port, &header, 5000)) {
            consecutive_timeouts = 0;
            if (header == XMODEM_SOH) {

            	uint8_t packet_num, packet_num_inv;
                if (!xmodem_receive_byte(ctx->uart_port, &packet_num, 1000) ||
                    !xmodem_receive_byte(ctx->uart_port, &packet_num_inv, 1000)) {
                    xmodem_send_byte(ctx->uart_port, XMODEM_NAK);
                    nak_count++;
                    if (ctx->debug_output_enabled) {
                        PRINTF("[XMODEM] Timeout reading packet number\r\n");
                    }
                    continue;
                }

                if (packet_num + packet_num_inv != 0xFF) {
                    if (ctx->debug_output_enabled) {
                        PRINTF("[XMODEM] Invalid packet sequence: %d + %d != 255\r\n",
                               packet_num, packet_num_inv);
                    }
                    xmodem_send_byte(ctx->uart_port, XMODEM_NAK);
                    nak_count++;
                    continue;
                }

                bool data_ok = true;
                for (int i = 0; i < XMODEM_BUFFER_SIZE; i++) {
                    if (!xmodem_receive_byte(ctx->uart_port, &packet_data[i], 1000)) {
                    	uint8_t sd[4] = {0x12, 0x23, 0x34, 0x45};
                    	uart_transmit(USART_1,sd,4,10);
                        data_ok = false;
                        if (ctx->debug_output_enabled) {
                            printf("[XMODEM] Timeout reading data byte %d\r\n", i);
                        }
                        break;
                    }
                }
                if (!data_ok) {
                    xmodem_send_byte(ctx->uart_port, XMODEM_NAK);
                    nak_count++;
                    continue;
                }

                uint8_t crc_high, crc_low;
                if (!xmodem_receive_byte(ctx->uart_port, &crc_high, 1000) ||
                    !xmodem_receive_byte(ctx->uart_port, &crc_low, 1000)) {
                    xmodem_send_byte(ctx->uart_port, XMODEM_NAK);
                    nak_count++;
                    if (ctx->debug_output_enabled) {
                        PRINTF("[XMODEM] Timeout reading CRC\r\n");
                    }
                    continue;
                }

                uint16_t received_crc = (crc_high << 8) | crc_low;
                uint16_t calculated_crc = xmodem_crc16(packet_data, XMODEM_BUFFER_SIZE);
                if (calculated_crc != received_crc) {
                	uint8_t sd[4] = {0x1A, 0x1B, 0x1C, 0x1D};
                	uart_transmit(USART_1,sd,4,10);
                    if (ctx->debug_output_enabled) {
                        PRINTF("[XMODEM] Packet %d CRC error: calc=0x%04X, recv=0x%04X\r\n",
                               packet_num, calculated_crc, received_crc);
                    }
                    xmodem_send_byte(ctx->uart_port, XMODEM_NAK);
                    nak_count++;
                    continue;
                }

                if (packet_num != expected_packet) {
                    if (ctx->debug_output_enabled) {
                        PRINTF("[XMODEM] Sequence error: expected %lu, got %d\r\n",
                               expected_packet, packet_num);
                    }
                    xmodem_send_byte(ctx->uart_port, XMODEM_NAK);
                    nak_count++;
                    continue;
                }

                xmodem_app(packet_data, XMODEM_BUFFER_SIZE);
                xmodem_send_byte(ctx->uart_port, XMODEM_ACK);
                ctx->total_bytes += XMODEM_BUFFER_SIZE;
                ctx->total_packets = expected_packet;
                expected_packet++;
                nak_count = 0;
                xmodem_yes = 0;
                if (ctx->debug_output_enabled) {
                    PRINTF("[XMODEM] Packet %lu OK, Total: %lu bytes\r\n",
                           expected_packet - 1, ctx->total_bytes);
                }
            } else if (header == XMODEM_EOT) {
            	uint8_t sd[4] = {0xf5, 0xfd, 0xad, 0xf5};
            	uart_transmit(USART_1,sd,4,10);
                xmodem_send_byte(ctx->uart_port, XMODEM_ACK);
                vTaskDelay(50);
                xmodem_send_byte(ctx->uart_port, XMODEM_ACK);
                ctx->transfer_success = true;
                ctx->result = XMODEM_SUCCESS;
                eot_received = 1;

                if (ctx->debug_output_enabled) {
                    PRINTF("[XMODEM] Transfer completed successfully!\r\n");
                }
                break;
            } else if (header == XMODEM_CAN) {
            	uint8_t sd[4] = {0xab, 0xfd, 0xad, 0xab};
            	uart_transmit(USART_1,sd,4,10);
                if (ctx->debug_output_enabled) {
                    PRINTF("[XMODEM] Transfer cancelled by sender\r\n");
                }
                ctx->result = XMODEM_ERROR_CANCEL;
                break;
            } else {
                if (ctx->debug_output_enabled) {
                    PRINTF("[XMODEM] Unexpected character: 0x%02X\r\n", header);
                }
                xmodem_send_byte(ctx->uart_port, XMODEM_NAK);
                nak_count++;
            }
        } else {
        	vTaskDelay(50);
            xmodem_send_byte(ctx->uart_port, XMODEM_C);
        }

        if ((xTaskGetTickCount() - start_time) > timeout_ms) {
        	uint8_t sd[4] = {0x39, 0xfd, 0xad, 0x93};
        	uart_transmit(USART_1,sd,4,10);
            if (ctx->debug_output_enabled) {
                PRINTF("[XMODEM] Overall timeout reached\r\n");
            }
            ctx->result = XMODEM_ERROR_TIMEOUT;
            break;
        }
    }

    ctx->transfer_active = false;
    xmodem_transfer_active = false;
    vTaskDelay(100);

    if (ctx->transfer_complete) {
        ctx->transfer_complete(ctx->result, ctx->total_bytes);
    }
    return ctx->result;
}
void xmodem_cancel(xmodem_context_t *ctx)
{
    if (ctx && ctx->transfer_active) {
        ctx->transfer_active = false;
        xmodem_transfer_active = false;

        // Send cancel sequence
        xmodem_send_byte(ctx->uart_port, XMODEM_CAN);
        xmodem_send_byte(ctx->uart_port, XMODEM_CAN);

        ctx->result = XMODEM_ERROR_CANCEL;

        if (ctx->debug_output_enabled) {
            PRINTF("[XMODEM] Transfer cancelled by receiver\r\n");
        }
    }
}
