/**
  **************************
  * @file    sntp_time.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 31
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "sntp_time.h"
#include "hal_rtc.h"
#include "lwip/apps/sntp.h"
#include <time.h>
#include "modbus_gw_cfg.h"
#include "epoch_conversion.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************
 * @brief       epoch time to calendar
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void epoch_to_calendar_lib(uint32_t unix_epoch, calendar_info_t *cal)
{
    time_t t = unix_epoch;
    struct tm *tm_info = gmtime(&t);  // Use localtime(&t) for local timezone

    cal->year  = tm_info->tm_year % 100;  // last 2 digits
    cal->month = tm_info->tm_mon + 1;
    cal->date  = tm_info->tm_mday;
    cal->hour  = tm_info->tm_hour;
    cal->min   = tm_info->tm_min;
    cal->sec   = tm_info->tm_sec;
    cal->week  = tm_info->tm_wday + 1;    // tm_wday: 0=Sun, 6=Sat
    cal->am_pm_type = (tm_info->tm_hour >= 12) ? 1 : 0; // 1=PM,0=AM
}
/******************************************************************************
 * @brief       SNTP callback
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void sntp_callback_app(uint32_t epoch) {

	 calendar_info_t rtc_time;
	  PRINTF(">>>>>>>SNTP UNIX sec: %lu\n", epoch);
	  sntp_stop();
	  epoch_to_calendar_lib(epoch, &rtc_time);
	  PRINTF("20%02d-%02d-%02d %02d:%02d:%02d\n",
	         rtc_time.year, rtc_time.month, rtc_time.date,
	         rtc_time.hour, rtc_time.min, rtc_time.sec);
	  hal_rtc_calendar_set(&rtc_time);
	  sntp_stop();

}
/******************************************************************************
 * @brief       SNTP time init
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void sntp_time_init(void) {

	sntp_callback_register(sntp_callback_app);
    sntp_setoperatingmode(0);
    ip_addr_t str;
    str.addr = 0x504E5542;
    sntp_setserver(0, &str);
    sntp_init();
}



 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
