/**
  **************************
  * @file    fota_parser.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 31
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "fota_parser.h"
#include <string.h>
#include "modbus_gw_cfg.h"
#include <stdint.h>
#include <stdio.h>
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define ONE_DAY_SECONDS      (24 * 60 * 60)
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


uint8_t compare_version(const char *v1, const char *v2)
{
    int major1 = 0, minor1 = 0, patch1 = 0;
    int major2 = 0, minor2 = 0, patch2 = 0;

    int n1 = sscanf(v1, "%d.%d.%d", &major1, &minor1, &patch1);
    int n2 = sscanf(v2, "%d.%d.%d", &major2, &minor2, &patch2);

    // Handle versions like "1.0"
    if (n1 == 2) patch1 = 0;
    if (n2 == 2) patch2 = 0;

    PRINTF("OLD VER %d:%d:%d\r\n", major1, minor1, patch1);
    PRINTF("NEW VER %d:%d:%d\r\n", major2, minor2, patch2);

    if (major1 != major2) return (major2 > major1);
    if (minor1 != minor2) return (minor2 > minor1);
    if (patch1 != patch2) return (patch2 > patch1);

    return 0; // equal
}
/******************************************************************************
 * @brief       Extract json block data
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t extract_json_block(const char *src, char *dst, uint16_t dst_size)
{
    const char *start = strchr(src, '{');
    const char *end   = strchr(src, '}');

    if (!start || !end || end <= start) {
        return 0;   // Not found
    }

    uint16_t len = (end - start) + 1;  // include '}'

    if (len >= dst_size) {
        return 0;   // Destination buffer too small
    }

    memcpy(dst, start, len);
    dst[len] = '\0';

    return 1;   // Success
}

/******************************************************************************
 * @brief       Fota status check
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t is_daily_fota_check_due(uint32_t now, uint32_t last)
{
	PRINTF("FOTA TIME %u:%u\n", now, last);
	PRINTF("DIFF = %u\n", (uint32_t)(now - last));
    if (last == 0) {
    	return 1;
    }               // First boot
    if ((now - last) >= ONE_DAY_SECONDS) {
    	PRINTF("FOTA YES\n");
    	return 1;
    } else {
    	PRINTF("FOTA NO\n");
    	return 0;
    }
}



 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
