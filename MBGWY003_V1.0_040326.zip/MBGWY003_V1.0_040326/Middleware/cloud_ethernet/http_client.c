/**
  **************************
  * @file    http_client.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 31
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "http_client.h"
#include <stdint.h>
#include <string.h>
#include "flash.h"
#include "http.h"
#include "modbus_gw_cfg.h"
#include "lwip/inet.h"
#include "dns_client.h"
#include "cJSON_parser_modbus_gw.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define HTTP_SERVER_PORT                  80
#define FOTA_BUF_SIZE                    (10240)
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

typedef enum {
    HOST_INVALID = 0,
    HOST_IPV4,
    HOST_DNS
} host_type_t;

typedef struct {
    host_type_t type;
    uint32_t    ip;        // network order if IPv4
    char        host[128];  // DNS name if HOST_DNS
    char        path[128]; // always starts with '/'
} url_info_t;

char *fota_buf = NULL;
extern modbus_cfg_t modbus_data;
uint32_t fota_range;
static uint32_t totalreceived, file_size = 0;
httpc_connection_t settings;

typedef void (*http_cbk_fun)(uint8_t event_type, uint16_t data);
http_cbk_fun http_conn_cbk;

uint32_t fota_get_len;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/******************************************************************************
 * @brief       HTTP CLIENT callback register
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void http_client_callback_register(void *cbk) {
     http_conn_cbk = cbk;
}
/********************************************************************************
 * @brief Verify HTTP response header and status code
 * @param resp        Pointer to received buffer
 * @param len         Length of received buffer
 * @param content_len Output Content-Length (optional, can be NULL)
 * @return HTTP_RESP_OK         -> Valid HTTP/1.x 200 OK
 *         HTTP_RESP_INCOMPLETE -> Header not fully received
 *         HTTP_RESP_ERROR      -> Invalid or non-200 response
 *******************************************************************************/
uint8_t http_verify_response(const char *resp, uint32_t len)
{
    const char *p;
    const char *hdr_end;

    if (!resp || len < 12) {
        return 0;
    }

    /* Check HTTP version */
    if (strncmp(resp, "HTTP/1.1", 8) != 0 &&
        strncmp(resp, "HTTP/1.0", 8) != 0) {
        return 0;
    }

    /* Check status code 200 */
    p = strchr(resp, ' ');
    if (!p || (p + 4) > (resp + len)) {
        return 0;
    }

    if (strncmp(p + 1, "200", 3) != 0) {
        return 0;
    }
    return 1;
}
/******************************************************************************
 * @brief       Print parsed url
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void print_parsed_url(const url_info_t *info)
{
    if (!info) {
        PRINTF("URL info is NULL\n");
        return;
    }

    PRINTF("---- Parsed URL ----\n");

    if (info->type == HOST_IPV4) {
        PRINTF("Host Type : IPv4\n");
        PRINTF("IP (net)  : 0x%08lX\n", info->ip);
        PRINTF("IP (str)  : %lu.%lu.%lu.%lu\n",
               (info->ip >> 24) & 0xFF,
               (info->ip >> 16) & 0xFF,
               (info->ip >> 8)  & 0xFF,
                info->ip        & 0xFF);
    }
    else if (info->type == HOST_DNS) {
        PRINTF("Host Type : DNS\n");
        PRINTF("Host Name : %s\n", info->host);
    }
    else {
        PRINTF("Host Type : INVALID\n");
    }

    PRINTF("Path      : %s\n", info->path);
    PRINTF("--------------------\n");
}
/******************************************************************************
 * @brief       Decode http url
 * @param[in]   None
 * @return      None
 ******************************************************************************/
int decode_http_url(const char *url, url_info_t *out)
{
    const char *p;
    const char *host_start;
    const char *path_start;

    if (!url || !out)
        return -1;

    memset(out, 0, sizeof(url_info_t));

    /* Skip scheme */
    if (strncmp(url, "http://", 7) == 0) {
        p = url + 7;
    } else {
        return -1;  // only http supported
    }

    host_start = p;

    /* Find path */
    path_start = strchr(p, '/');
    if (!path_start)
        return -1;

    /* Extract path */
    strncpy(out->path, path_start, sizeof(out->path) - 1);

    /* Extract host */
    size_t host_len = path_start - host_start;
    if (host_len == 0 || host_len >= sizeof(out->host))
        return -1;

    strncpy(out->host, host_start, host_len);
    out->host[host_len] = '\0';

    /* Detect IP or DNS */
    ip4_addr_t addr;
    if (inet_aton(out->host, &addr)) {
        out->type = HOST_IPV4;
        out->ip   = addr.addr;   // network order
    } else {
        out->type = HOST_DNS;
    }

    return 0;
}
/******************************************************************************
 * @brief       resut_fn calback
 * @param[in]   None
 * @return      None
 ******************************************************************************/
static void result_fn(void *arg, httpc_result_t httpc_result, u32_t rx_content_len, u32_t srv_res, err_t err)
{
	if (fota_buf != NULL) {
		if (httpc_result == HTTPC_RESULT_OK ) {
			if (file_size == rx_content_len) {
	        	http_conn_cbk(CONNECTION_EVENT, totalreceived);
	        	if (rx_content_len == 8194) {
	        		fota_get_len += 8194;
	        	}
	        	totalreceived = 0;
			}
		}
	}
	PRINTF("HTTP RSP:%d, %u, %u, %d" ,httpc_result, rx_content_len, srv_res, err);
}
/******************************************************************************
 * @brief       recv_fn calback
 * @param[in]   None
 * @return      None
 ******************************************************************************/
err_t recv_fn(void *arg, struct altcp_pcb *conn, struct pbuf *p, err_t err)
{

	PRINTF("recv_fn\r\n");
    struct pbuf *q = p;
    uint32_t i = 0;
    if (fota_buf != NULL) {
        if (totalreceived == 0) {
        	memset(fota_buf, 0, FOTA_BUF_SIZE);
        }
        if (q->len <= FOTA_BUF_SIZE) {
            while(q != NULL) {
            	memcpy((fota_buf + totalreceived), (char*)q->payload, q->len);
                totalreceived += q->len;
                q = q->next;
            }
        }
    }
    altcp_recved(conn, p->tot_len);
    pbuf_free(p);
    return ERR_OK;
}
/******************************************************************************
 * @brief       recv_http_header_fn calback
 * @param[in]   None
 * @return      None
 ******************************************************************************/
err_t recv_http_header_fn(httpc_state_t *connection, void *arg, struct pbuf *hdr, u16_t hdr_len, u32_t content_len)
{
	PRINTF("HTTP HEADER:%d,%d\n", hdr_len, content_len);
	uint8_t *http_rsp = (uint8_t*)hdr->payload;
	uint8_t sts = http_verify_response(http_rsp, hdr->len);
	if (sts) {
		PRINTF("HTTP OK\n");
		http_conn_cbk(DATA_RSP_EVENT, 1);
	}
    file_size = content_len;
    return ERR_OK;
}
/******************************************************************************
 * @brief       http_client_example
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void http_client_fota_get(uint8_t *url){

	err_t err = ERR_OK;
	uint16_t server_port = HTTP_SERVER_PORT;
	url_info_t info;
	decode_http_url(url, &info);
	print_parsed_url(&info);
	settings.use_proxy = 0;
	settings.result_fn = result_fn;
	settings.headers_done_fn = recv_http_header_fn;
	PRINTF("START HTTP LEN:%u\n", fota_get_len);
	fota_range = fota_get_len + 8193;
	if (info.type == HOST_IPV4) {
	    ip_addr_t srv_ip;
	    srv_ip.addr = info.ip;
	    err = httpc_get_file(&srv_ip, server_port, info.path, &settings, recv_fn, NULL, NULL, fota_get_len, fota_range);
	} else if (info.type == HOST_DNS) {
		err = httpc_get_file_dns(info.host, server_port, info.path, &settings, recv_fn, NULL, NULL, fota_get_len, fota_range);
	}
    if ( err != ERR_OK ) {
    	printf("httpc_get_file failed (%d)\r\n", err);
    }
}
/******************************************************************************
 * @brief       http_client_example
 * @param[in]   None
 * @return      None
 ******************************************************************************/
err_t http_client_post(uint8_t *http_buf, uint16_t length) {

	err_t err = ERR_OK;
	url_info_t info;
	decode_http_url(modbus_data.cloud_data.cfg.http.url, &info);
	print_parsed_url(&info);
	settings.use_proxy = 0;
	settings.result_fn = result_fn;
	settings.headers_done_fn = recv_http_header_fn;
	if (info.type == HOST_IPV4) {
	    ip_addr_t srv_ip;
	    srv_ip.addr = info.ip;
	    err = httpc_post_file(&srv_ip, HTTP_SERVER_PORT, info.path, &settings, recv_fn, NULL, NULL, http_buf, length);
	} else if (info.type == HOST_DNS) {
		err = httpc_post_file_dns(info.host, HTTP_SERVER_PORT, info.path, &settings, recv_fn, NULL, NULL, http_buf, length);
	}
    if ( err != ERR_OK ) {
    	printf("httpc_post_file failed (%d)\r\n", err);
    }
    return err;
}
/******************************************************************************
 * @brief       fota init
 * @param[in]   None
 * @return      None
 ******************************************************************************/

void fota_init(void) {

	if (fota_buf == NULL) {
		fota_buf = (char*)malloc((10 * FOTA_BUF_SIZE) + 4);
	}
}

 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
