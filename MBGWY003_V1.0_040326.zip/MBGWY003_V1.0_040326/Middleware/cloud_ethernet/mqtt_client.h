/**
  **************************
  * @file    mqtt_client.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 30
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MQTT_CLIENT_H_
#define __MQTT_CLIENT_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "lwip/pbuf.h"
#include "lwip/apps/mqtt.h"
#include "lwip/apps/mqtt_priv.h"
#include "lwip/netif.h"
/* Exported types ------------------------------------------------------------*/
#define MQTT_SERVER_ADDRESS  "3.75.162.31"//"192.168.81.1"
#define MQTT_SERVER_PORT     1883
/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/

 err_t mqtt_client_init(void);
 static void at32_mqtt_connection_cb(mqtt_client_t *client, void *arg, mqtt_connection_status_t status);
 static void at32_mqtt_incoming_data_cb(void *arg, const u8_t *data, u16_t len, u8_t flags);
 static void at32_mqtt_incoming_publish_cb(void *arg, const char *topic, u32_t tot_len);
 static void mqtt_client_pub_request_cb(void *arg, err_t result);
 err_t at32_mqtt_publish(mqtt_client_t *client, char *pub_topic, char *pub_buf, uint16_t data_len, uint8_t qos, uint8_t retain);
 static void at32_mqtt_request_cb(void *arg, err_t err);
 static err_t at32_mqtt_subscribe(mqtt_client_t *mqtt_client, char *sub_topic, uint8_t qos);
 err_t mqtt_connect_routine(void);

 uint8_t mqtt_publish_status_get(void);
 uint8_t mqtt_publish_status_set(uint8_t status);
 err_t cs_mqtt_publish(char *pub_topic, char *pub_buf, uint16_t data_len, uint8_t qos, uint8_t retain);
 void mqtt_callback_register(void *cbk);
/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __FILENAME_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
