/**
  **************************
  * @file    tcp_client_comm.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 30
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include <dns_client.h>
#include <string.h>
#include <tcp_client.h>
#include "lwip/tcp.h"
#include "modbus_gw_cfg.h"
#include "cJSON_parser_modbus_gw.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern modbus_cfg_t modbus_data;
extern struct tcp_pcb *tcp_active_pcbs;
unsigned char connect_flag = 0;

uint32_t tcp_server_ip;
uint16_t tcp_server_port;
struct tcp_pcb *pcb;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

typedef void (*tcp_cbk_fun)(uint8_t event_type, uint8_t data);
tcp_cbk_fun tcp_conn_cbk;


err_t tcp_client_init_start(uint16_t local_port, uint16_t remote_port, uint32_t ip);

/*************************************************************************************************
  * @brief  mqtt callback register
  * @param  none
  * @retval none
  ************************************************************************************************/
void tcp_client_callback_register(void *cbk) {

	tcp_conn_cbk = cbk;
}

/******************************************************************************
  * @brief  tcp client send data
  * @param  cpcb: the tcp_pcb that has sent the data
  * @param  buff: the packet buffer
  * @param  length: data size
  * @retval error value
  ********************************************************************************/
err_t tcp_client_send_data_tx(struct tcp_pcb *cpcb,unsigned char *buff,unsigned int length) {

	err_t err;
    err = tcp_write(cpcb, buff, length, TCP_WRITE_FLAG_COPY);  //send data
    tcp_output(cpcb);
    //tcp_close(cpcb);
    return err;
}

/**********************************************************************************
  * @brief  check connection
  * @param  none
  * @retval the tcp_pcb which accepted the connection
  *********************************************************************************/
struct tcp_pcb *check_tcp_client_connect(void) {

	struct tcp_pcb *cpcb = 0;
    connect_flag = 0;
    for(cpcb = tcp_active_pcbs;cpcb != NULL; cpcb = cpcb->next) {
    	if(cpcb -> state == ESTABLISHED) {
    		connect_flag = 1;
            break;
    	}
    }
    if(connect_flag == 0) {
    	tcp_conn_cbk(CONNECTION_EVENT, 0);
	    tcp_client_init_start(0, tcp_server_port, tcp_server_ip);
        cpcb = 0;
    }
    return cpcb;
}

/**********************************************************************************
  * @brief  report connection is establish
  * @param  arg: user supplied argument
  * @param  pcb: the tcp_pcb which accepted the connection
  * @param  err: error value
  * @retval err_t: it will response error code
  *********************************************************************************/
err_t tcp_connected_cbk(void *arg, struct tcp_pcb *pcb, err_t err)
{
	printf("TCP CONNECTED\n");
	tcp_conn_cbk(CONNECTION_EVENT, TCP_MODE);
    return ERR_OK;
}
/**********************************************************************************
  * @brief  receiving callback funtion for TCP client
  * @param  arg: the user argument
  * @param  pcb: the tcp_pcb that has received the data
  * @param  p: the packet buffer
  * @param  err: the error value linked with the received data
  * @retval error value
  *********************************************************************************/
err_t tcp_client_recv_cbk(void *arg, struct tcp_pcb *pcb,struct pbuf *p,err_t err) {

	if(p != NULL) {
		tcp_recved(pcb, p->tot_len);
        char* rx_buf = (char*)p->payload;
        tcp_conn_cbk(DATA_RSP_EVENT, 1);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
        printf("TCP RECEIVED DATA:%d\n\r", p->tot_len);
        for (uint16_t i = 0; i < p->tot_len; i++) {
    	    printf("%c", rx_buf[i]);
        }
        printf("\r\n");
#endif
	} else {
	   tcp_conn_cbk(CONNECTION_EVENT, 0);
       tcp_close(pcb);
	}
    pbuf_free(p);
    err = ERR_OK;
    return err;
}
/**********************************************************************************
  * @brief  initialize tcp client
  * @param  local_port: local port
  * @param  remote_port: remote port
  * @param  a: ip byte 0
  * @param  b: ip byte 1
  * @param  c: ip byte 2
  * @param  d: ip byte 3
  * @retval none
  *********************************************************************************/
err_t tcp_client_init_start(uint16_t local_port, uint16_t remote_port, uint32_t ip) {


	  struct tcp_pcb *cpcb = 0;
	  connect_flag = 0;
	  for(cpcb = tcp_active_pcbs;cpcb != NULL; cpcb = cpcb->next)
	  {
	    if(cpcb -> state == SYN_SENT)
	    {
	      tcp_close(cpcb);
	    }
	  }
	  PRINTF("TCP INIT : %08X, %u, %u\n", ip, local_port, remote_port );
      ip_addr_t ipaddr;
      ipaddr.addr = ip;
      struct tcp_pcb *tcp_pcb;
      err_t err;
  	  tcp_pcb = tcp_new();
      if (!tcp_pcb) {
  	    PRINTF("MEM ERROR");
          return ERR_MEM;
      }
      err = tcp_bind(tcp_pcb, IP_ADDR_ANY, local_port); //tcp_client_pcb->state
      if(err != ERR_OK) {
      	PRINTF("BIND ERROR");
          return ERR_MEM;
      }
      err = tcp_connect(tcp_pcb, &ipaddr, remote_port, tcp_connected_cbk);
      PRINTF("CONNECT:%d\n", err);
      tcp_recv(tcp_pcb, tcp_client_recv_cbk);
      return err;
}

/**********************************************************************************
  * @brief  TCP client Init
  * @param  None
  * @retval none
  *********************************************************************************/
err_t tcp_client_initialization(void) {

	PRINTF("IP PORT : %s , %u \r\n", modbus_data.cloud_data.cfg.tcp.url, modbus_data.cloud_data.cfg.tcp.port);
      tcp_server_ip = dns_to_ip(modbus_data.cloud_data.cfg.tcp.url, strlen(modbus_data.cloud_data.cfg.tcp.url));
      tcp_server_port = modbus_data.cloud_data.cfg.tcp.port;
      err_t err = tcp_client_init_start(0, tcp_server_port, tcp_server_ip);
      return err;
}
/**********************************************************************************
  * @brief  TCP client data transmit
  * @param  None
  * @retval none
  *********************************************************************************/
err_t tcp_client_data_transmit(uint8_t *tx_buf, uint16_t tx_len) {

	err_t err = ERR_OK;
    pcb = check_tcp_client_connect();

    if(pcb != NULL)
    {
      err = tcp_client_send_data_tx(pcb, (unsigned char *)tx_buf, tx_len);      //Send data to TCP server actively
      return err;
    }
    return ERR_MEM;
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
