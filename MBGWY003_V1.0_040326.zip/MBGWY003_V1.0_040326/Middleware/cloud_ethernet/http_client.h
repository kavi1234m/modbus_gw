/**
  **************************
  * @file    http_client.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 31
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HTTP_CLIENT_H_
#define __HTTP_CLIENT_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "at32f435_437.h"
#include "lwip/err.h"
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/

void http_client_fota_get(uint8_t *url);
err_t http_client_post(uint8_t *http_buf, uint16_t length);
flag_status update_status_get(void);
flag_status update_status_set(void);
void http_client_callback_register(void *cbk);
void fota_init(void);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __HTTP_CLIENT_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
