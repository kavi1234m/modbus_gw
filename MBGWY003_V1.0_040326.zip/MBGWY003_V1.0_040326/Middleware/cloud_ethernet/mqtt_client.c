/**
  **************************
  * @file    mqtt_client.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 30
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include <dns_client.h>
#include "mqtt_client.h"
#include "string.h"
#include "at32f435_437_board.h"
#include "lwip/pbuf.h"
#include "lwip/apps/mqtt.h"
#include "lwip/apps/mqtt_priv.h"
#include "lwip/netif.h"
#include "mqtt_client.h"
#include "modbus_gw_cfg.h"
#include "cJSON_parser_modbus_gw.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern modbus_cfg_t modbus_data;
mqtt_client_t *s__mqtt_client_instance;

typedef void (*mqtt_cbk_fun)(uint8_t event_type, uint8_t data);
mqtt_cbk_fun mqtt_conn_cbk;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*************************************************************************************************
  * @brief  mqtt callback register
  * @param  none
  * @retval none
  ************************************************************************************************/
void mqtt_callback_register(void *cbk) {

	mqtt_conn_cbk = cbk;
}

/************************************************************************************
  * @brief  mqtt connection subscription process
  * @param  client: mqtt connection handle
  * @param  arg: mqtt connection parameter point
  * @retval none
  ************************************************************************************/
__WEAK void mqtt_conn_sub_proc(mqtt_client_t *client, void *arg) {

	//at32_mqtt_subscribe(client, modbus_data.cloud_data.cfg.mqtt.subtopic, modbus_data.cloud_data.cfg.mqtt.qos);// modbus_data.cloud_data.cfg.mqtt.qos

}
/**************************************************************************************
  * @brief  mqtt error process callback
  * @param  client: mqtt connection handle
  * @param  arg: mqtt connection parameter point
  * @retval none
  *************************************************************************************/
__WEAK void mqtt_error_process_callback(mqtt_client_t *client, void *arg) {

	mqtt_connect_routine();

}
/**************************************************************************************
  * @brief  mqtt connection status callback
  * @param  client: mqtt connection handle
  * @param  arg: mqtt connection parameter point
  * @param  status: mqtt connection status
  * @retval none
  *************************************************************************************/
static void at32_mqtt_connection_cb(mqtt_client_t *client, void *arg, mqtt_connection_status_t status) {

	if (client == NULL) {
		PRINTF("at32_mqtt_connection_cb: condition error @entry\r\n");
        return;
	}
    /* Successfully connected */
    if (status == MQTT_CONNECT_ACCEPTED) {
    	PRINTF("at32_mqtt_connection_cb: Successfully connected\r\n");
        mqtt_set_inpub_callback(client, at32_mqtt_incoming_publish_cb, at32_mqtt_incoming_data_cb, arg);
        mqtt_conn_cbk(CONNECTION_EVENT, MQTT_MODE);
//        mqtt_conn_sub_proc(client, arg);
    } else if (status == MQTT_CONNECT_DISCONNECTED) {
    	PRINTF("at32_mqtt_connection_cb: Fail connected, status = %s\r\n", lwip_strerr(status));
        mqtt_error_process_callback(client, arg);
        mqtt_conn_cbk(CONNECTION_EVENT, 0);
    } else {
    	PRINTF("at32_mqtt_connection_cb: Fail connected, status = %s\r\n", lwip_strerr(status));
        mqtt_conn_cbk(CONNECTION_EVENT, 0);
    }
}

/**************************************************************************************
  * @brief  connect to mqtt server
  * @retval error status
  *************************************************************************************/
err_t mqtt_client_init(void) {

	PRINTF("at32_mqtt_connect: Enter!\r\n");
    if (s__mqtt_client_instance == NULL) {
    	s__mqtt_client_instance = mqtt_client_new();
    }
    if (s__mqtt_client_instance == NULL) {
    	PRINTF("at32_mqtt_connect: s__mqtt_client_instance malloc fail @@!!!\r\n");
        return ERR_MEM;
    }
    return mqtt_connect_routine();
}

/**************************************************************************************
  * @brief  mqtt received data callback
  * @param  arg: mqtt connection parameter point
  * @param  data: data
  * @param  len: data length
  * @param  flags: data flag
  * @retval none
  *************************************************************************************/
static void at32_mqtt_incoming_data_cb(void *arg, const u8_t *data, u16_t len, u8_t flags) {

	if ((data == NULL) || (len == 0)) {
		PRINTF("mqtt_client_incoming_data_cb: condition error @entry\r\n");
        return;
	}
    PRINTF("recv_buffer = %s\r\n", data);
    PRINTF("mqtt_client_incoming_data_cb:reveiving incomming data.\r\n");
}

/**************************************************************************************
  * @brief  mqtt received publish callback
  * @param  arg: mqtt connection parameter point
  * @param  topic: mqtt topic
  * @param  tot_len: data total length
  * @retval none
  *************************************************************************************/
static void at32_mqtt_incoming_publish_cb(void *arg, const char *topic, u32_t tot_len) {

	if ((topic == NULL) || (tot_len == 0)) {
		PRINTF("at32_mqtt_incoming_publish_cb: condition error @entry\r\n");
        return;
	}
    PRINTF("at32_mqtt_incoming_publish_cb: topic = %s.\r\n", topic);
    PRINTF("at32_mqtt_incoming_publish_cb: tot_len = %d.\r\n", tot_len);
}

/**************************************************************************************
  * @brief  mqtt send data callback
  * @param  arg: mqtt connection parameter point
  * @param  result: send data result
  * @retval none
  *************************************************************************************/
static void mqtt_client_pub_request_cb(void *arg, err_t result) {

	mqtt_client_t *client = (mqtt_client_t *)arg;
    if (result != ERR_OK) {
       mqtt_conn_cbk(DATA_RSP_EVENT , 0);
       PRINTF("mqtt_client_pub_request_cb: c002: Publish FAIL, result = %s\r\n", lwip_strerr(result));
       mqtt_error_process_callback(client, arg);
    } else {
       mqtt_conn_cbk(DATA_RSP_EVENT , 1);
       PRINTF("mqtt_client_pub_request_cb: c005: Publish complete!\r\n");
    }
}

/**************************************************************************************
  * @brief  mqtt send data to server
  * @param  client: mqtt connection handle
  * @param  pub_topic: mqtt publish topic
  * @param  pub_buf: mqtt publish buffer
  * @param  data_len: data length
  * @param  qos��quality of service, 0 1 or 2
  * @param  retain��mqtt retain flag
  * @retval send status
  *************************************************************************************/
err_t at32_mqtt_publish(mqtt_client_t *client, char *pub_topic, char *pub_buf, uint16_t data_len, uint8_t qos, uint8_t retain) {

	err_t err;
    if ((client == NULL) || (pub_topic == NULL) || (pub_buf == NULL) || (data_len == 0) || (qos > 2) || (retain > 1)) {
    	PRINTF("at32_mqtt_publish: input error@@");
        return ERR_VAL;
    }

    err = mqtt_publish(client, pub_topic, pub_buf, data_len, \
                       qos, retain, mqtt_client_pub_request_cb, (void *)client);
    if(err != ERR_OK) {
        PRINTF("at32_mqtt_publish: mqtt_publish err = %s\r\n", lwip_strerr(err));
    }
    return err; // MQTT_REQ_TIMEOUT
}
/**************************************************************************************
  * @brief  mqtt send data to server
  * @param  pub_topic: mqtt publish topic
  * @param  pub_buf: mqtt publish buffer
  * @param  data_len: data length
  * @param  qos��quality of service, 0 1 or 2
  * @param  retain��mqtt retain flag
  * @retval send status
  *************************************************************************************/
err_t cs_mqtt_publish(char *pub_topic, char *pub_buf, uint16_t data_len, uint8_t qos, uint8_t retain) {

	err_t err;
	err = at32_mqtt_publish(s__mqtt_client_instance, pub_topic, pub_buf, data_len, qos, retain);
	PRINTF("MQTT ERR :%d\n", err);
	return err;
}
/**************************************************************************************
  * @brief  mqtt request callback
  * @param  arg: mqtt connection parameter point
  * @param  err: error status
  * @retval none
  *************************************************************************************/
static void at32_mqtt_request_cb(void *arg, err_t err) {

	mqtt_client_t *client = (mqtt_client_t *)arg;
    if (arg == NULL) {
    	PRINTF("at32_mqtt_request_cb: input error@@\r\n");
        return;
    }
    if (err != ERR_OK) {
    	PRINTF("at32_mqtt_request_cb: FAIL sub, sub again, err = %s\r\n", lwip_strerr(err));
        mqtt_error_process_callback(client, arg);
    } else {
    	PRINTF("at32_mqtt_request_cb: sub SUCCESS!\r\n");
    }
}

/**************************************************************************************
  * @brief  mqtt subscribe
  * @param  client: mqtt connection handle
  * @param  sub_topic: mqtt subscribe topic
  * @param  qos��quality of service, 0 1 or 2
  * @retval subscribe status
  *************************************************************************************/
err_t at32_mqtt_subscribe(mqtt_client_t *mqtt_client, char *sub_topic, uint8_t qos) {

	err_t err;
    PRINTF("at32_mqtt_subscribe: Enter\r\n");
    if ((mqtt_client == NULL) || (sub_topic == NULL) || (qos > 2)) {
    	PRINTF("at32_mqtt_subscribe: input error@@\r\n");
        return ERR_VAL;
    }
    if (mqtt_client_is_connected(mqtt_client) != 1) {
    	PRINTF("at32_mqtt_subscribe: mqtt is not connected, return ERR_CLSD.\r\n");
        return ERR_CLSD;
    }
    err = mqtt_subscribe(mqtt_client, sub_topic, qos, at32_mqtt_request_cb, (void *)mqtt_client);
    if (err != ERR_OK) {
    	PRINTF("at32_mqtt_subscribe: mqtt_subscribe Fail, return:%s \r\n", lwip_strerr(err));
    } else {
    	PRINTF("at32_mqtt_subscribe: mqtt_subscribe SUCCESS, reason: %s\r\n", lwip_strerr(err));
    }
    return err;
}
/**************************************************************************************
  * @brief  mqtt connect routine
  * @param  none
  * @retval status
  *************************************************************************************/
err_t mqtt_connect_routine(void) {

	uint8_t *mqtt_user = NULL;
	uint8_t *mqtt_pass = NULL;
	if (strlen(modbus_data.cloud_data.cfg.mqtt.username) > 1) {
		mqtt_user = modbus_data.cloud_data.cfg.mqtt.username;
	}
	if (strlen(modbus_data.cloud_data.cfg.mqtt.password) > 1) {
		mqtt_pass = modbus_data.cloud_data.cfg.mqtt.username;
	}
    err_t ret;
    struct mqtt_connect_client_info_t mqtt_connect_info =
    {
    modbus_data.cloud_data.cfg.mqtt.client_id,
	mqtt_user,
	mqtt_pass,
    120,
    NULL,
    NULL,
    0,
    0
    };

    ip_addr_t server_ip;
    server_ip.addr = 0;
    server_ip.addr = dns_to_ip(modbus_data.cloud_data.cfg.mqtt.url, strlen(modbus_data.cloud_data.cfg.mqtt.url));
    if (server_ip.addr == 0) {
	  return ERR_ARG;
    }
    /* mqtt server port */
    uint16_t server_port = modbus_data.cloud_data.cfg.mqtt.port;
    /* mqtt server ip */
    ret = mqtt_client_connect(s__mqtt_client_instance, &server_ip, server_port, \
                            at32_mqtt_connection_cb, NULL, &mqtt_connect_info);

    PRINTF("at32_mqtt_connect: connect to mqtt %s\r\n", lwip_strerr(ret));
    return ret;
}

 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
