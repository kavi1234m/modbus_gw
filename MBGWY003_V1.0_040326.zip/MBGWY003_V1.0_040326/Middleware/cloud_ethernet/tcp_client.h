/**
  **************************
  * @file    tcp_client_comm.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 30
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __TCP_CLIENT_COMM_H_
#define __TCP_CLIENT_COMM_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stdint.h"
#include "lwip/err.h"
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/
 extern struct tcp_pcb *tcp_client_pcb;
/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

 err_t tcp_client_initialization(void);
 err_t tcp_client_data_transmit(uint8_t *tx_buf, uint16_t tx_len);
 void tcp_client_callback_register(void *cbk);
 err_t tcp_client_init_start(uint16_t local_port, uint16_t remote_port, uint32_t ip);
/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __TCP_CLIENT_COMM_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
