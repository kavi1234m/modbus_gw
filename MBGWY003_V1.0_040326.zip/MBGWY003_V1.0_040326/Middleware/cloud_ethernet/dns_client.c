/**
  **************************
  * @file    dns_to_ip.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 30
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "dns_client.h"
#include "lwip/dns.h"
#include "lwip/ip_addr.h"
#include "lwip/inet.h"
#include "FreeRTOS.h"
#include "task.h"
#include "modbus_gw_cfg.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

uint32_t dns_ip;

typedef enum {
    STR_INVALID = 0,
    STR_IPV4,
    STR_URL
} str_type_t;

str_type_t parse_ip_or_url(const char *str, uint32_t *ip)
{
    ip4_addr_t addr;

    if (!str || *str == '\0')
        return STR_INVALID;

    /* Try IPv4 first */
    if (inet_aton(str, &addr)) {
        if (ip)
            *ip = addr.addr;   // network byte order
        return STR_IPV4;
    }

//    /* Check URL / hostname */
//    while (*str) {
//        if ((*str >= 'a' && *str <= 'z') ||
//            (*str >= 'A' && *str <= 'Z') ||
//            (*str >= '0' && *str <= '9') ||
//            (*str == '-') ||
//            (*str == '.')) {
//            str++;
//        } else {
//            return STR_INVALID;
//        }
//    }

    return STR_URL;
}
/******************************************************************************
 * @brief       Parse IP to inet order
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void parsing_result(const char *name, ip_addr_t *ipaddr, void *arg) {

	if (ipaddr == NULL) {
		PRINTF("DNS RESOLUTION FAILED\n");
	} else {
	    dns_ip = ipaddr->addr;   // already in network order
	    uint8_t a = (dns_ip >> 24) & 0xFF;
	    uint8_t b = (dns_ip >> 16) & 0xFF;
	    uint8_t c = (dns_ip >> 8)  & 0xFF;
	    uint8_t d =  dns_ip        & 0xFF;

	    PRINTF("%d.%d.%d.%d\n", d, c, b, a);
	}
}
/******************************************************************************
 * @brief       DNS Test
 * @param[in]   ip_url
 * @return      none
 ******************************************************************************/
err_t dns_test(uint8_t *ip)
{
  ip_addr_t cipaddr_dns;

  err_t err = dns_gethostbyname(ip, &cipaddr_dns, (dns_found_callback)parsing_result, &dns_ip);
  return err;
}
/******************************************************************************
 * @brief       DNS Init
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void dns_initialization(void) {
	dns_init();
}
/******************************************************************************
 * @brief       Convert DNS to IP
 * @param[in]   None
 * @return      none
 ******************************************************************************/
uint32_t dns_to_ip(uint8_t *ip_addr, uint16_t ip_len) {

	str_type_t type = parse_ip_or_url(ip_addr, &dns_ip);
	if (type == STR_IPV4) {
	    PRINTF("IPv4 detected (net order): 0x%08lX\n", dns_ip);
	} else if (type == STR_URL) {
	    PRINTF("URL detected, resolve via DNS: %s\n", ip_addr);
		err_t err = dns_test(ip_addr);
		PRINTF("DNS STATUS:%d\n",err); // ERR_OK
		vTaskDelay(5000);
	} else {
	    PRINTF("Invalid input\n");
	}
	return dns_ip;

}


 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
