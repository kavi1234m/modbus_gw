/**
  **************************
  * @file    epoch_conversion.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 29
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "epoch_conversion.h"
#include "hal_rtc.h"
#include <stdio.h>
#include <time.h>
#include <stdint.h>
#include "modbus_gw_cfg.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************
 * @brief       Epoch to calendar conversion (library based)
 * @param[in]   epoch   UNIX epoch time (seconds)
 * @param[out]  cal     Calendar structure
 * @return      none
 ******************************************************************************/
void epoch_to_calendar(time_t epoch, calendar_info_t *cal)
{
    struct tm tm_time;

    /* Use UTC time (recommended for gateways) */
    gmtime_r(&epoch, &tm_time);
    /* If you want local time instead, use:
     * localtime_r(&epoch, &tm_time);
     */

    cal->year  = (tm_time.tm_year + 1900) - 2000;  // store as YY
    cal->month = tm_time.tm_mon + 1;               // 1�12
    cal->date  = tm_time.tm_mday;
    cal->hour  = tm_time.tm_hour;
    cal->min   = tm_time.tm_min;
    cal->sec   = tm_time.tm_sec;
    cal->week  = tm_time.tm_wday;                  // 0=Sun
    cal->am_pm_type = (cal->hour >= 12) ? 1 : 0;
}
/******************************************************************************
 * @brief       Calendar to epoch time
 * @param[in]   None
 * @return      none
 ******************************************************************************/
time_t epoch_convertion(uint8_t dd, uint8_t mm, uint8_t yy, uint8_t hr, uint8_t mn, uint8_t sc)
{
   struct tm t;
   int year = 2000 + yy;

    t.tm_year = year - 1900; // year since 1900 -> 2025-1900 = 125
    t.tm_mon  = mm - 1;       // month 0-11 -> September = 8
    t.tm_mday = dd;          // day of month
    t.tm_hour = hr;          // hour
    t.tm_min  = mn;          // minute
    t.tm_sec  = sc;           // second
    t.tm_isdst = -1;         // let system determine if DST applies

    return mktime(&t);
}

/******************************************************************************
 * @brief       Epoch time get
 * @param[in]   None
 * @return      none
 ******************************************************************************/
uint32_t epoch_time_get(void) {

	calendar_info_t ts;
	hal_rtc_calendar_get(&ts);
    time_t epoch = epoch_convertion(ts.date, ts.month, ts.year, ts.hour, ts.min, ts.sec);
    if (epoch == -1) {
        PRINTF("Failed to convert time.\n");
    } else {
        PRINTF("Epoch time: %ld\n", (long)epoch);
    }
    return epoch;
}
/******************************************************************************
 * @brief       Calendar time get
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void real_time_get(calendar_info_t* calendar) {

	hal_rtc_calendar_get(calendar);
}


 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
