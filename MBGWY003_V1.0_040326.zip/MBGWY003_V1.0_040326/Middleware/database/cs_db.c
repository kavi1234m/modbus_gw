/**
  **************************
  * @file    cs_db.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 19
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "cs_db.h"
#include <stdlib.h>
#include <string.h>
#include "spi_flash.h"
#include "FreeRTOS.h"
#include "task.h"
#include "epoch_conversion.h"
/* Private typedef -----------------------------------------------------------*/
typedef struct {
	uint32_t seq_num;
	uint32_t read_flg;
	uint32_t timestamp;
}data_log_header_t;
/* Private define ------------------------------------------------------------*/
#define IS_SECTOR_START(addr)   ((addr % SFP_SECTOR_SIZE) == 0)
#define SECTOR_BASE(addr)       ((addr / SFP_SECTOR_SIZE) * SFP_SECTOR_SIZE)
#define IS_SECTOR_END(addr) \
		(((addr % SFP_SECTOR_SIZE) + ONE_LOG_SIZE) > SFP_SECTOR_SIZE)

#define LOG_AREA_SIZE           (LOG_END - LOG_START + 1)
#define TOTAL_LOGS              (LOG_AREA_SIZE / ONE_LOG_SIZE)

#define ONE_LOG_SIZE           (sizeof(log_store_t))//328
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint32_t write_addr;
uint32_t read_addr;

uint32_t data_log_seq_num;
uint32_t data_log_spi_write_addr;
uint32_t data_log_spi_read_addr;
uint8_t write_overlap;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

static inline uint8_t log_fits_in_sector(uint32_t addr)
{
    uint32_t offset = addr - SECTOR_BASE(addr);
    return (offset + ONE_LOG_SIZE) <= SFP_SECTOR_SIZE;
}
/****************************************************************************************************************
  * @brief  sfp write part
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t sfp_write_part(uint8_t part, uint8_t *buf, uint32_t buf_len) {

	if (part == SFP_PRTN1) {
        if (spiflash_write(buf, CONFG_P1_START, buf_len)) {
        	if(spiflash_write(buf, CONFG_P2_START, buf_len)) {
        		return 1;
        	}
        }
	} else if (part == SFP_PRTN2) {
        if (spiflash_write(buf, write_addr, buf_len)) {
        	return 1;
        }
	} else if (part == SFP_PRTN3) {
        if (spiflash_write(buf, write_addr, buf_len)) {
        	return 1;
        }
	}
	return 0;
}
/****************************************************************************************************************
  * @brief  sfp read part
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t sfp_read_part(uint8_t part, uint8_t *buf, uint32_t buf_len) {

	if (part == SFP_PRTN1) {
        if (spiflash_read(buf, CONFG_P1_START, buf_len)) {
        	return 1;
        } else {
            if (spiflash_read(buf, CONFG_P2_START, buf_len)) {
            	return 1;
            }
        }
	} else if (part == SFP_PRTN2) {
        if (spiflash_read(buf, read_addr, buf_len)) {
        	return 1;
        }
	} else if (part == SFP_PRTN3) {
        if (spiflash_read(buf, read_addr, buf_len)) {
        	return 1;
        }
	}
	return 0;
}
/****************************************************************************************************************
  * @brief  Erase entire SPI Flash partition 1
  * @retval 1 = success, 0 = failure
  ***************************************************************************************************************/
uint8_t sfp_erase_part(uint8_t part)
{
	uint32_t start_addr;
	uint32_t end_addr;

	if (part == SFP_PRTN1) {
	    start_addr = SFP_PRTN1_STRT_ADDR;
	    end_addr   = SFP_PRTN1_END_ADDR;
	} else if (part == SFP_PRTN2) {
	    start_addr = SFP_PRTN2_STRT_ADDR;
	    end_addr   = SFP_PRTN2_END_ADDR;
	} else if (part == SFP_PRTN3) {
	    start_addr = SFP_PRTN3_STRT_ADDR;
	    end_addr   = SFP_PRTN3_END_ADDR;
	} else if (part == SFP_PRTN4) {
	    start_addr = SFP_PRTN4_STRT_ADDR;
	    end_addr   = SFP_PRTN4_END_ADDR;
	} else if (part == SFP_PRTN5) {
	    start_addr = LOG_START;
	    end_addr   = LOG_START;
	}

    uint32_t start_sector = start_addr / SFP_SECTOR_SIZE;
    uint32_t end_sector   = end_addr   / SFP_SECTOR_SIZE;

    for (uint32_t sector = start_sector; sector <= end_sector; sector++)
    {
        if (!spiflash_sector_erase(sector))
        {
        	PRINTF("ERASE FAILED:%u\n",sector);
            return 0;   // erase failed
        }
    }

    return 1;   // partition erase successful
}
/****************************************************************************************************************
  * @brief  write modbus cfg into spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_erase_mb_conf(void) {

	if (sfp_erase_part(SFP_PRTN1)) {
		return 1;
	}
	return 0;
}
/****************************************************************************************************************
  * @brief  write modbus cfg into spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_write_mb_conf(uint8_t *buf, uint32_t buf_len) {

	if (sfp_write_part(SFP_PRTN1, buf, buf_len)) {
		return 1;
	}
	PRINTF("WRITE FAILED\n");
	return 0;
}
/****************************************************************************************************************
  * @brief  Read modbus cfg from spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_read_mb_conf(uint8_t *buf, uint32_t buf_len) {

	if (sfp_read_part(SFP_PRTN1, buf, buf_len)) {
		return 1;
	}
	PRINTF("READ FAILED\n");
	return 0;
}
/****************************************************************************************************************
  * @brief  write fota into spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_write_fota(uint8_t *buf, uint32_t buf_len) {

	if (write_addr == 0) {
		write_addr = FOTA_START_ADDR;
	}
	if (sfp_write_part(SFP_PRTN2, buf, buf_len)) {
		write_addr += FOTA_CHUNK_SIZE;
		return 1;
	}
	return 0;
}
/****************************************************************************************************************
  * @brief  Read fota from spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_read_fota(uint8_t *buf, uint32_t buf_len) {

	if (write_addr == 0) {
		read_addr = FOTA_START_ADDR;
	}
	if (sfp_read_part(SFP_PRTN2, buf, buf_len)) {
		read_addr += FOTA_CHUNK_SIZE;
		return 1;
	}
	return 0;
}
/****************************************************************************************************************
  * @brief  write html pages into spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_write_html_page(uint32_t addr, uint8_t *buf, uint32_t buf_len) {

    write_addr = addr;
	if (sfp_write_part(SFP_PRTN3, buf, buf_len)) {
		return 1;
	}
	return 0;
}
/****************************************************************************************************************
  * @brief  read html pages into spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_read_html_page(uint32_t addr, uint8_t *buf, uint32_t buf_len) {

    read_addr = addr;
	if (sfp_read_part(SFP_PRTN3, buf, buf_len)) {
		return 1;
	}
	return 0;
}

/****************************************************************************************************************
  * @brief  write configuration ssl into the memory
  * @param  conf_dat: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_write_cert(uint8_t *conf_dat, uint16_t len, uint8_t cert_type)
{
	 uint8_t ret = 0;
		uint8_t* new_log = NULL;
		new_log = (uint8_t*)malloc(len + 3);
		if (new_log == NULL) {
		    PRINTF("Malloc failed!\n");
		    return 0;   // or handle error
		}

		new_log[0] = (len) & 0xFF;
		new_log[1] = (len >> 8) & 0xFF;

		memcpy(&new_log[2], conf_dat, len);

		if (cert_type == 1) {
			ret = spiflash_write(new_log, SSL_CA_CERT_ADDR, len + 2);
		} else if (cert_type == 2) {
			ret = spiflash_write(new_log, SSL_CLIENT_CERT_ADDR, len + 2);
		} else if (cert_type == 4) {
			ret = spiflash_write(new_log, SSL_CLIENT_KEY_ADDR, len + 2);
		}

		free(new_log);  // always free malloc memory!

		if (ret == 0)  // assuming 0 = fail in your API
		    return 0;
		return 1;

}

/****************************************************************************************************************
  * @brief  read configuration from memory
  * @param  conf_dat: buffer to hold  data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint16_t cdb_read_cert(uint8_t *conf_dat, uint8_t cert_type)
{
	uint8_t ret;
	uint16_t len = 0;
	if (cert_type == 1) {
		spiflash_read((uint8_t*)&len, SSL_CA_CERT_ADDR, 2);
		spiflash_read(conf_dat, SSL_CA_CERT_ADDR + 2, len);
		return len;
	} else if (cert_type == 2) {
		spiflash_read((uint8_t*)&len, SSL_CLIENT_CERT_ADDR, 2);
		ret = spiflash_read(conf_dat, SSL_CLIENT_CERT_ADDR + 2, len);
		return len;
	} else if (cert_type == 4) {
		spiflash_read((uint8_t*)&len, SSL_CLIENT_KEY_ADDR, 2);
		ret = spiflash_read(conf_dat, SSL_CLIENT_KEY_ADDR + 2, len);
		return len;
	}
	return 0;
}
/****************************************************************************************************************
  * @brief  write modbus cfg into spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_erase_data_log(void) {

//	if (!(SFP_FLASH_SIZE > 1048576)) {
//		return 0;
//	}

	if (sfp_erase_part(SFP_PRTN5)) {
		return 1;
	}
	return 0;
}
/****************************************************************************************************************
  * @brief  Get the pointer for data log
  * @param  None
  * @retval None
  ***************************************************************************************************************/
/****************************************************************************************************************
  * @brief  Get the pointer for data log
  * @param  None
  * @retval None
  ***************************************************************************************************************/
void cdb_data_log_pointer_get(void)
{
	PRINTF("DATA LOG PONTER START:%u\n", xTaskGetTickCount());
    uint32_t min_seq = UINT32_MAX;
    uint32_t max_seq = 0;
    uint8_t found_valid = 0;
//    uint8_t seq_found = 0;
    uint16_t seq = 0;
    uint32_t flash_addr = LOG_START;  //LOG_START
    uint32_t previous_timestamp = 0;
    uint32_t lat_tmt = 0;
    while (flash_addr <= LOG_END) {

        data_log_header_t hdr;
        spiflash_read((uint8_t *)&hdr, flash_addr, sizeof(data_log_header_t));
        lat_tmt = hdr.timestamp;
        if (hdr.seq_num != 0xFFFFFFFF) {

            found_valid = 1;
            if ((hdr.seq_num < min_seq) && (hdr.read_flg == 0xFFFFFFFF)) {

                min_seq = hdr.seq_num;
                data_log_spi_read_addr = flash_addr;
            }
            if ((previous_timestamp < hdr.timestamp) && (hdr.timestamp != 0xFFFFFFFF)) {
            	if ((hdr.seq_num > max_seq)) {
//                	seq_found = 0;
                	seq++;
                    max_seq = hdr.seq_num;
                    data_log_spi_write_addr = flash_addr;
//                    if ((flash_addr + SFP_SECTOR_SIZE) < LOG_END) {
//                    	seq_found = 1;
//                    	data_log_spi_write_addr = flash_addr + SFP_SECTOR_SIZE;
//                    } else {
//                    	data_log_spi_write_addr = flash_addr;
//                    }
            	}
            	previous_timestamp = hdr.timestamp;
            }
        } else if (flash_addr == LOG_START) {
        	if (hdr.seq_num == 0xFFFFFFFF && hdr.read_flg == 0xFFFFFFFF) {
        		break;
        	}
        }
        flash_addr += SFP_SECTOR_SIZE;
    }

    if (!found_valid) {

    	PRINTF("FRESH FLASH\n");
        /* Fresh flash */
        data_log_spi_read_addr  = LOG_START;
        data_log_spi_write_addr = LOG_START;
        data_log_seq_num = 1;
    } else {
    	PRINTF("OLD FLASH\n");
    	if (min_seq == 0xFFFFFFFF) {
    		data_log_spi_read_addr = data_log_spi_write_addr;
    	}
    	if ((data_log_spi_write_addr + SFP_SECTOR_SIZE) < LOG_END) {
    		data_log_spi_write_addr += SFP_SECTOR_SIZE;
    		data_log_seq_num = max_seq + 1;
    	} else {
    		data_log_seq_num = max_seq;
    	}
    }
//
//    printf("TMT PREV:%u, LAT:%u\n\r", previous_timestamp, lat_tmt);
	PRINTF("WRITE ADDR:%04X, READ ADDR:%04X, SEQ:%u,%u\n", data_log_spi_write_addr, data_log_spi_read_addr, data_log_seq_num, seq);
    PRINTF("DATA LOG PONTER FINISH:%u\n", xTaskGetTickCount());
}
/****************************************************************************************************************
  * @brief  write modbus cfg into spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_write_data_log(uint8_t *log_data)
{

//	PRINTF("WRITE LOG START:%04X\n",data_log_spi_write_addr);
    if ((data_log_spi_write_addr + ONE_LOG_SIZE - 1) > LOG_END)
    {
    	data_log_spi_write_addr = LOG_START;
    	write_overlap = 1;
    }

    uint32_t write_addr = SECTOR_BASE(data_log_spi_write_addr);
    uint32_t read_addr  = SECTOR_BASE(data_log_spi_read_addr);

    if ( (write_overlap == 1) && (write_addr == read_addr)) {
    	if(read_addr + SFP_SECTOR_SIZE >= LOG_END) {
    		data_log_spi_read_addr = LOG_START;
    	} else {
    		data_log_spi_read_addr = read_addr + SFP_SECTOR_SIZE;
    	}
    }

    // Erase sector if write starts at sector boundary
    if (IS_SECTOR_START(data_log_spi_write_addr))
    {
        if (spiflash_sector_erase(data_log_spi_write_addr/ SFP_SECTOR_SIZE) == 0) {
        	PRINTF("1.WRITE START\n");
        	return 0;
        } else {
        	data_log_spi_write_addr += sizeof(data_log_header_t);
        }
    }

    // Write the log
    if (spiflash_write_nocheck(log_data, data_log_spi_write_addr, ONE_LOG_SIZE) == 0) {
    	return 0;
    }
    PRINTF("WRITTEN DATA LOG:%04X\n",data_log_spi_write_addr);
    uint32_t next_addr = data_log_spi_write_addr + ONE_LOG_SIZE;
    // Advance write pointer
    if (!log_fits_in_sector(next_addr)) {

        uint32_t sector_base = SECTOR_BASE(data_log_spi_write_addr);
    	data_log_header_t data;
    	data.seq_num = data_log_seq_num++;
    	data.read_flg = 0xFFFFFFFF;
    	data.timestamp = epoch_time_get();
    	spiflash_page_write((uint8_t*)&data, sector_base, sizeof(data_log_header_t));
        data_log_spi_write_addr = SECTOR_BASE(data_log_spi_write_addr) + SFP_SECTOR_SIZE;
    } else {
    	data_log_spi_write_addr = next_addr;
    }
    PRINTF("WRITE LOG END:%04X\n",data_log_spi_write_addr);
    return 1;
}
/****************************************************************************************************************
  * @brief  write modbus cfg into spi flash
  * @param  buf: buffer holding configuration data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_read_data_log(uint8_t *log_buf) {


//	PRINTF("READ LOG START:%04X\n",data_log_spi_read_addr);
	if (data_log_spi_write_addr == data_log_spi_read_addr) {
		return 0;
	}

	if ((data_log_spi_read_addr + ONE_LOG_SIZE - 1) > LOG_END) {
		data_log_spi_read_addr = LOG_START;
	}
    if (IS_SECTOR_START(data_log_spi_read_addr)) {
    	data_log_header_t data;
    	spiflash_read((uint8_t*)&data, data_log_spi_read_addr, sizeof(data_log_header_t));
    	if (data.read_flg == 0xFFFFFFFF) {
    		data_log_spi_read_addr += sizeof(data_log_header_t);
    	} else {
    		return 0;
    	}
    }
	if (spiflash_read(log_buf, data_log_spi_read_addr, ONE_LOG_SIZE) == 0) {
		PRINTF("2.READ DATA LOG\n");
		return 0;
	}
	PRINTF("READ DATA LOG:%04X\n",data_log_spi_read_addr);

	uint32_t next_addr = data_log_spi_read_addr + ONE_LOG_SIZE;
    /* If end of sector reached  mark sector as READ */
    if (!log_fits_in_sector(next_addr)) {
        uint32_t sector_base = SECTOR_BASE(data_log_spi_read_addr);

        uint32_t hdr_data = 0xAABB;   // consumed

        spiflash_page_write((uint8_t*)&hdr_data, (sector_base + sizeof(uint32_t)), sizeof(uint32_t));

        /* Move to next sector header */
        data_log_spi_read_addr = sector_base + SFP_SECTOR_SIZE;
    } else {
    	data_log_spi_read_addr = next_addr;
    }
    PRINTF("READ LOG END:%04X\n",data_log_spi_read_addr);
    return 1;
}
/****************************************************************************************************************
  * @brief  fota status get
  * @param  None
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t fota_status_set(fota_meta_t *fota_data) {

	if(spiflash_write((uint8_t*)fota_data, FOTA_FLAG_ADDR, sizeof(fota_meta_t))){
        return 1;
	} else {
		return 0;
	}
}
/****************************************************************************************************************
  * @brief  fota status get
  * @param  None
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t fota_status_get(fota_meta_t *fota_data) {

	if(spiflash_read((uint8_t*)fota_data, FOTA_FLAG_ADDR, sizeof(fota_meta_t))){
        return 1;
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       Device mode set function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t device_config_mode_set(uint8_t data) {

	if(spiflash_page_write(&data,(CONFG_P1_START),1)) {
		if (spiflash_page_write(&data,(CONFG_P2_START),1)) {
			return 1;
		} else {
			return 0;
		}
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       Device mode get function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t device_config_mode_get(void) {
	uint8_t data = 0;
	spiflash_read(&data, (CONFG_P1_START), 1);
	return data;
}
/******************************************************************************
 * @brief       Device mode set function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t device_ssl_file_handle_set(uint8_t data) {

	if(spiflash_page_write(&data,(CONFG_P1_START+1),1)) {
		spiflash_page_write(&data,(CONFG_P2_START+1),1);
		return 1;
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       Device mode get function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t device_ssl_file_handle_get(void) {
	uint8_t data = 0;
	if(!spiflash_read(&data, (CONFG_P1_START+1), 1)){
		spiflash_read(&data, (CONFG_P2_START+1), 1);
	}
	return data;
}



 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
