/**
  **************************
  * @file    cs_db.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Dec 19
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FILENAME_H_
#define __FILENAME_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include "modbus_gw_cfg.h"
/* Exported types ------------------------------------------------------------*/
#define SFP_PAGE_SIZE      256
#define SFP_SECTOR_SIZE    4096
#define SFP_FLASH_SIZE     1048576
#define SFP_FLASH_START    0x000000


#define SFP_PRTN_CNT           5

#define SFP_PRTN1              0x00
#define SFP_PRTN1_TYP          0x00
#define SFP_PRTN1_STRT_ADDR    SFP_FLASH_START
#define SFP_PRTN1_SIZE         147456
#define SFP_PRTN1_END_ADDR     ((SFP_PRTN1_STRT_ADDR+SFP_PRTN1_SIZE)-1)

#define CONFG_P1_START         SFP_PRTN1_STRT_ADDR
#define CONFG_P1_SIZE          73728
#define CONFG_P1_END           (CONFG_P1_START+CONFG_P1_SIZE-1)

#define CONFG_P2_START         (CONFG_P1_END+1)
#define CONFG_P2_SIZE          73728
#define CONFG_P2_END           (CONFG_P2_START+CONFG_P2_SIZE-1)

#define SFP_PRTN2              0x01
#define SFP_PRTN2_TYP          0x01
#define SFP_PRTN2_STRT_ADDR    (SFP_PRTN1_END_ADDR + 1)
#define SFP_PRTN2_SIZE         524288
#define SFP_PRTN2_END_ADDR     ((SFP_PRTN2_STRT_ADDR + SFP_PRTN2_SIZE)-1)

#define FOTA_FLAG_ADDR         SFP_PRTN2_STRT_ADDR
#define FOTA_START_ADDR        (SFP_PRTN2_STRT_ADDR + SFP_SECTOR_SIZE)

#define SFP_PRTN3              0x02
#define SFP_PRTN3_TYP          0x02
#define SFP_PRTN3_STRT_ADDR    (SFP_PRTN2_END_ADDR + 1)
#define SFP_PRTN3_SIZE         352256
#define SFP_PRTN3_END_ADDR     ((SFP_PRTN3_STRT_ADDR + SFP_PRTN3_SIZE)-1)

#define SFP_PRTN4              0x03
#define SFP_PRTN4_TYP          0x03
#define SFP_PRTN4_STRT_ADDR    (SFP_PRTN3_END_ADDR + 1)
#define SFP_PRTN4_SIZE         24576
#define SFP_PRTN4_END_ADDR     ((SFP_PRTN4_STRT_ADDR + SFP_PRTN4_SIZE)-1)

#define SSL_CA_CERT_ADDR               SFP_PRTN4_STRT_ADDR
#define SSL_CA_CERT_SIZE               8192
#define SSL_CLIENT_CERT_ADDR           (SSL_CA_CERT_ADDR + SSL_CA_CERT_SIZE)
#define SSL_CLIENT_CERT_SIZE           8192
#define SSL_CLIENT_KEY_ADDR            (SSL_CLIENT_CERT_ADDR + SSL_CLIENT_CERT_SIZE)
#define SSL_CLIENT_KEY_CERT_SIZE       8192

#define SFP_PRTN5              0x04
#define SFP_PRTN5_TYP          0x04
#define SFP_PRTN5_STRT_ADDR    (SFP_PRTN3_END_ADDR + 1)
#define SFP_PRTN5_SIZE         24576//(SFP_FLASH_SIZE - 1048576)
#define SFP_PRTN5_END_ADDR     ((SFP_PRTN5_STRT_ADDR + SFP_PRTN5_SIZE)-1)

#define LOG_START              (SFP_PRTN5_STRT_ADDR)
#define LOG_SECTORS            (SFP_PRTN5_SIZE / SFP_SECTOR_SIZE) //no.of log sectors
#define LOG_END                (((LOG_START)+((LOG_SECTORS)*SFP_SECTOR_SIZE))-1)

#define FOTA_CHUNK_SIZE        (2*4096)
/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/
 uint8_t cdb_write_mb_conf(uint8_t *buf, uint32_t buf_len);
 uint8_t cdb_read_mb_conf(uint8_t *buf, uint32_t buf_len);
 uint8_t cdb_write_fota(uint8_t *buf, uint32_t buf_len);
 uint8_t cdb_read_fota(uint8_t *buf, uint32_t buf_len);
 uint8_t cdb_write_html_page(uint32_t addr, uint8_t *buf, uint32_t buf_len);
 uint8_t cdb_read_html_page(uint32_t addr, uint8_t *buf, uint32_t buf_len);
 uint8_t cdb_write_cert(uint8_t *conf_dat, uint16_t len, uint8_t cert_type);
 uint16_t cdb_read_cert(uint8_t *conf_dat, uint8_t cert_type);
 uint8_t device_config_mode_set(uint8_t data);
 uint8_t device_config_mode_get(void);
 uint8_t device_ssl_file_handle_set(uint8_t data);
 uint8_t device_ssl_file_handle_get(void);
 uint8_t fota_status_set(fota_meta_t *fota_data);
 uint8_t fota_status_get(fota_meta_t *fota_data);

 uint8_t cdb_erase_mb_conf(void);
 uint8_t cdb_erase_data_log(void);

 uint8_t cdb_write_data_log(uint8_t *log_data);
 uint8_t cdb_read_data_log(uint8_t *log_buf);

 void cdb_data_log_pointer_get(void);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __FILENAME_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
