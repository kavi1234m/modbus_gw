/**
  **************************
  * @file    cJSON_parser_modbus_gw.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 11
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "cJSON_parser_modbus_gw.h"
#include "epoch_conversion.h"
#include "cJSON.h"
#include <string.h>
#include <math.h>
#include "hal_rtc.h"

uint8_t mac_addr[18];
uint8_t model_id[10];

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**************************************************************************************************
 * @brief  Mac and model id set
 * @param  addr  : mac address
 * @param  id    : model id
 * @return None
 ***************************************************************************************************/
void mac_devid_set_for_cloud(uint8_t addr[6], const char id[10]) {

    snprintf(mac_addr, sizeof(mac_addr),
             "%02X:%02X:%02X:%02X:%02X:%02X",
             addr[0], addr[1], addr[2],
             addr[3], addr[4], addr[5]);

    strncpy(model_id, id, sizeof(model_id) - 1);
    model_id[sizeof(model_id) - 1] = '\0';
}
/**************************************************************************************************
 * @brief  Calendar to string
 * @param  addr  : mac address
 * @param  id    : model id
 * @return None
 ***************************************************************************************************/
void calendar_to_string(const calendar_info_t *cal, char *out, size_t out_len) {

    uint16_t full_year;
    /* If RTC gives year as 0�99 */
    if (cal->year < 100) {
        full_year = 2000 + cal->year;
    } else {
        full_year = cal->year;
    }
    /* Microseconds not available  fixed 000000 */
    snprintf(out, out_len, "%04u-%02u-%02u %02u:%02u:%02u.000000", full_year, cal->month, cal->date, cal->hour, cal->min, cal->sec);
}

#if !CUSTOM_CLOUD_PACKET
/**************************************************************************************************
 * @brief  Create RTU JSON packet from stored data
 * @param  channel_name : "RTU1", "RTU2", etc.
 * @param  dev          : Pointer to RTU device configuration
 * @param  input_data   : 2D buffer [num_points][max bytes] from Modbus read
 * @param  out_buf      : Output buffer for JSON string
 ***************************************************************************************************/
void create_rtu_json_packet(const char *channel_name, rtu_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf) {

    cJSON *root = cJSON_CreateObject();

    cJSON *gw_info = cJSON_CreateObject();
    cJSON_AddStringToObject(gw_info, "mac", mac_addr);
    cJSON_AddStringToObject(gw_info, "mid", model_id);
    cJSON_AddItemToObject(root, "gw_info", gw_info);

    /* -------- Slave Info -------- */
    cJSON *slave_info = cJSON_CreateObject();
#if !EPOCH_TIME_IN_PKT
    char time_str[30];
    calendar_info_t real_time;
    epoch_to_calendar(cdev->timestamp, &real_time);
    calendar_to_string(&real_time, time_str, 30);
    cJSON_AddStringToObject(slave_info, "tsp", time_str);
#else
    cJSON_AddNumberToObject(slave_info, "tsp", cdev->timestamp);
#endif
    cJSON_AddStringToObject(slave_info, "dtp", dev->device_type);
    cJSON_AddStringToObject(slave_info, "dnm", dev->device_name);
    cJSON_AddStringToObject(slave_info, "ctp", channel_name);
    cJSON_AddNumberToObject(slave_info, "sid", dev->slave_id);
    cJSON_AddStringToObject(slave_info, "mtp", "live");
    cJSON_AddItemToObject(root, "slave_info", slave_info);

    /* -------- Modbus Data -------- */
    cJSON *modbus = cJSON_CreateObject();
    cJSON_AddNumberToObject(modbus, "dpc", dev->num_points);

    cJSON *dp = cJSON_CreateObject();

    for (int p = 0; p < dev->num_points; p++) {

        const cloud_point_t *pt = &cdev->points[p];
        data_type_t dtype   = dev->points[p].data_type;
        uint8_t reg_count   = dev->points[p].reg_count;

        if (dtype == DT_FLOAT) {
        	float f;
            memcpy(&f, &pt->data[0], sizeof(float));
            double num = (double)f * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        } else if (dtype == DT_UINT16) {

        	uint16_t v = (uint16_t)((pt->data[1] << 8) | pt->data[0]);
            double num = (double)v * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        } else if (dtype == DT_INT16) {

        	int16_t v = (int16_t)((pt->data[1] << 8) | pt->data[0]);
            double num = (double)v * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        } else if (dtype == DT_UINT32) {

        	uint32_t v = (uint32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
            double num = (double)v * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        } else if (dtype == DT_INT32) {

        	int32_t v = (int32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
            double num = (double)v * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        }  else if (dtype == DT_BOOL) {

        	uint8_t val = pt->data[0];
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, val);

        } else if(dtype == DT_DOUBLE) {

        	double d = 0;
        	memcpy(&d, &pt->data[0], sizeof(double));
        	d = d * dev->points[p].scaling_factor;
        	cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, d);
        }
    }
    cJSON_AddItemToObject(modbus, "dp", dp);
    cJSON_AddItemToObject(root, "modbus", modbus);

    if (!cJSON_PrintPreallocated(root, out_buf, JSON_OUT_BUF_SIZE, 0)) {
        PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
        PRINTF("\r\n %s ERROR PACKET:%s,>>>>%u,%p\n", channel_name, out_buf, strlen(out_buf), out_buf);
        out_buf[0] = '\0';
        cJSON_Delete(root);
        return;
    }
    cJSON_Delete(root);
}
/******************************************************************************
 * @brief       Create data log json packet
 * @param[in]   dev - device log info
 * @param[in]   out_buf - output json
 * @return      None
 ******************************************************************************/
void create_data_log_json_packet(log_send_t *dev, uint8_t *out_buf)
{
    cJSON *root = cJSON_CreateObject();

    if (root == NULL) {
    	PRINTF("1.LOG JSON FAILED\n");
    }
    /* --- Gateway Info --- */
    cJSON *gw_info = cJSON_CreateObject();
    cJSON_AddStringToObject(gw_info, "mac", mac_addr);
    cJSON_AddStringToObject(gw_info, "mid", model_id);
    cJSON_AddItemToObject(root, "gw_info", gw_info);

    /* --- Slave Info --- */
    cJSON *slave_info = cJSON_CreateObject();
#if !EPOCH_TIME_IN_PKT
    char time_str[30];
    calendar_info_t real_time;
    epoch_to_calendar(dev->timestamp, &real_time);
    calendar_to_string(&real_time, time_str, 30);
    cJSON_AddStringToObject(slave_info, "tsp", time_str);
#else
    cJSON_AddNumberToObject(slave_info, "tsp", dev->timestamp);
#endif
//    cJSON_AddNumberToObject(slave_info, "tsp", dev->timestamp);
    cJSON_AddStringToObject(slave_info, "dtp", (char*)dev->device_type);
    cJSON_AddStringToObject(slave_info, "dnm", (char*)dev->device_name);

    switch (dev->channel_type)
    {
        case 1: cJSON_AddStringToObject(slave_info, "channel_type", "RTU1"); break;
        case 2: cJSON_AddStringToObject(slave_info, "channel_type", "RTU2"); break;
        default: cJSON_AddStringToObject(slave_info, "channel_type", "RTU1"); break;
    }

    cJSON_AddNumberToObject(slave_info, "sid", dev->slave_id);

    cJSON_AddStringToObject(slave_info, "mtp", "log");
    cJSON_AddItemToObject(root, "slave_info", slave_info);

    /* --- Modbus Data Logging --- */
    cJSON *modbus = cJSON_CreateObject();
    cJSON_AddNumberToObject(modbus, "dpc", dev->num_points);

    cJSON *dp = cJSON_CreateObject();

    for (int p = 0; p < dev->num_points; p++) {

             log_point_t *src = &dev->points[p];
             uint8_t *buf = src->log_data;
             uint8_t reg_count = src->reg_count;
             switch (src->data_type)
             {
                 case DT_FLOAT:
                      {
                         float f = 0;
                         memcpy(&f, &buf[0], sizeof(float));
                         double num = (double)f * dev->points[p].scaling_factor;
                         cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                      }
                      break;

                 case DT_BOOL:
                      {
                 	    uint8_t f = buf[0];
                 	    cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, f);
                      }
                      break;

                 case DT_UINT16:
                      {
                         uint16_t val = (uint16_t)((buf[1] << 8) | buf[0]);
                         double num = (double)val * dev->points[p].scaling_factor;
                         cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                      }
                      break;
                 case DT_INT16:
                      {
                         int16_t val = (int16_t)((buf[1] << 8) | buf[0]);
                         double num = (double)val * dev->points[p].scaling_factor;
                         cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                      }
                      break;

                 case DT_UINT32:
                      {
                         uint32_t val = (uint32_t)((buf[3] << 24) | (buf[2] << 16) | (buf[1] << 8)  | buf[0]);
                         double num = (double)val * dev->points[p].scaling_factor;
                         cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                      }
                      break;
                 case DT_INT32:
                      {
                         int32_t val = (int32_t)((buf[3] << 24) | (buf[2] << 16) | (buf[1] << 8)  | buf[0]);
                         double num = (double)val * dev->points[p].scaling_factor;
                         cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                      }
                      break;
                 case DT_DOUBLE:
                      {
                 	      double d = 0;
                 	      memcpy(&d, &buf[0], sizeof(double));
                 	      d *=dev->points[p].scaling_factor;
                 	      cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, d);
                      }
                 	 break;
             }
         }

    cJSON_AddItemToObject(modbus, "dp", dp);
    cJSON_AddItemToObject(root, "modbus", modbus);

    if (!cJSON_PrintPreallocated(root, out_buf, JSON_OUT_BUF_SIZE, 0)) {

        PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
        PRINTF("\r\n 2.ERROR PACKET:%s,>>>>%u\n", out_buf, strlen(out_buf));
        out_buf[0] = '\0';
        cJSON_Delete(root);
        return;
    }

    cJSON_Delete(root);
}
#else
/**************************************************************************************************
 * @brief  Create CUSTOM  JSON packet from stored data
 * @param  channel_name : "RTU1", "RTU2", etc.
 * @param  dev          : Pointer to RTU device configuration
 * @param  input_data   : 2D buffer [num_points][max bytes] from Modbus read
 * @param  out_buf      : Output buffer for JSON string
 ***************************************************************************************************/
void create_custom_json_packet(const char *channel_name, rtu_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf) {

    /* -------- Modbus Data -------- */
    cJSON *modbus = cJSON_CreateObject();

    for (int p = 0; p < dev->num_points; p++) {

        const cloud_point_t *pt = &cdev->points[p];

        data_type_t dtype   = dev->points[p].data_type;
        uint8_t reg_count   = dev->points[p].reg_count;

        if (dtype == DT_FLOAT) {
                float f;
                memcpy(&f, &pt->data[0], sizeof(float));
                cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, (double)f * dev->points[p].scaling_factor);
        }
        else if (dtype == DT_UINT16) {
                uint16_t v = (pt->data[1] << 8) | pt->data[0];
                cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, (double)v * dev->points[p].scaling_factor);
        }
        else if (dtype == DT_INT16) {
                int16_t v = (pt->data[1] << 8) | pt->data[0];
                cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, (double)v * dev->points[p].scaling_factor);
        } else if (dtype == DT_UINT32) {
                uint32_t v =
                    (pt->data[3] << 24) |
                    (pt->data[2] << 16) |
                    (pt->data[1] << 8)  |
                     pt->data[0];
                cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, (double)v * dev->points[p].scaling_factor);
        } else if (dtype == DT_INT32) {
                int32_t v =
                    (pt->data[3] << 24) |
                    (pt->data[2] << 16) |
                    (pt->data[1] << 8)  |
                     pt->data[0];
                cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, (double)v * dev->points[p].scaling_factor);
        }  else if (dtype == DT_BOOL) {
            	cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, pt->data[0]);
        } else if(dtype == DT_DOUBLE) {
        		double d = 0;
        	    memcpy(&d, &pt->data[0], sizeof(double));
        	    cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, (double)d * dev->points[p].scaling_factor);
        }
    }

    char time_str[30];
    calendar_info_t real_time;
    epoch_to_calendar(cdev->timestamp, &real_time);
    calendar_to_string(&real_time, time_str, 30);
    cJSON_AddStringToObject(modbus, "ts", time_str);

    cJSON_AddStringToObject(modbus, "devicename", (char*)dev->device_name);

    if (!cJSON_PrintPreallocated(modbus, out_buf, JSON_OUT_BUF_SIZE, 0)) {
        PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
        PRINTF("\r\n %s ERROR PACKET:%s,>>>>%u,%p\n", channel_name, out_buf, strlen(out_buf), out_buf);
        out_buf[0] = '\0';
        cJSON_Delete(modbus);
        return;
    }
    cJSON_Delete(modbus);
}
/******************************************************************************
 * @brief       Create custom data log json packet
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void create_custom_data_log_json_packet(log_send_t *dev, uint8_t *out_buf)
{

    cJSON *modbus = cJSON_CreateObject();

    for (int p = 0; p < dev->num_points; p++)
    {
        log_point_t *src = &dev->points[p];
        uint8_t *buf = src->log_data;

        switch (src->data_type)
        {
            case DT_FLOAT:
                {
                    float f;
                    memcpy(&f, &buf[0], sizeof(float));
                    double num = f * dev->points[p].scaling_factor;
                    cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

                }
                break;

            case DT_BOOL:
                 {
                    cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, buf[0]);
                 }
                 break;

            case DT_UINT16:
                 {
                    uint16_t val = (buf[1] << 8) | buf[0];
                    double num = val * dev->points[p].scaling_factor;
                    cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                 }
                 break;
            case DT_INT16:
                {
                    int16_t val = (buf[1] << 8) | buf[0];
                    double num = val * dev->points[p].scaling_factor;
                    cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                }
                break;

            case DT_UINT32:
            	{
                    uint32_t val = (uint32_t)((buf[3] << 24) |
                                   (buf[2] << 16) |
                                   (buf[1] << 8)  |
                                    buf[0]);
                    double num = val * dev->points[p].scaling_factor;
                    cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                 }
                 break;
            case DT_INT32:
                 {
                    int32_t val = (int32_t)((buf[3] << 24) |
                                   (buf[2] << 16) |
                                   (buf[1] << 8)  |
                                    buf[0]);
                    double num = val * dev->points[p].scaling_factor;
                    cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                 }
                 break;
            case DT_DOUBLE:
                 {
            	      double d;
            	      memcpy(&d, &buf[0], sizeof(double));
            	      d *=dev->points[p].scaling_factor;
                      cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, d);

            	 }
            	 break;
        }

    }
    char time_str[30];
    calendar_info_t real_time;
    epoch_to_calendar(dev->timestamp, &real_time);
    calendar_to_string(&real_time, time_str, 30);
    cJSON_AddStringToObject(modbus, "ts", time_str);
    cJSON_AddStringToObject(modbus, "devicename", (char*)dev->device_name);

    if (!cJSON_PrintPreallocated(modbus, (char*)out_buf, (JSON_OUT_BUF_SIZE - 1), 0)) {
        PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
        cJSON_Delete(modbus);
        PRINTF("\r\n ERROR PACKET:%s,>>>>%u\n", out_buf, strlen(out_buf));
        out_buf[0] = '\0';
        return;
    }
    cJSON_Delete(modbus);
}
#endif
/******************************************************************************
 * @brief       Copy RTU log
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void copy_rtu_log(rtu_device_t *dev,uint8_t chn_type, uint32_t timestamp, uint8_t data[16][MAX_PAYLOAD], log_send_t *log_info) {

    memset(log_info, 0, sizeof(log_send_t));
    log_info->slave_id = dev->slave_id;
    log_info->slave_ip = 0;
    log_info->slave_port = 0;
    log_info->timestamp = timestamp;
    log_info->channel_type = chn_type;

    memcpy(log_info->device_type, dev->device_type, SIZEOF_JSON_KEY);
    memcpy(log_info->device_name, dev->device_name, SIZEOF_JSON_KEY);

    log_info->num_points = dev->num_points;

    for (int p = 0; p < dev->num_points; p++) {
        data_point_t *src = &dev->points[p];
        log_point_t *dst = &log_info->points[p];

        dst->reg_type      = src->reg_type;
        dst->start_address = src->start_address;
        dst->reg_count     = src->reg_count;
        dst->data_type     = src->data_type;
        dst->scaling_factor= src->scaling_factor;

        memcpy(dst->json_key, src->json_key, SIZEOF_JSON_KEY);
        memcpy(dst->log_data, data[p], MAX_PAYLOAD);
    }

}
/******************************************************************************
 * @brief       parse json single key value function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_json_key_value(const char *json_packet, const char *json_key, uint8_t *value) {
    cJSON *json = cJSON_Parse(json_packet);
    if (!json) return 0;

    cJSON *item = cJSON_GetObjectItemCaseSensitive(json, json_key);
    if (!cJSON_IsString(item) || item->valuestring == NULL) {
        cJSON_Delete(json);
        return 0;
    }

    *value = (uint8_t)atoi(item->valuestring);  // Convert "01" to 1
    cJSON_Delete(json);
    return 1;
}
/******************************************************************************
 * @brief       Parse json config function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_json_for_fresh_config(const char *json, fresh_device_config_t *config) {
    cJSON *root = cJSON_Parse(json);
    if (!root) return 0;

    cJSON *mac = cJSON_GetObjectItemCaseSensitive(root, "MAC");
    cJSON *dvt = cJSON_GetObjectItemCaseSensitive(root, "MID");

    if (!cJSON_IsString(mac) || !cJSON_IsString(dvt)) {
        cJSON_Delete(root);
        return 0;
    }

    const char *mac_str = mac->valuestring;
    size_t len = strlen(mac_str);
    if (len != 12) {  // Must be 12 hex chars for 6 bytes
        cJSON_Delete(root);
        return 0;
    }

    // Convert MAC string (e.g., "020304050607") to 6 bytes
    for (int i = 0; i < 6; i++) {
        char byte_str[3] = { mac_str[i * 2], mac_str[i * 2 + 1], '\0' };
        config->mac_address[i] = (uint8_t)strtoul(byte_str, NULL, 16);
    }

    // Copy device type string
    strncpy(config->device_type_id, dvt->valuestring, sizeof(config->device_type_id) - 1);
    config->device_type_id[sizeof(config->device_type_id) - 1] = '\0';

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Function to create a json packet from the fresh device config structure fields
 * @param  config - config is a fresh device config structure variable
 * @param  seq_no - Sequence number of the json packet
 * @param  output_buffer - used for the storing of json packet
 * @retval Success - 1 Failed - 0
 **********************************************************************************************/
uint8_t prepare_read_back_response_for_fresh_device(fresh_device_config_t fresh_dv_cfg, uint8_t *output_buffer) {

	cJSON* root = cJSON_CreateObject();
    if(root == NULL){
    	return 0;
    }

    // Convert MAC address to hex string
    char mac_str[13];  // 12 hex chars + null
    for (int i = 0; i < 6; i++) {
        sprintf(&mac_str[i * 2], "%02X", fresh_dv_cfg.mac_address[i]);
    }

    // Build JSON
    cJSON_AddStringToObject(root, "MTP", "02");
    cJSON_AddStringToObject(root, "MAC", mac_str);
    cJSON_AddStringToObject(root, "MID", fresh_dv_cfg.device_type_id);

    uint8_t *ptr = cJSON_PrintUnformatted(root);
    strcpy((uint8_t*)output_buffer, (uint8_t*)ptr);
    free(ptr);
    cJSON_Delete(root);
    return 1;
}
/******************************************************************************
 * @brief       function to check valid JSON
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t is_valid_json(const char *json_buffer,uint16_t buffer_length) {

	const char *endptr = NULL;
	cJSON *root = cJSON_ParseWithLengthOpts(json_buffer, buffer_length, &endptr, 0);
	if (root == NULL || (endptr - json_buffer) != buffer_length) {
	    // Either parsing failed OR not all data was consumed
//	    printf("Invalid JSON or extra data\n");
	    return 0;
	} else {
		return 1;
	    // Valid and complete JSON
	}
}
/***********************************************************************************************
 * @brief  Function to create a packet from an input string
 * @param  input_buffer - input_buffer holds the input json packet
 * @param  status -  holds the status of the input packet
 * @param  output_buffer - holds the output string
 * @retval Success 1 failed 0
 **********************************************************************************************/
uint8_t prepare_response_with_status(uint8_t *input_buffer,uint8_t status,uint8_t *output_buffer) {

	cJSON *root = cJSON_CreateObject();    // root points to new packet
	if (root == NULL) {
		return 0;
	}

	cJSON *parse = cJSON_Parse((const char*)input_buffer);  //  parse points to input packet string
	if (!parse) {
		cJSON_Delete(root);
	    return 0;
	}

	cJSON *response = cJSON_CreateObject();
	if (response == NULL) {
		cJSON_Delete(root);
	    cJSON_Delete(parse);
	    return 0;
	}

    cJSON *item = NULL;
	cJSON_ArrayForEach(item, parse) {
		if (cJSON_IsString(item)) {
			cJSON_AddStringToObject(response, item->string, item->valuestring);
		}
	}

	cJSON_AddItemToObject(root, "RESPONSE", response);
    if (status == 1) {
    	cJSON_AddStringToObject(root, "STATUS", "OK");
    } else {
    	cJSON_AddStringToObject(root, "STATUS", "ERR");
    }

    uint8_t* ptr = cJSON_PrintUnformatted(root);
    strcpy((uint8_t*)output_buffer, (uint8_t*)ptr);
    free(ptr);
    cJSON_Delete(root);
    cJSON_Delete(parse);
    return 1;
}
/***********************************************************************************************
 * @brief  Function to prepare gsm response with status
 * @param  gsm_rsp
 * @param  status
 * @param  output_buffer - holds the output string
 * @retval None
 **********************************************************************************************/
void prepare_gsm_rsp_with_status(const char *gsm_rsp, uint8_t status_ok, uint8_t *output_buffer)
{
    if (output_buffer == NULL) return;

    const char *status = status_ok ? "OK" : "FAIL";

    snprintf((char *)output_buffer, 256,
             "{\"RESPONSE\":{\"AT_RSP\":\"%s\"},\"STATUS\":\"%s\"}",
             gsm_rsp ? gsm_rsp : "",
             status);
}
/***********************************************************************************************
 * @brief  Function for parse_fota_metadata_cjson
 * @param  json str
 * @param  fota_meta_t
 * @retval None
 **********************************************************************************************/
uint8_t parse_fota_metadata_cjson(const char *json_str, fota_meta_t *meta)
{
    if (!json_str || !meta)
        return 0;

    cJSON *root = cJSON_Parse(json_str);
    if (!root)
        return 0;

    const cJSON *fw_version = cJSON_GetObjectItem(root, "fw_version");
    const cJSON *size       = cJSON_GetObjectItem(root, "size");
    const cJSON *chunks     = cJSON_GetObjectItem(root, "chunks");
    const cJSON *update     = cJSON_GetObjectItem(root, "update");
    const cJSON *crc        = cJSON_GetObjectItem(root, "crc");

    /* Validate types */
    if (!cJSON_IsString(fw_version) ||
        !cJSON_IsNumber(size) ||
        !cJSON_IsNumber(chunks) ||
        !cJSON_IsString(update) ||
        !cJSON_IsString(crc))
    {
        cJSON_Delete(root);
        return 0;
    }

    /* Copy values */
    strncpy(meta->fw_version, fw_version->valuestring,
            sizeof(meta->fw_version) - 1);
    meta->fw_version[sizeof(meta->fw_version) - 1] = '\0';

    meta->size   = (uint32_t)size->valuedouble;
    meta->chunks = (uint32_t)chunks->valuedouble;

    meta->crc = (uint16_t)strtoul(crc->valuestring, NULL, 16);

//    if(strcmp(update->valuestring, "yes") == 0) {
//
//    } else {
//    	return 0;
//    }

    cJSON_Delete(root);
    return 1;
}


/******************************************************************************
 * @brief       validate cloud response
 * @param[in]   json_str - input json string
 * @param[in]   last_seq - last seq number of cloud packet
 * @param[in]   act -
 * @return      None
 ******************************************************************************/
cloud_status_t validate_cloud_response(const char *json_str, uint32_t *last_seq, uint8_t *rsp_sts)
{
    cJSON *root = cJSON_Parse(json_str);
    if (!root) {
    	return CLOUD_ERR_JSON;
    }

    cJSON *mtp     = cJSON_GetObjectItem(root, "msg_type");
    cJSON *mac     = cJSON_GetObjectItem(root, "mac");
    cJSON *seq     = cJSON_GetObjectItem(root, "seq_num");
    cJSON *status  = cJSON_GetObjectItem(root, "status");

    if (!mtp || !mac || !seq || !status ) {
        cJSON_Delete(root);
        return CLOUD_ERR_MISSING_FIELD;
    }
    /* Type validation */
    if (!cJSON_IsString(mtp) || !cJSON_IsString(mac) || !cJSON_IsNumber(seq) || !cJSON_IsString(status)) {
        cJSON_Delete(root);
        return CLOUD_ERR_MISSING_FIELD;
    }

    if (strcmp(mtp->valuestring, "rsp") != 0) {
        cJSON_Delete(root);
        return CLOUD_ERR_MSG_TYPE;
    }
    if (strcmp(mac->valuestring, mac_addr) != 0) {
        cJSON_Delete(root);
        return CLOUD_ERR_MAC;
    }

    *last_seq = seq->valuedouble;
    *rsp_sts = 0;
    if (strcmp(status->valuestring, "success") == 0) {
    	*rsp_sts = 1;
    }

    cJSON_Delete(root);
    return CLOUD_OK;
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
