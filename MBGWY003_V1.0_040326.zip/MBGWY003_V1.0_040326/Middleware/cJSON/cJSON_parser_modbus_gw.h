/**
  **************************
  * @file    cJSON_parser_modbus_gw.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 11
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CJSON_PARSER_MODBUS_GW_H_
#define __CJSON_PARSER_MODBUS_GW_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "modbus_gw_cfg.h"
/* Exported types ------------------------------------------------------------*/

 typedef enum {

     CLOUD_OK = 0,
     CLOUD_ERR_JSON,
     CLOUD_ERR_MISSING_FIELD,
	 CLOUD_ERR_MSG_TYPE,
     CLOUD_ERR_MAC,
     CLOUD_ERR_SEQ,
     CLOUD_ERR_STATUS,
     CLOUD_ERR_ACTION

 } cloud_status_t;

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/
 void create_rtu_json_packet(const char *channel_name, rtu_device_t *dev, const cloud_device_t *cloud_dev, uint8_t *out_buf);

 void copy_rtu_log(rtu_device_t *dev,uint8_t chn_type, uint32_t timestamp, uint8_t data[16][MAX_PAYLOAD], log_send_t *log_info);
 void copy_tcp_log(tcp_device_t *dev, uint32_t timestamp, uint8_t data[16][20], log_send_t *log_info);

 void mac_devid_set_for_cloud(uint8_t addr[6], const char id[10]);
 uint8_t parse_json_key_value(const char *json_packet, const char *json_key, uint8_t *value);
 uint8_t parse_json_for_fresh_config(const char *json, fresh_device_config_t *config);
 uint8_t is_valid_json(const char *json_buffer,uint16_t buffer_length);
 uint8_t prepare_read_back_response_for_fresh_device(fresh_device_config_t fresh_dv_cfg, uint8_t *output_buffer);
 uint8_t prepare_response_with_status(uint8_t *input_buffer,uint8_t status,uint8_t *output_buffer);
 void prepare_gsm_rsp_with_status(const char *gsm_rsp, uint8_t status_ok, uint8_t *output_buffer);

 void create_data_log_json_packet(log_send_t *dev, uint8_t *out_buf);
 uint8_t parse_fota_metadata_cjson(const char *json_str, fota_meta_t *meta);


 void create_custom_json_packet(const char *channel_name, rtu_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf);
 void create_custom_data_log_json_packet(log_send_t *dev, uint8_t *out_buf);

 cloud_status_t validate_cloud_response(const char *json_str, uint32_t *last_seq, uint8_t *rsp_sts);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __CJSON_PARSER_MODBUS_GW_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
