################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Middleware/database/calix_db.c \
../Middleware/database/spi_flash_partition.c 

OBJS += \
./Middleware/database/calix_db.o \
./Middleware/database/spi_flash_partition.o 

C_DEPS += \
./Middleware/database/calix_db.d \
./Middleware/database/spi_flash_partition.d 


# Each subdirectory must supply rules for building sources it contributes
Middleware/database/%.o: ../Middleware/database/%.c Middleware/database/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F407\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include" -I"D:\AT32F407\mcu_boot_modbus_gw\boot\ext\tinycrypt-sha512\lib\include" -I"D:\AT32F407\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include" -I"D:\AT32F407\mcu_boot_modbus_gw\boot\bootutil\include" -I"D:\AT32F407\mcu_boot_modbus_gw\boot\bootutil\src" -I"D:\AT32F407\mcu_boot_modbus_gw\boot\ext\fiat" -I"D:\AT32F407\mcu_boot_modbus_gw\boot\target_at32f347\include" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


