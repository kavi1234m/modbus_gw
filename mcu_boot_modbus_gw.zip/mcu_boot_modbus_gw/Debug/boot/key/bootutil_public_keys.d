boot/key/bootutil_public_keys.o: ../boot/key/bootutil_public_keys.c \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include/bootutil/sign_key.h \
 d:\at32f437_workspace\mcu_boot_modbus_gw\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include/bootutil/sign_key.h:
d:\at32f437_workspace\mcu_boot_modbus_gw\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h:
