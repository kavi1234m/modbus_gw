boot/target_at32f347/src/flash_map/flash_map.o: \
 ../boot/target_at32f347/src/flash_map/flash_map.c \
 d:\at32f437_workspace\mcu_boot_modbus_gw\boot\target_at32f347\include\flash_map_backend\flash_map_backend.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\target_at32f347\include/sysflash/sysflash.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\target_at32f347\include/mcuboot_config/mcuboot_config.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include/bootutil/bootutil_log.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include/bootutil/ignore.h \
 d:\at32f437_workspace\mcu_boot_modbus_gw\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h \
 d:\at32f437_workspace\mcu_boot_modbus_gw\boot\target_at32f347\include\mcuboot_config\mcuboot_logging.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include/bootutil/ignore.h \
 ../include/at32f435_437_conf.h \
 ../include/libraries/drivers/inc/at32f435_437_crm.h \
 ../include/libraries/cmsis/cm4/device_support/at32f435_437.h \
 ../include/libraries/cmsis/cm4/core_support/core_cm4.h \
 ../include/libraries/cmsis/cm4/core_support/cmsis_version.h \
 ../include/libraries/cmsis/cm4/core_support/cmsis_compiler.h \
 ../include/libraries/cmsis/cm4/core_support/cmsis_gcc.h \
 ../include/libraries/cmsis/cm4/core_support/mpu_armv7.h \
 ../include/libraries/cmsis/cm4/device_support/system_at32f435_437.h \
 ../include/libraries/drivers/inc/at32f435_437_def.h \
 ../include/libraries/drivers/inc/at32f435_437_tmr.h \
 ../include/libraries/drivers/inc/at32f435_437_ertc.h \
 ../include/libraries/drivers/inc/at32f435_437_gpio.h \
 ../include/libraries/drivers/inc/at32f435_437_i2c.h \
 ../include/libraries/drivers/inc/at32f435_437_usart.h \
 ../include/libraries/drivers/inc/at32f435_437_pwc.h \
 ../include/libraries/drivers/inc/at32f435_437_can.h \
 ../include/libraries/drivers/inc/at32f435_437_adc.h \
 ../include/libraries/drivers/inc/at32f435_437_dac.h \
 ../include/libraries/drivers/inc/at32f435_437_spi.h \
 ../include/libraries/drivers/inc/at32f435_437_dma.h \
 ../include/libraries/drivers/inc/at32f435_437_debug.h \
 ../include/libraries/drivers/inc/at32f435_437_flash.h \
 ../include/libraries/drivers/inc/at32f435_437_crc.h \
 ../include/libraries/drivers/inc/at32f435_437_wwdt.h \
 ../include/libraries/drivers/inc/at32f435_437_wdt.h \
 ../include/libraries/drivers/inc/at32f435_437_exint.h \
 ../include/libraries/drivers/inc/at32f435_437_sdio.h \
 ../include/libraries/drivers/inc/at32f435_437_xmc.h \
 ../include/libraries/drivers/inc/at32f435_437_acc.h \
 ../include/libraries/drivers/inc/at32f435_437_misc.h \
 ../include/libraries/drivers/inc/at32f435_437_edma.h \
 ../include/libraries/drivers/inc/at32f435_437_qspi.h \
 ../include/libraries/drivers/inc/at32f435_437_scfg.h \
 ../include/libraries/drivers/inc/at32f435_437_emac.h \
 ../include/libraries/drivers/inc/at32f435_437_dvp.h \
 ../include/libraries/drivers/inc/at32f435_437_usb.h
d:\at32f437_workspace\mcu_boot_modbus_gw\boot\target_at32f347\include\flash_map_backend\flash_map_backend.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\target_at32f347\include/sysflash/sysflash.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\target_at32f347\include/mcuboot_config/mcuboot_config.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include/bootutil/bootutil_log.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include/bootutil/ignore.h:
d:\at32f437_workspace\mcu_boot_modbus_gw\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h:
d:\at32f437_workspace\mcu_boot_modbus_gw\boot\target_at32f347\include\mcuboot_config\mcuboot_logging.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include/bootutil/ignore.h:
../include/at32f435_437_conf.h:
../include/libraries/drivers/inc/at32f435_437_crm.h:
../include/libraries/cmsis/cm4/device_support/at32f435_437.h:
../include/libraries/cmsis/cm4/core_support/core_cm4.h:
../include/libraries/cmsis/cm4/core_support/cmsis_version.h:
../include/libraries/cmsis/cm4/core_support/cmsis_compiler.h:
../include/libraries/cmsis/cm4/core_support/cmsis_gcc.h:
../include/libraries/cmsis/cm4/core_support/mpu_armv7.h:
../include/libraries/cmsis/cm4/device_support/system_at32f435_437.h:
../include/libraries/drivers/inc/at32f435_437_def.h:
../include/libraries/drivers/inc/at32f435_437_tmr.h:
../include/libraries/drivers/inc/at32f435_437_ertc.h:
../include/libraries/drivers/inc/at32f435_437_gpio.h:
../include/libraries/drivers/inc/at32f435_437_i2c.h:
../include/libraries/drivers/inc/at32f435_437_usart.h:
../include/libraries/drivers/inc/at32f435_437_pwc.h:
../include/libraries/drivers/inc/at32f435_437_can.h:
../include/libraries/drivers/inc/at32f435_437_adc.h:
../include/libraries/drivers/inc/at32f435_437_dac.h:
../include/libraries/drivers/inc/at32f435_437_spi.h:
../include/libraries/drivers/inc/at32f435_437_dma.h:
../include/libraries/drivers/inc/at32f435_437_debug.h:
../include/libraries/drivers/inc/at32f435_437_flash.h:
../include/libraries/drivers/inc/at32f435_437_crc.h:
../include/libraries/drivers/inc/at32f435_437_wwdt.h:
../include/libraries/drivers/inc/at32f435_437_wdt.h:
../include/libraries/drivers/inc/at32f435_437_exint.h:
../include/libraries/drivers/inc/at32f435_437_sdio.h:
../include/libraries/drivers/inc/at32f435_437_xmc.h:
../include/libraries/drivers/inc/at32f435_437_acc.h:
../include/libraries/drivers/inc/at32f435_437_misc.h:
../include/libraries/drivers/inc/at32f435_437_edma.h:
../include/libraries/drivers/inc/at32f435_437_qspi.h:
../include/libraries/drivers/inc/at32f435_437_scfg.h:
../include/libraries/drivers/inc/at32f435_437_emac.h:
../include/libraries/drivers/inc/at32f435_437_dvp.h:
../include/libraries/drivers/inc/at32f435_437_usb.h:
