################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../boot/ext/fiat/src/curve25519.c 

OBJS += \
./boot/ext/fiat/src/curve25519.o 

C_DEPS += \
./boot/ext/fiat/src/curve25519.d 


# Each subdirectory must supply rules for building sources it contributes
boot/ext/fiat/src/%.o: ../boot/ext/fiat/src/%.c boot/ext/fiat/src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\Middleware\internal_flash" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\Middleware\spi_flash" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt-sha512\lib\include" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\include" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\bootutil\src" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\fiat" -I"D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\target_at32f347\include" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


