boot/ext/tinycrypt-sha512/lib/source/sha512.o: \
 ../boot/ext/tinycrypt-sha512/lib/source/sha512.c \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt-sha512\lib\include/tinycrypt/sha512.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/utils.h
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt-sha512\lib\include/tinycrypt/sha512.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/utils.h:
