boot/ext/mbedtls-asn1/src/platform_util.o: \
 ../boot/ext/mbedtls-asn1/src/platform_util.c \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/common.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/build_info.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/mbedtls_config.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/check_config.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/check_config.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/platform_util.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/build_info.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/platform.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/private_access.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/threading.h
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/common.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/build_info.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/mbedtls_config.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/check_config.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/check_config.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/platform_util.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/build_info.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/platform.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/private_access.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\mbedtls-asn1\include/mbedtls/threading.h:
