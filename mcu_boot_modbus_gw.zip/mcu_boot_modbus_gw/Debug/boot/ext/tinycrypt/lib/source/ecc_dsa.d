boot/ext/tinycrypt/lib/source/ecc_dsa.o: \
 ../boot/ext/tinycrypt/lib/source/ecc_dsa.c \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/ecc.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/ecc_dsa.h
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/ecc.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/ecc_dsa.h:
