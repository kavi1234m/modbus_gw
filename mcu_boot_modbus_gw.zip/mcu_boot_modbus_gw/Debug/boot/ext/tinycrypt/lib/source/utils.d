boot/ext/tinycrypt/lib/source/utils.o: \
 ../boot/ext/tinycrypt/lib/source/utils.c \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/utils.h \
 D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/utils.h:
D:\AT32F437_WORKSPACE\mcu_boot_modbus_gw\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h:
