/**
  **************************************************************************
  * @file     main.c
  * @brief    main program
  **************************************************************************
  *                       Copyright notice & Disclaimer
  *
  * The software Board Support Package (BSP) that is made available to
  * download from Artery official website is the copyrighted work of Artery.
  * Artery authorizes customers to use, copy, and distribute the BSP
  * software and its related documentation for the purpose of design and
  * development in conjunction with Artery microcontrollers. Use of the
  * software is governed by this copyright notice and the following disclaimer.
  *
  * THIS SOFTWARE IS PROVIDED ON "AS IS" BASIS WITHOUT WARRANTIES,
  * GUARANTEES OR REPRESENTATIONS OF ANY KIND. ARTERY EXPRESSLY DISCLAIMS,
  * TO THE FULLEST EXTENT PERMITTED BY LAW, ALL EXPRESS, IMPLIED OR
  * STATUTORY OR OTHER WARRANTIES, GUARANTEES OR REPRESENTATIONS,
  * INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
  *
  **************************************************************************
  */

#include "at32f435_437_board.h"
#include "at32f435_437_clock.h"
#include "flash.h"
#include "spi_flash.h"
#include <stdlib.h>
#include "at32f435_437_flash.h"
#include "checksum.h"
#include "flash.h"


#define MSP_VERIFY_MASK	      0x2FFE0000

#define FW_SET_FLAG_ADDR      0x080FF000
#define FW_SET_FLAG           0xFFFF

#define BOOTLOADER_ADDRESS     0x08000000
#define BOOTLOADER_SIZE        0x8000			/* 32kB */

#define MAIN_APPLICATION_ADDR   		(BOOTLOADER_ADDRESS + BOOTLOADER_SIZE)
#define MAIN_APPLICATION_SIZE   		0x80000    				/* 512kB */

#define DEF_APPLICATION_ADDR    		(MAIN_APPLICATION_ADDR + MAIN_APPLICATION_SIZE)
#define DEF_APPLICATION_SIZE    		0X77000     			/* 476kB */

#define SECTOR_SIZE           0X800
#define HALF_SECTOR_SIZE      (SECTOR_SIZE/2)

typedef void (*func_ptr)(void);

uint16_t flag_sector_buff[HALF_SECTOR_SIZE];


#define SFP_PAGE_SIZE      256
#define SFP_SECTOR_SIZE    4096
#define SFP_FLASH_SIZE     1048576
#define SFP_FLASH_START    0x000000


#define SFP_PRTN_CNT           5

#define SFP_PRTN1              0x00
#define SFP_PRTN1_TYP          0x00
#define SFP_PRTN1_STRT_ADDR    SFP_FLASH_START
#define SFP_PRTN1_SIZE         147456
#define SFP_PRTN1_END_ADDR     ((SFP_PRTN1_STRT_ADDR+SFP_PRTN1_SIZE)-1)

#define CONFG_P1_START         SFP_PRTN1_STRT_ADDR
#define CONFG_P1_SIZE          73728
#define CONFG_P1_END           (CONFG_P1_START+CONFG_P1_SIZE-1)

#define CONFG_P2_START         (CONFG_P1_END+1)
#define CONFG_P2_SIZE          73728
#define CONFG_P2_END           (CONFG_P2_START+CONFG_P2_SIZE-1)

#define SFP_PRTN2              0x01
#define SFP_PRTN2_TYP          0x01
#define SFP_PRTN2_STRT_ADDR    (SFP_PRTN1_END_ADDR + 1)
#define SFP_PRTN2_SIZE         524288
#define SFP_PRTN2_END_ADDR     ((SFP_PRTN2_STRT_ADDR + SFP_PRTN2_SIZE)-1)

#define FOTA_FLAG_ADDR         SFP_PRTN2_STRT_ADDR
#define FOTA_START_ADDR        (SFP_PRTN2_STRT_ADDR + SFP_SECTOR_SIZE)
#define FOTA_END_ADDR          (SFP_PRTN2_END_ADDR - 4096)

#define FOTA_CHUNK_SIZE        (2*4096)

//#define SPI_FOTA_FLAG_ADDR     0x28000
//#define SPI_FOTA_START_ADDR    0x29000
//#define SPI_FOTA_END_ADDR      (0x29000 + 0X7F000)
//#define FOTA_CHUNK_SIZE        (2*4096)

uint32_t spi_fota_read_addr = FOTA_START_ADDR;

typedef struct {
    char     fw_version[8];
    uint32_t size;
    uint16_t chunks;
    uint16_t crc;
} fota_meta_t;

/****************************************************************************************************************
  * @brief  read FOTA data from memory
  * @param  conf_dat: buffer to hold FOTA data
  * @param  len: length of buffer
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t cdb_read_fota(uint8_t *fota_dat, uint16_t fota_read_len)
{
	if (((spi_fota_read_addr <= FOTA_END_ADDR) && (spi_fota_read_addr >= FOTA_START_ADDR))) {
		if(spiflash_read(fota_dat, spi_fota_read_addr, fota_read_len)) {
			spi_fota_read_addr += fota_read_len;
			return 1;
		} else {
			return 0;
		}
	} else {
		return 0;
	}
}
/****************************************************************************************************************
  * @brief  fota status get
  * @param  None
  * @retval 1 if success, 0 if failure
  ***************************************************************************************************************/
uint8_t fota_status_get(fota_meta_t *fota_data) {

	if(spiflash_read((uint8_t*)fota_data, FOTA_FLAG_ADDR, sizeof(fota_meta_t))){
        return 1;
	} else {
		return 0;
	}
}
/**
  * @brief  init exint function.
  * @param  none
  * @retval none
  */
static inline uint8_t app_exists(uint32_t addr)
{
    return ((*(volatile uint32_t *)addr) & MSP_VERIFY_MASK) ==  0x20080000;
}
/**
  * @brief  init exint function.
  * @param  none
  * @retval none
  */
void jump_to_application(uint32_t app_addr)
{
    if (!app_exists(app_addr))
    {
        printf("No application found!\r\n");
        return;
    }

    printf("Jumping to application @ 0x%08X...\r\n", app_addr);

    uint32_t stack_ptr = *(volatile uint32_t *)app_addr;
    uint32_t reset_vec = *(volatile uint32_t *)(app_addr + 4);

    func_ptr app = (func_ptr)reset_vec;

    __disable_irq();
    __set_MSP(stack_ptr);

    flash_lock();

    app();
}
/**
  * @brief  main function.
  * @param  none
  * @retval none
  */
int main(void)
{
	uint16_t global_crc = 0xFFFF;
	fota_meta_t fota_dt;
	uint16_t fota_len = 8192;
    system_clock_config();
    uart_print_init(115200, 0);


    printf("\r\n=== Bootloader Starting ===\r\n");
    uint16_t initial_flag = *(volatile uint16_t *)FW_SET_FLAG_ADDR;
    printf("Initial flag at 0x%08X: 0x%04X\r\n", FW_SET_FLAG_ADDR, initial_flag);

    fw_flag_t flag_sts = read_fw_flag();

    if (flag_sts == FOTA_SET) {
    	printf("New FW flag detected! Updating firmware...\r\n");
        __disable_irq();
        spiflash_init();

        fota_status_get(&fota_dt);

        printf("BEFORE FOTA READ DATA: size=%u, crc=0x%04X\r\n",
               fota_dt.size, fota_dt.crc);

        uint32_t remaining = fota_dt.size;
        uint32_t read_addr = FOTA_START_ADDR;
        uint32_t chunk_size = 8 * 1024;
        error_status write_result;
        uint32_t write_addr = MAIN_APPLICATION_ADDR;
        uint8_t *fota_buffer = (uint8_t *)malloc(chunk_size);

        if(fota_buffer == NULL){
            printf("Failed to allocate the memory for FOTA Copy\r\n");
            __enable_irq();
            NVIC_SystemReset();
        } else {

            while (remaining > 0)
            {
                uint32_t read_len = (remaining > chunk_size) ? chunk_size : remaining;

                if (!cdb_read_fota(fota_buffer, read_len))
                {
                    printf("FOTA read failed at address 0x%08X\r\n", read_addr);
                    break;
                }
                global_crc = crc16_update(global_crc, fota_buffer, read_len);
                write_result = flash_write(write_addr, (uint16_t *) fota_buffer, (read_len/2));
                write_addr += read_len;
                read_addr += read_len;
                remaining -= read_len;
            }
            free(fota_buffer);
            if(write_result == SUCCESS) {
            	printf("AFTER FOTA READ DATA:%04X,%04X\r\n", global_crc, fota_dt.crc);
            	if (global_crc == fota_dt.crc) {
                	printf("Firmware update successful!\r\n");
                    printf("Clearing update flag...\r\n");
            		write_firmware_flag(FW_SET_FLAG_ADDR, 0xFFFF);
            	} else {
            		write_firmware_flag(FW_SET_FLAG_ADDR, 0x5A5A);
            		printf("fota failure\r\n");
            	}
            } else {
            	write_firmware_flag(FW_SET_FLAG_ADDR, 0x5A5A);
                printf("Firmware update FAILED: %d\r\n", write_result);
            }
            __enable_irq();
            printf("Update complete. Restarting...\r\n");
            NVIC_SystemReset();
        }

    } else if (flag_sts == DEF_FW_SET) {
    	jump_to_application(DEF_APPLICATION_ADDR);
    } else {
    	jump_to_application(MAIN_APPLICATION_ADDR);
    }
    while(1) { }
}
