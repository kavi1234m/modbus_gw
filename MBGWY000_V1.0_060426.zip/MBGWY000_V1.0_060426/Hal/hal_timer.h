/**
  **************************
  * @file    hal_timer.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 3
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HAL_TIMER_H_
#define __HAL_TIMER_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#include <stdio.h>
#include <stdint.h>
#include "at32f435_437_tmr.h"

/* Exported types ------------------------------------------------------------*/

 /*************************************************

 Frequency(hz) = TMRxCLK /(TMRx_DIV+1)(TMRx_PR+1);
               = 240*10^6 / (24000)*(100)
               = 240*10^6 / 240*10^4
               = 100

 if frequency is 100hz
       T = 1/F
       T = 1/100
       T = 0.01 = 10 ms

  **********************************************/

typedef enum {
	TIMER1  = 0,
	TIMER2  = 1,
	TIMER3  = 2,
	TIMER4  = 3,
	TIMER5  = 4,
	TIMER6  = 5,
	TIMER7  = 6,
	TIMER8  = 7,
	TIMER9  = 8,
	TIMER10 = 9,
	TIMER11 = 10,
	TIMER12 = 11,
	TIMER13 = 12,
	TIMER14 = 13,
}timer_type;

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/

void hal_timer_init(timer_type tmr_x, uint32_t time_in_ms);
void hal_timer_deinit(timer_type tmr_x);
void hal_timer_enable_disable(timer_type tmr_x,uint8_t new_state);
void hal_timer_interrupt_enable(timer_type tmr_x, uint8_t new_state);
void timer_callback_register(void *callback_function);
uint32_t hal_timer_counter_value_get(timer_type tmr_x);

void timer_clock_enable(timer_type tmr_x);
void timer_interrupt_set(timer_type tmr_x);
tmr_type *timer_select(timer_type tmr_x);


#ifdef __cplusplus
}
#endif

#endif /* __FILENAME_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
