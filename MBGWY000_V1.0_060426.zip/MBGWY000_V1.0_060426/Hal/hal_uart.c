/**
  ******************************************************************************
  * @file    hal_uart.c
  * @author  Kaviyarasan, Calixto Firmware Team
  * @version V1.0.0
  * @date    29-08-2024
   * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  ******************************************************************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include "hal_uart.h"
#include "at32f435_437_usart.h"
#include "at32f435_437_board.h"
#include "hal_gpio.h"
#include "hal_timer.h"

#include "FreeRTOS.h"
#include "task.h"
#include "modbus_gw_cfg.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#define UART_BUF_LEN        260
/*********  uart tx and rx pins ***********************/

#define USART1_TX_PIN       GPIO_PINS_9
#define USART1_TX_PORT      GPIOA
#define USART1_RX_PIN       GPIO_PINS_10
#define USART1_RX_PORT      GPIOA

#define USART2_TX_PIN       GPIO_PINS_2
#define USART2_TX_PORT      GPIOA
#define USART2_RX_PIN       GPIO_PINS_3
#define USART2_RX_PORT      GPIOA

#define USART3_TX_PIN       GPIO_PINS_10
#define USART3_TX_PORT      GPIOB
#define USART3_RX_PIN       GPIO_PINS_11
#define USART3_RX_PORT      GPIOB

#define UART4_TX_PIN        GPIO_PINS_10
#define UART4_TX_PORT       GPIOC
#define UART4_RX_PIN        GPIO_PINS_11
#define UART4_RX_PORT       GPIOC

#define UART5_TX_PIN        GPIO_PINS_12
#define UART5_TX_PORT       GPIOC
#define UART5_RX_PIN        GPIO_PINS_2
#define UART5_RX_PORT       GPIOD

#define USART6_TX_PIN        GPIO_PINS_6
#define USART6_TX_PORT       GPIOC
#define USART6_RX_PIN        GPIO_PINS_7
#define USART6_RX_PORT       GPIOC

#define UART7_TX_PIN        GPIO_PINS_8
#define UART7_TX_PORT       GPIOE
#define UART7_RX_PIN        GPIO_PINS_7
#define UART7_RX_PORT       GPIOE

#define UART8_TX_PIN        GPIO_PINS_1
#define UART8_TX_PORT       GPIOE
#define UART8_RX_PIN        GPIO_PINS_0
#define UART8_RX_PORT       GPIOE

/********** hardware flow control pins for USART1,USART2,USART3 **********/
#define USART1_RTS_PIN      GPIO_PINS_12
#define USART1_RTS_PORT     GPIOA
#define USART1_CTS_PIN      GPIO_PINS_11
#define USART1_CTS_PORT     GPIOA

#define USART2_RTS_PIN      GPIO_PINS_4
#define USART2_RTS_PORT     GPIOD
#define USART2_CTS_PIN      GPIO_PINS_3
#define USART2_CTS_PORT     GPIOD

#define USART3_RTS_PIN      GPIO_PINS_12
#define USART3_RTS_PORT     GPIOD
#define USART3_CTS_PIN      GPIO_PINS_11
#define USART3_CTS_PORT     GPIOD

typedef void (*cbk_fun)();
cbk_fun uart_cbk;

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

uint8_t uart_4_buf[UART_BUF_LEN];
uint8_t uart_5_buf[UART_BUF_LEN];

volatile uint8_t uart_4_index;
volatile uint8_t uart_5_index;
volatile uint8_t slave_id;
volatile uint32_t msTick=0;
volatile uint8_t uart4_rx_start;
volatile uint8_t uart5_rx_start;

uint8_t *uart_4_head = uart_4_buf;  // Pointer to the head (write position)
uint8_t *uart_4_tail = uart_4_buf;

uint8_t *uart_5_head = uart_5_buf;  // Pointer to the head (write position)
uint8_t *uart_5_tail = uart_5_buf;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*************************************************************************************************
  * @brief  uart callback register
  * @param  none
  * @retval none
  ************************************************************************************************/
void uart_callback_register(void *cbk)
{
     uart_cbk = cbk;
}
/******************************************interrupt handler****************************************************/

/*************************************************************************************************
  * @brief  Receive interrupt handler for uart4
  * @param  none
  * @retval none
  ************************************************************************************************/
void UART4_IRQHandler(void)
{
    if(usart_interrupt_flag_get(UART4, USART_RDBF_FLAG) != RESET) {
        uint8_t data = usart_data_receive(UART4);
        if (!uart4_rx_start) {
            if (slave_id == data) {
                uart4_rx_start = 1;
      		    *uart_4_head = data;
      		    uart_4_head++;
      		    uart_4_index = 1;
            }
        } else {
            if (uart_4_index < UART_BUF_LEN) {
      		    *uart_4_head = data;
      		    uart_4_head++;
      		    uart_4_index++;
            }
        }
    }
}
/*************************************************************************************************
  * @brief  Receive interrupt handler for uart5
  * @param  none
  * @retval none
  ************************************************************************************************/
void UART5_IRQHandler(void)
{
	  if(usart_interrupt_flag_get(UART5, USART_RDBF_FLAG) != RESET)
	  {
		  uint8_t data = usart_data_receive(UART5);
	        if (!uart5_rx_start) {
	            if (slave_id == data) {
	                uart5_rx_start = 1;
	      		    *uart_5_head = data;
	      		    uart_5_head++;
	      		    uart_5_index = 1;
	            }
	        } else {
	            if (uart_5_index < UART_BUF_LEN) {
	      		    *uart_5_head = data;
	      		    uart_5_head++;
	      		    uart_5_index++;
	            }
	        }
	  }
}
/*************************************************************************************************
  * @brief  Receive interrupt handler for uart5
  * @param  none
  * @retval none
  ************************************************************************************************/
void USART6_IRQHandler(void)
{
	  if(usart_interrupt_flag_get(USART6, USART_RDBF_FLAG) != RESET)
	  {
		   uint8_t data = usart_data_receive(USART6);
		   uart_cbk(USART_6, 1, data);
	  }
	  if (usart_interrupt_flag_get(USART6, USART_IDLEF_FLAG) != RESET)
	  {
		    uint16_t buf = usart_data_receive(USART6);
		    uart_cbk(USART_6, 2, 0);
	  }
}
/************************************************** interrupt part End *********************************************************************/

/***********************************************************************************
  * @brief  this function handles timer6 overflow handler.
  * @param  none
  * @retval none
  ***********************************************************************************/
void TMR6_DAC_GLOBAL_IRQHandler(void)
{
  if(tmr_interrupt_flag_get(TMR6, TMR_OVF_FLAG) != RESET)
  {
	 msTick++;
     tmr_flag_clear(TMR6, TMR_OVF_FLAG);
  }
}

/*************************************************************************************************************
  * @brief  uart select function
  * @param1 uart_x -uart to select
  * @retval usart_type
  ************************************************************************************************************/
usart_type *uart_select(uart_type uart_x) {

	usart_type *selected_uart;
	switch (uart_x) {
	    case USART_1 :
	    	 selected_uart = USART1;
	    	 break;
	    case USART_2 :
	    	 selected_uart = USART2;
	    	 break;
	    case USART_3 :
	    	 selected_uart = USART3;
	    	 break;
	    case UART_4 :
	    	 selected_uart = UART4;
	    	 break;
	    case UART_5 :
	    	 selected_uart = UART5;
	    	 break;
	    case USART_6 :
	    	 selected_uart = USART6;
	    	 break;
	    case UART_7 :
	    	 selected_uart = UART7;
	    	 break;
	    case UART_8 :
	    	 selected_uart = UART8;
	    	 break;
	}
	return selected_uart;
}
/*************************************************************************************************************
  * @brief  Enable clock for uart function
  * @param1 uart_x -uart to set clock
  * @retval none
  ************************************************************************************************************/
void uart_clock_enable(uart_type uart_x) {

	switch (uart_x) {
	    case USART_1 :
	  	     crm_periph_clock_enable(CRM_USART1_PERIPH_CLOCK, TRUE);
	    	 break;
	    case USART_2 :
	  	     crm_periph_clock_enable(CRM_USART2_PERIPH_CLOCK, TRUE);
	    	 break;
	    case USART_3 :
	  	     crm_periph_clock_enable(CRM_USART3_PERIPH_CLOCK, TRUE);
	    	 break;
	    case UART_4 :
	  	     crm_periph_clock_enable(CRM_UART4_PERIPH_CLOCK, TRUE);
	    	 break;
	    case UART_5 :
	  	     crm_periph_clock_enable(CRM_UART5_PERIPH_CLOCK, TRUE);
	    	 break;
	    case USART_6 :
	  	     crm_periph_clock_enable(CRM_USART6_PERIPH_CLOCK, TRUE);
	    	 break;
	    case UART_7 :
	  	     crm_periph_clock_enable(CRM_UART7_PERIPH_CLOCK, TRUE);
	    	 break;
	    case UART_8 :
	  	     crm_periph_clock_enable(CRM_UART8_PERIPH_CLOCK, TRUE);
	    	 break;
	}
}
/*************************************************************************************************************
  * @brief  select uart tx rx pin function
  * @param1 uart_x -uart to pin select
  * @param2 flow_state - select hardware flow control type
  * @retval none
  ************************************************************************************************************/
void configure_uart_pin(uart_type uart_x, flow_control_type flow_state) {

	 gpio_init_type gpio_init_struct;
	 gpio_default_para_init(&gpio_init_struct);
	 gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
	 gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;
	 switch (uart_x) {
	     case USART_1 :
	    	  /* configure the  tx pin */
	    	  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
	    	  gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = GPIO_PINS_9 | GPIO_PINS_10;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	    	  gpio_init(GPIOA, &gpio_init_struct);
	    	  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE9, GPIO_MUX_7);
	    	  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE10, GPIO_MUX_7);
	    	  if (flow_state == FLOW_RTS_CTS) {
	    		  gpio_init_struct.gpio_pins = GPIO_PINS_11 | GPIO_PINS_12;
	    		  gpio_init(GPIOA, &gpio_init_struct);
		    	  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE11, GPIO_MUX_7);
		    	  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE12, GPIO_MUX_7);
	    	  }
	    	  break;
	     case USART_2 :
	    	  /* configure the  tx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = USART2_TX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	    	  gpio_init(USART2_TX_PORT, &gpio_init_struct);
	    	  /* configure the rx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
	    	  gpio_init_struct.gpio_pins = USART2_RX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(USART2_RX_PORT, &gpio_init_struct);

	    	  if(flow_state == FLOW_RTS) {
		    	  /* configure the  RTS pin */
	    		  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
		    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
		    	  gpio_init_struct.gpio_pins = USART2_RTS_PIN;
		    	  gpio_init(USART2_RTS_PORT, &gpio_init_struct);

	    	  } else if (flow_state == FLOW_CTS) {
	    		  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
		    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
		    	  gpio_init_struct.gpio_pins = USART2_CTS_PIN;
		    	  gpio_init(USART2_CTS_PORT, &gpio_init_struct);

	    	  } else if (flow_state == FLOW_RTS_CTS) {
		    	  /* configure rts pin */
		    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
		    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
		    	  gpio_init_struct.gpio_pins = USART2_RTS_PIN;
		    	  gpio_init(USART2_RTS_PORT, &gpio_init_struct);
		    	  /* configure the CTS pin */
		    	  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
		    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
		    	  gpio_init_struct.gpio_pins = USART2_CTS_PIN;
		    	  gpio_init(USART2_CTS_PORT, &gpio_init_struct);

	    	  }
	    	  break;
	     case USART_3 :
	    	  /* configure the  tx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = USART3_TX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	    	  gpio_init(USART3_TX_PORT, &gpio_init_struct);
	    	  /* configure the rx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
	    	  gpio_init_struct.gpio_pins = USART3_RX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(USART3_RX_PORT, &gpio_init_struct);

	    	  if(flow_state == FLOW_RTS) {
		    	  /* configure the  tx and RTS pin */
	    		  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
		    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
		    	  gpio_init_struct.gpio_pins = USART3_RTS_PIN;
		    	  gpio_init(USART3_RTS_PORT, &gpio_init_struct);

	    	  } else if (flow_state == FLOW_CTS) {
	    		  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
		    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
		    	  gpio_init_struct.gpio_pins = USART3_CTS_PIN;
		    	  gpio_init(USART3_CTS_PORT, &gpio_init_struct);

	    	  } else if (flow_state == FLOW_RTS_CTS) {
		    	  /* configure the  tx pin */
		    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
		    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
		    	  gpio_init_struct.gpio_pins = USART3_RTS_PIN;
		    	  gpio_init(USART3_RTS_PORT, &gpio_init_struct);
		    	  /* configure the rx pin */
		    	  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
		    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
		    	  gpio_init_struct.gpio_pins = USART3_CTS_PIN;
		    	  gpio_init(USART3_CTS_PORT, &gpio_init_struct);

	    	  }
	    	  break;
	     case UART_4 :
	    	  /* configure the  tx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = UART4_TX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(UART4_TX_PORT, &gpio_init_struct);
	    	  /* configure the rx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = UART4_RX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(UART4_RX_PORT, &gpio_init_struct);

	    	  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE10, GPIO_MUX_8);
	    	  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE11, GPIO_MUX_8);
	    	  break;
	     case UART_5 :
	    	  /* configure the  tx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = UART5_TX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(UART5_TX_PORT, &gpio_init_struct);
	    	  /* configure the rx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = UART5_RX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(UART5_RX_PORT, &gpio_init_struct);

	    	  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE12, GPIO_MUX_8);
	    	  gpio_pin_mux_config(GPIOD, GPIO_PINS_SOURCE2, GPIO_MUX_8);
	    	  break;
	     case USART_6 :
	    	  /* configure the  tx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = USART6_TX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	    	  gpio_init(USART6_TX_PORT, &gpio_init_struct);
	    	  /* configure the rx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
	    	  gpio_init_struct.gpio_pins = USART6_RX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(USART6_RX_PORT, &gpio_init_struct);
	    	  break;
	     case UART_7 :
	    	  /* configure the  tx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = UART7_TX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	    	  gpio_init(UART7_TX_PORT, &gpio_init_struct);
	    	  /* configure the rx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
	    	  gpio_init_struct.gpio_pins = UART7_RX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(UART7_RX_PORT, &gpio_init_struct);
	    	  break;
	     case UART_8 :
	    	  /* configure the  tx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	    	  gpio_init_struct.gpio_pins = UART8_TX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	    	  gpio_init(UART8_TX_PORT, &gpio_init_struct);
	    	  /* configure the rx pin */
	    	  gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
	    	  gpio_init_struct.gpio_pins = UART8_RX_PIN;
	    	  gpio_init_struct.gpio_pull = GPIO_PULL_UP;
	    	  gpio_init(UART8_RX_PORT, &gpio_init_struct);
	    	  break;
	}
}
/*************************************************************************************************************
  * @brief  uart set nvic function
  * @param1 uart_x -uart to set interrupt
  * @retval none
  ************************************************************************************************************/
void uart_interrupt_set(uart_type uart_x) {

	nvic_priority_group_config(NVIC_PRIORITY_GROUP_4);
	switch (uart_x) {
	    case USART_1 :
	    	 nvic_irq_enable(USART1_IRQn, 2, 0);
	    	 break;
	    case USART_2 :
	    	 nvic_irq_enable(USART2_IRQn, 0, 0);
	    	 break;
	    case USART_3 :
	    	 nvic_irq_enable(USART3_IRQn, 0, 0);
	    	 break;
	    case UART_4 :
	    	 nvic_irq_enable(UART4_IRQn, 1, 0);
	    	 break;
	    case UART_5 :
	    	 nvic_irq_enable(UART5_IRQn, 2, 0);
	    	 break;
	    case USART_6 :
	    	 nvic_irq_enable(USART6_IRQn, 0, 0);
	    	 break;
	    case UART_7 :
	         nvic_irq_enable(UART7_IRQn, 0, 0);
	    	 break;
	    case UART_8 :
	    	 nvic_irq_enable(UART8_IRQn, 0, 0);
	    	 break;
	}
}
/*************************************************************************************************************
  * @brief  uart initialization function
  * @param1 uart_x
  * @param2 baud rate
  * @param3 parity
  * @param4 data bit
  * @param4 stop bit
  * @param5 hardware flow control type
  * @retval none
  ************************************************************************************************************/
void uart_init(uart_type uart_x, uint32_t baud_rate, uint8_t parity, uint8_t data_bit, uint8_t stop_bit) {

//	printf("UART INFO:%d,%d,%c,%d,%d\n",uart_x, baud_rate, parity, data_bit, stop_bit);
	gpio_init_type gpio_init_struct;
	usart_type *uart = uart_select(uart_x);
	uart_clock_enable(uart_x);

	if (uart_x == USART_1) {
		configure_uart_pin(uart_x,FLOW_RTS_CTS);
	} else {
		configure_uart_pin(uart_x,FLOW_NONE);
	}
	uint8_t data_bit_length;
	uint8_t stop_bit_length = (stop_bit == USART_STOP_2_BIT) ? USART_STOP_2_BIT : USART_STOP_1_BIT;
	uint8_t is_parity_enabled = ((parity == 'O') || (parity == 'E')) ? 1 : 0;
	if (is_parity_enabled) {
	    data_bit_length = (data_bit == 7) ? USART_DATA_8BITS : USART_DATA_9BITS;
	} else {
		data_bit_length = (data_bit == 7) ? USART_DATA_7BITS : USART_DATA_8BITS;
	}
	usart_init(uart, baud_rate, data_bit_length, stop_bit_length);

    uart_interrupt_set(uart_x);
//    usart_interrupt_enable(uart, USART_RDBF_INT, TRUE);
    if (uart_x == UART_4 || uart_x == UART_5) {
    	usart_interrupt_enable(uart, USART_RDBF_INT, FALSE);
    	usart_receiver_enable(uart, FALSE);
    } else {
    	usart_interrupt_enable(uart, USART_RDBF_INT, TRUE);
    	usart_receiver_enable(uart, TRUE);
    }
    usart_transmitter_enable(uart, TRUE);

    if (uart_x == USART_1) {
    	usart_interrupt_enable(uart, USART_IDLE_INT, TRUE);
    	usart_hardware_flow_control_set(uart,USART_HARDWARE_FLOW_RTS_CTS);
    }
	if (parity == 'O') {
		usart_parity_selection_config(uart,USART_PARITY_ODD);
	} else if (parity == 'E') {
		usart_parity_selection_config(uart,USART_PARITY_EVEN);
	} else {
		usart_parity_selection_config(uart,USART_PARITY_NONE);
	}
	usart_enable(uart, TRUE);

}
/*************************************************************************************************************
  * @brief  uart inetrrupt enable function
  * @param1 uart_x
  * @param2 flow type
  * @retval none
  ************************************************************************************************************/
void uart_interrupt_enable(uart_type uart_x, uint8_t status) {
	usart_type *uart = uart_select(uart_x);
	if (status) {
		usart_receiver_enable(uart, TRUE);
		usart_interrupt_enable(uart, USART_RDBF_INT, TRUE);
	} else {
		usart_receiver_enable(uart, FALSE);
		usart_interrupt_enable(uart, USART_RDBF_INT, FALSE);
	}
}
/*************************************************************************************************************
  * @brief  uart inetrrupt enable function
  * @param1 uart_x
  * @param2 flow type
  * @retval none
  ************************************************************************************************************/
void uart_idle_interrupt_enable_disable(uart_type uart_x, uint8_t status) {
	usart_type *uart = uart_select(uart_x);
	if (status) {
		usart_interrupt_enable(uart, USART_IDLE_INT, TRUE);
	} else {
		usart_interrupt_enable(uart, USART_IDLE_INT, FALSE);
	}
}
/*************************************************************************************************************
  * @brief  uart flow control set function
  * @param1 uart_x
  * @param2 flow type
  * @retval none
  ************************************************************************************************************/
void usart_flow_control_set(uart_type uart_x, flow_control_type flow_state) {

	gpio_init_type gpio_init_struct;
	usart_type *uart = uart_select(uart_x);
    switch (flow_state) {
        case FLOW_NONE :
    	     usart_hardware_flow_control_set(uart,USART_HARDWARE_FLOW_NONE);
    	     break;
        case FLOW_RTS :
    	     usart_hardware_flow_control_set(uart,USART_HARDWARE_FLOW_RTS);
    	     break;
        case FLOW_CTS :
    	     usart_hardware_flow_control_set(uart,USART_HARDWARE_FLOW_CTS);
    	     break;
        case FLOW_RTS_CTS :
    	     usart_hardware_flow_control_set(uart,USART_HARDWARE_FLOW_RTS_CTS);
    	     break;
        default:
        	break;
    }

}
/*************************************************************************************************************
  * @brief  uart deinitialization function
  * @param1 uart_x
  * @retval none
  ************************************************************************************************************/
void uart_deinit(uart_type uart_x) {
//	usart_type *uart = uart_select(uart_x);
//	usart_reset(uart);

}
/************************************************************************************************
  * @brief  uart transmit function
  * @param1 uart_x - uart to transmit
  * @param2 *data_buf - buffer to transmit
  * @param3 data_len - length of the buffer
  * @param4 timeout in us
  * @retval 0-success -1 failure
  **********************************************************************************************/
int8_t uart_transmit(uart_type uart_x,const uint8_t *req,uint16_t req_length, uint16_t ms) {

    if (ms == 0) {
    	ms = 10;
    }
	usart_type *uart = uart_select(uart_x);
	if (uart_x == UART_4 || uart_x == UART_5) {
		uart4_rx_start = 0;
		uart5_rx_start = 0;
	    slave_id = req[0];
	    uart_interrupt_enable(UART_4, FALSE);
	    uart_interrupt_enable(UART_5, FALSE);
//        uart_interrupt_enable(uart_x, FALSE);
	}
	if (uart_x == UART_4) {
		hal_gpio_write(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_SET);
	} else if (uart_x == UART_5) {
		hal_gpio_write(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_SET);
	}
	hal_timer_enable_disable(TIMER6,1);
    for (uint16_t i = 0; i < req_length; i++) {
        uint32_t start_time = msTick; // Start timer
        while (usart_flag_get(uart, USART_TDBE_FLAG) == RESET) {
            if ((msTick - start_time) >= ms) { // 1 ms timeout
                hal_timer_enable_disable(TIMER6, 0);
//                printf("1.fail\r\n");
                return -1; // Indicate failure due to timeout
            }
        }
        usart_data_transmit(uart, req[i]);
        start_time = msTick; // Start timer
        while (usart_flag_get(uart, USART_TDC_FLAG) == RESET) {
            if ((msTick - start_time) >= ms) { // 1 ms timeout
                hal_timer_enable_disable(TIMER6, 0);
//                printf("2.fail\r\n");
                return -1; // Indicate failure due to timeout
            }
        }
    }
    hal_timer_enable_disable(TIMER6, 0);
	if (uart_x == UART_4 || uart_x == UART_5) {
		uart_interrupt_enable(uart_x, TRUE);
	}
	if (uart_x == UART_4) {
		hal_gpio_write(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_RESET);
	} else if (uart_x == UART_5) {
		hal_gpio_write(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_RESET);
	}
	return 0;
}

/************************************************************************************************
  * @brief  uart transmit function
  * @param1 uart_x - uart to transmit
  * @param2 *data_buf - buffer to transmit
  * @param3 data_len - length of the buffer
  * @param4 timeout in us
  * @retval 0-success -1 failure
  **********************************************************************************************/
int8_t uart_transmit_for_modbus_test(uart_type uart_x,const uint8_t *req,uint16_t req_length, uint16_t ms) {

    if (ms == 0) {
    	ms = 10;
    }
	usart_type *uart = uart_select(uart_x);
	if (uart_x == UART_4 || uart_x == UART_5) {
		uart4_rx_start = 1;
		uart5_rx_start = 1;
	    slave_id = req[0];
		uart_interrupt_enable(uart_x, FALSE);
	}
	if (uart_x == UART_4) {
		hal_gpio_write(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_SET);
	} else if (uart_x == UART_5) {
		hal_gpio_write(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_SET);
	}
	hal_timer_enable_disable(TIMER6,1);
    for (uint16_t i = 0; i < req_length; i++) {

        uint32_t start_time = msTick; // Start timer
        while (usart_flag_get(uart, USART_TDBE_FLAG) == RESET) {
            if ((msTick - start_time) >= ms) { // 1 ms timeout
                hal_timer_enable_disable(TIMER6, 0);
                return -1; // Indicate failure due to timeout
            }
        }
        usart_data_transmit(uart, req[i]);
        start_time = msTick; // Start timer
        while (usart_flag_get(uart, USART_TDC_FLAG) == RESET) {
            if ((msTick - start_time) >= ms) { // 1 ms timeout
                hal_timer_enable_disable(TIMER6, 0);
                return -1; // Indicate failure due to timeout
            }
        }
    }
    hal_timer_enable_disable(TIMER6, 0);
	if (uart_x == UART_4 || uart_x == UART_5) {
		uart_interrupt_enable(uart_x, TRUE);
	}
	if (uart_x == UART_4) {
		hal_gpio_write(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_RESET);
	} else if (uart_x == UART_5) {
		hal_gpio_write(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_RESET);
	}
	return 0;
}
/*********************************************************************************************
  * @brief  uart rx check
  * @param1 uart_x - uart buffer to clear
  * @retval none
  *******************************************************************************************/
uint8_t uart_receive_check(uint8_t uart_x, uint8_t length) {

	uint32_t available = 0;
	    switch (uart_x) {

	        case UART_4:
	            if (uart_4_head >= uart_4_tail) {
	            	available = uart_4_head - uart_4_tail;
	            } else {
	                available = (UART_BUF_LEN - (uart_4_tail - uart_4_buf)) +
	                            (uart_4_head - uart_4_buf);
	            }
	            return (length <= available) ? 1 : 0;

	        case UART_5:
	            if (uart_5_head >= uart_5_tail) {
	            	available = uart_5_head - uart_5_tail;
	            } else {
	                available = (UART_BUF_LEN - (uart_5_tail - uart_5_buf)) +
	                            (uart_5_head - uart_5_buf);
	            }
	            return (length <= available) ? 1 : 0;

	        default:
	            return 0;
	    }
}
/*********************************************************************************************
  * @brief  uart rx check
  * @param1 uart_x - uart buffer to clear
  * @retval none
  *******************************************************************************************/
uint8_t uart_receive_check_for_modbus_test(uint8_t uart_x) {

	uint8_t available = 0;
	    switch (uart_x) {

	        case UART_4:
	            if (uart_4_head >= uart_4_tail) {
	            	available = uart_4_head - uart_4_tail;
	            } else {
	                available = (UART_BUF_LEN - (uart_4_tail - uart_4_buf)) +
	                            (uart_4_head - uart_4_buf);
	            }
	            break;
//	            return available;

	        case UART_5:
	            if (uart_5_head >= uart_5_tail) {
	            	available = uart_5_head - uart_5_tail;
	            } else {
	                available = (UART_BUF_LEN - (uart_5_tail - uart_5_buf)) +
	                            (uart_5_head - uart_5_buf);
	            }
	            break;
//	            return available;
	    }
	    return available;
}
/************************************************************************************************
  * @brief  uart transmit function
  * @param1 uart_x - uart to transmit
  * @param2 *data_buf - buffer to transmit
  * @param3 data_len - length of the buffer
  * @retval None
  **********************************************************************************************/
void uart_receive(uart_type uart_x,uint8_t *data_buf,uint16_t data_len) {

	switch (uart_x) {
	    case UART_4 :
	    	if (data_len <= (uart_4_head - uart_4_tail)) {
		    	memcpy(data_buf,uart_4_tail,data_len);
		    	uart_4_tail = uart_4_tail+data_len;
	    	}
	    	 break;
	    case UART_5 :
	    	if (data_len <= (uart_5_head - uart_5_tail)) {
		    	memcpy(data_buf,uart_5_tail,data_len);
		    	uart_5_tail = uart_5_tail+data_len;
	    	}
	    	 break;
	    default:
	    	break;
	}

}
/************************************************************************************************
  * @brief  uart transmit function
  * @param1 uart_x - uart to transmit
  * @param2 *data_buf - buffer to transmit
  * @param3 data_len - length of the buffer
  * @retval None
  **********************************************************************************************/
void uart_rx_for_modbus_test(uart_type uart_x,uint8_t *data_buf,uint16_t data_len) {

	switch (uart_x) {
	    case UART_4 :
		     memcpy(data_buf, uart_4_tail, data_len);
	    	 break;
	    case UART_5 :
		     memcpy(data_buf, uart_5_tail, data_len);
	    	 break;
	    default:
	    	break;
	}

}
/*********************************************************************************************
  * @brief  uart clear buffer function
  * @param1 uart_x - uart buffer to clear
  * @retval none
  *******************************************************************************************/
void clear_uart_buffer(uart_type uart_x) {

	switch (uart_x) {
	    case UART_4 :
	    	memset(uart_4_buf, 0, UART_BUF_LEN);
	    	uart_4_head = uart_4_buf;
	    	uart_4_tail = uart_4_buf;
	    	uart_4_index = 0;
	    	 break;
	    case UART_5 :
	    	memset(uart_5_buf, 0, UART_BUF_LEN);
	    	uart_5_head = uart_5_buf;
	    	uart_5_tail = uart_5_buf;
	    	uart_5_index = 0;
	    	break;
	}
}
/*********************************************************************************************
  * @brief  uart close function
  * @param1 uart_x - uart to close
  * @retval none
  *******************************************************************************************/
void uart_enable_disable(uart_type uart_x,uint8_t status) {

	usart_type *uart = uart_select(uart_x);
	usart_enable(uart, status);
}
/************** (C) COPYRIGHT 2024 Calixto Systems Pvt Ltd *****END OF FILE****/
