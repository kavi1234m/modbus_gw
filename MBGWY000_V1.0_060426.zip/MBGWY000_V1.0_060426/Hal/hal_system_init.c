/**
  **************************
  * @file    hal_system_init.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 3
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "hal_system_init.h"

#include "at32f435_437_clock.h"
#include "at32f435_437_misc.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************
 * @brief       System Initialization function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void system_init(void) {

	system_clock_config();

	/* enable gpioa periph clock */
	crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);

	/* enable gpiob periph clock */
	crm_periph_clock_enable(CRM_GPIOB_PERIPH_CLOCK, TRUE);

	/* enable gpioc periph clock */
	crm_periph_clock_enable(CRM_GPIOC_PERIPH_CLOCK, TRUE);

	/* enable gpiod periph clock */
	crm_periph_clock_enable(CRM_GPIOD_PERIPH_CLOCK, TRUE);

	nvic_priority_group_config(NVIC_PRIORITY_GROUP_4);
}
/**********************************************************
  * @brief  init clkout function
  * @param  none
  * @retval none
  *********************************************************/
void clkout_init(void)
{
  gpio_init_type gpio_init_struct;

  /* enable periph clock */
  crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);

  /* set default parameter */
  gpio_default_para_init(&gpio_init_struct);
  /* config gpio mux function */
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE8, GPIO_MUX_0);
  /* config gpio */
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
  gpio_init_struct.gpio_pins = GPIO_PINS_8;
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init(GPIOA, &gpio_init_struct);

  /* config clkout1 output clock source */
  crm_clock_out1_set(CRM_CLKOUT1_PLL);
  /* config clkout1 div */
  crm_clkout_div_set(CRM_CLKOUT_INDEX_1, CRM_CLKOUT_DIV1_5, CRM_CLKOUT_DIV2_1);

}
/******************************************************************************
 * @brief       System reset function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void hal_system_reset(void) {

	nvic_system_reset();
}


 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
