/**
  **************************
  * @file    hal_exint.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 May 3
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "hal_exint.h"
#include "hal_gpio.h"
#include "at32f435_437_gpio.h"
/* Private typedef -----------------------------------------------------------*/
typedef void (*ext_int_fn_cb)();
ext_int_fn_cb   ext_int_callback_tmp;
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************************
 * @brief callback register function using the gpio callback function
 *
 * @param   (*callback_fun)  function pointer
 *
 * @retval  None
 *********************************************************************************************/
void hal_usr_butn_clbk_reg(void (*callback_fun))
{
    ext_int_callback_tmp = callback_fun;
}
/***********************************************************************************************************
  * @brief  exint0 interrupt handler
  * @param  none
  * @retval none
  **********************************************************************************************************/
void EXINT9_5_IRQHandler(void) {

	if(exint_interrupt_flag_get(EXINT_LINE_9) != RESET) {
		ext_int_callback_tmp();
		exint_flag_clear(EXINT_LINE_9);
	}
}
/*****************************************************************************************************************
  * @brief  exint init function.
  * @param  port_type - gpio port type
  * @param  pin_num - Pin number of the port
  * @retval none
  ****************************************************************************************************************/
void hal_exint_init(uint8_t port_type, uint8_t pin_num) {

	gpio_init_type gpio_init_struct;
	exint_init_type exint_init_struct;

	gpio_type *gpio_port = gpio_port_select(port_type);
	uint16_t gpio_pin_num = gpio_pin_num_select(pin_num);

	crm_periph_clock_enable(CRM_SCFG_PERIPH_CLOCK, TRUE);
	/* configure the EXINT9 */
	gpio_default_para_init(&gpio_init_struct);
	gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
	gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;
	gpio_init_struct.gpio_mode = GPIO_MODE_INPUT;
	gpio_init_struct.gpio_pins = gpio_pin_num;
	gpio_init_struct.gpio_pull = GPIO_PULL_DOWN;
	gpio_init(gpio_port, &gpio_init_struct);

	scfg_exint_line_config(port_type, pin_num);

	/*  chane this below part for other interrupt lines*/
	exint_default_para_init(&exint_init_struct);
	exint_init_struct.line_enable = TRUE;
	exint_init_struct.line_mode = EXINT_LINE_INTERRUPUT;
	exint_init_struct.line_select = EXINT_LINE_9;
	exint_init_struct.line_polarity = EXINT_TRIGGER_BOTH_EDGE;
	exint_init(&exint_init_struct);
	nvic_priority_group_config(NVIC_PRIORITY_GROUP_4);
	nvic_irq_enable(EXINT9_5_IRQn, 1, 0);
}
