/**
  **************************
  * @file    hal_tcp_client.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    26-03-2025
   * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "tcp_client.h"
#include "lwip/err.h"
#include "lwip/tcp.h"
#include "modbus_gw_cfg.h"
/* Private typedef -----------------------------------------------------------*/

typedef void (*cbk_fun)(uint8_t, uint8_t);
cbk_fun tcp_connection_cbk;

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/

#define TCP_DISCONNECT   1
#define TCP_CONNECTED    2

/* Private variables ---------------------------------------------------------*/

#define MODBUS_RESPONSE_BUF_SIZE      280
extern struct tcp_pcb *tcp_active_pcbs;
struct tcp_pcb *tcp_client_pcb = NULL;

uint8_t tcp_rcvd_data[280];
uint8_t *tcp_buffer_head = tcp_rcvd_data;
uint8_t *tcp_buffer_tail = tcp_rcvd_data;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************
 * @brief       tcp callback register function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void tcp_callback_register(void *callback) {

	tcp_connection_cbk = callback;
}
/**************************************************************************************
  * @brief  tcp client send data
  * @param  cpcb: the tcp_pcb that has sent the data
  * @param  buff: the packet buffer
  * @param  length: data size
  * @retval error value
  ***************************************************************************************/
err_t tcp_client_send_data(struct tcp_pcb *cpcb,unsigned char *buff,unsigned int length) {

	err_t err;
    uint16_t send_buf_len = tcp_sndbuf(tcp_client_pcb);
  	if(send_buf_len >= length) {
  		err = tcp_write(tcp_client_pcb,buff,length,TCP_WRITE_FLAG_COPY);  //send data //tcp_client_pcb tcp_sndbuf()
  	    if(err != ERR_OK) {
  	    	return err;
  	    }
  	    err = tcp_output(tcp_client_pcb);
  	    if(err != ERR_OK) {
  		  return err;
  	    }
//  	    PRINTF("TX status:%d\n",err);
  	    return err;
  	} else {
  		return -1;
  	}
}
/****************************************************************************************
  * @brief  check connection
  * @param  none
  * @retval the tcp_pcb which accepted the connection
  ***************************************************************************************/
struct tcp_pcb *check_tcp_connect(void) {
	struct tcp_pcb *cpcb = NULL;
    uint8_t connect_flag = 0;
    for(cpcb = tcp_active_pcbs;cpcb != NULL; cpcb = cpcb->next) {
    	if(cpcb -> state == ESTABLISHED) {
    		connect_flag = 1;
            break;
    	}
    }
    if(connect_flag == 0) {
    	cpcb = NULL;
    }
    return cpcb;
}

/****************************************************************************************
  * @brief  report connection is establish
  * @param  arg: user supplied argument
  * @param  pcb: the tcp_pcb which accepted the connection
  * @param  err: error value
  * @retval err_t: it will response error code
  ***************************************************************************************/
err_t tcp_connected(void *arg,struct tcp_pcb *pcb,err_t err) {

    if (err == ERR_OK)
    {
    	tcp_connection_cbk(1,1);
//    	PRINTF("TCP CONNECTED\n");
    }
	return ERR_OK;
}
/*************************************************************************************************
  * @brief  tcp buffer clear
  * @param  None
  * @retval none
  ************************************************************************************************/
void tcp_buffer_clear(void) {

//	tcp_rcvd_data[280] = 0;
	memset(tcp_rcvd_data, 0, sizeof(tcp_rcvd_data));
	tcp_buffer_head = tcp_rcvd_data;
	tcp_buffer_tail = tcp_rcvd_data;
}
/*************************************************************************************************
  * @brief  store_received_data
  * @param  1- buffer
  *         2- buffer length
  * @retval none
  ************************************************************************************************/
void tcp_data_receive(uint8_t *buffer, uint16_t buf_len) {

    memcpy(buffer, tcp_buffer_tail, buf_len);
	tcp_buffer_tail = tcp_buffer_tail + buf_len;
}

/*************************************************************************************************
  * @brief  store_tcp_data_to_buffer
  * @param  1- buffer
  *         2- buffer length
  * @retval none
  ************************************************************************************************/
void store_tcp_data_to_buffer(uint8_t *buffer,uint16_t buf_len) {

	if (buf_len < MODBUS_RESPONSE_BUF_SIZE) {
		memcpy(tcp_buffer_head, buffer, buf_len);
		tcp_buffer_head = tcp_buffer_head + buf_len;
	}
}
/****************************************************************************************
  * @brief  receiving callback funtion for TCP client
  * @param  arg: the user argument
  * @param  pcb: the tcp_pcb that has received the data
  * @param  p: the packet buffer
  * @param  err: the error value linked with the received data
  * @retval error value
  ***************************************************************************************/
err_t tcp_client_recv(void *arg, struct tcp_pcb *pcb,struct pbuf *p,err_t err) {

	if(p != NULL) {
//		PRINTF("RX LEN:%d\n",p->tot_len);
//	    for (uint16_t i = 0; i < p->tot_len; i++) {
//	    	PRINTF("%c",(uint8_t*)p->payload);
//	    }
//	    PRINTF("\n");
		store_tcp_data_to_buffer((uint8_t*)p->payload, p->tot_len);
		tcp_recved(pcb, p->tot_len);
	} else {
		PRINTF("ABORT");
	    tcp_close(tcp_client_pcb);
//	    return ERR_ABRT;
	}
    pbuf_free(p);
    err = ERR_OK;
    return err;
}
/******************************************************************************
 * @brief       error callback function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void tcp_client_err(void *arg, err_t err) {

	PRINTF("TCP connection closed due to error: %d\n", err);
}
/******************************************************************************
 * @brief       ack for tx data callback function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
err_t tcp_client_sent(void *arg, struct tcp_pcb *tpcb, u16_t len) {

	tcp_connection_cbk(2,1);
    return ERR_OK;
}
/****************************************************************************************
  * @brief  initialize tcp client
  * @param  local_port: local port
  * @retval none
  ***************************************************************************************/
int8_t tcp_client_init(uint16_t local_port) {


	err_t err;
    tcp_client_pcb = tcp_new();//tcp_pcb
    if (!tcp_client_pcb) {
    	PRINTF("NEW\n");
        return ERR_MEM;
    }
    PRINTF("PCB STATE : %d\n",tcp_client_pcb->state);
    err = tcp_bind(tcp_client_pcb, IP_ADDR_ANY, local_port);//local_port // TCP_MSL
    if(err != ERR_OK) {
    	PRINTF("BIND:%d\n",err);
        return err;
    }
    PRINTF("TCP CLIENT INIT\n");
    return ERR_OK;
}
/****************************************************************************************
  * @brief  connect tcp client
  * @param  remote_port: remote port
  * @param  server ip - network byte order
  * @param  remort port
  * @retval none
  ***************************************************************************************/
int8_t tcp_client_connect(uint32_t server_ip, uint16_t remote_port) {

	PRINTF("client ---ip:%x port :%u\n",server_ip,remote_port);
	ip_addr_t ipaddr;
	ipaddr.addr = server_ip;
	err_t err;
	PRINTF("CONNECT STATE : %d\n",tcp_client_pcb->state);
	err = tcp_connect(tcp_client_pcb, &ipaddr, remote_port, tcp_connected); // ERR_OK
	if(err != ERR_OK)
	{
		PRINTF("Couldn't make the connection\n");
		return ERR_CONN;
	}
	PRINTF("1.AFTER CONNECT STATE : %d\n",tcp_client_pcb->state);
	tcp_arg(tcp_client_pcb, NULL);
    tcp_recv(tcp_client_pcb, tcp_client_recv);
    tcp_err(tcp_client_pcb, tcp_client_err);
    tcp_sent(tcp_client_pcb, tcp_client_sent);
	return ERR_OK;
}

/******************************************************************************
 * @brief       function transmit data through tcp
 * @param[in]   none
 * @return      none
 ******************************************************************************/
int8_t tcp_data_transmit(unsigned char *buffer,unsigned char length) {

	err_t err;
	struct tcp_pcb *pcb = NULL;
	pcb = check_tcp_connect();
    if(pcb != NULL) {
//    	PRINTF("<TX LEN:%d>\n",length);
	    uint16_t send_buf_len = tcp_sndbuf(pcb);
	  	if(send_buf_len >= length) {
	  		if (tcp_write(pcb, buffer, length, 1) == ERR_OK) {
	  			if (tcp_output(pcb) == ERR_OK) {
	  				PRINTF("TX OK\n");
	  				return ERR_OK;
	  			}
	  		}
	  	}
	  	return -1;
    } else {
    	return -1;
    }
}
/******************************************************************************
 * @brief       Tcp rx length check function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t tcp_receive_len_check(uint16_t length) {

	if ((tcp_buffer_head - tcp_rcvd_data) >= length) {
         return 1;
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       function for closing tcp connection
 * @param[in]   none
 * @return      none
 ******************************************************************************/
int8_t tcp_connection_close(void) {

	err_t err;
	if (tcp_client_pcb != NULL) {
		tcp_buffer_clear();
		PRINTF("CLOSE STATE : %d\n",tcp_client_pcb->state);
	    tcp_arg(tcp_client_pcb, NULL);
	    tcp_sent(tcp_client_pcb, NULL);
	    tcp_recv(tcp_client_pcb, NULL);
	    tcp_err(tcp_client_pcb, NULL);
	    if (tcp_client_pcb->state != CLOSED) {
		    err = tcp_close(tcp_client_pcb);
			if (err != ERR_OK) {
				tcp_abort(tcp_client_pcb);
			}
			PRINTF("TCP CLOSE:%p,%d,%d\n", tcp_client_pcb, tcp_client_pcb->state, err); // tcp_slowtmr
	    }
		tcp_client_pcb = NULL;
	}
	return err;
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2024 Calixto Systems Pvt Ltd ***END OF FILE*/

