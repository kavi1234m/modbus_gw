/**
  **************************
  * @file    http_parser.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 26
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "http_parser.h"
#include <stdlib.h>
#include <string.h>
//#include "fsdata.c"
#include <stdio.h>
#include <ctype.h>
#include "lwip/inet.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define PARSE_DEV_BUF_SIZE	3072
#define USERNAME "admin"
#define PASSWORD "1234"

#define LOGIN_SUCCESS                   1
#define LOGIN_INVALID_CREDENTIALS       2
#define LOGIN_NO_PARAMS                 3
/* Private macro -------------------------------------------------------------*/
#define ERROR_PLACEHOLDER "<!--%LOGIN_ERROR%-->"
#define ERROR_SNIPPET \
    "<script>\n" \
    "  window.addEventListener(\"load\", function() {\n" \
    "    alert(\"User Name or Password is Incorrect!!!\");\n" \
    "  });\n" \
    "</script>\n"
/* Private variables ---------------------------------------------------------*/
//static char out_buf[30000];
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*********************************************************************************
 * @brief Convert 32-bit IP (e.g., 0xC0A80101) to string (e.g., "192.168.1.1")
 ***********************************************************************************/
void ip_to_string_tcp(uint32_t ip, char *out) {
    sprintf(out, "%u.%u.%u.%u",
            (ip & 0xFF) ,
            (ip >> 8) & 0xFF,
            (ip >> 16) & 0xFF,
            (ip >> 24)& 0xFF);
}
/******************************************************************************
 * @brief       Html close
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void html_close(struct html_file *file)
{
  (void)file;
}
/******************************************************************************
 * @brief       html bytes left
 * @param[in]   none
 * @return      none
 ******************************************************************************/
int html_bytes_left(struct html_file *file)
{
  return file->len - file->index;
}
/******************************************************************************
 * @brief       Verify login request function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t verify_login_request(const char *http_buf) {
    const char *user_key = "user=";
    const char *pass_key = "passw=";
    const char *param_start = strchr(http_buf, '?');
    if (!param_start) {
        return LOGIN_NO_PARAMS;
    }

    // 3. Parse user
    const char *user_pos = strstr(param_start, user_key);
    const char *pass_pos = strstr(param_start, pass_key);
    if (!user_pos || !pass_pos) {
        return LOGIN_INVALID_CREDENTIALS;
    }

    user_pos += strlen(user_key);
    const char *user_end = strchr(user_pos, '&');
    if (!user_end || user_end - user_pos >= 32) return LOGIN_INVALID_CREDENTIALS;
    char username[32] = {0};
    strncpy(username, user_pos, user_end - user_pos);

    pass_pos += strlen(pass_key);
    const char *pass_end = strpbrk(pass_pos, " \r\n");
    if (!pass_end || pass_end - pass_pos >= 32) return LOGIN_INVALID_CREDENTIALS;
    char password[32] = {0};
    strncpy(password, pass_pos, pass_end - pass_pos);

    // 4. Compare
    if (strcmp(username, USERNAME) == 0 && strcmp(password, PASSWORD) == 0) {
        return LOGIN_SUCCESS;
    }

    return LOGIN_INVALID_CREDENTIALS;
}
/******************************************************************************
 * @brief       Replace ERROR placeholder inside the existing HTML in output_buf
 * @param[in]   output_buf : Buffer that already contains the full HTML page
 * @return      Total length of updated HTML
 ******************************************************************************/
uint16_t build_login_error_page(uint8_t *output_buf)
{
    char *placeholder = strstr((char *)output_buf, ERROR_PLACEHOLDER);
    const char *insert = ERROR_SNIPPET;

    if (!placeholder)
    {
        // No placeholder found return existing length
        uint16_t len = strlen((char *)output_buf);
        return len;
    }

    // Calculate lengths
    size_t placeholder_len = strlen(ERROR_PLACEHOLDER);
    size_t insert_len = strlen(insert);
    size_t original_len = strlen((char *)output_buf);

    // Move the suffix part to make space or close the gap
    char *suffix_src  = placeholder + placeholder_len;
    char *suffix_dest = placeholder + insert_len;
    size_t suffix_len = strlen(suffix_src);

    // memmove handles overlapping memory correctly
    memmove(suffix_dest, suffix_src, suffix_len + 1);

    // Copy the error snippet in place of placeholder
    memcpy(placeholder, insert, insert_len);

    // New total length
    uint16_t total_len = original_len - placeholder_len + insert_len;

    return total_len;
}
/******************************************************************************
 * @brief      Replace the placeholder function
 * @param[in]   parity_str - Parity string ("None", "Odd", "Even")
 * @return      Parity value as uint8_t
 ******************************************************************************/
void replace_all(char *str, const char *placeholder, const char *replacement)
{
	size_t placeholder_len = strlen(placeholder);
	size_t replacement_len = strlen(replacement);
	char *pos = str;
	while ((pos = strstr(pos, placeholder)) != NULL)
	{
		size_t tail_len = strlen(pos + placeholder_len);

		// Shift the tail to make space (or close the gap)
		memmove(pos + replacement_len, pos + placeholder_len, tail_len + 1);
		// Copy replacement
		memcpy(pos, replacement, replacement_len);
		// Advance pointer
		pos += replacement_len;
	}
}
/******************************************************************************
 * @brief       prepare device info page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_device_info_page(char *output, const device_info_t *info) {
    // Perform all placeholder replacements
    replace_all(output, "%SYS_NAM%", info->system_name);
    replace_all(output, "%FWR_VER%", info->firmware_version);
    replace_all(output, "%DEV_HEL%", info->device_health);
    replace_all(output, "%MAC_ADS%", info->mac_address);
    replace_all(output, "%IPV4%", info->ipv4_address);
    replace_all(output, "%SUBNET%", info->subnet_mask);
    replace_all(output, "%GATEWAY%", info->default_gateway);
    replace_all(output, "%IMEI%", info->imei);
}
/******************************************************************************
 * @brief       Parse parity string to enum/value
 * @param[in]   parity_str - Parity string ("None", "Odd", "Even")
 * @return      Parity value as uint8_t
 ******************************************************************************/
uint8_t parse_parity(const char *parity_str) {
    if (strcmp(parity_str, "None") == 0) {
        return 'N'; // or your enum value for no parity
    } else if (strcmp(parity_str, "Odd") == 0) {
        return 'O'; // or your enum value for odd parity
    } else if (strcmp(parity_str, "Even") == 0) {
        return 'E'; // or your enum value for even parity
    }
    return 0; // Default to no parity
}


// URL decoding helper function
void url_decode(const char *src, char *dst, size_t dst_size) {
    char a, b;
    size_t i = 0, j = 0;

    while (src[i] && j < dst_size - 1) {
        if (src[i] == '%') {
            if (src[i+1] && src[i+2]) {
                a = src[i+1];
                b = src[i+2];

                if (isxdigit(a) && isxdigit(b)) {
                    if (a >= '0' && a <= '9') a -= '0';
                    else if (a >= 'a' && a <= 'f') a = a - 'a' + 10;
                    else if (a >= 'A' && a <= 'F') a = a - 'A' + 10;

                    if (b >= '0' && b <= '9') b -= '0';
                    else if (b >= 'a' && b <= 'f') b = b - 'a' + 10;
                    else if (b >= 'A' && b <= 'F') b = b - 'A' + 10;

                    dst[j++] = (a << 4) | b;
                    i += 3;
                    continue;
                }
            }
        } else if (src[i] == '+') {
            dst[j++] = ' ';
            i++;
            continue;
        }
        dst[j++] = src[i++];
    }
    dst[j] = '\0';
}

/******************************************************************************
 * @brief       Network config parsing function (safe for MCU)
 * @param[in]   query_string : full HTTP GET query string
 * @param[out]  nwk_cfg      : pointer to network config struct
 * @return      none
 ******************************************************************************/
void parse_gw_network_config(const char *query_string, network_config_t *nwk_cfg) {
    if (!query_string || !nwk_cfg) return;

    char temp[512];
    const char *q = strchr(query_string, '?');

    if (q) q++; else q = query_string;

    size_t len = 0;
    while (q[len] && q[len] != ' ' && len < sizeof(temp) - 1) {
        temp[len] = q[len];
        len++;
    }
    temp[len] = '\0';

    const char *p = temp;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = eq - p;
        if (key_len == 0) break;

        char key[32];
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        char value[128];
        if (val_len >= sizeof(value)) val_len = sizeof(value) - 1;
        memcpy(value, val_start, val_len);
        value[val_len] = '\0';

        if (strcmp(key, "ipv4-address") == 0) {
            nwk_cfg->ipv4_address = inet_addr(value);
        } else if (strcmp(key, "subnet-mask") == 0) {
            nwk_cfg->subnet_mask = inet_addr(value);
        } else if (strcmp(key, "default-gateway") == 0) {
            nwk_cfg->default_gateway = inet_addr(value);
        } else if (strcmp(key, "apn") == 0) {
            char decoded_val[256];
            url_decode(value, decoded_val, sizeof(decoded_val));
//        	url_decode(src, dst, dst_size);
            strncpy(nwk_cfg->apn, decoded_val, sizeof(nwk_cfg->apn));
        } else if (strcmp(key, "username") == 0) {
            char decoded_val[256];
            url_decode(value, decoded_val, sizeof(decoded_val));
            strncpy(nwk_cfg->username, decoded_val, sizeof(nwk_cfg->username));
        } else if (strcmp(key, "password") == 0) {
            char decoded_val[256];
            url_decode(value, decoded_val, sizeof(decoded_val));
            strncpy(nwk_cfg->password, decoded_val, sizeof(nwk_cfg->password));
        }

        if (!amp) break;
        p = amp + 1;
    }
    ip4_addr_t ip, mask, gw;

    ip.addr   = nwk_cfg->ipv4_address;
    mask.addr = nwk_cfg->subnet_mask;
    gw.addr   = nwk_cfg->default_gateway;
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
    printf("\n---- Parsed Network Config ----\n");
    printf("IPv4 Address   : %s\n", ip4addr_ntoa(&ip));
    printf("Subnet Mask    : %s\n", ip4addr_ntoa(&mask));
    printf("Default Gateway: %s\n", ip4addr_ntoa(&gw));
    printf("APN            : %s\n", nwk_cfg->apn);
    printf("Username       : %s\n", nwk_cfg->username);
    printf("Password       : %s\n", nwk_cfg->password);
    printf("--------------------------------\n");
#endif
}

/******************************************************************************
 * @brief       Parity check function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
char parse_parity_char(const char *str) {
    if (strcmp(str, "None") == 0) return 'N';
    else if (strcmp(str, "Odd") == 0) return 'O';
    else if (strcmp(str, "Even") == 0) return 'E';
    return 'N';  // Invalid
}

/******************************************************************************
 * @brief       Serial config parsing function
 * @param[in]   query_string - The query string from POST request
 * @param[out]  out_cfg - Pointer to serial_config_t structure to fill
 * @return      none
 ******************************************************************************/
void parse_gw_serial_config(const char *query_string, char *buff, serial_config_t *out_cfg) {
    if (!query_string || !buff || !out_cfg) return;

    const char *params = strchr(query_string, '?');
    if (params) params++; else params = query_string;

    // Clear buffer
    memset(buff, 0, 150);

    // Find end of query (space or null)
    const char *end = strchr(params, ' ');
    size_t copy_len = end ? (size_t)(end - params) : strlen(params);
    if (copy_len > 149) copy_len = 149;

    strncpy(buff, params, copy_len);
    buff[copy_len] = '\0';

    // ---------------- Manual parsing ----------------
    const char *p = buff;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = eq - p;
        char key[64];
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        char val[64];
        if (val_len >= sizeof(val)) val_len = sizeof(val) - 1;
        memcpy(val, val_start, val_len);
        val[val_len] = '\0';

        // ---------------- Store parameters ----------------
        if (strcmp(key, "baud-rate-1") == 0) {
            out_cfg->channel1.baud_rate = (uint32_t)atoi(val);
        } else if (strcmp(key, "data-bits-1") == 0) {
            out_cfg->channel1.data_bits = (uint8_t)atoi(val);
        } else if (strcmp(key, "parity-1") == 0) {
            out_cfg->channel1.parity = parse_parity(val);
        } else if (strcmp(key, "stop-bits-1") == 0) {
            out_cfg->channel1.stop_bits = (uint8_t)atoi(val);
        } else if (strcmp(key, "baud-rate-2") == 0) {
            out_cfg->channel2.baud_rate = (uint32_t)atoi(val);
        } else if (strcmp(key, "data-bits-2") == 0) {
            out_cfg->channel2.data_bits = (uint8_t)atoi(val);
        } else if (strcmp(key, "parity-2") == 0) {
            out_cfg->channel2.parity = parse_parity(val);
        } else if (strcmp(key, "stop-bits-2") == 0) {
            out_cfg->channel2.stop_bits = (uint8_t)atoi(val);
        }

        if (!amp) break;
        p = amp + 1;
    }
//    PRINTF("\n=== Parsed Serial Configuration ===\n");
//    PRINTF("Channel 1:\n");
//    PRINTF("  Baud Rate : %lu\n", (unsigned long)out_cfg->channel1.baud_rate);
//    PRINTF("  Data Bits : %u\n", out_cfg->channel1.data_bits);
//    PRINTF("  Parity    : %c\n", out_cfg->channel1.parity);
//    PRINTF("  Stop Bits : %u\n", out_cfg->channel1.stop_bits);
//
//    PRINTF("Channel 2:\n");
//    PRINTF("  Baud Rate : %lu\n", (unsigned long)out_cfg->channel2.baud_rate);
//    PRINTF("  Data Bits : %u\n", out_cfg->channel2.data_bits);
//    PRINTF("  Parity    : %c\n", out_cfg->channel2.parity);
//    PRINTF("  Stop Bits : %u\n", out_cfg->channel2.stop_bits);
//    PRINTF("===================================\n");
}


void parse_cloud_config(const char *query_string, cloud_config_t *cloud_cfg) {
    if (!query_string || !cloud_cfg) return;

    memset(cloud_cfg, 0, sizeof(cloud_config_t));

    // Extract query string part
    const char *q = strchr(query_string, '?');
    if (q) q++; else q = query_string;

    char temp[1024];
    size_t len = 0;
    while (q[len] && q[len] != ' ' && q[len] != '\n' && q[len] != '\r' && len < sizeof(temp) - 1) {
        temp[len] = q[len];
        len++;
    }
    temp[len] = '\0';

    // Parse key=value manually
    const char *p = temp;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = eq - p;
        char key[128];
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        char val[256];
        if (val_len >= sizeof(val)) val_len = sizeof(val) - 1;
        memcpy(val, val_start, val_len);
        val[val_len] = '\0';

        // URL decode
        char decoded_val[256];
        url_decode(val, decoded_val, sizeof(decoded_val));

        // ---------------- Store parameters ----------------
        if (strcmp(key, "push-time") == 0) {
            cloud_cfg->publish_interval_sec = (uint16_t)atoi(decoded_val);
        } else if (strcmp(key, "config-type") == 0) {
            if (strcmp(decoded_val, "tcp") == 0) cloud_cfg->mode = CLOUD_MODE_TCP;
            else if (strcmp(decoded_val, "http") == 0) cloud_cfg->mode = CLOUD_MODE_HTTP;
            else if (strcmp(decoded_val, "mqtt") == 0) cloud_cfg->mode = CLOUD_MODE_MQTT;
        } else if (strcmp(key, "tcp-url") == 0) {
            strncpy(cloud_cfg->cfg.tcp.url, decoded_val, SIZEOF_URL);
//            cloud_cfg->cfg.tcp.url[SIZEOF_URL-1] = '\0';
        } else if (strcmp(key, "tcp-port") == 0) {
            cloud_cfg->cfg.tcp.port = (uint16_t)atoi(decoded_val);
        } else if (strcmp(key, "http-url") == 0) {
            strncpy(cloud_cfg->cfg.http.url, decoded_val, SIZEOF_URL);
//            cloud_cfg->cfg.http.url[SIZEOF_URL-1] = '\0';
        } else if (strcmp(key, "http-method") == 0) {
            if (strcmp(decoded_val, "GET") == 0) cloud_cfg->cfg.http.method = HTTP_METHOD_GET;
            else if (strcmp(decoded_val, "POST") == 0) cloud_cfg->cfg.http.method = HTTP_METHOD_POST;
        } else if (strcmp(key, "mqtt-url") == 0) {
            strncpy(cloud_cfg->cfg.mqtt.url, decoded_val, SIZEOF_URL);
//            cloud_cfg->cfg.mqtt.url[SIZEOF_URL-1] = '\0';
        } else if (strcmp(key, "mqtt-port") == 0) {
            cloud_cfg->cfg.mqtt.port = (uint16_t)atoi(decoded_val);
        } else if (strcmp(key, "mqtt-qos") == 0) {
            cloud_cfg->cfg.mqtt.qos = (uint8_t)atoi(decoded_val);
        } else if (strcmp(key, "mqtt-topic") == 0) {
            strncpy(cloud_cfg->cfg.mqtt.pub_topic, decoded_val, SIZEOF_TOPIC);
//            cloud_cfg->cfg.mqtt.topic[SIZEOF_TOPIC-1] = '\0';
        } else if (strcmp(key, "cfg-req-topic") == 0) {
            strncpy(cloud_cfg->cfg.mqtt.cfg_req_topic, decoded_val, SIZEOF_TOPIC);
        }else if (strcmp(key, "cfg-rsp-topic") == 0) {
            strncpy(cloud_cfg->cfg.mqtt.cfg_rsp_topic, decoded_val, SIZEOF_TOPIC);
        }else if (strcmp(key, "mqtt-client-id") == 0) {
            strncpy(cloud_cfg->cfg.mqtt.client_id, decoded_val, SIZEOF_CLIENTID);
//            cloud_cfg->cfg.mqtt.client_id[SIZEOF_CLIENTID-1] = '\0';
        } else if (strcmp(key, "mqtt-username") == 0) {
            strncpy(cloud_cfg->cfg.mqtt.username, decoded_val, SIZEOF_USERNAME);
//            cloud_cfg->cfg.mqtt.username[SIZEOF_USERNAME-1] = '\0';
        } else if (strcmp(key, "mqtt-password") == 0) {
            strncpy(cloud_cfg->cfg.mqtt.password, decoded_val, SIZEOF_PASSWORD);
//            cloud_cfg->cfg.mqtt.password[SIZEOF_PASSWORD-1] = '\0';
        }

        if (!amp) break;
        p = amp + 1;
    }
}

/******************************************************************************
 * @brief       Polling Interval parsing function (safe for MCU)
 * @param[in]   query_string : full HTTP GET query string
 * @param[out]  mb_cfg_poll  : pointer to modbus config struct
 * @return      none
 ******************************************************************************/
void parse_pollinterval(const char *query_string, modbus_cfg_t *mb_cfg_poll) {
    if (!query_string || !mb_cfg_poll) return;

    char temp[56];
    const char *q = strchr(query_string, '?');

    if (q) q++; else q = query_string;

    size_t len = 0;
    while (q[len] && q[len] != ' ' && len < sizeof(temp) - 1) {
        temp[len] = q[len];
        len++;
    }
    temp[len] = '\0';

    const char *p = temp;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = eq - p;
        if (key_len == 0) break;

        char key[32];
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        char value[32];
        if (val_len >= sizeof(value)) val_len = sizeof(value) - 1;
        memcpy(value, val_start, val_len);
        value[val_len] = '\0';

        // Step 4: Store value in struct
        if (strcmp(key, "pollInterval") == 0) {
            mb_cfg_poll->data_poll_interval = (uint32_t)atoi(value);
        }

        if (!amp) break;
        p = amp + 1;
    }
}

void replace_row_placeholders(char *buf, rtu_data_mapping_t *mapping) {
    char placeholder[32];
    char temp[32];

    for (uint8_t row_num = 1; row_num <= MAX_DEVICE_COUNT; row_num++) {
    	rtu_device_t *dev = NULL;
		if (row_num <= mapping->num_devices) {
			dev = &mapping->devices[row_num - 1];
		}

		sprintf(placeholder, "%%ROW%d_CLICKED%%", row_num);
		if (dev) sprintf(temp, "%s", "checked"); else strcpy(temp, "");
		replace_all(buf, placeholder, temp);

		// Slave ID
		sprintf(placeholder, "%%ROW%d_SLAVE%%", row_num);
		if (dev) sprintf(temp, "%u", dev->slave_id); else strcpy(temp, "");
		replace_all(buf, placeholder, temp);

		// Device Type
		sprintf(placeholder, "%%ROW%d_TYPE%%", row_num);
		if (dev) {
			uint8_t len = sizeof(dev->device_type);
			memcpy(temp, dev->device_type, len);
			temp[len] = '\0';

		}else strcpy(temp, "");

		replace_all(buf, placeholder, temp);

		// Device Name
		sprintf(placeholder, "%%ROW%d_NAME%%", row_num);
		if (dev) {
			uint8_t len = sizeof(dev->device_name);
			memcpy(temp, dev->device_name, len);
			temp[len] = '\0';
		}else strcpy(temp, "");
		replace_all(buf, placeholder, temp);

		// Timeout
		sprintf(placeholder, "%%ROW%d_TIMEOUT%%", row_num);
		if (dev) sprintf(temp, "%u", dev->response_timeout_ms); else strcpy(temp, "");
		replace_all(buf, placeholder, temp);
    }
}
/**
 * @brief Replace placeholders in the HTML page with actual TCP device data
 */
void replace_tcp_placeholders(char *html, const tcp_data_mapping_t *tcp_data) {
    char placeholder[64];
    char value[64];

    for (int i = 0; i < MAX_DEVICE_COUNT; i++) {
//        PRINTF("device no.:%d\r\n", i+1);
        snprintf(placeholder, sizeof(placeholder), "%%TCP_ROW%d_CHECKED%%", i + 1);
        replace_all(html, placeholder, (i < tcp_data->num_devices) ? "checked" : "");

        snprintf(placeholder, sizeof(placeholder), "%%TCP_ROW%d_SLAVE%%", i + 1);
        if (i < tcp_data->num_devices) {
            sprintf(value, "%u", tcp_data->devices[i].slave_id);
            replace_all(html, placeholder, value);
        } else {
            replace_all(html, placeholder, "");
        }

        snprintf(placeholder, sizeof(placeholder), "%%TCP_ROW%d_IP%%", i + 1);
        if (i < tcp_data->num_devices) {
        	ip_to_string_tcp(tcp_data->devices[i].slave_ip, value);
            replace_all(html, placeholder, value);
        } else {
            replace_all(html, placeholder, "");
        }

        snprintf(placeholder, sizeof(placeholder), "%%TCP_ROW%d_PORT%%", i + 1);
        if (i < tcp_data->num_devices) {
            sprintf(value, "%u", tcp_data->devices[i].slave_port);
            replace_all(html, placeholder, value);
        } else {
            replace_all(html, placeholder, "");
        }

        snprintf(placeholder, sizeof(placeholder), "%%TCP_ROW%d_TYPE%%", i + 1);
        if (i < tcp_data->num_devices) {
            uint8_t len = sizeof(tcp_data->devices[i].device_type);
            memcpy(value, tcp_data->devices[i].device_type, len);
            value[len] = '\0';
            replace_all(html, placeholder, value);
        } else {
            replace_all(html, placeholder, "");
        }

        snprintf(placeholder, sizeof(placeholder), "%%TCP_ROW%d_NAME%%", i + 1);
        if (i < tcp_data->num_devices) {

            uint8_t len = sizeof(tcp_data->devices[i].device_name);
            memcpy(value, tcp_data->devices[i].device_name, len);
            value[len] = '\0';

            replace_all(html, placeholder, value);
        } else {
            replace_all(html, placeholder, "");
        }

        snprintf(placeholder, sizeof(placeholder), "%%TCP_ROW%d_TIMEOUT%%", i + 1);
        if (i < tcp_data->num_devices) {
            sprintf(value, "%u", tcp_data->devices[i].response_timeout_ms);
            replace_all(html, placeholder, value);
        } else {
            replace_all(html, placeholder, "");
        }
    }
}
/* Main placeholder replacement function */

void replace_reg_cfg_placeholders(char *send_html_buf, uint8_t num_devices, const data_point_t *pt)
{
    char placeholder[64];
    char value[64];
    char safe_key[SIZEOF_JSON_KEY+1];

//    PRINTF("1.ROW CHECK:%u\n",num_devices);
    for (int i = 0; i < num_devices; i++) {
        int row = i + 1;
//        PRINTF("ROW CHECK\n");
        /* %ROWx_CHECKED% */
        sprintf(placeholder, "%%ROW%d_CHECKED%%", row);
        replace_all(send_html_buf, placeholder, "checked" );

        /* Register type selection */
        sprintf(placeholder, "%%ROW%d_TYPE_HOLDING%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->reg_type == REG_HOLDING_REGISTER)? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_COIL%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->reg_type == REG_COIL) ? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_DISCRETE%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->reg_type == REG_DISCRETE_INPUT) ? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_INPUT%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->reg_type == REG_INPUT_REGISTER) ? "selected" : "");

        /* Start address */
        sprintf(placeholder, "%%ROW%d_START_ADDR%%", row);
        sprintf(value, "%u", (pt+i)->start_address);
        replace_all(send_html_buf, placeholder, value);

        /* Register count */
//        sprintf(placeholder, "%%ROW%d_COUNT%%", row);
//        sprintf(value, "%u", (pt+i)->reg_count);
//        replace_all(send_html_buf, placeholder, value);

        /* Data type selection */
        sprintf(placeholder, "%%ROW%d_TYPE_UINT16%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->data_type == DT_UINT16)  ? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_UINT32%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->data_type == DT_UINT32)  ? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_INT16%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->data_type == DT_INT16)  ? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_INT32%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->data_type == DT_INT32)  ? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_FLOAT%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->data_type == DT_FLOAT)  ? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_DOUBLE%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->data_type == DT_DOUBLE)  ? "selected" : "");

        sprintf(placeholder, "%%ROW%d_TYPE_BOOL%%", row);
        replace_all(send_html_buf, placeholder, ((pt+i)->data_type == DT_BOOL)  ? "selected" : "");

        /* Scaling Factor */
        sprintf(placeholder, "%%ROW%d_SCALE%%", row);
        sprintf(value, "%.6f", (pt+i)->scaling_factor);
        char *p = value + strlen(value) - 1;
        while (*p == '0') *p-- = '\0';
        if (*p == '.') *p = '\0';
        replace_all(send_html_buf, placeholder, value);

        /* JSON key */
        sprintf(placeholder, "%%ROW%d_JSON_KEY%%", row);

        uint8_t len = sizeof((pt+i)->json_key);
        memcpy(safe_key, (pt+i)->json_key, len);
        safe_key[len] = '\0';

        replace_all(send_html_buf, placeholder, safe_key);

    }

    for (int i = num_devices; i < MAX_DATA_POINT; i++) {
        int row = i + 1;

        sprintf(placeholder, "%%ROW%d_CHECKED%%", row);
        replace_all(send_html_buf, placeholder, "");

        snprintf(placeholder, sizeof(placeholder), "%%ROW%d_START_ADDR%%", row);
        replace_all(send_html_buf, placeholder, "");

        sprintf(placeholder, "%%ROW%d_COUNT%%", row);
        replace_all(send_html_buf, placeholder, "");

        sprintf(placeholder, "%%ROW%d_SCALE%%", row);
        replace_all(send_html_buf, placeholder, "");

        sprintf(placeholder, "%%ROW%d_JSON_KEY%%", row);
        replace_all(send_html_buf, placeholder, "");

        sprintf(placeholder, "%%ROW%d_TYPE_HOLDING%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_COIL%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_DISCRETE%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_INPUT%%", row);
        replace_all(send_html_buf, placeholder, "");

        sprintf(placeholder, "%%ROW%d_TYPE_UINT16%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_UINT32%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_INT16%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_INT32%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_FLOAT%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_DOUBLE%%", row);
        replace_all(send_html_buf, placeholder, "");
        sprintf(placeholder, "%%ROW%d_TYPE_BOOL%%", row);
        replace_all(send_html_buf, placeholder, "");
    }
}
/******************************************************************************
 * @brief       prepare cloud info page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_cloud_info_page(char *output, const cloud_config_t *info) {

    char temp[SIZEOF_URL+1];
    uint8_t len = 0;

    sprintf(temp, "%u", info->publish_interval_sec);

    replace_all(output, "%PUSH_TIME%", temp);
    if(info->mode == CLOUD_MODE_TCP || info->mode == 0){
        replace_all(output, "%TCP_CHECKED%", "checked");
        replace_all(output, "%MQTT_CHECKED%", "");
        replace_all(output, "%HTTP_CHECKED%", "");

        len = sizeof(info->cfg.tcp.url);
        memcpy(temp, info->cfg.tcp.url, len);
        temp[len] = '\0';
        replace_all(output, "%TCP_URL%",temp);

        sprintf(temp, "%u", info->cfg.tcp.port);
        replace_all(output, "%TCP_PORT%", temp);

        replace_all(output, "%HTTP_URL%", "");
        replace_all(output, "%HTTP_METHOD_PUT%", "");
        replace_all(output, "%HTTP_METHOD_POST%", "");

        replace_all(output, "%MQTT_URL%", "");
        replace_all(output, "%MQTT_PORT%", "");
        replace_all(output, "%MQTT_TOPIC%", "");
        replace_all(output, "%CFG_REQ_TOPIC%", "");
        replace_all(output, "%CFG_RSP_TOPIC%", "");
        replace_all(output, "%MQTT_CLIENT_ID%", "");
        replace_all(output, "%MQTT_QOS_0%", "");
        replace_all(output, "%MQTT_QOS_1%", "");
        replace_all(output, "%MQTT_QOS_2%", "");
        replace_all(output, "%MQTT_USERNAME%", "");
        replace_all(output, "%MQTT_PASSWORD%", "");


    }else if(info->mode == CLOUD_MODE_HTTP){
        replace_all(output, "%HTTP_CHECKED%", "checked");
        replace_all(output, "%MQTT_CHECKED%", "");
        replace_all(output, "%TCP_CHECKED%", "");

        len = sizeof(info->cfg.http.url);
        memcpy(temp,info->cfg.http.url, len);
        temp[len] = '\0';

        replace_all(output, "%HTTP_URL%",temp);

        strcpy(temp, "selected");
        if(info->cfg.http.method == HTTP_METHOD_GET){
            replace_all(output, "%HTTP_METHOD_PUT%", temp);
            replace_all(output, "%HTTP_METHOD_POST%", "");
        }else{
            replace_all(output, "%HTTP_METHOD_POST%", temp);
            replace_all(output, "%HTTP_METHOD_PUT%", "");
        }

        replace_all(output, "%TCP_URL%","");
        replace_all(output, "%TCP_PORT%", "");

        replace_all(output, "%MQTT_URL%", "");
        replace_all(output, "%MQTT_PORT%", "");
        replace_all(output, "%MQTT_TOPIC%", "");
        replace_all(output, "%CFG_REQ_TOPIC%", "");
        replace_all(output, "%CFG_RSP_TOPIC%", "");
        replace_all(output, "%MQTT_CLIENT_ID%", "");
        replace_all(output, "%MQTT_QOS_0%", "");
        replace_all(output, "%MQTT_QOS_1%", "");
        replace_all(output, "%MQTT_QOS_2%", "");
        replace_all(output, "%MQTT_USERNAME%", "");
        replace_all(output, "%MQTT_PASSWORD%", "");

    }else if(info->mode == CLOUD_MODE_MQTT){
        replace_all(output, "%MQTT_CHECKED%", "checked");
        replace_all(output, "%HTTP_CHECKED%", "");
        replace_all(output, "%TCP_CHECKED%", "");

        len = sizeof(info->cfg.mqtt.url);
        memcpy(temp, info->cfg.mqtt.url, len);
        temp[len] = '\0';

        replace_all(output, "%MQTT_URL%", temp);

        sprintf(temp, "%u",  info->cfg.mqtt.port);
        replace_all(output, "%MQTT_PORT%", temp);
        strcpy(temp, "selected");
        if(info->cfg.mqtt.qos == 0){
            replace_all(output, "%MQTT_QOS_0%", temp);
            replace_all(output, "%MQTT_QOS_1%", "");
            replace_all(output, "%MQTT_QOS_2%", "");
        }else if(info->cfg.mqtt.qos == 1){
            replace_all(output, "%MQTT_QOS_1%", temp);
            replace_all(output, "%MQTT_QOS_0%", "");
            replace_all(output, "%MQTT_QOS_2%", "");
        }else if(info->cfg.mqtt.qos == 2){
            replace_all(output, "%MQTT_QOS_2%", temp);
            replace_all(output, "%MQTT_QOS_1%", "");
            replace_all(output, "%MQTT_QOS_0%", "");
        }
        len = sizeof(info->cfg.mqtt.pub_topic);
        memcpy(temp, info->cfg.mqtt.pub_topic, len);
        temp[len] = '\0';
        replace_all(output, "%MQTT_TOPIC%",temp);

        len = sizeof(info->cfg.mqtt.cfg_req_topic);
        memcpy(temp, info->cfg.mqtt.cfg_req_topic, len);
        temp[len] = '\0';
        replace_all(output, "%CFG_REQ_TOPIC%",temp);

        len = sizeof(info->cfg.mqtt.cfg_rsp_topic);
        memcpy(temp, info->cfg.mqtt.cfg_rsp_topic, len);
        temp[len] = '\0';
        replace_all(output, "%CFG_RSP_TOPIC%",temp);

        len = sizeof(info->cfg.mqtt.client_id);
        memcpy(temp,info->cfg.mqtt.client_id, len);
        temp[len] = '\0';
        replace_all(output, "%MQTT_CLIENT_ID%", temp);
        len = sizeof(info->cfg.mqtt.username);
        memcpy(temp,info->cfg.mqtt.username, len);
        temp[len] = '\0';
        replace_all(output, "%MQTT_USERNAME%", temp);
        len = sizeof(info->cfg.mqtt.password);
        memcpy(temp,info->cfg.mqtt.password, len);
        temp[len] = '\0';
        replace_all(output, "%MQTT_PASSWORD%", temp);

        replace_all(output, "%TCP_URL%","");
        replace_all(output, "%TCP_PORT%", "");

        replace_all(output, "%HTTP_URL%", "");
        replace_all(output, "%HTTP_METHOD_PUT%", "");
        replace_all(output, "%HTTP_METHOD_POST%", "");


    }
}

/******************************************************************************
 * @brief       prepare serial cfg page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_serial_info_page(char *output, const serial_config_t *info) {

    char tmp[32];
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 2400) ? "selected" : "");
    replace_all(output, "%BAUD1_2400%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 4800) ? "selected" : "");
    replace_all(output, "%BAUD1_4800%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 9600) ? "selected" : "");
    replace_all(output, "%BAUD1_9600%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 19200) ? "selected" : "");
    replace_all(output, "%BAUD1_19200%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 38400) ? "selected" : "");
    replace_all(output, "%BAUD1_38400%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 57600) ? "selected" : "");
    replace_all(output, "%BAUD1_57600%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 115200) ? "selected" : "");
    replace_all(output, "%BAUD1_115200%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 128000) ? "selected" : "");
    replace_all(output, "%BAUD1_128000%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.baud_rate == 256000) ? "selected" : "");
    replace_all(output, "%BAUD1_256000%", tmp);

    snprintf(tmp, sizeof(tmp), (info->channel1.data_bits == 8) ? "selected" : "");
    replace_all(output, "%DB1_8%", tmp);

    snprintf(tmp, sizeof(tmp), (info->channel1.parity == 'N') ? "selected" : "");
    replace_all(output, "%PB1_None%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.parity == 'O') ? "selected" : "");
    replace_all(output, "%PB1_Odd%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.parity == 'E') ? "selected" : "");
    replace_all(output, "%PB1_Even%", tmp);

    snprintf(tmp, sizeof(tmp), (info->channel1.stop_bits == 1) ? "selected" : "");
    replace_all(output, "%SB1_1%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel1.stop_bits == 2) ? "selected" : "");
    replace_all(output, "%SB1_2%", tmp);


    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 2400) ? "selected" : "");
    replace_all(output, "%BAUD2_2400%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 4800) ? "selected" : "");
    replace_all(output, "%BAUD2_4800%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 9600) ? "selected" : "");
    replace_all(output, "%BAUD2_9600%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 19200) ? "selected" : "");
    replace_all(output, "%BAUD2_19200%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 38400) ? "selected" : "");
    replace_all(output, "%BAUD2_38400%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 57600) ? "selected" : "");
    replace_all(output, "%BAUD2_57600%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 115200) ? "selected" : "");
    replace_all(output, "%BAUD2_115200%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 128000) ? "selected" : "");
    replace_all(output, "%BAUD2_128000%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.baud_rate == 256000) ? "selected" : "");
    replace_all(output, "%BAUD2_256000%", tmp);

    snprintf(tmp, sizeof(tmp), (info->channel2.data_bits == 8) ? "selected" : "");
    replace_all(output, "%DB2_8%", tmp);


    snprintf(tmp, sizeof(tmp), (info->channel2.parity == 'N') ? "selected" : "");
    replace_all(output, "%PB2_None%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.parity == 'O') ? "selected" : "");
    replace_all(output, "%PB2_Odd%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.parity == 'E') ? "selected" : "");
    replace_all(output, "%PB2_Even%", tmp);


    snprintf(tmp, sizeof(tmp), (info->channel2.stop_bits == 1) ? "selected" : "");
    replace_all(output, "%SB2_1%", tmp);
    snprintf(tmp, sizeof(tmp), (info->channel2.stop_bits == 2) ? "selected" : "");
    replace_all(output, "%SB2_2%", tmp);

}

/******************************************************************************
 * @brief       prepare network cfg page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_nwk_info_page(char *output, const network_config_t *info) {

    char ip_str[16], def_gw_str[16], sm_str[16] , temp[SIZEOF_APN+1];

    ip4addr_ntoa_r((const ip4_addr_t *)&info->ipv4_address, ip_str, sizeof(ip_str));
    ip4addr_ntoa_r((const ip4_addr_t *)&info->default_gateway,def_gw_str, sizeof(def_gw_str));
    ip4addr_ntoa_r((const ip4_addr_t *)&info->subnet_mask, sm_str, sizeof(sm_str));

    // Perform placeholder replacements
    replace_all(output, "%IP_ADDR%", ip_str);
    replace_all(output, "%DEF_GW_ADDR%", def_gw_str);
    replace_all(output, "%SM_ADDR%", sm_str);

    uint8_t len = sizeof(info->apn);
    memcpy(temp, info->apn, len);
    temp[len] = '\0';
	replace_all(output, "%GSM_APN%", temp);
	len = sizeof(info->username);
	memcpy(temp, info->username, len);
	temp[len] = '\0';
	replace_all(output, "%GSM_USERNAME%",temp);
	len = sizeof(info->password);
	memcpy(temp,info->password, len);
	temp[len] = '\0';
	replace_all(output, "%GSM_PASSWORD%", temp);

}

/******************************************************************************
 * @brief       prepare data mapping page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_data_mapping_page(char *output, const modbus_cfg_t *info) {
    char value[8];
    snprintf(value, sizeof(value), "%u", info->data_poll_interval);
    replace_all(output, "%Poll_Interval%", value);
}


uint8_t count_devices_by_slave_id(modbus_cfg_t *mapping, uint8_t dev) {
    uint8_t device_count = 0;

    for (int i = 0; i < MAX_DEVICE_COUNT; i++) {

        switch(dev){
        case 1: if (mapping->rtu_port_1.devices[i].slave_id > 0) device_count++; break;
        case 2: if (mapping->rtu_port_2.devices[i].slave_id > 0) device_count++; break;
        case 3: if (mapping->tcp_port.devices[i].slave_id > 0) device_count++; break;
        default: device_count = 0;
        }
    }
    return device_count;
}

void parse_device_config_data(const char *query_string, modbus_cfg_t *modbus_cfg, uint8_t row_number)
{

    if (!query_string || !modbus_cfg) {
        PRINTF("ERROR: Null parameters\n");
        return;
    }
    if (row_number >= MAX_DEVICE_COUNT) {
        PRINTF("ERROR: row_number %d >= MAX_DEVICE_COUNT %d\r\n", row_number, MAX_DEVICE_COUNT);
        return;
    }

    typedef struct {
        uint8_t slave_id;
        char device_type[SIZEOF_JSON_KEY];
        char device_name[SIZEOF_JSON_KEY];
        uint16_t timeout;
        char ip_address[16];
        uint16_t port;
        uint8_t rtu_channel;
        uint8_t tcp_channel;
        uint8_t total_selected;
        struct {
            char register_type[16];
            uint16_t start_address;
            uint16_t count;
            char data_type[16];
            char json_key[SIZEOF_JSON_KEY];
            float scale;
        } mappings[MAX_DATA_POINT];
    } temp_config_t;

    temp_config_t *temp_cfg = malloc(sizeof(temp_config_t));
    if (!temp_cfg) {
        PRINTF("ERROR: Failed to allocate memory for temp config\n");
        return;
    }
    memset(temp_cfg, 0, sizeof(temp_config_t));

    char *temp = malloc(PARSE_DEV_BUF_SIZE);
    if (!temp) {
        PRINTF("ERROR: Failed to allocate temp buffer\n");
        free(temp_cfg);
        return;
    }

    const char *q = strchr(query_string, '?');
    if (q) {
        q++;
    } else {
        q = query_string;
    }

    size_t len = 0;
    const char *end = q;
    while (*end && *end != ' ' && *end != '\n' && *end != '\r' && *end != '\0') {
        end++;
    }
    len = end - q;

    if (len >= PARSE_DEV_BUF_SIZE) {
        PRINTF("WARNING: Query string truncated from %u to %u\n", len, PARSE_DEV_BUF_SIZE-1);
        len = PARSE_DEV_BUF_SIZE - 1;
    }
    memcpy(temp, q, len);
    temp[len] = '\0';

    char key[128];
    char val[256];
    char decoded_val[256];

    const char *p = temp;
    while (*p) {
        const char *eq = strchr(p, '=');
        if (!eq) break;

        size_t key_len = (size_t)(eq - p);
        if (key_len >= sizeof(key)) key_len = sizeof(key) - 1;
        memcpy(key, p, key_len);
        key[key_len] = '\0';

        const char *val_start = eq + 1;
        const char *amp = strchr(val_start, '&');
        size_t val_len = amp ? (size_t)(amp - val_start) : strlen(val_start);

        if (val_len >= sizeof(val)) val_len = sizeof(val) - 1;
        memcpy(val, val_start, val_len);
        val[val_len] = '\0';

        url_decode(val, decoded_val, sizeof(decoded_val));

        if (strcmp(key, "slaveId") == 0) {
            temp_cfg->slave_id = (uint8_t)atoi(decoded_val);
        }
        else if (strcmp(key, "deviceType") == 0) {
            strncpy(temp_cfg->device_type, decoded_val, strlen(decoded_val));
        }
        else if (strcmp(key, "deviceName") == 0) {
            strncpy(temp_cfg->device_name, decoded_val, strlen(decoded_val));
        }
        else if (strcmp(key, "timeout") == 0) {
            temp_cfg->timeout = (uint16_t)atoi(decoded_val);
        }
        else if (strcmp(key, "ipAddress") == 0) {
            if (strlen(decoded_val) > 0) {
                strncpy(temp_cfg->ip_address, decoded_val, sizeof(temp_cfg->ip_address));
            }
        }
        else if (strcmp(key, "port") == 0) {
            if (strlen(decoded_val) > 0) {
                temp_cfg->port = (uint16_t)atoi(decoded_val);
            }
        }
        else if (strcmp(key, "rtuchannel") == 0) {
            if (strlen(decoded_val) > 0) {
                temp_cfg->rtu_channel = (uint8_t)atoi(decoded_val);
            }
        }
        else if (strcmp(key, "tcpchannel") == 0) {
            if (strlen(decoded_val) > 0) {
                temp_cfg->tcp_channel = (uint8_t)atoi(decoded_val);
            }
        }
        else if (strcmp(key, "totalSelected") == 0) {
            temp_cfg->total_selected = (uint8_t)atoi(decoded_val);
        }
        else if (strncmp(key, "row", 3) == 0) {
            int point_num = -1;
            char field[64] = {0};

            if (sscanf(key, "row%d_%63s", &point_num, field) == 2) {
                if (point_num >= 0 && point_num < MAX_DATA_POINT) {
                    PRINTF("Found point %d field '%s' = '%s'\n", point_num, field, decoded_val);

                    if (strcmp(field, "registerType") == 0) {
                        strncpy(temp_cfg->mappings[point_num].register_type, decoded_val,
                               sizeof(temp_cfg->mappings[point_num].register_type));
                    }
                    else if (strcmp(field, "startAddress") == 0) {
                        temp_cfg->mappings[point_num].start_address = (uint16_t)atoi(decoded_val);
                    }
//                    else if (strcmp(field, "count") == 0) {
//                        temp_cfg->mappings[point_num].count = (uint16_t)atoi(decoded_val);
//                    }
                    else if (strcmp(field, "dataType") == 0) {
                        strncpy(temp_cfg->mappings[point_num].data_type, decoded_val,
                               sizeof(temp_cfg->mappings[point_num].data_type));
                    }
                    else if (strcmp(field, "jsonKey") == 0) {
                        strncpy(temp_cfg->mappings[point_num].json_key, decoded_val,
                        		strlen(decoded_val));
                    }
                    else if(strcmp(field, "scale")== 0){
                    	temp_cfg->mappings[point_num].scale = (float)atof(decoded_val);
                    	PRINTF("  scaling factor: %f\r\n", temp_cfg->mappings[point_num].scale);
                    }
                } else {
                    PRINTF("WARNING: Invalid point number %d\n", point_num);
                }
            } else {
                PRINTF("WARNING: Failed to parse row field: %s\n", key);
            }
        }

        if (!amp) break;
        p = amp + 1;
    }

    PRINTF("Parsed configuration:\r\n");
    PRINTF("  slave_id: %d\r\n", temp_cfg->slave_id);
    PRINTF("  device_type: %s\r\n", temp_cfg->device_type);
    PRINTF("  device_name: %s\r\n", temp_cfg->device_name);
    PRINTF("  timeout: %d\r\n", temp_cfg->timeout);
    PRINTF("  rtu_channel: %d\r\n", temp_cfg->rtu_channel);
    PRINTF("  tcp_channel: %d\r\n", temp_cfg->tcp_channel);
    PRINTF("  total_selected: %d\r\n", temp_cfg->total_selected);

    if (temp_cfg->rtu_channel > 0) {
        rtu_data_mapping_t *rtu_mapping = (temp_cfg->rtu_channel == 1) ? &modbus_cfg->rtu_port_1 : &modbus_cfg->rtu_port_2;
        rtu_device_t *device = &rtu_mapping->devices[row_number];

        PRINTF("Parse Row No.: %d\r\n", row_number);

        memset(device, 0, sizeof(*device));

        device->slave_id = temp_cfg->slave_id;
        strncpy((char *)device->device_type, temp_cfg->device_type, SIZEOF_JSON_KEY);
        strncpy((char *)device->device_name, temp_cfg->device_name, SIZEOF_JSON_KEY);
        device->response_timeout_ms = temp_cfg->timeout;

        device->num_points = (temp_cfg->total_selected > MAX_DATA_POINT) ? MAX_DATA_POINT : temp_cfg->total_selected;
        PRINTF("Setting %d points for device\r\n", device->num_points);

        for (int i = 0; i < device->num_points; i++) {
            data_point_t *point = &device->points[i];

            if (strcmp(temp_cfg->mappings[i].register_type, "holding") == 0) point->reg_type = REG_HOLDING_REGISTER;
            else if (strcmp(temp_cfg->mappings[i].register_type, "coil") == 0) point->reg_type = REG_COIL;
            else if (strcmp(temp_cfg->mappings[i].register_type, "discrete") == 0) point->reg_type = REG_DISCRETE_INPUT;
            else if (strcmp(temp_cfg->mappings[i].register_type, "input") == 0) point->reg_type = REG_INPUT_REGISTER;
            else point->reg_type = REG_HOLDING_REGISTER;

            point->start_address = temp_cfg->mappings[i].start_address;
//            point->reg_count = (uint8_t)temp_cfg->mappings[i].count;
            point->scaling_factor = temp_cfg->mappings[i].scale;

            if (strcmp(temp_cfg->mappings[i].data_type, "uint16_t") == 0) {
            	point->data_type = DT_UINT16;
            	point->reg_count = 1;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "int16_t") == 0) {
            	point->data_type = DT_INT16;
            	point->reg_count = 1;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "uint32_t") == 0) {
            	point->data_type = DT_UINT32;
            	point->reg_count = 2;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "int32_t") == 0) {
            	point->data_type = DT_INT32;
            	point->reg_count = 2;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "float") == 0) {
            	point->data_type = DT_FLOAT;
            	point->reg_count = 2;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "double") == 0) {
            	point->data_type = DT_DOUBLE;
            	point->reg_count = 4;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "boolean") == 0) {
            	point->data_type = DT_BOOL;
            	point->reg_count = 1;
            }
            else {
            	point->data_type = DT_UINT16;
            	point->reg_count = 1;
            }

            strncpy((char *)point->json_key, temp_cfg->mappings[i].json_key, SIZEOF_JSON_KEY);
        }
        if(temp_cfg->rtu_channel == 1){
            rtu_mapping->num_devices = count_devices_by_slave_id(modbus_cfg,1);
        }else{
            rtu_mapping->num_devices = count_devices_by_slave_id(modbus_cfg,2);
        }


        PRINTF("Successfully configured RTU device at row %d\r\nTotal No of Dev: %d\r\n", row_number, rtu_mapping->num_devices);
    }
    else if (temp_cfg->tcp_channel > 0) {
        tcp_data_mapping_t *tcp_mapping = &modbus_cfg->tcp_port;
        tcp_device_t *device = &tcp_mapping->devices[row_number];

        memset(device, 0, sizeof(*device));

        device->slave_id = temp_cfg->slave_id;
        strncpy((char *)device->device_type, temp_cfg->device_type, SIZEOF_JSON_KEY);
        strncpy((char *)device->device_name, temp_cfg->device_name, SIZEOF_JSON_KEY);
        device->response_timeout_ms = temp_cfg->timeout;
        device->slave_ip =  inet_addr(temp_cfg->ip_address);
        device->slave_port = temp_cfg->port ;

        device->num_points = (temp_cfg->total_selected > MAX_DATA_POINT) ? MAX_DATA_POINT : temp_cfg->total_selected;
        PRINTF("Setting %d points for tcp-device\r\n", device->num_points);

        for (int i = 0; i < device->num_points; i++) {
            data_point_t *point = &device->points[i];

            if (strcmp(temp_cfg->mappings[i].register_type, "holding") == 0) point->reg_type = REG_HOLDING_REGISTER;
            else if (strcmp(temp_cfg->mappings[i].register_type, "coil") == 0) point->reg_type = REG_COIL;
            else if (strcmp(temp_cfg->mappings[i].register_type, "discrete") == 0) point->reg_type = REG_DISCRETE_INPUT;
            else if (strcmp(temp_cfg->mappings[i].register_type, "input") == 0) point->reg_type = REG_INPUT_REGISTER;
            else point->reg_type = REG_HOLDING_REGISTER;

            point->start_address = temp_cfg->mappings[i].start_address;
//            point->reg_count = (uint8_t)temp_cfg->mappings[i].count;
            point->scaling_factor = temp_cfg->mappings[i].scale;

            if (strcmp(temp_cfg->mappings[i].data_type, "uint16_t") == 0) {
            	point->data_type = DT_UINT16;
            	point->reg_count = 1;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "int16_t") == 0) {
            	point->data_type = DT_INT16;
            	point->reg_count = 1;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "uint32_t") == 0) {
            	point->data_type = DT_UINT32;
            	point->reg_count = 2;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "int32_t") == 0) {
            	point->data_type = DT_INT32;
            	point->reg_count = 2;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "float") == 0) {
            	point->data_type = DT_FLOAT;
            	point->reg_count = 2;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "double") == 0) {
            	point->data_type = DT_DOUBLE;
            	point->reg_count = 4;
            }
            else if (strcmp(temp_cfg->mappings[i].data_type, "boolean") == 0) {
            	point->data_type = DT_BOOL;
            	point->reg_count = 1;
            }
            else {
            	point->data_type = DT_UINT16;
            	point->reg_count = 1;
            }

            strncpy((char *)point->json_key, temp_cfg->mappings[i].json_key, SIZEOF_JSON_KEY);
        }

        tcp_mapping->num_devices = count_devices_by_slave_id(modbus_cfg,3);
        PRINTF("Successfully configured TCP device at row %d\r\nTotal No of Dev: %d\r\n", row_number, tcp_mapping->num_devices);

    }
    else {
        PRINTF("WARNING: No channel specified (rtu_channel=%d, tcp_channel=%d)\n",
               temp_cfg->rtu_channel, temp_cfg->tcp_channel);
    }

    free(temp);
    free(temp_cfg);
}

/******************************************************************************
 * @brief       prepare success cfg page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_cfg_success_page(char* output, uint8_t cfg_status) {

    if (cfg_status) {
    	replace_all(output, "%STATUS_MSG%", "System Configuration Completed Successfully");
    } else {
    	replace_all(output, "%STATUS_MSG%", "System Configuration Failed");
    }
}
/******************************************************************************
 * @brief       prepare success cfg page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_ssl_cfg_page(char* output, uint8_t cert_status) {

	uint8_t temp[32];
    if (cert_status & 1) {
    	replace_all(output, "%CA_STATUS%", "status-ok");
    	sprintf(temp, "%s", "checked");
    	replace_all(output, "%CA_CHECKED%", temp);
    } else {
    	strcpy(temp, "");
    	replace_all(output, "%CA_CHECKED%", temp);
    }
    if (cert_status & 2) {
    	replace_all(output, "%CLIENT_STATUS%", "status-ok");
    	sprintf(temp, "%s", "checked");
    	replace_all(output, "%CLIENT_CHECKED%", temp);
    } else {
    	strcpy(temp, "");
    	replace_all(output, "%CLIENT_CHECKED%", temp);
    }
    if (cert_status & 4) {
    	replace_all(output, "%KEY_STATUS%", "status-ok");
    	sprintf(temp, "%s", "checked");
    	replace_all(output, "%KEY_CHECKED%", temp);
    } else {
    	strcpy(temp, "");
    	replace_all(output, "%KEY_CHECKED%", temp);
    }
}

uint8_t parse_fota_config(const char *query, modbus_cfg_t *g_fota_config)
{


    if (query == NULL)
        return 0;

    uint8_t result = 0;
    const char *param = strchr(query, '?');
    if (!param)
        return 0;

    param++; // skip '?'

    while (*param)
    {
        if (strncmp(param, "ca=1", 4) == 0)
        {
        	result |= 1;
//            g_fota_config.ca = (uint8_t)atoi(param + 3);
        }
        else if (strncmp(param, "client=1", 8) == 0)
        {
        	result |= 2;
//            g_fota_config.client = (uint8_t)atoi(param + 7);
        }
        else if (strncmp(param, "key=1", 5) == 0)
        {
        	result |= 4;
//            g_fota_config.key = (uint8_t)atoi(param + 4);
        }
        else if (strncmp(param, "fota_url=", 9) == 0)
        {
            const char *url_start = param + 9;
            const char *url_end = strchr(url_start, ' ');

            if (url_end == NULL)
                url_end = url_start + strlen(url_start);

            size_t len = url_end - url_start;

            if (len >= sizeof(g_fota_config->fota_url))
                len = sizeof(g_fota_config->fota_url) - 1;

            memcpy(g_fota_config->fota_url, url_start, len);
            g_fota_config->fota_url[len] = '\0';  // null terminate
            break;
        }

        param = strchr(param, '&');
        if (!param)
            break;

        param++; // move to next param
    }
    PRINTF("CERT: %d, URL :%s\n", result, g_fota_config->fota_url);
    return result;
}

/******************************************************************************
 * @brief       prepare success cfg page
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void prepare_fota_cfg_page(char* output, modbus_cfg_t *ft_data) {

	uint8_t temp[160];
    uint8_t cert_status = ft_data-> fota_ssl_flg;
    if (cert_status & 1) {
    	replace_all(output, "%FOTA_CA_STATUS%", "status-ok");
    	sprintf(temp, "%s", "checked");
    	replace_all(output, "%CA_CHECKED%", temp);
    } else {
    	strcpy(temp, "");
    	replace_all(output, "%CA_CHECKED%", temp);
    }
    if (cert_status & 2) {
    	replace_all(output, "%FOTA_CLIENT_STATUS%", "status-ok");
    	sprintf(temp, "%s", "checked");
    	replace_all(output, "%CLIENT_CHECKED%", temp);
    } else {
    	strcpy(temp, "");
    	replace_all(output, "%CLIENT_CHECKED%", temp);
    }
    if (cert_status & 4) {
    	replace_all(output, "%FOTA_KEY_STATUS%", "status-ok");
    	sprintf(temp, "%s", "checked");
    	replace_all(output, "%KEY_CHECKED%", temp);
    } else {
    	strcpy(temp, "");
    	replace_all(output, "%KEY_CHECKED%", temp);
    }
    uint8_t len = sizeof(ft_data->fota_url);
    memcpy(temp, ft_data->fota_url, len);
    temp[len] = '\0';
    replace_all(output, "%FOTA_URL%",temp);
}
/******************************************************************************
 * @brief       get channels from query
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void get_channels_from_query(const char *http_payload, uint8_t *rtu_channel, uint8_t *tcp_channel) {
    if (!http_payload || !rtu_channel || !tcp_channel) return;

    *rtu_channel = 0;
    *tcp_channel = 0;

    const char *p = http_payload;

    while (*p) {
        if (strncmp(p, "rtuchannel=", 11) == 0) {
            *rtu_channel = (uint8_t)atoi(p + 11);
        } else if (strncmp(p, "tcpchannel=", 11) == 0) {
            *tcp_channel = (uint8_t)atoi(p + 11);
        }
        p++;
    }
}
/******************************************************************************
 * @brief       rearrange devices
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void rearrange_devices(const char *rearrange_string, modbus_cfg_t *modbus_cfg, uint8_t rtu_channel, uint8_t tcp_channel) {
    if (!rearrange_string || !modbus_cfg) return;

    const char *rows_ptr = strstr(rearrange_string, "rows=");
    if (!rows_ptr) return;

    rows_ptr += 5;

    uint8_t new_order[MAX_DEVICE_COUNT] = {0};
    uint8_t new_count = 0;
    char temp[8] = {0};

    const char *p = rows_ptr;
    while (*p && *p != '&' && *p != ' ' && new_count < MAX_DEVICE_COUNT) {
        while (*p == ',') p++;
        const char *end = p;
        while (*end && *end != ',' && *end != '&' && *end != ' ') end++;

        size_t len = end - p;
        if (len > 0 && len < sizeof(temp)) {
            memcpy(temp, p, len);
            temp[len] = '\0';
            uint8_t val = (uint8_t)atoi(temp);
            if (val > 0) new_order[new_count++] = val;
        }
        if (!*end || *end == '&' || *end == ' ') break;
        p = end + 1;
    }

    PRINTF("Rearranging - Found %d rows: ", new_count);
    for (int i = 0; i < new_count; i++) PRINTF("%d ", new_order[i]);
    PRINTF("\r\n");

    if (rtu_channel > 0) {
        rtu_data_mapping_t *rtu_mapping = (rtu_channel == 1) ? &modbus_cfg->rtu_port_1 : &modbus_cfg->rtu_port_2;

        if (new_count == 0) {
            PRINTF("Clearing RTU channel %d\r\n", rtu_channel);
            memset(rtu_mapping->devices, 0, sizeof(rtu_mapping->devices));
            rtu_mapping->num_devices = 0;
            return;
        }

        rtu_device_t *temp_devices = malloc(sizeof(rtu_device_t) * new_count);
        if (!temp_devices) {
            PRINTF("Error: Memory allocation failed for RTU temp devices\r\n");
            return;
        }
        memset(temp_devices, 0, sizeof(rtu_device_t) * new_count);

        uint8_t actual_count = 0;
        for (uint8_t i = 0; i < new_count; i++) {
            uint8_t old_index = new_order[i] - 1;
            if (old_index < rtu_mapping->num_devices) {
                memcpy(&temp_devices[actual_count], &rtu_mapping->devices[old_index], sizeof(rtu_device_t));
                actual_count++;
            } else {
                PRINTF("Warning: Invalid RTU old index %d (max is %d)\r\n", old_index, rtu_mapping->num_devices-1);
            }
        }

        memset(rtu_mapping->devices, 0, sizeof(rtu_mapping->devices));

        memcpy(rtu_mapping->devices, temp_devices, sizeof(rtu_device_t) * actual_count);
        rtu_mapping->num_devices = actual_count;

        free(temp_devices);
        PRINTF("RTU channel %d now has %d devices\r\n", rtu_channel, actual_count);
    }
    else if (tcp_channel > 0) {
        tcp_data_mapping_t *tcp_mapping = &modbus_cfg->tcp_port;

        if (new_count == 0) {
            PRINTF("Clearing TCP channel\n");
            memset(tcp_mapping->devices, 0, sizeof(tcp_mapping->devices));
            tcp_mapping->num_devices = 0;
            return;
        }

        tcp_device_t *temp_devices = malloc(sizeof(tcp_device_t) * new_count);
        if (!temp_devices) {
            PRINTF("Error: Memory allocation failed for TCP temp devices\r\n");
            return;
        }
        memset(temp_devices, 0, sizeof(tcp_device_t) * new_count);

        uint8_t actual_count = 0;
        for (uint8_t i = 0; i < new_count; i++) {
            uint8_t old_index = new_order[i] - 1;
            if (old_index < tcp_mapping->num_devices) {
                memcpy(&temp_devices[actual_count], &tcp_mapping->devices[old_index], sizeof(tcp_device_t));
                actual_count++;
                PRINTF("Moving TCP device from old index %d to new index %d\r\n", old_index, actual_count-1);
            } else {
                PRINTF("Warning: Invalid TCP old index %d (max is %d)\r\n", old_index, tcp_mapping->num_devices-1);
            }
        }

        memset(tcp_mapping->devices, 0, sizeof(tcp_mapping->devices));

        memcpy(tcp_mapping->devices, temp_devices, sizeof(tcp_device_t) * actual_count);
        tcp_mapping->num_devices = actual_count;

        free(temp_devices);
        PRINTF("TCP channel now has %d devices\r\n", actual_count);
    }
}
/******************************************************************************
 * @brief       parse ssl configure
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_ssl_configure(const char *query)
{
    int result = 0;

    if (query == NULL) return 0;

    // Look for ca=1
    const char *ca_ptr = strstr(query, "ca=");
    if (ca_ptr && ca_ptr[3] == '1') {
        result |= 1;   // Bit 0
    }

    // Look for client=1
    const char *client_ptr = strstr(query, "client=");
    if (client_ptr && client_ptr[7] == '1') {
        result |= 2;   // Bit 1
    }

    // Look for key=1
    const char *key_ptr = strstr(query, "key=");
    if (key_ptr && key_ptr[4] == '1') {
        result |= 4;   // Bit 2
    }

    return result;
}

static int get_query_param(const char *query,
                           const char *key,
                           char *out,
                           int out_len)
{
    char pattern[32];
    snprintf(pattern, sizeof(pattern), "%s=", key);

    const char *p = strstr(query, pattern);
    if (!p)
        return 0;

    p += strlen(pattern);

    int i = 0;
    while (*p && *p != '&' && *p != ' ' && i < out_len - 1) {
        out[i++] = *p++;
    }
    out[i] = '\0';

    return 1;
}

int parse_modbus_test_request(const char *http_req, modbus_test_req_t *out)
{
    if (!http_req || !out)
        return 0;

    const char *q = strchr(http_req, '?');
    if (!q)
        return 0;

    q++; // move past '?'

    char val[16];

    if (!get_query_param(q, "port", val, sizeof(val)))
        return 0;
    out->port = (uint8_t)atoi(val);

    if (!get_query_param(q, "sid", val, sizeof(val)))
        return 0;
    out->slave_id = (uint8_t)atoi(val);

    if (!get_query_param(q, "fc", val, sizeof(val)))
        return 0;
    out->function_code = (uint8_t)atoi(val);

    if (!get_query_param(q, "addr", val, sizeof(val)))
        return 0;
    out->start_address = (uint16_t)atoi(val);

    if (!get_query_param(q, "qty", val, sizeof(val)))
        return 0;
    out->quantity = (uint16_t)atoi(val);

    return 1; // success
}

void modbus_bytes_to_hex_string(uint8_t *data, uint16_t len, char *out, uint16_t out_size)
{
    uint16_t idx = 0;

    for (uint16_t i = 0; i < len; i++)
    {
        if ((idx + 3) >= out_size) break; // safety

        idx += sprintf(&out[idx], "%02X ", data[i]);
    }

    if (idx > 0)
        out[idx - 1] = '\0'; // remove last space
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
