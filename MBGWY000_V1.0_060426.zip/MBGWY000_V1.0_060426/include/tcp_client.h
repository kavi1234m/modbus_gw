/**
  **************************
  * @file    hal_tcp_client.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    26-03-2025
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef HAL_TCP_CLIENT_H_
#define HAL_TCP_CLIENT_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include <stdint.h>
#include "lwip/err.h"
/* Exported types ------------------------------------------------------------*/
 extern struct tcp_pcb *tcp_client_pcb;
/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/
 int8_t tcp_client_init(uint16_t local_port);
 err_t tcp_client_send_data(struct tcp_pcb *cpcb,unsigned char *buff,unsigned int length);
 struct tcp_pcb *check_tcp_connect(void);
 int8_t tcp_client_connect(uint32_t server_ip, uint16_t remote_port);
 int8_t tcp_data_transmit(unsigned char *buffer,unsigned char length);

 void tcp_callback_register(void *callback);

 int8_t tcp_connection_close(void);
 void tcp_data_receive(uint8_t *buffer,uint16_t buf_len);
 void tcp_buffer_clear(void);
 int8_t is_tcp_connection_established(void);
 uint8_t tcp_receive_len_check(uint16_t length);

/*  Functions used to _________________ ***/


/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* HAL_TCP_CLIENT_H_ */

/***** (C) COPYRIGHT 2022 Calixto Systems Pvt Ltd ***END OF FILE*/
