/**
  **************************
  * @file    http_parser.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 26
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HTTP_PARSER_H_
#define __HTTP_PARSER_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>
#include <stddef.h>
#include "modbus_gw_cfg.h"

#define FS_FILE_FLAGS_HEADER_INCLUDED     0x01
#define FS_FILE_FLAGS_HEADER_PERSISTENT   0x02
#define FS_FILE_FLAGS_HEADER_HTTPVER_1_1  0x04
#define FS_FILE_FLAGS_SSI                 0x08

typedef void html_file_extension;

 struct html_file {
   const char *data;
   int len;
   int index;
   html_file_extension *pextension;
   uint8_t flags;
 };

 struct htmldata_file {
   const struct htmldata_file *next;
   const unsigned char *name;
   const unsigned char *data;
   int len;
   uint8_t flags;
 };

 typedef struct {
     uint8_t  port;
     uint8_t  slave_id;
     uint8_t  function_code;
     uint16_t start_address;
     uint16_t quantity;
 } modbus_test_req_t;


uint8_t html_open(struct html_file *file, const char *name);
int html_bytes_left(struct html_file *file);
void html_close(struct html_file *file);

uint8_t verify_login_request(const char *http_buf);
uint16_t build_login_error_page(uint8_t *output_buf);

uint8_t verify_login_request(const char *http_buf);
void parse_gw_network_config(const char *query_string, network_config_t *nwk_cfg);
void parse_gw_serial_config(const char *query_string,char * buff, serial_config_t *out_cfg);
void prepare_device_info_page(char *output, const device_info_t *info);
void parse_cloud_config(const char *query_string, cloud_config_t *cloud_cfg);
void parse_pollinterval(const char *query_string, modbus_cfg_t *mb_cfg_poll);
void parse_device_config(const char *query_string, modbus_cfg_t *modbus_cfg);
void prepare_cloud_info_page(char *output, const cloud_config_t *info);
void prepare_serial_info_page(char *output, const serial_config_t *info);
void prepare_nwk_info_page(char *output, const network_config_t *info);
void replace_row_placeholders(char *buf, rtu_data_mapping_t *mapping);
void replace_tcp_placeholders(char *html, const tcp_data_mapping_t *tcp_data);

void prepare_data_mapping_page(char *output, const modbus_cfg_t *info);
void replace_reg_cfg_placeholders(char *html_buf, uint8_t num_devices, const data_point_t *pt);
void parse_device_config_data(const char *query_string, modbus_cfg_t *modbus_cfg, uint8_t row_number);
//void prepare_cfg_success_page(char* output, uint8_t cfg_status);
void prepare_cfg_success_page(char* output, uint8_t cfg_status);

void get_channels_from_query(const char *http_payload, uint8_t *rtu_channel, uint8_t *tcp_channel);
void rearrange_devices(const char *rearrange_string, modbus_cfg_t *modbus_cfg, uint8_t rtu_channel, uint8_t tcp_channel);
void prepare_ssl_cfg_page(char* output, uint8_t cert_status);
uint8_t parse_ssl_configure(const char *query);
int parse_modbus_test_request(const char *http_req, modbus_test_req_t *out);
void modbus_bytes_to_hex_string(uint8_t *data, uint16_t len, char *out, uint16_t out_size);
void replace_all(char *str, const char *placeholder, const char *replacement);

void prepare_fota_cfg_page(char* output, modbus_cfg_t *ft_data);
uint8_t parse_fota_config(const char *query, modbus_cfg_t *g_fota_config);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __HTTP_PARSER_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
