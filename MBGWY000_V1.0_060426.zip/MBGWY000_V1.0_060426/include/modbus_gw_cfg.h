/**
  **************************
  * @file    modbus_gw_cfg.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 12
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MODBUS_GW_CFG_H_
#define __MODBUS_GW_CFG_H_


#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>


 /************** Features Enable*****************************/

#define CUSTOM_JSON_PACKET                         0
#define EPOCH_TIME_IN_PKT                          1    // 1- epoch time 0 - calendar time
#define ENABLE_MB_WRT_FEATURE                      1

 /***********************************************************/

#define LONG_PRESS_TIME_MS                          5000
#define MODIFY_CONFIG_TIMEOUT_IN_MS                 600000 // 10 min
#define DOUBLE_PRESS_WINDOW_MS                      500


#define REMOTE_CFG_BUF_LEN                          2048
#define JSON_OUT_BUF_SIZE                           1536
#define CLOUD_RESET_COUNT                           5
#define GSM_SERIAL_BUFF_LEN                         10240

#define USR_BUTTON_PORT                GPIO_PORTB
#define USR_BUTTON_PIN                 PIN_NUM_9

#define PORT_UART4_DIR                 GPIO_PORTA
#define PIN_UART4_DIR                  PIN_NUM_6
#define PORT_UART5_DIR                 GPIO_PORTA
#define PIN_UART5_DIR                  PIN_NUM_5

#define PORT_WDI                       GPIO_PORTB
#define PIN_WDI                        PIN_NUM_10

#define PORT_3V8                       GPIO_PORTC
#define PIN_3V8                        PIN_NUM_13
#define PORT_GSM_ON_OFF                GPIO_PORTC
#define PIN_GSM_ON_OFF                 PIN_NUM_8
#define PORT_GSM_RESET                 GPIO_PORTC
#define PIN_GSM_RESET                  PIN_NUM_9

#define ENABLE_PRINTF_ALL              1
#define ENABLE_PRINTF_MODBUS           2
#define DISABLE_ALL_PRINTF             3

#define DEBUG_PRINTF                  ENABLE_PRINTF_ALL

/***************** User defined Macros End*******************************/


#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
    #define PRINTF(fmt, ...)            printf(fmt, ##__VA_ARGS__);printf("\r")
    #define MODBUS_PRINTF(fmt, ...)     printf(fmt, ##__VA_ARGS__)
#elif (DEBUG_PRINTF == ENABLE_PRINTF_CRITICAL)
    #define PRINTF(fmt, ...)             // Empty, disabled
    #define MODBUS_PRINTF(fmt, ...)   printf(fmt, ##__VA_ARGS__)
#else
    #define PRINTF(fmt, ...)             // Empty, disabled
    #define MODBUS_PRINTF(fmt, ...)    // Empty, disabled

#endif

#define CONFIG_DONE                1
#define DEVICE_RESET               2
#define FACTORY_DEFAULT            3
#define REBOOT                     4

#define SIZEOF_USERNAME            64+1
#define SIZEOF_PASSWORD            32+1
#define SIZEOF_APN                 64+1
#define SIZEOF_URL                 128+1
#define SIZEOF_CLIENTID            64+1
#define SIZEOF_TOPIC               128+1
#define SIZEOF_JSON_KEY            16+1
#define MAX_DATA_POINT             16
#define MAX_DEVICE_COUNT           32

#define MAX_POINTS                 16
#define MAX_PAYLOAD                 8

typedef struct {
 	uint8_t mac_address[6];
 	uint8_t device_type_id[10];
 	uint8_t imei[16];
 	uint8_t checksum;
} fresh_device_config_t;

 typedef struct {
   uint8_t major;
   uint8_t minor;
   uint8_t patch;
   uint8_t checksum;
 }firmware_version_t;

 /***** Device info struct *****/
 typedef struct {
     char system_name[32];
     char firmware_version[16];
     char device_health[16];
     char mac_address[20];
     char ipv4_address[16];
     char subnet_mask[16];
     char default_gateway[16];
     char imei[16];
 } device_info_t;

 /***** Network & GSM config *****/
 typedef struct {
     uint32_t ipv4_address;
     uint32_t subnet_mask;
     uint32_t default_gateway;
     // GSM
     uint8_t apn[SIZEOF_APN];
     uint8_t username[SIZEOF_USERNAME];
     uint8_t password[SIZEOF_PASSWORD];
 } network_config_t;  // 144 bytes

 /***** Serial port config *****/
 typedef struct {
     uint32_t baud_rate;
     uint8_t data_bits;   // usually 8
     uint8_t stop_bits;   // 1 or 2
     uint8_t parity;      // "N", "E", "O"
 } serial_channel_t;

 typedef struct {
     serial_channel_t channel1;
     serial_channel_t channel2;
 } serial_config_t;  // 20 bytes

 /***** Cloud communication config *****/
 typedef enum {
     CLOUD_MODE_TCP = 1,
     CLOUD_MODE_HTTP,
     CLOUD_MODE_MQTT
 } cloud_mode_t;

 typedef enum {
     HTTP_METHOD_GET,
     HTTP_METHOD_POST
 } http_method_t;

 typedef struct {
     uint8_t url[SIZEOF_URL];
     uint16_t port;
 } tcp_config_t;

 typedef struct {
     uint8_t url[SIZEOF_URL];
     uint8_t method;       // "GET", "POST"
 } http_config_t;

 typedef struct {
     uint8_t url[SIZEOF_URL];
     uint16_t port;
     uint8_t client_id[SIZEOF_CLIENTID];
     uint8_t pub_topic[SIZEOF_TOPIC];
     uint8_t cfg_req_topic[SIZEOF_TOPIC];
     uint8_t cfg_rsp_topic[SIZEOF_TOPIC];
     uint8_t username[SIZEOF_USERNAME];
     uint8_t password[SIZEOF_PASSWORD];
     uint8_t qos;
 } mqtt_config_t;

 typedef struct {
     cloud_mode_t mode;
     uint16_t publish_interval_sec;
     struct {
         tcp_config_t  tcp;
         http_config_t http;
         mqtt_config_t mqtt;
     } cfg;
 } cloud_config_t;  // 400 bytes

 /***** Data Mapping ******/
 typedef enum {
     REG_COIL,
     REG_DISCRETE_INPUT,
     REG_INPUT_REGISTER,
     REG_HOLDING_REGISTER
 } register_type_t;

 typedef enum {
     DT_BOOL,
     DT_INT16,
     DT_UINT16,
     DT_INT32,
     DT_UINT32,
     DT_FLOAT,
     DT_DOUBLE
 } data_type_t;

 typedef struct {
     uint8_t reg_type;
     uint16_t start_address;
     uint8_t reg_count;
     uint8_t data_type;
     uint8_t json_key[SIZEOF_JSON_KEY];
     float scaling_factor;
 } data_point_t;

 typedef struct {
     uint8_t  slave_id;                        // Modbus RTU slave ID
     uint8_t  device_type[SIZEOF_JSON_KEY];    // Device Type
     uint8_t  device_name[SIZEOF_JSON_KEY];    // user-friendly name
     uint16_t response_timeout_ms;             // timeout per request
     uint8_t  num_points;                      // how many points are used
     data_point_t points[MAX_DATA_POINT];      // up to 16 data points
 } rtu_device_t;

 typedef struct {
     uint8_t  slave_id;                        // Modbus RTU slave ID
     uint32_t slave_ip;
     uint16_t slave_port;
     uint8_t  device_type[SIZEOF_JSON_KEY];     // Device Type
     uint8_t  device_name[SIZEOF_JSON_KEY];     // user-friendly name
     uint16_t response_timeout_ms;             // timeout per request  100 ms - 10 sec
     uint8_t  num_points;                      // how many points are used
     data_point_t points[MAX_DATA_POINT];      // up to 16 data points
 } tcp_device_t;

 typedef struct {
     uint8_t  rtu_channel_type;
     uint8_t  num_devices;
     rtu_device_t devices[MAX_DEVICE_COUNT];
 } rtu_data_mapping_t;  // 15620 bytes

 typedef struct {
     uint8_t  num_devices;
     tcp_device_t devices[MAX_DEVICE_COUNT];
 } tcp_data_mapping_t; // 15876 bytes

 typedef struct {
	 uint8_t cfg_flg;
	 uint8_t ssl_cfg_check;
	 uint8_t ssl_flg;
	 uint8_t fota_ssl_flg;
	 uint8_t fota_url[SIZEOF_URL];
     uint16_t data_poll_interval;
     network_config_t network_data;
     serial_config_t serial_data;
     cloud_config_t cloud_data;
     rtu_data_mapping_t rtu_port_1;
     rtu_data_mapping_t rtu_port_2;
     tcp_data_mapping_t tcp_port;
     uint8_t checksum;
 }modbus_cfg_t;// 47952

 /******************* data log ******************/
 typedef struct {
     uint8_t reg_type;
     uint16_t start_address;
     uint8_t reg_count;
     uint8_t data_type;
     float scaling_factor;
     uint8_t json_key[SIZEOF_JSON_KEY];
     uint8_t log_data[MAX_PAYLOAD];
 } log_point_t;

 typedef struct {
     uint8_t  slave_id;                        // Modbus RTU  or TCP slave ID
     uint32_t slave_ip;
     uint16_t slave_port;
     uint32_t timestamp;
     uint8_t  channel_type;
     uint8_t  device_type[SIZEOF_JSON_KEY];     // Device Type
     uint8_t  device_name[SIZEOF_JSON_KEY];     // user-friendly name
     uint8_t  num_points;                      // how many points are used
     log_point_t points[MAX_DATA_POINT];      // up to 16 data points
 }log_send_t;

 typedef struct {
	 uint8_t dev_no;
	 uint8_t channel_type;
	 uint16_t log_flg;
	 uint32_t timestamp;
	 uint8_t log_data[MAX_POINTS][MAX_PAYLOAD];
 }log_store_t; // 136

 typedef struct {
     char     fw_version[8];
     uint32_t size;
     uint16_t chunks;
     uint16_t crc;
     uint32_t epoch_time;
 } fota_meta_t;

typedef struct {
	uint32_t write_addr;
	uint32_t read_addr;
	uint8_t wrapped;
} log_meta_t;


typedef struct {
    uint8_t  data[MAX_PAYLOAD];
} cloud_point_t;

typedef struct {
    cloud_point_t points[MAX_POINTS];
    uint32_t timestamp;
} cloud_device_t;

typedef struct {
    cloud_device_t rtu1[32];
    cloud_device_t rtu2[32];
    cloud_device_t tcp[32];
} cloud_data_t; // 12672


typedef struct {
    uint8_t mac[18];
    uint8_t seq_no;
    uint8_t ctp;
    uint32_t ip_addr;
    uint16_t port;
    uint8_t sid;
    uint16_t tmt;
    uint8_t fc;
    uint16_t addr;
    uint8_t data_type;
    uint8_t len;
    uint8_t data[44];
} mb_wrt_t;

typedef enum {
    PKT_UNKNOWN = 0,
    PKT_CFG_START,
    PKT_CFG_FINISH,
    PKT_FACTORY_RESET,
    PKT_CFG_GET_REQ,
    PKT_CFG_SET_REQ,
	PKT_MB_WRT_REQ
} pkt_type_t;

typedef enum {
    CFG_NONE = 0,
    CFG_NWK,
    CFG_CLOUD,
    CFG_SERIAL,
    CFG_DATA_MAP
} cfg_type_t;

typedef enum {
	OP_ADD = 1,
	OP_EDIT,
	OP_DELETE
} op_type_t;

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __MODBUS_GW_CFG_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
