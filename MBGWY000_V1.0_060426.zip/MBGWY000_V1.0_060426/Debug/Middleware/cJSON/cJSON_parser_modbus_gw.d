Middleware/cJSON/cJSON_parser_modbus_gw.o: \
 ../Middleware/cJSON/cJSON_parser_modbus_gw.c \
 ../Middleware/cJSON/cJSON_parser_modbus_gw.h ../include/modbus_gw_cfg.h \
 D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\epoch_conversion/epoch_conversion.h \
 D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Hal/hal_rtc.h \
 ../Middleware/cJSON/cJSON.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/inet.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h \
 ../include/FreeRTOSConfig.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/portable.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h \
 D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6_addr.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h
../Middleware/cJSON/cJSON_parser_modbus_gw.h:
../include/modbus_gw_cfg.h:
D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\epoch_conversion/epoch_conversion.h:
D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Hal/hal_rtc.h:
../Middleware/cJSON/cJSON.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/inet.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h:
D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h:
../include/FreeRTOSConfig.h:
D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h:
D:\AT32F437\lwip_rtos\freertos\source\include/portable.h:
D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h:
D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h:
D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip4_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/ip6_addr.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/def.h:
