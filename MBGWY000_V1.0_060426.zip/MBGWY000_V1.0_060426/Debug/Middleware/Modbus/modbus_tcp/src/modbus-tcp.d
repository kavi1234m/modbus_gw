Middleware/Modbus/modbus_tcp/src/modbus-tcp.o: \
 ../Middleware/Modbus/modbus_tcp/src/modbus-tcp.c \
 ../Middleware/Modbus/modbus_tcp/src/../inc/modbus-tcp.h \
 ../Middleware/Modbus/modbus_tcp/src/../inc/../../modbus.h \
 ../Middleware/Modbus/modbus_tcp/src/../inc/../../modbus_rtu/inc/modbus-rtu.h \
 d:\at32f437_workspace\mbgwy000_v1.0_060426\hal\hal_uart.h \
 d:\at32f437_workspace\mbgwy000_v1.0_060426\middleware\modbus\modbus.h \
 ../Middleware/Modbus/modbus_tcp/src/../inc/../../modbus_rtu/inc/modbus-rtu-private.h \
 ../Middleware/Modbus/modbus_tcp/src/../inc/../../modbus_tcp/inc/modbus-tcp.h \
 ../Middleware/Modbus/modbus_tcp/src/../inc/modbus-tcp-private.h \
 ../Middleware/Modbus/modbus_tcp/src/../../modbus.h \
 ../Middleware/Modbus/modbus_tcp/src/../../modbus-private.h \
 ../Middleware/Modbus/modbus_tcp/src/../../modbus.h \
 ../include/modbus_gw_cfg.h ../include/tcp_client.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/err.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h \
 D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h \
 ../include/FreeRTOSConfig.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/portable.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h \
 D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/task.h \
 D:\AT32F437\lwip_rtos\freertos\source\include/list.h
../Middleware/Modbus/modbus_tcp/src/../inc/modbus-tcp.h:
../Middleware/Modbus/modbus_tcp/src/../inc/../../modbus.h:
../Middleware/Modbus/modbus_tcp/src/../inc/../../modbus_rtu/inc/modbus-rtu.h:
d:\at32f437_workspace\mbgwy000_v1.0_060426\hal\hal_uart.h:
d:\at32f437_workspace\mbgwy000_v1.0_060426\middleware\modbus\modbus.h:
../Middleware/Modbus/modbus_tcp/src/../inc/../../modbus_rtu/inc/modbus-rtu-private.h:
../Middleware/Modbus/modbus_tcp/src/../inc/../../modbus_tcp/inc/modbus-tcp.h:
../Middleware/Modbus/modbus_tcp/src/../inc/modbus-tcp-private.h:
../Middleware/Modbus/modbus_tcp/src/../../modbus.h:
../Middleware/Modbus/modbus_tcp/src/../../modbus-private.h:
../Middleware/Modbus/modbus_tcp/src/../../modbus.h:
../include/modbus_gw_cfg.h:
../include/tcp_client.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/err.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/opt.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/lwipopts.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/debug.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include/lwip/arch.h:
D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch/cc.h:
D:\AT32F437\lwip_rtos\freertos\source\include/FreeRTOS.h:
../include/FreeRTOSConfig.h:
D:\AT32F437\lwip_rtos\freertos\source\include/projdefs.h:
D:\AT32F437\lwip_rtos\freertos\source\include/portable.h:
D:\AT32F437\lwip_rtos\freertos\source\include/deprecated_definitions.h:
D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F/portmacro.h:
D:\AT32F437\lwip_rtos\freertos\source\include/mpu_wrappers.h:
D:\AT32F437\lwip_rtos\freertos\source\include/task.h:
D:\AT32F437\lwip_rtos\freertos\source\include/list.h:
