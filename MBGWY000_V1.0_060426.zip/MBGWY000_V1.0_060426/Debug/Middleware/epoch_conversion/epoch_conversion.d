Middleware/epoch_conversion/epoch_conversion.o: \
 ../Middleware/epoch_conversion/epoch_conversion.c \
 ../Middleware/epoch_conversion/epoch_conversion.h \
 D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Hal/hal_rtc.h \
 ../include/modbus_gw_cfg.h
../Middleware/epoch_conversion/epoch_conversion.h:
D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Hal/hal_rtc.h:
../include/modbus_gw_cfg.h:
