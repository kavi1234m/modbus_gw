################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Middleware/Led_timer/led_timer.c 

OBJS += \
./Middleware/Led_timer/led_timer.o 

C_DEPS += \
./Middleware/Led_timer/led_timer.d 


# Each subdirectory must supply rules for building sources it contributes
Middleware/Led_timer/%.o: ../Middleware/Led_timer/%.c Middleware/Led_timer/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Led_timer" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\xmodem" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\user" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\database" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\epoch_conversion" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\cJSON" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Gsm" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Gsm" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\spi_flash" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\GCC\ARM_CM4F" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/src/include" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port" -I"D:/AT32F437/lwip_rtos/freertos_tcpip_stack/port/arch" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Modbus\modbus_rtu\inc" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Modbus\modbus_tcp\inc" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Modbus" -I"D:\AT32F437\lwip_rtos\freertos\source\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Application" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\checksum" -I"D:\AT32F437\lwip_rtos\freertos\source\portable\memmang" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Modbus\modbus_rtu\inc" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Modbus\modbus_tcp\inc" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Application" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Hal" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\Modbus" -I"D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Middleware\spi_flash" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


