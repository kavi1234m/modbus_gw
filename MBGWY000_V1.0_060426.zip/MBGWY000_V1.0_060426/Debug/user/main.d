user/main.o: ../user/main.c \
 D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Application/application.h \
 D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Hal/hal_system_init.h
D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Application/application.h:
D:\AT32F437_WORKSPACE\MBGWY000_V1.0_060426\Hal/hal_system_init.h:
