################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
OBJS := 
SECONDARY_FLASH := 
SECONDARY_SIZE := 
ASM_DEPS := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Application \
Hal \
Middleware/Gsm \
Middleware/Led_timer \
Middleware/Modbus \
Middleware/Modbus/modbus_rtu/src \
Middleware/Modbus/modbus_tcp/src \
Middleware/cJSON \
Middleware/checksum \
Middleware/database \
Middleware/epoch_conversion \
Middleware/spi_flash \
Middleware/xmodem \
bsp \
cmsis \
firmware \
freertos \
lwip \
user \

