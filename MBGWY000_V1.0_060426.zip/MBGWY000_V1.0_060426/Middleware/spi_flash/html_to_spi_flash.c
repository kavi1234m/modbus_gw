/**
  **************************
  * @file    html_to_spi_flash.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Nov 21
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include "html_to_spi_flash.h"
#include "spi_flash.h"
#include "modbus_gw_cfg.h"
#include "cs_db.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#define LOGIN_PAGE_ADDR     SFP_PRTN3_STRT_ADDR//0XAE000

#define HTML_PAGE_COUNT     15
#define MARKER              "HTTP/1.0"
#define MARKER_LEN          8
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

uint32_t html_flash_addr = LOGIN_PAGE_ADDR;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

uint32_t flash_write_addr = LOGIN_PAGE_ADDR;

uint32_t page_start[HTML_PAGE_COUNT];
uint32_t page_len[HTML_PAGE_COUNT];
uint8_t page_count = 0;

// Store tail to detect marker across boundary
uint8_t tail_buf[MARKER_LEN];
uint16_t tail_len = 0;

/****************************************************************************************************************
  * @brief  Process Chunk
  * @param  write_buf : Pointer to the buffer containing HTML data to be written.
  * @param  write_len : Number of bytes to write from the input buffer.
  * @retval None
  ****************************************************************************************************************/
void process_flash_chunk(uint8_t *buf, uint32_t len)
{
	if (flash_write_addr == LOGIN_PAGE_ADDR) {
		for (uint8_t i = 0; i < ((HTML_PAGE_COUNT * 4)*2) ; i++) {
			buf[i] = 0xFF;
		}
	}
	cdb_write_html_page(flash_write_addr, buf, len);
    // STEP 1: Write chunk to Flash
//    spiflash_write(buf, flash_write_addr, len);

    // STEP 2: Check inside the current chunk
    for (uint32_t i = 0; i <= len - MARKER_LEN; i++)
    {
        if (memcmp(&buf[i], MARKER, MARKER_LEN) == 0)
        {
            uint32_t marker_addr = flash_write_addr + i;

            // Mark new page
            page_start[page_count] = marker_addr;

            // Calculate previous page length
            if (page_count > 0)
            {
                page_len[page_count - 1] =
                    marker_addr - page_start[page_count - 1];
            }

            page_count++;
        }
    }

    // STEP 3: Check across boundary (tail of last 4KB + start of this 4KB)
    if (tail_len > 0)
    {
        for (uint32_t i = 0; i < MARKER_LEN; i++)
        {
            if (tail_len + (len - i) < MARKER_LEN)
                break;

            uint8_t temp[MARKER_LEN];
            memcpy(temp, tail_buf, tail_len);

            uint32_t need = MARKER_LEN - tail_len;
            memcpy(&temp[tail_len], &buf[i], need);

            if (memcmp(temp, MARKER, MARKER_LEN) == 0)
            {
                uint32_t marker_addr =
                    (flash_write_addr - tail_len) + i;

                page_start[page_count] = marker_addr;

                if (page_count > 0)
                {
                    page_len[page_count - 1] =
                        marker_addr - page_start[page_count - 1];
                }

                page_count++;
                break;
            }
        }
    }

    // STEP 4: Store last 8 bytes as new tail
    if (len >= MARKER_LEN)
    {
        memcpy(tail_buf, &buf[len - MARKER_LEN], MARKER_LEN);
        tail_len = MARKER_LEN;
    }
    else
    {
        memcpy(tail_buf, buf, len);
        tail_len = len;
    }

    // STEP 5: Advance write pointer
    flash_write_addr += len;
}
/****************************************************************************************************************
  * @brief  Writes page len to spi flash
  * @param  None
  * @retval None
  ****************************************************************************************************************/
void html_metadata_write(void) {

	spiflash_page_write((uint8_t*)page_start, LOGIN_PAGE_ADDR, (HTML_PAGE_COUNT*4));
	spiflash_page_write((uint8_t*)page_len, LOGIN_PAGE_ADDR + (HTML_PAGE_COUNT*4) , (HTML_PAGE_COUNT*4));

}
/****************************************************************************************************************
  * @brief  Read page len from spi flash
  * @param  None
  * @retval None
  ****************************************************************************************************************/
void html_metadata_read(void) {

	spiflash_read((uint8_t*)page_start, LOGIN_PAGE_ADDR, (HTML_PAGE_COUNT * 4));
	spiflash_read((uint8_t*)page_len, LOGIN_PAGE_ADDR + (HTML_PAGE_COUNT * 4), (HTML_PAGE_COUNT * 4));
    for (uint8_t i = 0; i < HTML_PAGE_COUNT; i++)
    {
        PRINTF("Page %u:\r\n", i + 1);
        PRINTF("Start Address : 0x%08lX\r\n", page_start[i]);
        PRINTF("Length        : %lu bytes\r\n", page_len[i]);
    }
}
/****************************************************************************************************************
  * @brief  finalize_last_page_on_eot
  * @param  None
  * @retval None
  ****************************************************************************************************************/
void finalize_last_page_on_eot(void)
{
    PRINTF("\n=== Stored HTML Pages ===\r\n");
    if (page_count > 0)
    {
        page_len[page_count - 1] =
            flash_write_addr - page_start[page_count - 1];
    }
    for (uint8_t i = 0; i < HTML_PAGE_COUNT; i++)
    {
        PRINTF("Write Page %u:\r\n", i + 1);
        PRINTF("  Start Address : 0x%08lX\r\n", page_start[i]);
        PRINTF("  Length        : %lu bytes\r\n", page_len[i]);
    }
    html_metadata_write();
    html_metadata_read();
    PRINTF("HTML END\r\n");
//    memset(page_start, 0, sizeof(page_start));
//    memset(page_len, 0, sizeof(page_len));
//    page_len_read();
}
/****************************************************************************************************************
  * @brief  Writes HTML page data into SPI Flash memory.
  * @param  write_buf : Pointer to the buffer containing HTML data to be written.
  * @param  write_len : Number of bytes to write from the input buffer.
  * @retval None
  ****************************************************************************************************************/

void html_page_write_into_flash(uint8_t *write_buf, uint16_t write_len) {

	process_flash_chunk(write_buf, write_len);
}

/****************************************************************************************************************
  * @brief  Reads the requested HTML page content from SPI Flash memory.
  * @param  ip_buffer : Pointer to the buffer where the HTML data will be copied.
  * @param  page_type : HTML page type identifier (e.g., LOGIN_PAGE).
  * @retval None
  ****************************************************************************************************************/
void html_page_read_from_flash(uint8_t *ip_buffer, html_page_t page_type) {

	cdb_read_html_page(page_start[page_type], ip_buffer, page_len[page_type]);
	ip_buffer[page_len[page_type]] = '\0';
	PRINTF("<<<<0x%08lX:%lu>>>>\n", page_start[page_type], page_len[page_type]);
}

 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
