/**
  **************************
  * @file    hal_clock.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    26-03-2025
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef LED_TIMER_H_
#define LED_TIMER_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "hal_timer.h"
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/
 void hal_timer4_led_cfg(uint16_t time_in_ms);
 void hal_timer_pwm_cfg(timer_type tmr_x, uint32_t time_in_ms, float duty_cycle);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* LED_TIMER_H_ */




/***** (C) COPYRIGHT 2022 Calixto Systems Pvt Ltd ***END OF FILE*/
