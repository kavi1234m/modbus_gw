/**
  **************************
  * @file    led_timer.c
  * @author  Kaviyarasan m , Calixto Firmware Team
  * @version V1.0.0
  * @date    dd-Month-Year
   * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "led_timer.h"
#include "hal_timer.h"
#include "at32f435_437_clock.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/




/****************************************************************************************
  * @brief  Hal timer cfg for led
  * @param  time_in_ms
  * @retval None
  ***************************************************************************************/
void hal_timer4_led_cfg(uint16_t time_in_ms) {

	crm_clocks_freq_type crm_clocks_freq_struct = {0};
	crm_clocks_freq_get(&crm_clocks_freq_struct);
	time_in_ms = time_in_ms * 10;
	timer_clock_enable(TIMER4);
	tmr_base_init(TMR4, (time_in_ms-1), ((crm_clocks_freq_struct.apb2_freq * 2 / 10000) - 1));
	tmr_cnt_dir_set(TMR4, TMR_COUNT_UP);
	tmr_flag_clear(TMR4, TMR_OVF_FLAG);
	/**** tmr interrupt******/
	tmr_interrupt_enable(TMR4, TMR_OVF_INT, TRUE);
	timer_interrupt_set(TIMER4);
	tmr_counter_enable(TMR4, TRUE);
}

/****************************************************************************************
  * @brief  Timer Pwm init function
  * @param  param1: tmr_pr  - Period register
  * @param  param2: tmr_div - Divider register
  * @retval None
  ***************************************************************************************/
void hal_timer_pwm_cfg(timer_type tmr_x, uint32_t time_in_ms, float duty_cycle) {

	tmr_type *timer = timer_select(tmr_x);
	tmr_reset(timer);
	gpio_init_type gpio_init_struct;
	gpio_default_para_init(&gpio_init_struct);
	gpio_init_struct.gpio_pins = GPIO_PINS_0;
	gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
    gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
	gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
	gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
	gpio_init(GPIOA, &gpio_init_struct);
	gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE0, GPIO_MUX_2);

	crm_clocks_freq_type crm_clocks_freq_struct = {0};
	tmr_output_config_type  tmr_output_struct = {0};
	crm_clocks_freq_get(&crm_clocks_freq_struct);
	uint16_t channel1pulse = 0;
	time_in_ms = time_in_ms * 10;
	timer_clock_enable(tmr_x);
	  /* tmr1 configuration ---------------------------------------------------
	   generate 7 pwm signals with 4 different duty cycles:
	   prescaler = 0, tmr1 counter clock = apb2_freq *2

	   the objective is to generate 7 pwm signal at 17.57 khz:
	     - tim1_period = (apb2_freq * 2 / 17570) - 1
	   the channel 1 and channel 1n duty cycle is set to 50%
	   the channel 2 and channel 2n duty cycle is set to 37.5%
	   the channel 3 and channel 3n duty cycle is set to 25%
	   the channel 4 duty cycle is set to 12.5%
	   the timer pulse is calculated as follows:
	     - channelxpulse = dutycycle * (tim1_period - 1) / 100
	  ----------------------------------------------------------------------- */
     channel1pulse = (uint16_t) (((uint32_t) (float) duty_cycle * (time_in_ms - 1)) / 100); // 85.7%
     tmr_base_init(timer, (time_in_ms-1), (((crm_clocks_freq_struct.apb1_freq * 2) / 10000 ) - 1));
     tmr_cnt_dir_set(timer, TMR_COUNT_UP);

     tmr_output_default_para_init(&tmr_output_struct);
     tmr_output_struct.oc_mode = TMR_OUTPUT_CONTROL_PWM_MODE_B;
     tmr_output_struct.oc_output_state = TRUE;
     tmr_output_struct.oc_polarity = TMR_OUTPUT_ACTIVE_LOW;
     tmr_output_struct.oc_idle_state = TRUE;
     tmr_output_struct.occ_output_state = TRUE;
     tmr_output_struct.occ_polarity = TMR_OUTPUT_ACTIVE_HIGH;
     tmr_output_struct.occ_idle_state = FALSE;

     tmr_output_channel_config(timer, TMR_SELECT_CHANNEL_1, &tmr_output_struct);
     tmr_channel_value_set(timer, TMR_SELECT_CHANNEL_1, channel1pulse);

     tmr_output_enable(timer, TRUE);
     tmr_counter_enable(timer, TRUE);
}

 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2024 Calixto Systems Pvt Ltd ***END OF FILE*/

