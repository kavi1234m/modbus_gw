/******************************************************************************
 * @file    gsm_engine.c
 * @author  Kaviyarasan M, Calixto Firmware Team
 * @version V2.0.0
 * @date    2025-Sep-06
 * @brief   GSM engine for managing module power, init, commands, error handling.
 ******************************************************************************/
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "at32f435_437_usart.h"
#include "at32f435_437_board.h"
#include "hal_uart.h"
#include "hal_gpio.h"
#include "gsm_engine.h"
#include "hal_rtc.h"
#include "modbus_gw_cfg.h"

#include "FreeRTOS.h"
#include "task.h"
#include "cs_db.h"
#include "checksum.h"
#include "flash.h"
#include "hal_system_init.h"
#include "cJSON_parser_modbus_gw.h"
#include "epoch_conversion.h"
#include "semphr.h"

#define FOTA_TEST                           0
#define FOTA_BUF_LEN                        1024
#define ONE_DAY_SECONDS                     86400 //(1 * 24 * 60 * 60)

extern modbus_cfg_t modbus_data;

typedef void (*gsm_cbk_fun)(uint8_t);
gsm_cbk_fun gsm_cbk;

typedef void (*mbwrt_cbk_fun)(uint8_t *buf, uint16_t len);
mbwrt_cbk_fun mb_wrt_cbk;

extern TaskHandle_t modbus_task_handler;
extern TaskHandle_t cloud_comm_task_handler;
extern SemaphoreHandle_t UartMutex;
extern SemaphoreHandle_t spiMutex;

volatile uint8_t gsm_device_state = GSM_ON;
volatile uint8_t gsm_init_state = GSM_CMD1;
volatile uint8_t gsm_mqtt_state = MQTT_STATE_CFG;
volatile uint8_t gsm_tcp_state = TCP_STATE_OPEN;
volatile uint8_t gsm_http_state = HTTP_REQ_SET;
volatile uint8_t gsm_ssl_state = SSL_CFG_CTX;
volatile uint8_t gsm_fota_state = FOTA_HTTP_REQ1;
uint8_t gsm_fota_ssl_state = SSL_CFG_CTX;
volatile uint8_t gsm_command_flag;
static uint8_t gsm_reset_count;
volatile uint8_t gsm_mqtt_connected_flag;
volatile uint8_t gsm_http_connected_flag;
volatile uint8_t gsm_tcp_connected_flag;
uint8_t gsm_buf[GSM_SERIAL_BUFF_LEN];
volatile uint16_t gsm_buf_len;
uint8_t time_got_flag;

const char gsm_cmd1[]  = "ATE0\r\n";
const char gsm_cmd2[]  = "AT+CMEE=0\r\n";
const char gsm_cmd3[]  = "AT+CREG?\r\n";              // Enable network registration updates
const char gsm_cmd4[]  = "AT+CSQ\r\n";      // Query operator selection
const char gsm_cmd5[]  = "AT+CGDCONT?\r\n";      // Query PDP context definitions
const char gsm_cmd6[]  = "AT+CGATT=1\r\n";     // Attach to GPRS network
const char gsm_cmd7[]  = "AT+CGACT=1,1\r\n";   // Activate PDP context
const char gsm_cmd8[]  = "AT+COPS?\r\n";
const char gsm_cmd9[]  = "AT+CGPADDR=1\r\n";   // Get IP address assigned
const char gsm_cmd10[] = "AT+CCLK?\r\n";
//const char gsm_apn_cmd_x[] = "AT+CGDCONT=1,\"%IP_F%\",\"%APN%\"\r\n";
const char gsm_apn_cmd_x[] = "AT+CGDCONT=1,\"IPV4V6\",\"%APN%\"\r\n";
char gsm_apn_cmd[94];

//------------------------------------------------------------------------------------------------------

const char mqtt_tmt_cfg[] = "AT+QMTCFG=\"timeout\",0,5,1,1\r\n";
const char mqtt_cfg[]     = "AT+QMTCFG=\"version\",0,4\r\n"; // enable receive data in string MQTT V3.1.1
char mqtt_open[160];
const char mqtt_open_x[]  = "AT+QMTOPEN=0,\"%MQTT_URL%\",%MQTT_PRT%\r\n"; // open mqtt connection 5sec (120 second)
char mqtt_conn[190];
const char mqtt_conn_x[]  = "AT+QMTCONN=0,\"%CID%\",\"%UN%\",\"%PW%\"\r\n"; // connect to mqtt broker 5 second
const char mqtt_pub[]     = "AT+QMTPUBEX=0,%MID%,%QOS%,0,\"%PUB_TOP%\",%PUB_LEN%\r\n"; // 5sec
char mqtt_pub_data[168];

const char mqtt_cfg_req[] = "AT+QMTSUB=0,1,\"%SUB_TOP%\",%QOS%\r\n"; // 5sec
char mqtt_cfg_req_data[168];
const char mqtt_cfg_rsp[]     = "AT+QMTPUBEX=0,%MID%,%QOS%,0,\"%PUB_TOP%\",%PUB_LEN%\r\n"; // 5sec
char mqtt_cfg_rsp_data[168];

/*************** HTTP *******************************/
const char http_cfg1[]    = "AT+QHTTPCFG=\"contextid\",1\r\n";
const char http_cfg2[]    = "AT+QHTTPCFG=\"contenttype\",1\r\n";
char http_url[24];
char http_url_data[130];

/***************** TCP ***********************/
char tcp_open_cmd[160];
const char tcp_open_cmd_x[] = "AT+QIOPEN=1,0,\"TCP\",\"%TCP_IP%\",%TCP_PRT%,0,0\r\n";

/*************** FILE OPERATION *************/

const char file_open_ca_cert[]     = "AT+QFOPEN=\"UFS:cacert.pem\",1\r\n";
const char file_open_client_cert[] = "AT+QFOPEN=\"UFS:clientcert.pem\",1\r\n";
const char file_open_client_key[]  = "AT+QFOPEN=\"UFS:clientkey.pem\",1\r\n";

const char fota_file_open_ca_cert[]     = "AT+QFOPEN=\"UFS:fota_cacert.pem\",1\r\n";
const char fota_file_open_client_cert[] = "AT+QFOPEN=\"UFS:fota_clientcert.pem\",1\r\n";
const char fota_file_open_client_key[]  = "AT+QFOPEN=\"UFS:fota_clientkey.pem\",1\r\n";

/****************** SSL CFG ************************/

const char mqtt_ssl_cfg[]   = "AT+QMTCFG=\"ssl\",0,1,2\r\n";   // enable ssl
const char http_ssl_cfg[]   = "AT+QHTTPCFG=\"sslctxid\",2\r\n";
const char ssl_cfg1[]       = "AT+QSSLCFG=\"seclevel\",2,2\r\n";
const char ssl_cfg2[]       = "AT+QSSLCFG=\"sslversion\",2,4\r\n";
const char ssl_cfg3[]       = "AT+QSSLCFG=\"ciphersuite\",2,0xFFFF\r\n";
const char ssl_cfg_ca[]     = "AT+QSSlCFG=\"cacert\",2,\"UFS:cacert.pem\"\r\n";
const char ssl_cfg_client[] = "AT+QSSlCFG=\"clientcert\",2,\"UFS:clientcert.pem\"\r\n";
const char ssl_cfg_key[]    = "AT+QSSlCFG=\"clientkey\",2,\"UFS:clientkey.pem\"\r\n";
const char ssl_sni[]        = "AT+QSSLCFG=\"sni\",2,1\r\n";

const char fota_ssl_cfg_ca[]     = "AT+QSSlCFG=\"cacert\",2,\"UFS:fota_cacert.pem\"\r\n";
const char fota_ssl_cfg_client[] = "AT+QSSlCFG=\"clientcert\",2,\"UFS:fota_clientcert.pem\"\r\n";
const char fota_ssl_cfg_key[]    = "AT+QSSlCFG=\"clientkey\",2,\"UFS:fota_clientkey.pem\"\r\n";

/************************** FOTA ***************/

const char fota_url_http[]  = "%sfota_mbgwy000_%d.txt\r\n"; //  fota.mywire.org

uint8_t ssl_cert_state;
uint8_t fota_ssl_cert_state;
uint16_t global_crc = 0xFFFF;
uint16_t fota_current_part_num;
fota_meta_t fota_meta_data;
uint8_t fota_reset;
volatile uint8_t cloud_reset;
volatile uint8_t mqtt_msg_id;
uint32_t fota_idx;
uint8_t fota_task_sts;
static volatile uint8_t uart_frame_finish;

void gsm_send_command(const uint8_t* cmd, uint16_t timeout);
uint8_t gsm_response_process(uint8_t state);
uint8_t check_gsm_buffer_status(void);
static int gsm_rx_contains_bin(const char *substr, const uint8_t *buf, uint16_t len);
void gsm_reset(void);
uint8_t gsm_connect_rsp_process(uint8_t *data, uint16_t length);

/*************************************************************************************************
  * @brief  gsm engine callback register
  * @param  none
  * @retval none
  ************************************************************************************************/
void gsm_engine_callback_register(void *cbk) {
     gsm_cbk = cbk;
}
/*************************************************************************************************
  * @brief  gsm engine callback register
  * @param  none
  * @retval none
  ************************************************************************************************/
void mb_wrt_callback_register(void *cbk) {
     mb_wrt_cbk = cbk;
}
/******************************************************************************
 * @brief       SEND GSM BUFF - send at command to uart
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void SEND_GSM_BUFF(const uint8_t *tx, uint16_t tx_len) {

	if (fota_task_sts) {
		uart_transmit(USART_1, tx, tx_len, 20);
	} else {
		xSemaphoreTake(UartMutex, portMAX_DELAY);
		uart_transmit(USART_1, tx, tx_len, 20);
		xSemaphoreGive(UartMutex);
	}
}
/******************************************************************************
 * @brief       Read GSM response
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void read_gsm_response(uint8_t *data, uint16_t len) {

	if (gsm_buf_len < len) {
		memcpy(data,gsm_buf,gsm_buf_len);
	}
}
/******************************************************************************
 * @brief       Clear usart buffer
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_RxBuffClear(void) {

    memset(gsm_buf, 0, gsm_buf_len);
	gsm_buf_len = 0;
}
/******************************************************************************
 * @brief       Fota status check
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t is_daily_fota_check_due(uint32_t now, uint32_t last) {

	PRINTF("FOTA TIME %u:%u\n", now, last);
	PRINTF("DIFF = %lu\n", (uint32_t)(now - last));
    if (last == 0 || last == 0XFFFFFFFF) {
    	return 1;
    }               // First boot
    if ((now - last) >= ONE_DAY_SECONDS) {
    	PRINTF("FOTA YES\n");
    	return 1;
    } else {
    	PRINTF("FOTA NO\n");
    	return 0;
    }
}
/******************************************************************************
 * @brief       Calculate weekday
 * @param[in]   none
 * @return      none
 ******************************************************************************/
int calculate_weekday(int y, int m, int d) {

    static int day_of_week_table[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
    if (m < 3) y -= 1;
    return (y + y/4 - y/100 + y/400 + day_of_week_table[m-1] + d) % 7;
}
/******************************************************************************
 * @brief       Parse CCLK GSM command response
 * @param[in]   none
 * @return      none
 ******************************************************************************/
int parse_cclk_response(const char *input)
{
    calendar_info_t info;
    int yy, MM, dd, hh, mm, ss;
    char tz_sign;
    int tz_quarter;

    if (input == NULL) {
        PRINTF("CCLK parse error: NULL input\n");
        return 0;
    }

    /* Find first quote */
    const char *start = strchr(input, '"');
    if (start == NULL) {
        PRINTF("CCLK parse error: missing quote\n");
        return 0;
    }
    start++;   /* Skip quote */

    /*
     * Expected format:
     * yy/MM/dd,hh:mm:ss�zz
     */
    int parsed = sscanf(start,
                        "%2d/%2d/%2d,%2d:%2d:%2d%c%2d",
                        &yy, &MM, &dd,
                        &hh, &mm, &ss,
                        &tz_sign, &tz_quarter);

    if (parsed != 8) {
        PRINTF("CCLK parse failed (parsed=%d)\n", parsed);
        return 0;
    }

    /* Validate timezone sign */
    if (tz_sign != '+' && tz_sign != '-') {
        PRINTF("CCLK parse error: invalid TZ sign\n");
        return 0;
    }

    /* Validate date/time ranges */
    if (MM < 1 || MM > 12 ||
        dd < 1 || dd > 31 ||
        hh > 23 || mm > 59 || ss > 59) {
        PRINTF("CCLK parse error: invalid date/time\n");
        return 0;
    }

    /* Fill calendar structure */
    info.year  = (uint8_t)yy;      /* Offset from 2000 */
    info.month = (uint8_t)MM;
    info.date  = (uint8_t)dd;
    info.hour  = (uint8_t)hh;
    info.min   = (uint8_t)mm;
    info.sec   = (uint8_t)ss;

    /* Weekday calculation */
    info.week = calculate_weekday(2000 + yy, MM, dd);

    /* AM / PM (optional) */
    info.am_pm_type = (hh < 12) ? 0 : 1;

    /* Optional: convert GSM TZ (15-min units) to minutes */
    int tz_minutes = tz_quarter * 15;
    if (tz_sign == '-') {
        tz_minutes = -tz_minutes;  // +CCLK: "26/02/09,09:01:19+00"
    }

    PRINTF("CCLK: %02u/%02u/%02u %02u:%02u:%02u (TZ %c%02d => %d min)\n",
           info.year, info.month, info.date,
           info.hour, info.min, info.sec,
           tz_sign, tz_quarter, tz_minutes);

    /* Set RTC */
    if (!hal_rtc_calendar_set(&info)) {
        PRINTF("RTC set failed\n");
        return 0;
    }

    return 1;
}

/*************************************************************************************************
  * @brief  Receive interrupt handler for USART1
  * @param  none
  * @retval none
  ************************************************************************************************/
void USART1_IRQHandler(void) {

	if(usart_interrupt_flag_get(USART1, USART_RDBF_FLAG) != RESET) {
		uint8_t data = usart_data_receive(USART1);
		if (gsm_buf_len <= GSM_SERIAL_BUFF_LEN) {
			gsm_buf[gsm_buf_len++] = data;
		}
	}
	if (usart_interrupt_flag_get(USART1, USART_IDLEF_FLAG) != RESET) {

		uint8_t fin = usart_data_receive(USART1);
#if ENABLE_MB_WRT_FEATURE
		if (gsm_mqtt_state == MQTT_STATE_DONE) {
				if (gsm_rx_contains_bin("+QMTRECV: 0", gsm_buf, gsm_buf_len)) {
                       mb_wrt_cbk(gsm_buf, gsm_buf_len);
                       gsm_RxBuffClear();
				}
			}
#endif
		uart_frame_finish = 1;
	}
}
/******************************************************************************
 * @brief       Replace placeholder
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_replace_placeholder(char *str, const char *placeholder, const char *replacement) {
    size_t placeholder_len = strlen(placeholder);
    size_t replacement_len = strlen(replacement);

    char *pos = str;
    while ((pos = strstr(pos, placeholder)) != NULL) {
        size_t tail_len = strlen(pos + placeholder_len);

        // Shift the tail to make space (or close the gap)
        memmove(pos + replacement_len, pos + placeholder_len, tail_len + 1);

        // Copy replacement
        memcpy(pos, replacement, replacement_len);

        // Advance pointer
        pos += replacement_len;
    }
}
/******************************************************************************
 * @brief       Check Frame complete within tmt
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void check_rx_frame_complete(uint32_t tmt) {

//	printf("\rSTART FRAME:%u\n", uart_frame_finish);
	uint32_t start_time = xTaskGetTickCount();
	while ((xTaskGetTickCount() - start_time) <= tmt ) {
		if (uart_frame_finish) {
//			printf("1.FRAME FINISH:%lu,%u\n", (xTaskGetTickCount() - start_time), uart_frame_finish);
			break;
		}
		vTaskDelay(100);
	}
	PRINTF("\r1.FRAME FIN:%lu,%u\n", (xTaskGetTickCount() - start_time), uart_frame_finish);
}
/******************************************************************************
 * @brief       GSM TCP send publish
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_send_data_via_tcp(uint8_t *data, uint16_t data_len) {

    if (!gsm_tcp_connected_flag) {
    	return 0;
    }
    char tcp_tx[32];
    snprintf(tcp_tx, sizeof(tcp_tx), "AT+QISEND=0,%d\r\n", data_len);
    gsm_send_command(tcp_tx, GSM_TCP_RESPONSE_TIMEOUT1);
    gsm_command_flag = 0;
	if (gsm_rx_contains_bin(">", gsm_buf, gsm_buf_len) == 0) {
		PRINTF("1.TCP RESP ERROR\n");
		cloud_reset++;
		if (cloud_reset >= CLOUD_RESET_COUNT) {
			cloud_reset = 0;
			gsm_device_state = GSM_RESET;
		}
		return 0;
	}
    gsm_send_command(data, GSM_TCP_RESPONSE_TIMEOUT2);
	if (gsm_rx_contains_bin("SEND OK", gsm_buf, gsm_buf_len) == 0) {
		PRINTF("2.TCP RESP ERROR\n");
		cloud_reset++;
		if (cloud_reset >= CLOUD_RESET_COUNT) {
			cloud_reset = 0;
			gsm_device_state = GSM_RESET;
		}
		return 0;
	}
	gsm_command_flag = 0;
	cloud_reset = 0;
	return 1;
}
/******************************************************************************
 * @brief       GSM mqtt publish
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_send_data_via_http(uint8_t* data, uint16_t data_len) {

	if (gsm_http_connected_flag) {
	    char post[32];
	    snprintf(post, sizeof(post), "AT+QHTTPPOST=%d,5,5\r\n", data_len);
	    uart_frame_finish = 0;
	    SEND_GSM_BUFF(post, strlen(post));
//	    gsm_send_command(post, GSM_HTTP_RESPONSE_TIMEOUT1);
	    check_rx_frame_complete(GSM_HTTP_RESPONSE_TIMEOUT2);
	    if (gsm_connect_rsp_process(gsm_buf, gsm_buf_len)) {
	    	gsm_RxBuffClear();
	    	PRINTF("HTTP POST DATA\n");
	    	SEND_GSM_BUFF(data, data_len);
	    	vTaskDelay(GSM_HTTP_RESPONSE_TIMEOUT1);
		    if (gsm_rx_contains_bin("OK", gsm_buf, gsm_buf_len) == 0) {
		    	PRINTF("HTTP OK ERROR\r\n");
	    		cloud_reset++;
	    		if (cloud_reset >= CLOUD_RESET_COUNT) {
	    			cloud_reset = 0;
	    			gsm_device_state = GSM_RESET;
	    		}
	    		return 0;
		    }
		    uart_frame_finish = 0;
		    if (gsm_rx_contains_bin("+QHTTPPOST: 0,200", gsm_buf, gsm_buf_len)) {
		    	gsm_RxBuffClear();
		    	gsm_command_flag = 0;
		    	cloud_reset = 0;
		    	return 1;
		    }
	    	check_rx_frame_complete(GSM_HTTP_RESPONSE_TIMEOUT2);
	    	if (gsm_rx_contains_bin("+QHTTPPOST: 0,200", gsm_buf, gsm_buf_len) == 0) {
	    		PRINTF("HTTP RESPONSE ERROR\n");
	    		cloud_reset++;
	    		if (cloud_reset >= CLOUD_RESET_COUNT) {
	    			cloud_reset = 0;
	    			gsm_device_state = GSM_RESET;
	    		}
		    	gsm_RxBuffClear();
		    	gsm_command_flag = 0;
	    		vTaskDelay(GSM_HTTP_RESPONSE_TIMEOUT2);
	    		return 0;
	    	}
	    	gsm_RxBuffClear();
	    	gsm_command_flag = 0;
	    	cloud_reset = 0;
	    	return 1;
	    } else {
			cloud_reset++;
			if (cloud_reset >= CLOUD_RESET_COUNT) {
				cloud_reset = 0;
				gsm_device_state = GSM_RESET;
			}
	    	return 0;
	    }
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       GSM mqtt publish
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t mb_wrt_rsp_via_mqtt(uint8_t* data, uint16_t data_len) {

	if (gsm_mqtt_connected_flag) {
    	if (mqtt_msg_id) {
    		mqtt_msg_id++;
    		if (mqtt_msg_id == 128) {
    			mqtt_msg_id = 1;
    		}
    	}
		char cmd[256];
		gsm_RxBuffClear();
	    strncpy(cmd, mqtt_cfg_rsp_data, sizeof(mqtt_cfg_rsp_data));
	    char pub_len[8];  // enough for "255" + '\0'
	    snprintf(pub_len, sizeof(pub_len), "%u", data_len);
	    gsm_replace_placeholder(cmd, "%PUB_LEN%", pub_len);
	    snprintf(pub_len, sizeof(pub_len), "%u", mqtt_msg_id);
	    gsm_replace_placeholder(cmd, "%MID%", pub_len);
	    uart_transmit(USART_1, cmd, strlen(cmd), 20);
	    vTaskDelay(GSM_MQTT_RESPONSE_TIMEOUT1);
    	if (gsm_rx_contains_bin(">", gsm_buf, gsm_buf_len) == 0) {
    		PRINTF("1.MQTT RESPONSE ERROR\n");
    		cloud_reset++;
    		if (cloud_reset >= CLOUD_RESET_COUNT) {
    			cloud_reset = 0;
    			gsm_device_state = GSM_RESET;
    		}
    		return 0;
    	}
	    gsm_RxBuffClear();
	    uart_transmit(USART_1, data, data_len, 20);
	    vTaskDelay(GSM_MQTT_RESPONSE_TIMEOUT1);
	    if (gsm_rx_contains_bin("OK", gsm_buf, gsm_buf_len) == 0) {
	    	PRINTF("MQTT OK ERROR\r\n");
    		cloud_reset++;
    		if (cloud_reset >= CLOUD_RESET_COUNT) {
    			cloud_reset = 0;
    			gsm_device_state = GSM_RESET;
    		}
    		return 0;
	    }
	    uart_frame_finish = 0;
	    snprintf(cmd, sizeof(cmd), "+QMTPUBEX: 0,%u,0", mqtt_msg_id);
	    if (gsm_rx_contains_bin(cmd, gsm_buf, gsm_buf_len)) {
	    	gsm_RxBuffClear();
	    	gsm_command_flag = 0;
	    	cloud_reset = 0;
	    	return 1;
	    }
	    check_rx_frame_complete(GSM_MQTT_RESPONSE_TIMEOUT2);
    	if ((gsm_rx_contains_bin(cmd, gsm_buf, gsm_buf_len) == 0)) {
        		cloud_reset++;
        		if (cloud_reset >= CLOUD_RESET_COUNT) {
        			cloud_reset = 0;
        			gsm_device_state = GSM_RESET;
        		}
        		gsm_RxBuffClear();
        		gsm_command_flag = 0;
        		vTaskDelay(GSM_MQTT_RESPONSE_TIMEOUT2);
        		return 0;
    	}
    	gsm_RxBuffClear();
    	gsm_command_flag = 0;
    	cloud_reset = 0;
    	return 1;
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       GSM mqtt publish
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_send_data_via_mqtt(uint8_t* data, uint16_t data_len) {

	if (gsm_mqtt_connected_flag) {
    	if (mqtt_msg_id) {
    		mqtt_msg_id++;
    		if (mqtt_msg_id == 128) {
    			mqtt_msg_id = 1;
    		}
    	}
		char cmd[256];
	    strncpy(cmd, mqtt_pub_data, sizeof(mqtt_pub_data));
	    char pub_len[8];  // enough for "255" + '\0'
	    snprintf(pub_len, sizeof(pub_len), "%u", data_len);
	    gsm_replace_placeholder(cmd, "%PUB_LEN%", pub_len);
	    snprintf(pub_len, sizeof(pub_len), "%u", mqtt_msg_id);
	    gsm_replace_placeholder(cmd, "%MID%", pub_len);
	    SEND_GSM_BUFF(cmd, strlen(cmd));
	    vTaskDelay(GSM_MQTT_RESPONSE_TIMEOUT1);
    	if (gsm_rx_contains_bin(">", gsm_buf, gsm_buf_len) == 0) {
    		PRINTF("1.MQTT RESPONSE ERROR\n");
    		cloud_reset++;
    		if (cloud_reset >= CLOUD_RESET_COUNT) {
    			cloud_reset = 0;
    			gsm_device_state = GSM_RESET;
    		}
    		return 0;
    	}
	    gsm_RxBuffClear();
	    SEND_GSM_BUFF(data, data_len);
	    vTaskDelay(GSM_MQTT_RESPONSE_TIMEOUT1);
	    if (gsm_rx_contains_bin("OK", gsm_buf, gsm_buf_len) == 0) {
	    	PRINTF("MQTT OK ERROR\r\n");
    		cloud_reset++;
    		if (cloud_reset >= CLOUD_RESET_COUNT) {
    			cloud_reset = 0;
    			gsm_device_state = GSM_RESET;
    		}
    		return 0;
	    }
	    uart_frame_finish = 0;
	    snprintf(cmd, sizeof(cmd), "+QMTPUBEX: 0,%u,0", mqtt_msg_id);
	    if (gsm_rx_contains_bin(cmd, gsm_buf, gsm_buf_len)) {
	    	gsm_RxBuffClear();
	    	gsm_command_flag = 0;
	    	cloud_reset = 0;
	    	return 1;
	    }
	    check_rx_frame_complete(GSM_MQTT_RESPONSE_TIMEOUT2);
    	if ((gsm_rx_contains_bin(cmd, gsm_buf, gsm_buf_len) == 0)) {
        		cloud_reset++;
        		if (cloud_reset >= CLOUD_RESET_COUNT) {
        			cloud_reset = 0;
        			gsm_device_state = GSM_RESET;
        		}
        		gsm_RxBuffClear();
        		gsm_command_flag = 0;
        		vTaskDelay(GSM_MQTT_RESPONSE_TIMEOUT2);
        		return 0;
    	}
    	gsm_RxBuffClear();
    	gsm_command_flag = 0;
    	cloud_reset = 0;
    	return 1;
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       build fota url
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void build_fota_url(char *out_buf, char* fota_set_buf, size_t buf_len, uint8_t part_no)
{
	if (part_no == 0) {
		snprintf(out_buf, buf_len, fota_url_http, modbus_data.fota_url, 0);
	} else {
		snprintf(out_buf, buf_len, fota_url_http, modbus_data.fota_url, 1);

	}
	snprintf(fota_set_buf, 32, "AT+QHTTPURL=%u,20\r\n", strlen(out_buf) - 2);
	PRINTF("FOTA URL : %s\n", out_buf);
}
/*************************************************************************************************
  * @brief  gsm replace tcp commands
  * @param  data
  * @retval none
  ************************************************************************************************/
void gsm_init_replace_cmd(void) {

//    char ip_family[6];
//    if ((strncmp(modbus_data.network_data.apn, "jionet", 6) == 0) || (strncmp(modbus_data.network_data.apn, "JIONET", 6) == 0)) {
//    	strcpy(ip_family, "IPV6"); // IPV6
//    	PRINTF("IPV6 TYPE");
//    } else {
//    	strcpy(ip_family, "IP");
//    	PRINTF("IPV4 TYPE");
//    }
	strncpy(gsm_apn_cmd, gsm_apn_cmd_x, sizeof(gsm_apn_cmd_x));
//	gsm_replace_placeholder(gsm_apn_cmd, "%IP_F%", ip_family);
	gsm_replace_placeholder(gsm_apn_cmd, "%APN%", modbus_data.network_data.apn);

}
/*************************************************************************************************
  * @brief  gsm replace tcp commands
  * @param  data
  * @retval none
  ************************************************************************************************/
void gsm_http_replace_cmd(void) {

    const char *url = (const char *)modbus_data.cloud_data.cfg.http.url;
    uint16_t url_len = strlen(url);

    // Format the AT+HTTPURL command
    snprintf(http_url, sizeof(http_url), "AT+QHTTPURL=%d,80\r\n", url_len);

    // Copy URL data separately (this will be sent after CONNECT)
    strncpy(http_url_data, url, sizeof(http_url_data) - 1);
    http_url_data[sizeof(http_url_data) - 1] = '\0';

    snprintf(http_url_data, sizeof(http_url_data), "%s\r\n", url);
}
/*************************************************************************************************
  * @brief  gsm mqtt replace commands
  * @param  data
  * @retval none
  ************************************************************************************************/
void gsm_mqtt_replace_cmd(void) {
	strncpy(mqtt_open, mqtt_open_x, sizeof(mqtt_open_x));
	gsm_replace_placeholder(mqtt_open, "%MQTT_URL%", modbus_data.cloud_data.cfg.mqtt.url);
	char port_str[10];  // buffer to hold number as string
	sprintf(port_str, "%u", modbus_data.cloud_data.cfg.mqtt.port);
	gsm_replace_placeholder(mqtt_open, "%MQTT_PRT%", port_str);
	strncpy(mqtt_conn, mqtt_conn_x, sizeof(mqtt_conn_x));
	gsm_replace_placeholder(mqtt_conn, "%CID%", modbus_data.cloud_data.cfg.mqtt.client_id);
	gsm_replace_placeholder(mqtt_conn, "%UN%", modbus_data.cloud_data.cfg.mqtt.username);
	gsm_replace_placeholder(mqtt_conn, "%PW%", modbus_data.cloud_data.cfg.mqtt.password);

	strncpy(mqtt_pub_data, mqtt_pub, sizeof(mqtt_pub));

    char qos_str[4];  // enough for "255" + '\0'
    snprintf(qos_str, sizeof(qos_str), "%u", modbus_data.cloud_data.cfg.mqtt.qos);
    if (modbus_data.cloud_data.cfg.mqtt.qos) {
    	mqtt_msg_id = 1;
    }
    gsm_replace_placeholder(mqtt_pub_data, "%QOS%", qos_str);
    gsm_replace_placeholder(mqtt_pub_data, "%PUB_TOP%", modbus_data.cloud_data.cfg.mqtt.pub_topic);

 /******************************************************************/
	strncpy(mqtt_cfg_rsp_data, mqtt_cfg_rsp, sizeof(mqtt_cfg_rsp));

    gsm_replace_placeholder(mqtt_cfg_rsp_data, "%QOS%", qos_str);
    gsm_replace_placeholder(mqtt_cfg_rsp_data, "%PUB_TOP%", modbus_data.cloud_data.cfg.mqtt.cfg_rsp_topic);

    strncpy(mqtt_cfg_req_data, mqtt_cfg_req, sizeof(mqtt_cfg_req));
    gsm_replace_placeholder(mqtt_cfg_req_data, "%QOS%", qos_str);
    gsm_replace_placeholder(mqtt_cfg_req_data, "%SUB_TOP%", modbus_data.cloud_data.cfg.mqtt.cfg_req_topic);

}
/*************************************************************************************************
  * @brief  gsm replace tcp commands
  * @param  data
  * @retval none
  ************************************************************************************************/
void gsm_tcp_replace_cmd(void) {

	strncpy(tcp_open_cmd, tcp_open_cmd_x, sizeof(tcp_open_cmd_x));
	char rp_fd[10];
	gsm_replace_placeholder(tcp_open_cmd, "%TCP_IP%", modbus_data.cloud_data.cfg.tcp.url);
	sprintf(rp_fd, "%u", modbus_data.cloud_data.cfg.tcp.port);
	gsm_replace_placeholder(tcp_open_cmd, "%TCP_PRT%", rp_fd);
}
/*************************************************************************************************
  * @brief  gsm data set register
  * @param  data
  * @retval none
  ************************************************************************************************/
void gsm_config_set(void) {
    gsm_init_replace_cmd();
//    xSemaphoreTake(spiMutex, portMAX_DELAY);
//    ssl_sts = device_ssl_file_handle_get();
//    xSemaphoreGive(spiMutex);
    PRINTF("FILE STATUS GET:%u\n",modbus_data.ssl_cfg_check);
    if (modbus_data.ssl_cfg_check == 0xFF) {
    	ssl_cert_state = modbus_data.ssl_flg;
    	fota_ssl_cert_state = modbus_data.ssl_flg;
    } else {
    	ssl_cert_state = 0;
    	fota_ssl_cert_state = 0;
    }
    if (modbus_data.cloud_data.mode == HTTP_MODE) {
    	gsm_http_replace_cmd();
    } else if (modbus_data.cloud_data.mode == MQTT_MODE) {
    	gsm_mqtt_replace_cmd();
    } else {
    	gsm_tcp_replace_cmd();
    }
}
/******************************************************************************
 * @brief       GSM file write data
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_file_write_data(uint8_t *file, uint32_t file_len, uint32_t file_handle)
{

    uint32_t offset = 0;
    uint16_t chunk = 4096;

    while (offset < file_len)
    {
    	gsm_command_flag = 0;
        uint16_t to_send = (file_len - offset >= chunk) ? chunk : (file_len - offset);

        uint8_t cmd[32];
        sprintf(cmd, "AT+QFWRITE=%d,%d,100\r\n", file_handle, to_send);
        PRINTF("WRITE CMD :%s\r\n",cmd);
        // Tell modem you will write <to_send> bytes
        gsm_send_command(cmd, 1000);
        PRINTF("FILE WRITE:%u\n", gsm_buf_len);
//        for (uint16_t i = 0; i < gsm_buf_len; i++) {
//        	printf("%c", gsm_buf[i]);
//        }
        if (!gsm_rx_contains_bin("CONNECT", gsm_buf, gsm_buf_len)) {
            PRINTF("No '>' prompt. Write ABORT.\n");
            return 0;
        }
        gsm_RxBuffClear();
        SEND_GSM_BUFF(&file[offset], to_send);
        vTaskDelay(5000);
        PRINTF("WRITE RESP:%s,%u\n",gsm_buf, gsm_buf_len);

        if (!gsm_rx_contains_bin("OK", gsm_buf, gsm_buf_len)) {
            PRINTF("Chunk write failed.\n");
            return 0;
        }
        offset += to_send;
        PRINTF("Written %d/%d bytes\n", offset, file_len);
    }
    gsm_command_flag = 0;
    gsm_RxBuffClear();
    char cmd[32];
    sprintf(cmd, "AT+QFCLOSE=%d\r\n", file_handle);
    gsm_send_command(cmd, SSL_RESPONSE_TIMEOUT);
    if (gsm_rx_contains_bin("OK", gsm_buf, gsm_buf_len)) {
    	PRINTF("SUCCESS FILE WRITE\n");
    }
    gsm_command_flag = 0;
    return 1;
}
/******************************************************************************
 * @brief       certificates write into gsm
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_file_write(uint8_t *file_data, uint16_t file_len, uint8_t cert_type, uint8_t ssl_mode) {

	uint32_t file_handle = 0;
	if (cert_type == 1) {
		PRINTF("FILE CA\r\n");
		if (ssl_mode) {
			gsm_send_command(file_open_ca_cert, SSL_RESPONSE_TIMEOUT);
		} else {
			gsm_send_command(fota_file_open_ca_cert, SSL_RESPONSE_TIMEOUT);
		}
	} else if (cert_type == 2) {
		PRINTF("FILE CLIENT CERT\r\n");
		if (ssl_mode) {
			gsm_send_command(file_open_client_cert, SSL_RESPONSE_TIMEOUT);
		} else {
			gsm_send_command(fota_file_open_client_cert, SSL_RESPONSE_TIMEOUT);
		}
	} else if (cert_type == 4) {
		PRINTF("FILE CLIENT KEY\r\n");
		if (ssl_mode) {
			gsm_send_command(file_open_client_key, SSL_RESPONSE_TIMEOUT);
		} else {
			gsm_send_command(fota_file_open_client_key, SSL_RESPONSE_TIMEOUT);
		}
	}
	if(check_gsm_buffer_status()) {
		if (gsm_rx_contains_bin("OK", gsm_buf, gsm_buf_len)) {
		    const char *prefix = "+QFOPEN:";
		    char *ptr = strstr(gsm_buf, prefix);
		    if (ptr) {
		        ptr += strlen(prefix);       // Move pointer after "+SKTCREATE:"
		        while (*ptr == ' ') ptr++;   // Skip spaces

		        file_handle = (uint32_t)atoi(ptr);  // Convert number and store
		        PRINTF("File handle: %d\n", file_handle);
		    }
		}
		gsm_RxBuffClear();
		gsm_command_flag = 0;
		gsm_file_write_data(file_data, file_len, file_handle);
	}

}
/******************************************************************************
 * @brief       GSM fota check
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_fota_check(void) {
	 uint32_t epoch_tmt = epoch_time_get();
	 uint8_t fota_sts = is_daily_fota_check_due(epoch_tmt, fota_meta_data.epoch_time);
#if FOTA_TEST
	 fota_sts = 1;
#endif
	 if (fota_sts) {
		 if (fota_task_sts == 0) {
			 fota_task_sts = 1;
       	     taskENTER_CRITICAL();
             vTaskSuspend(cloud_comm_task_handler);
             vTaskSuspend(modbus_task_handler);
             taskEXIT_CRITICAL();
             gsm_cbk(0xAA);
		 }
		 PRINTF("FOTA OPERATION\n");
		 gsm_device_state = GSM_FOTA_SSL;
	 } else {
		 PRINTF("NORMAL OPERATON\n");
		 gsm_device_state = GSM_SSL;
	 }
}
/******************************************************************************
 * @brief       Compare firware version
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t compare_version(const char *v1, const char *v2)
{
    int major1 = 0, minor1 = 0;
    int major2 = 0, minor2 = 0;

    int n1 = sscanf(v1, "%d.%d", &major1, &minor1);
    int n2 = sscanf(v2, "%d.%d", &major2, &minor2);


    PRINTF("OLD VER %d:%d\r\n", major1, minor1);
    PRINTF("NEW VER %d:%d\r\n", major2, minor2);

    if (major1 != major2) return (major2 > major1);
    if (minor1 != minor2) return (minor2 > minor1);

    return 0; // equal
}
/******************************************************************************
 * @brief       parse http get payload
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_qhttpread_payload(const char *input, uint16_t input_len, char *output, uint16_t copy_len) {

    const char *connect_ptr;

    if (!input || !output)
        return 0;

    if (copy_len == 0)
        return 0;

    /* Find CONNECT */
    connect_ptr = strstr(input, "CONNECT");
    if (connect_ptr == NULL)
        return 0;

    /* Move after CONNECT */
    connect_ptr += strlen("CONNECT");

    /* Skip line ending */
    if (*connect_ptr == '\r') connect_ptr++;
    if (*connect_ptr == '\n') connect_ptr++;

    /* Ensure enough data available */
    if ((connect_ptr + copy_len) > (input + input_len))
        return 0;

    /* Copy exact length */
    memcpy(output, connect_ptr, copy_len);

    return 1;
}
/******************************************************************************
 * @brief       Parse HTTPGET Response
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_httpget_response(uint8_t *rxbuf, uint16_t rxlen, uint16_t *out_len)
{
    int profile;
    int http_code;
    int length;

    if (!rxbuf || !out_len)
        return 0;

    char *p = strstr((char *)rxbuf, "+QHTTPGET:");
    if (!p) {
        PRINTF("QHTTPGET response not found\n");
        return 0;
    }

    if (sscanf(p, "+QHTTPGET: %d,%d,%d",
               &profile, &http_code, &length) != 3) {
        PRINTF("QHTTPGET parse error\n");
        return 0;
    }

    if (!fota_current_part_num) {
    	if (http_code != 200) {
            PRINTF("HTTP GET failed, code=%d\n", http_code);
            return 0;
    	}
    } else {
    	if (http_code != 206) {
            PRINTF("HTTP GET failed, code=%d\n", http_code);
            return 0;
    	}
    }
    *out_len = (uint32_t)length;

    PRINTF("HTTP GET success, length=%lu\n", *out_len);
    return 1;
}
/******************************************************************************
 * @brief       GSM FOTA GET
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_fota_get(void) {

	char *fota_data = NULL;
	uint16_t http_len = 0;
	fota_data = (char*)malloc((10 * FOTA_BUF_LEN) + 4);
	if (fota_data == NULL) {
		return 0;
	}
	gsm_command_flag = 0;
	if (!fota_current_part_num) {
		gsm_send_command("AT+QHTTPGET=20\r\n", FOTA_RESPONSE_TIMEOUT2);
	} else {
	    char cmd[32];
	    sprintf(cmd, "AT+QHTTPGETEX=20,%d,8194\r\n", fota_idx);
		gsm_send_command(cmd, FOTA_RESPONSE_TIMEOUT2);
	}
	gsm_command_flag = 0;
	uint8_t ht_sts = parse_httpget_response(gsm_buf, gsm_buf_len, &http_len);
	if (ht_sts == 0) {
	    free(fota_data);
	    fota_data = NULL;
	    if (!fota_current_part_num) {
    		fota_meta_data.epoch_time = epoch_time_get();
    		fota_status_set(&fota_meta_data);
	    	return 0;
	    }
		fota_reset++;
		if (fota_reset >= 5) {
    		fota_meta_data.epoch_time = epoch_time_get();
    		fota_status_set(&fota_meta_data);
			return 0;
		}
		PRINTF("HT STS FAIL\n");
		return 1;
	}
	gsm_send_command("AT+QHTTPREAD=20\r\n", FOTA_RESPONSE_TIMEOUT2);
	gsm_command_flag = 0;
	uint8_t payload_sts = parse_qhttpread_payload(gsm_buf, gsm_buf_len, fota_data, http_len);
	if (payload_sts == 0) {
	    free(fota_data);
	    fota_data = NULL;
	    if (!fota_current_part_num) {
    		fota_meta_data.epoch_time = epoch_time_get();
    		fota_status_set(&fota_meta_data);
	    	return 0;
	    }
		fota_reset++;
		if (fota_reset >= 5) {
    		fota_meta_data.epoch_time = epoch_time_get();
    		fota_status_set(&fota_meta_data);
			return 0;
		}
		PRINTF("PAYLOAD STS FAIL\n");
		return 1;
	}
	PRINTF("HTTP PARSE STATUS:%u\n", http_len);
	if (!fota_current_part_num) {
		fota_meta_t ft;
		if (parse_fota_metadata_cjson(fota_data, &ft)) {
        	if (compare_version(fota_meta_data.fw_version, ft.fw_version)) {
        		fota_reset = 0;
        		fota_meta_data = ft;
        		PRINTF("DO FOTA\n");
    			fota_current_part_num = 1;
        	} else {
        		PRINTF("NO FOTA\n");
#if FOTA_TEST
        		fota_meta_data = ft;
        		fota_current_part_num = 1;
#else
        		fota_meta_data.epoch_time = epoch_time_get();
        		fota_status_set(&fota_meta_data);
        	    free(fota_data);
        	    fota_data = NULL;
        		return 0;
#endif
        	}
    		PRINTF("1.FOTA INFO:%u,%u\n", fota_meta_data.size, fota_meta_data.chunks);
    		PRINTF("2.FOTA INFO:%s,%04X\n", fota_meta_data.fw_version, fota_meta_data.crc);
		} else {
			if (fota_reset >= 5) {
        		fota_meta_data.epoch_time = epoch_time_get();
        		PRINTF("fota epoch:%u\n", fota_meta_data.epoch_time);
        		fota_status_set(&fota_meta_data);
        	    free(fota_data);
        	    fota_data = NULL;
        		return 0;
			} else {
				fota_reset++;
				PRINTF("<<<<FOTA RESET COUNT%u>>>>\n",fota_reset);
				fota_current_part_num = 0;
			}
		}
	} else {
	    uint16_t incoming_crc = (uint16_t)(fota_data[http_len - 2] |
	                                      (fota_data[http_len - 1] << 8));
	    uint16_t calc_crc = crc16(fota_data, (http_len - 2));
	    PRINTF("%u<<%04X:%04X>>,%u\n", fota_current_part_num, incoming_crc, calc_crc, gsm_buf_len);
	    if (calc_crc == incoming_crc) {
	    	global_crc = crc16_update(global_crc, fota_data, (http_len - 2));
	    	PRINTF("CRC OK\n");
        	if (cdb_write_fota(fota_data, http_len)) {
        		fota_reset = 0;
        		fota_idx += 8194;
        		fota_current_part_num++;
        	}
	        if (fota_current_part_num > fota_meta_data.chunks) {
	        	fota_meta_data.epoch_time = epoch_time_get();
	        	fota_status_set(&fota_meta_data);
	        	PRINTF("FINAL FOTA PART\r\n");
	        	PRINTF("GLOBAL CRC:%04X\r\n", global_crc);
	        	write_firmware_flag(FOTA_SET);
	        }

	    } else {
	    	if (fota_reset >= 5) {
	    		fota_meta_data.epoch_time = epoch_time_get();
	    		fota_status_set(&fota_meta_data);
	    	    gsm_fota_state = FOTA_DONE;
	    	    PRINTF("2.FOTA TIMEOUT\n");
	    	    return 0;
	    	} else {
	    		fota_reset++;
	    	}
	    	PRINTF("CRC FAILURE");
	    }
	}
	if (fota_data != NULL) {
	    free(fota_data);
	    fota_data = NULL;
	}
    gsm_command_flag = 0;
    return 1;
}
/******************************************************************************
 * @brief       check GSM buffer Status
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t check_gsm_buffer_status(void) {

	if (gsm_buf_len >= 2) {
		return 1;
	} else {
		return 0;
	}
}
/******************************************************************************
 * @brief       find substring in RX buffer
 * @param[in]   none
 * @return      none
 ******************************************************************************/
static int gsm_rx_contains_bin(const char *substr, const uint8_t *buf, uint16_t len) {

    size_t sublen = strlen(substr);
    if (len < sublen) {
    	return 0;
    }
    for (uint16_t i = 0; i <= len - sublen; i++) {
        if (memcmp(&buf[i], substr, sublen) == 0) {
            return 1;
        }
    }
    return 0;
}
/******************************************************************************
 * @brief       GSM Response Process
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_connect_rsp_process(uint8_t *data, uint16_t length) {

	data[length] = '\0';
    if (gsm_rx_contains_bin("CONNECT", data, length)) {
        return 1;
    }
    return 0;
}
/******************************************************************************
 * @brief       GSM Response Process
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_mqtt_response_data_process(uint8_t *data, uint16_t length, uint8_t type) {

	data[length] = '\0';
	if (type == MQTT_STATE_OPEN) {
	    if (gsm_rx_contains_bin("+QMTOPEN: 0,0", data, length)) {
	        return 1;
	    } else if (gsm_rx_contains_bin("ERROR", data, length)) {
	    	return 0;
	    }
	} else if (type == MQTT_STATE_CONN) {
	    if (gsm_rx_contains_bin("+QMTCONN: 0,0,0", data, length)) {
	        return 1;
	    } else if (gsm_rx_contains_bin("ERROR", data, length)) {
	    	return 0;
	    }
	} else if (type == MQTT_STATE_SUB) {
	    if (gsm_rx_contains_bin("+QMTSUB: 0", data, length)) {
	        return 1;
	    } else if (gsm_rx_contains_bin("ERROR", data, length)) {
	    	return 0;
	    }
	}
    return 0;
}
/******************************************************************************
 * @brief       GSM Response Process
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_tcp_response_data_process(uint8_t *data, uint16_t length) {

	data[length] = '\0';
    if (gsm_rx_contains_bin("+QIOPEN: 0,0", data, length)) {
        return 1;
    } else if (gsm_rx_contains_bin("ERROR", data, length)) {
    	return 0;
    }
    return 0;
}
/******************************************************************************
 * @brief       GSM Response Process
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_response_data_process(uint8_t *data, uint16_t length) {

	data[length] = '\0';
    if (gsm_rx_contains_bin("ERROR", data, length)) {
        return 0;
    } else if (gsm_rx_contains_bin("OK", data, length)) {
    	return 1;
    }
    return 0;
}
/******************************************************************************
 * @brief       GSM Ready response check
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_ready_check(uint8_t *data, uint16_t length) {

    if (gsm_rx_contains_bin("RDY", data, length)) {
    	return 1;
    }
    return 0;
}
/******************************************************************************
 * @brief       GSM Response process check
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t gsm_response_process(uint8_t state) {

	uint8_t status = 0;
	if (check_gsm_buffer_status()) {
		switch (state) {
		    case INIT_RESP:
				 status = gsm_response_data_process(gsm_buf, gsm_buf_len);
				 if (gsm_init_state == GSM_CMD11) {
					 if (parse_cclk_response(gsm_buf)) {
						 time_got_flag = 1;
					 }
				 }
			     break;
		    case MQTT_RESP:
		    	 if (gsm_mqtt_state == MQTT_STATE_OPEN) {
		    		 status = gsm_mqtt_response_data_process(gsm_buf, gsm_buf_len, MQTT_STATE_OPEN);
		    	 } else if (gsm_mqtt_state == MQTT_STATE_CONN) {
		    		 status = gsm_mqtt_response_data_process(gsm_buf, gsm_buf_len, MQTT_STATE_CONN);
		    	 } else if (gsm_mqtt_state == MQTT_STATE_SUB) {
		    		 status = gsm_mqtt_response_data_process(gsm_buf, gsm_buf_len, MQTT_STATE_SUB);
		    	 } else {
		    		 status = gsm_response_data_process(gsm_buf, gsm_buf_len);
		    	 }
			     break;
		    case TCP_RESP:
		    	 if (gsm_tcp_state == TCP_STATE_OPEN) {
		    		 status = gsm_tcp_response_data_process(gsm_buf, gsm_buf_len);
		    	 } else {
		    		 status = gsm_response_data_process(gsm_buf, gsm_buf_len);
		    	 }
			     break;
		    case HTTP_RESP:
		    		 status = gsm_response_data_process(gsm_buf, gsm_buf_len);
			     break;
		    case SSL_RESP:
		    	 status = gsm_response_data_process(gsm_buf, gsm_buf_len);
			     break;
		    case FOTA_RESP:
		    	 status = gsm_response_data_process(gsm_buf, gsm_buf_len);
			     break;
		    default:
		    	 break;
		}
		gsm_RxBuffClear();
		gsm_command_flag = 0;
		if (status == 0) {
			gsm_device_state = GSM_RESET;
		}
		return status;
	}
	return 0;
}
/******************************************************************************
 * @brief       GSM Send Command
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_send_command(const uint8_t* cmd, uint16_t timeout) {

    if (!gsm_command_flag) {
        gsm_command_flag = 1;
        if (cmd && cmd[0] != '\0') {
            gsm_RxBuffClear();
            PRINTF("TX:%s\n", cmd);
            SEND_GSM_BUFF(cmd, strlen(cmd));
            vTaskDelay(timeout);
        }
    }
}
/******************************************************************************
 * @brief       GSM init Commands
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_fota_ssl_engine(void) {

	   switch(gsm_fota_ssl_state) {

       case SSL_CFG_CTX:
 		    	if (modbus_data.fota_ssl_flg) {
 		    		gsm_send_command(http_ssl_cfg, GSM_HTTP_RESPONSE_TIMEOUT1);
 		    	    if (gsm_response_process(SSL_RESP)) {
 		    	    	gsm_fota_ssl_state = SSL_STATE_CA;
 		    	    }
 		    	} else {
 		    		gsm_fota_ssl_state = SSL_STATE_CA;
 		    	}
	         break;
             case SSL_STATE_CA:
       	          if (modbus_data.fota_ssl_flg & 0x01) {
	        	       gsm_send_command(fota_ssl_cfg_ca, SSL_RESPONSE_TIMEOUT);
	        	       if(gsm_response_process(SSL_RESP)) {
	        	    	   gsm_fota_ssl_state = SSL_STATE_CLIENT;
	        	       }
       	          } else {
       	        	gsm_fota_ssl_state = SSL_STATE_CLIENT;
       	          }
                  break;

             case SSL_STATE_CLIENT:
       	          if (modbus_data.fota_ssl_flg & 0x02) {
	        	       gsm_send_command(fota_ssl_cfg_client, SSL_RESPONSE_TIMEOUT);
	        	       if(gsm_response_process(SSL_RESP)) {
	        	    	   gsm_fota_ssl_state = SSL_STATE_KEY;
	        	       }
       	          } else {
       	        	gsm_fota_ssl_state = SSL_STATE_KEY;
       	          }
                  break;

             case SSL_STATE_KEY:
       	          if (modbus_data.fota_ssl_flg & 0x04) {
	        	      gsm_send_command(fota_ssl_cfg_key, SSL_RESPONSE_TIMEOUT);
	        	      if(gsm_response_process(SSL_RESP)) {
	        	    	  if (modbus_data.fota_ssl_flg) {
	        	    		  gsm_fota_ssl_state = SSL_SNI;
	        	    	  } else {
	        	    		  gsm_fota_ssl_state = SSL_STATE_DONE;
	        	    	  }
	        	      }
       	          } else {
        	    	  if (modbus_data.fota_ssl_flg) {
        	    		  gsm_fota_ssl_state = SSL_SNI;
        	    	  } else {
        	    		  gsm_fota_ssl_state = SSL_STATE_DONE;
        	    	  }
       	          }
                  break;
 	        case SSL_SNI:
 	             gsm_send_command((const uint8_t*)ssl_sni, SSL_RESPONSE_TIMEOUT);
 	             if (gsm_response_process(SSL_RESP)) {
 	            	gsm_fota_ssl_state = SSL_CFG1;
 	             }
 		         break;
	        case SSL_CFG1:
	             gsm_send_command((const uint8_t*)ssl_cfg1, SSL_RESPONSE_TIMEOUT);
	             if (gsm_response_process(SSL_RESP)) {
	            	 gsm_fota_ssl_state = SSL_CFG2;
	             }
		         break;
	        case SSL_CFG2:
	             gsm_send_command((const uint8_t*)ssl_cfg2, SSL_RESPONSE_TIMEOUT);
	             if (gsm_response_process(SSL_RESP)) {
	            	 gsm_fota_ssl_state = SSL_CFG3;
	             }
		         break;
	        case SSL_CFG3:
	             gsm_send_command((const uint8_t*)ssl_cfg3, SSL_RESPONSE_TIMEOUT);
	             if (gsm_response_process(SSL_RESP)) {
	            	 gsm_fota_ssl_state = SSL_STATE_DONE;
	             }
		         break;
	        case SSL_STATE_DONE:
       		     gsm_device_state = GSM_FOTA;
	            break;
	        default:
	            break;
	   }
}
/******************************************************************************
 * @brief       GSM init Commands
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_ssl_engine(void) {

	   switch(gsm_ssl_state) {

       case SSL_CFG_CTX:
             if (modbus_data.cloud_data.mode == MQTT_MODE) {
            	 if (modbus_data.ssl_flg) {
            	 	 gsm_send_command(mqtt_ssl_cfg, GSM_MQTT_RESPONSE_TIMEOUT1);
            	 	 if (gsm_response_process(SSL_RESP)) {
            	 		gsm_ssl_state = SSL_STATE_CA;
            	 	 }
            	 } else {
            		 gsm_ssl_state = SSL_STATE_CA;
            	 }
 		     } else if (modbus_data.cloud_data.mode == HTTP_MODE) {
 		    	if (modbus_data.ssl_flg) {
 		    		gsm_send_command(http_ssl_cfg, GSM_HTTP_RESPONSE_TIMEOUT1);
 		    	    if (gsm_response_process(SSL_RESP)) {
 		    	    	gsm_ssl_state = SSL_STATE_CA;
 		    	    }
 		    	} else {
 		    		gsm_ssl_state = SSL_STATE_CA;
 		    	}
 		     }
	         break;
             case SSL_STATE_CA:
       	          if (modbus_data.ssl_flg & 0x01) {
	        	       gsm_send_command(ssl_cfg_ca, SSL_RESPONSE_TIMEOUT);
	        	       if(gsm_response_process(SSL_RESP)) {
	        		       gsm_ssl_state = SSL_STATE_CLIENT;
	        	       }
       	          } else {
       		              gsm_ssl_state = SSL_STATE_CLIENT;
       	          }
                  break;

             case SSL_STATE_CLIENT:
       	          if (modbus_data.ssl_flg & 0x02) {
	        	       gsm_send_command(ssl_cfg_client, SSL_RESPONSE_TIMEOUT);
	        	       if(gsm_response_process(SSL_RESP)) {
	        		       gsm_ssl_state = SSL_STATE_KEY;
	        	       }
       	          } else {
       		            gsm_ssl_state = SSL_STATE_KEY;
       	          }
                  break;

             case SSL_STATE_KEY:
       	          if (modbus_data.ssl_flg & 0x04) {
	        	      gsm_send_command(ssl_cfg_key, SSL_RESPONSE_TIMEOUT);
	        	      if(gsm_response_process(SSL_RESP)) {
	        	    	  if (modbus_data.ssl_flg) {
	        	    		  gsm_ssl_state = SSL_SNI;
	        	    	  } else {
	        	    		  gsm_ssl_state = SSL_STATE_DONE;
	        	    	  }
	        	      }
       	          } else {
        	    	  if (modbus_data.ssl_flg) {
        	    		  gsm_ssl_state = SSL_SNI;
        	    	  } else {
        	    		  gsm_ssl_state = SSL_STATE_DONE;
        	    	  }
       	          }
                  break;
 	        case SSL_SNI:
 	             gsm_send_command((const uint8_t*)ssl_sni, SSL_RESPONSE_TIMEOUT);
 	             if (gsm_response_process(SSL_RESP)) {
 	            	 gsm_ssl_state = SSL_CFG1;
 	             }
 		         break;
	        case SSL_CFG1:
	             gsm_send_command((const uint8_t*)ssl_cfg1, SSL_RESPONSE_TIMEOUT);
	             if (gsm_response_process(SSL_RESP)) {
	            	 gsm_ssl_state = SSL_CFG2;
	             }
		         break;
	        case SSL_CFG2:
	             gsm_send_command((const uint8_t*)ssl_cfg2, SSL_RESPONSE_TIMEOUT);
	             if (gsm_response_process(SSL_RESP)) {
	            	 gsm_ssl_state = SSL_CFG3;
	             }
		         break;
	        case SSL_CFG3:
	             gsm_send_command((const uint8_t*)ssl_cfg3, SSL_RESPONSE_TIMEOUT);
	             if (gsm_response_process(SSL_RESP)) {
	            	 gsm_ssl_state = SSL_STATE_DONE;
	             }
		         break;
	        case SSL_STATE_DONE:
       		     if (modbus_data.cloud_data.mode == TCP_MODE) {
       			     gsm_device_state = GSM_TCP;
       		     } else if (modbus_data.cloud_data.mode == HTTP_MODE) {
       			     gsm_device_state = GSM_HTTP;
       		     } else {
       			     gsm_device_state = GSM_MQTT;
       		     }
	            break;
	        default:
	            break;
	   }
}
/******************************************************************************
 * @brief       GSM init Commands
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_init_engine(void) {

    switch(gsm_init_state) {
        case GSM_CMD1:
             gsm_send_command((const uint8_t*)gsm_cmd1, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD2;
             }
             break;

        case GSM_CMD2:
             gsm_send_command((const uint8_t*)gsm_cmd2, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD3;
             }
             break;

        case GSM_CMD3:
             gsm_send_command((const uint8_t*)gsm_cmd3, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD4;
             }
             break;
        case GSM_CMD4:
             gsm_send_command((const uint8_t*)gsm_cmd4, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD5;
             }
             break;

        case GSM_CMD5:
             gsm_send_command((const uint8_t*)gsm_cmd5, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD6;
             }
             break;

        case GSM_CMD6:
             gsm_send_command((const uint8_t*)gsm_apn_cmd, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD7;
             }
             break;

        case GSM_CMD7:
             gsm_send_command((const uint8_t*)gsm_cmd6, GSM_INIT_RESPONSE_TIMEOUT2);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD8;
             }
             break;

        case GSM_CMD8:
             gsm_send_command((const uint8_t*)gsm_cmd7, GSM_INIT_RESPONSE_TIMEOUT2);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD9;
             }
             break;

        case GSM_CMD9:
             gsm_send_command((const uint8_t*)gsm_cmd8, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
            	 gsm_init_state = GSM_CMD10;
             }
             break;

        case GSM_CMD10:
             gsm_send_command((const uint8_t*)gsm_cmd9, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
            	 if (time_got_flag) {
            		 PRINTF(">>GSM INIT SUCCESS\n");
            		 gsm_init_state = INIT_FOTA;
            	 } else {
            		 gsm_init_state = GSM_CMD11;
            	 }
             }
             break;

        case GSM_CMD11:
             gsm_send_command((const uint8_t*)gsm_cmd10, GSM_INIT_RESPONSE_TIMEOUT1);
             if (gsm_response_process(INIT_RESP)) {
        		 PRINTF("<<GSM INIT SUCCESS:%u>>\n",modbus_data.cloud_data.mode);
        		 gsm_init_state = INIT_FOTA;
             }
             break;
        case INIT_FOTA:
        	 gsm_init_state = INIT_DONE;
        	 gsm_device_state = GSM_SSL_FILE_HANDLE;
        	 gsm_reset_count = 0;
        	 break;
        case INIT_DONE:
        	 break;
        default :
        	break;
    }
}
/******************************************************************************
 * @brief       GSM init Commands
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_mqtt_engine(void) {

	   switch(gsm_mqtt_state) {

	        case MQTT_STATE_CFG:
	        	 gsm_send_command(mqtt_cfg, GSM_MQTT_RESPONSE_TIMEOUT1);
	        	 if(gsm_response_process(MQTT_RESP)) {
	        		 gsm_mqtt_state = MQTT_STATE_TMT;
	        	 }
	             break;

	        case MQTT_STATE_TMT:
		         gsm_send_command(mqtt_tmt_cfg, GSM_MQTT_RESPONSE_TIMEOUT1);
	        	 if(gsm_response_process(MQTT_RESP)) {
	        		 gsm_mqtt_state = MQTT_STATE_OPEN;
	        	 }
	            break;

	        case MQTT_STATE_OPEN:
		         gsm_send_command(mqtt_open, GSM_MQTT_RESPONSE_TIMEOUT2);
	        	 if(gsm_response_process(MQTT_RESP)) {
	        		 gsm_mqtt_state = MQTT_STATE_CONN;
	        	 }
	            break;

	        case MQTT_STATE_CONN:
	        	 gsm_send_command(mqtt_conn, GSM_MQTT_RESPONSE_TIMEOUT2);
	        	 if(gsm_response_process(MQTT_RESP)) {
	        		 if ((strlen(modbus_data.cloud_data.cfg.mqtt.cfg_req_topic) > 1) && (strlen(modbus_data.cloud_data.cfg.mqtt.cfg_rsp_topic) > 1)) {
	        			 gsm_mqtt_state = MQTT_STATE_SUB;
	        		 } else {
	        			 PRINTF("MQTT INIT DONE\n");
	        			 gsm_cbk(MQTT_MODE);
	        			 gsm_mqtt_connected_flag = 1;
	        			 gsm_mqtt_state = MQTT_STATE_DONE;
	        		 }
	        	 }
	             break;
	        case MQTT_STATE_SUB:
	        	 gsm_send_command(mqtt_cfg_req_data, GSM_MQTT_RESPONSE_TIMEOUT2);
	        	 if(gsm_response_process(MQTT_RESP)) {
		        	 PRINTF("MQTT INIT DONE\n");
		        	 gsm_cbk(MQTT_MODE);
	       		     gsm_mqtt_connected_flag = 1;
	       		     gsm_mqtt_state = MQTT_STATE_DONE;
	        	 }
	             break;

	        case MQTT_STATE_DONE:
	            break;

	        default:
	            break;
	   }
}
/******************************************************************************
 * @brief       GSM HTTP Engine
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_http_engine(void) {

	switch (gsm_http_state) {
	    case HTTP_REQ_SET:
	    	 gsm_send_command(http_cfg1, GSM_HTTP_RESPONSE_TIMEOUT1);
	    	 if (gsm_response_process(HTTP_RESP)) {
	    		 gsm_http_state = HTTP_CNT_TYP_SET;
	    	 }
	    	 break;
	    case HTTP_CNT_TYP_SET:
	    	 gsm_send_command(http_cfg2, GSM_HTTP_RESPONSE_TIMEOUT1);
	    	 if (gsm_response_process(HTTP_RESP)) {
	    		 gsm_http_state = HTTP_URL_SET;
	    	 }
	    	 break;
	    case HTTP_URL_SET:
	    	 gsm_send_command(http_url, GSM_HTTP_RESPONSE_TIMEOUT1);
	    	 if (gsm_connect_rsp_process(gsm_buf, gsm_buf_len)) {
	    		 gsm_command_flag = 0;
	    		 gsm_send_command(http_url_data, GSM_HTTP_RESPONSE_TIMEOUT2);
		    	 if (gsm_response_process(HTTP_RESP)) {
		    		 PRINTF("HTTP INIT DONE\n");
		   		     gsm_cbk(HTTP_MODE);
		   		     gsm_http_connected_flag = 1;
		   		     gsm_http_state = HTTP_STATE_DONE;
		    	 }
	    	 }
	    	 break;
	    case HTTP_STATE_DONE:
	    	 break;
	    default:
	    	break;
	}
}
/******************************************************************************
 * @brief       GSM TCP Engine
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_tcp_engine(void) {
	   switch(gsm_tcp_state) {
	        case TCP_STATE_OPEN:
	        	 gsm_send_command(tcp_open_cmd, GSM_TCP_RESPONSE_TIMEOUT2);
	        	 if(gsm_response_process(TCP_RESP)) {
	        		 PRINTF("GSM TCP INIT DONE\n");
	        		 gsm_cbk(TCP_MODE);
	        		 gsm_tcp_connected_flag = 1;
	        		 gsm_tcp_state = TCP_STATE_DONE;
	        	 }
	             break;
	        case TCP_STATE_DONE:
	             break;
	        default:
	            break;
	   }
}
/******************************************************************************
 * @brief       SSL FILE PUSH (certificates) TO GSM
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_ssl_file_handle_engine(uint8_t ssl_file_flg, uint8_t ssl_mode) {

		switch(ssl_file_flg) {
		   case SSL_CA_CERT_PUSH_STATE:
		        {
		    	    uint8_t* file_ptr = (uint8_t*)malloc(8 * 1024);
		    	    uint16_t file_len;
		    	    xSemaphoreTake(spiMutex, portMAX_DELAY);
		    	    if (ssl_mode) {
		    	    	file_len = cdb_read_cert(file_ptr, 1);
		    	    } else {
		    	    	file_len = cdb_fota_read_cert(file_ptr, 1);
		    	    }
		    	    xSemaphoreGive(spiMutex);
	                PRINTF("FILE LEN:%u,%s\n",file_len, file_ptr);
	                gsm_file_write(file_ptr, file_len, 1, ssl_mode);
	                free(file_ptr);
		        }
	            break;
	        case SSL_CLIENT_CERT_PUSH_STATE:
	             {
	        	     uint8_t* file_ptr = (uint8_t*)malloc(8 * 1024);
	        	     uint16_t file_len;
	        	     xSemaphoreTake(spiMutex, portMAX_DELAY);
			    	    if (ssl_mode) {
			    	    	file_len = cdb_read_cert(file_ptr, 2);
			    	    } else {
			    	    	file_len = cdb_fota_read_cert(file_ptr, 2);
			    	    }
	                 xSemaphoreGive(spiMutex);
	                 PRINTF("FILE LEN:%u,%s\n",file_len,file_ptr);
	                 gsm_file_write(file_ptr, file_len, 2, ssl_mode);
	                 free(file_ptr);
	              }
	              break;
	         case SSL_CLIENT_KEY_PUSH_STATE:
	              {
	            	  uint8_t* file_ptr = (uint8_t*)malloc(8 * 1024);
	            	  uint16_t file_len;
	            	  xSemaphoreTake(spiMutex, portMAX_DELAY);
			    	    if (ssl_mode) {
			    	    	file_len = cdb_read_cert(file_ptr, 4);
			    	    } else {
			    	    	file_len = cdb_fota_read_cert(file_ptr, 4);
			    	    }
	                  xSemaphoreGive(spiMutex);
	                  PRINTF("FILE LEN:%u,%s\n",file_len,file_ptr);
	                  gsm_file_write(file_ptr, file_len, 4, ssl_mode);
	                  free(file_ptr);
	              }
	              break;
	       default:
	    	   break;
		}
}
/******************************************************************************
 * @brief       GSM fota engine
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_fota_engine(void) {

	switch(gsm_fota_state) {

	    case FOTA_HTTP_REQ1:
       	     gsm_send_command(http_cfg1, FOTA_RESPONSE_TIMEOUT1);
       	     if(gsm_response_process(FOTA_RESP)) {
       		    gsm_fota_state = FOTA_HTTP_REQ2;
       	     }
       	     break;
	    case FOTA_HTTP_REQ2:
       	     gsm_send_command(http_cfg2, FOTA_RESPONSE_TIMEOUT1);
       	     if(gsm_response_process(FOTA_RESP)) {
       		    gsm_fota_state = FOTA_HTTP_URL;
       	     }
       	     break;
	    case FOTA_HTTP_URL:
	    	 if (fota_current_part_num < 2) {
       	    	 char url[256];
       	    	 char fota_cfg[32];
       	    	 PRINTF("HTTP URL SET\n");
       	    	 build_fota_url(url , fota_cfg, 256, fota_current_part_num);
	       	     gsm_send_command(fota_cfg, FOTA_RESPONSE_TIMEOUT1);
	       	     if(gsm_connect_rsp_process(gsm_buf, gsm_buf_len)) {
	       	    	 gsm_command_flag = 0;
	       	    	 gsm_send_command(url, FOTA_RESPONSE_TIMEOUT2);
	       	    	 if (gsm_response_process(FOTA_RESP)) {
	       	    		 gsm_fota_state = FOTA_HTTP_READ;
	       	    	 }
	       	     }
	    	 } else {
	    		 gsm_fota_state = FOTA_HTTP_READ;
	    	 }
       	     break;
	    case FOTA_HTTP_READ:
	    	 if (gsm_fota_get()) {
	    		 PRINTF("FOTA CRNT PART:%u\n", fota_current_part_num);
		    	 if ((fota_current_part_num > fota_meta_data.chunks)) {
		    		 gsm_fota_state = FOTA_DONE;
		    	 } else {
		    		 gsm_fota_state = FOTA_HTTP_URL;
		    	 }
	    	 } else {
	    		 gsm_fota_state = FOTA_DONE;
	    	 }
       	     break;
	    case FOTA_DONE:
	    	 hal_system_reset();
	    	 break;

	}
}
/******************************************************************************
 * @brief       Cold power ON
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void Cold_power_on(void) {

	PRINTF("COLD POWER ON\n");
	vTaskDelay(30);
	hal_gpio_write(PORT_GSM_ON_OFF, PIN_GSM_ON_OFF, GPIO_SET);
	vTaskDelay(2000);
	hal_gpio_write(PORT_GSM_ON_OFF, PIN_GSM_ON_OFF, GPIO_RESET);
}
/******************************************************************************
 * @brief       Modem reset
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void Modem_reset(void) {

	PRINTF("Modem reset\n");
	hal_gpio_write(PORT_GSM_RESET, PIN_GSM_RESET, GPIO_SET);
	vTaskDelay(100);
	hal_gpio_write(PORT_GSM_RESET, PIN_GSM_RESET, GPIO_RESET);
}
/******************************************************************************
 * @brief       Power cycle reset
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void power_cycle_reset(void) {

	PRINTF("Power cycle reset\n");
	hal_gpio_write(PORT_3V8, PIN_3V8, GPIO_RESET);
	vTaskDelay(2000);
	hal_gpio_write(PORT_3V8, PIN_3V8, GPIO_SET);
	hal_gpio_write(PORT_GSM_RESET, PIN_GSM_RESET, GPIO_SET);
	hal_gpio_write(PORT_GSM_ON_OFF, PIN_GSM_ON_OFF, GPIO_SET);
	hal_gpio_write(PORT_GSM_RESET, PIN_GSM_RESET, GPIO_RESET);
	hal_gpio_write(PORT_GSM_ON_OFF, PIN_GSM_ON_OFF, GPIO_RESET);
	Cold_power_on();
}
/******************************************************************************
 * @brief       GSM init Reset flag
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_reset_flags(void) {

    gsm_device_state = GSM_RDY;
    gsm_init_state = GSM_CMD1;
    gsm_mqtt_state = MQTT_STATE_CFG;
    gsm_tcp_state = TCP_STATE_OPEN;
    gsm_http_state = HTTP_REQ_SET;
    gsm_ssl_state = SSL_CFG_CTX;
    gsm_fota_ssl_state = SSL_CFG_CTX;
    gsm_fota_state = FOTA_HTTP_REQ1;
    gsm_command_flag = 0;
    gsm_mqtt_connected_flag = 0;
    gsm_http_connected_flag = 0;
    gsm_tcp_connected_flag = 0;
}
/******************************************************************************
 * @brief       GSM Reset
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_reset(void) {

    gsm_reset_count++;
    PRINTF("GSM RESET COUNT:%d\n",gsm_reset_count);
    gsm_cbk(GSM_RESET_MODE);
    if (gsm_reset_count <= GSM_RESET_MAX_COUNT) {
    	Modem_reset();
    } else {
    	gsm_reset_count = 0;
    	power_cycle_reset();
    }
    gsm_reset_flags();
}
/******************************************************************************
 * @brief       GSM Engine
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void gsm_engine(void) {

    xSemaphoreTake(spiMutex, portMAX_DELAY);
    fota_status_get(&fota_meta_data);
    xSemaphoreGive(spiMutex);
	PRINTF("FOTA INFO:%u,%u\n", fota_meta_data.size, fota_meta_data.chunks);
	PRINTF("FOTA INFO:%s,%04X,%lu\n", fota_meta_data.fw_version, fota_meta_data.crc, fota_meta_data.epoch_time);
	gsm_config_set();
	while (1) {
		switch (gsm_device_state) {
		        case GSM_ON:
		        	 Cold_power_on();
		        	 gsm_device_state = GSM_RDY;
		        	 vTaskDelay(2000);
		             break;
		        case GSM_RDY:
                     if(gsm_ready_check(gsm_buf, gsm_buf_len)) {
   		        	    PRINTF("1.GSM READY>>\n");
   		        	    gsm_device_state = GSM_INIT;
   		        	    gsm_init_state = GSM_CMD1;
   		        	    gsm_buf_len = 0;
   		        	    gsm_command_flag = 0;
                     }
                     vTaskDelay(100);
		             break;
		        case GSM_RESET:
		             gsm_reset();
		             break;
		        case GSM_INIT:
		             gsm_init_engine();
		             break;
		        case GSM_MQTT:
		             gsm_mqtt_engine();
		             break;
		        case GSM_HTTP:
		             gsm_http_engine();
		             break;
		        case GSM_TCP:
		             gsm_tcp_engine();
		             break;
		        case GSM_FOTA_CHECK:
		        	 gsm_fota_check();
		             break;
		        case GSM_FOTA_SSL:
		        	 if (modbus_data.fota_ssl_flg) {
		        		 gsm_fota_ssl_engine();
		        	 } else {
		        		 gsm_device_state = GSM_FOTA;
		        	 }
		        	 break;
		        case GSM_SSL:
		        	 PRINTF("SSL ENGINE :%u\n", modbus_data.ssl_flg);
		        	 if (modbus_data.ssl_flg) {
		        		 gsm_ssl_engine();
		        	 } else {
		       		     if (modbus_data.cloud_data.mode == TCP_MODE) {
		       			     gsm_device_state = GSM_TCP;
		       		     } else if (modbus_data.cloud_data.mode == HTTP_MODE) {
		       			     gsm_device_state = GSM_HTTP;
		       		     } else {
		       			     gsm_device_state = GSM_MQTT;
		       		     }
		        	 }
		             break;
		        case GSM_SSL_FILE_HANDLE:
		        	 PRINTF("GSM FILE HANDLE\n");
		        	 if (ssl_cert_state & 1) {
		        		 gsm_ssl_file_handle_engine(SSL_CA_CERT_PUSH_STATE, 1);
		        	 }
		        	 if (ssl_cert_state & 2) {
		        		 gsm_ssl_file_handle_engine(SSL_CLIENT_CERT_PUSH_STATE, 1);
		        	 }
		        	 if (ssl_cert_state & 4) {
		        		 gsm_ssl_file_handle_engine(SSL_CLIENT_KEY_PUSH_STATE, 1);
		        	 }
	        		 if (fota_ssl_cert_state & 1) {
	        			 gsm_ssl_file_handle_engine(SSL_CA_CERT_PUSH_STATE, 0);
	        		 }
	        		 if (fota_ssl_cert_state & 2) {
	        			 gsm_ssl_file_handle_engine(SSL_CLIENT_CERT_PUSH_STATE, 0);
	        		 }
	        		 if (fota_ssl_cert_state & 4) {
	        			 gsm_ssl_file_handle_engine(SSL_CLIENT_KEY_PUSH_STATE, 0);
	        		 }
		        	 if (modbus_data.ssl_cfg_check == 0xFF) {
		        		 xSemaphoreTake(spiMutex, portMAX_DELAY);
		        		 device_ssl_file_handle_set(0);
		        		 xSemaphoreGive(spiMutex);
		        	 }
		        	 gsm_device_state = GSM_FOTA_CHECK;
		        	 break;
		        case GSM_FOTA:
		        	 gsm_fota_engine();
		        	 break;
		        default:
		            break;
		    }
		    vTaskDelay(100);
	}
}
