/**
  **************************
  * @file    gsm_engine.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Sep 8
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __GSM_ENGINE_H_
#define __GSM_ENGINE_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "modbus_gw_cfg.h"
/* Exported types ------------------------------------------------------------*/
 // Module control states
 typedef enum {
     GSM_ON,
     GSM_RDY,
     GSM_RESET,
     GSM_INIT,
 	 GSM_MQTT,
 	 GSM_HTTP,
 	 GSM_TCP,
     GSM_SSL,
 	 GSM_SSL_FILE_HANDLE,
 	 GSM_FOTA,
	 GSM_FOTA_CHECK,
	 GSM_FOTA_SSL,
 } gsm_device_state_t;

 // Initialization states
 typedef enum {
     GSM_CMD1,
     GSM_CMD2,
     GSM_CMD3,
     GSM_CMD4,
     GSM_CMD5,
     GSM_CMD6,
     GSM_CMD7,
     GSM_CMD8,
     GSM_CMD9,
     GSM_CMD10,
 	 GSM_CMD11,
	 INIT_FOTA,
 	 INIT_DONE
 } gsm_init_state_t;

 // Response types
 typedef enum {
     RESP_OK,
     RESP_MQTT_OK,
     RESP_IDLE_OK
 } gsm_response_t;

 typedef enum {
     MQTT_STATE_CFG,
     MQTT_STATE_OPEN,
	 MQTT_STATE_TMT,
     MQTT_STATE_CONN,
	 MQTT_STATE_SUB,
     MQTT_STATE_DONE,
     MQTT_STATE_ERROR
 } mqtt_state_t;

 typedef enum {
 	TCP_STATE_OPEN,
 	TCP_STATE_CONNECT,
 	TCP_STATE_DONE,
 } tcp_state_t;

 typedef enum {
 	HTTP_REQ_SET,
	HTTP_CNT_TYP_SET,
 	HTTP_URL_SET,
 	HTTP_STATE_DONE
 } http_state_t;

 typedef enum {
	 SSL_CFG_CTX,
 	 SSL_STATE_CA,
 	 SSL_STATE_CLIENT,
 	 SSL_STATE_KEY,
	 SSL_SNI,
	 SSL_CFG1,
	 SSL_CFG2,
	 SSL_CFG3,
 	 SSL_STATE_DONE
 } ssl_state_t;

 typedef enum {
 	SSL_CA_CERT_PUSH_STATE,
 	SSL_CLIENT_CERT_PUSH_STATE,
 	SSL_CLIENT_KEY_PUSH_STATE
 } ssl_cert_state_t;

 enum {
 	INIT_RESP,
 	MQTT_RESP,
 	TCP_RESP,
 	HTTP_RESP,
 	SSL_RESP,
 	FOTA_RESP
 };

 typedef enum {
 	FOTA_HTTP_REQ1,
 	FOTA_HTTP_REQ2,
 	FOTA_HTTP_URL,
 	FOTA_HTTP_GET,
 	FOTA_HTTP_READ,
 	FOTA_DONE
 }fota_state_t;

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/
#define TCP_MODE                            1
#define HTTP_MODE                           2
#define MQTT_MODE                           3
#define GSM_RESET_MODE                      4
#define MODBUS_WRT_MODE                     5

#define GSM_INIT_RESPONSE_TIMEOUT1           500  // 3000
#define GSM_INIT_RESPONSE_TIMEOUT2           5000

#define GSM_MQTT_RESPONSE_TIMEOUT1           500
#define GSM_MQTT_RESPONSE_TIMEOUT2           5000

#define GSM_TCP_RESPONSE_TIMEOUT1            500
#define GSM_TCP_RESPONSE_TIMEOUT2            5000

#define GSM_HTTP_RESPONSE_TIMEOUT1           500
#define GSM_HTTP_RESPONSE_TIMEOUT2           5000

#define FOTA_RESPONSE_TIMEOUT1               500
#define FOTA_RESPONSE_TIMEOUT2               5000

#define SSL_RESPONSE_TIMEOUT                1000

#define GSM_RESET_MAX_COUNT                 5

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/
 // Function prototypes

 void gsm_engine(void);
 uint8_t gsm_send_data_via_tcp(uint8_t* data, uint16_t data_len);
 uint8_t gsm_send_data_via_mqtt(uint8_t* data, uint16_t data_len);
 uint8_t gsm_send_data_via_http(uint8_t* data, uint16_t data_len);
 void gsm_engine_callback_register(void *cbk);
 void mb_wrt_callback_register(void *cbk);
 void gsm_config_set(void);
 void gsm_file_write(uint8_t *file, uint16_t file_len, uint8_t cert_type, uint8_t ssl_mode);

 void read_gsm_response(uint8_t *data, uint16_t len);
 void Cold_power_on(void);
 void gsm_RxBuffClear(void);
 void power_cycle_reset(void);
 void gsm_power_reset(void);
 void Modem_reset(void);

 uint8_t mb_wrt_rsp_via_mqtt(uint8_t* data, uint16_t data_len);

/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __FILENAME_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
