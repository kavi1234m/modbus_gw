/**
  **************************
  * @file    cJSON_parser_modbus_gw.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 11
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "cJSON_parser_modbus_gw.h"
#include "epoch_conversion.h"
#include "cJSON.h"
#include <string.h>
#include <math.h>
#include "lwip/inet.h"

uint8_t mac_addr[18];
uint8_t model_id[10];
uint8_t gsm_imei[16];

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

void mac_devid_set_for_cloud(uint8_t addr[6], const char id[10], const char imei[16]) {

    snprintf(mac_addr, sizeof(mac_addr),
             "%02X:%02X:%02X:%02X:%02X:%02X",
             addr[0], addr[1], addr[2],
             addr[3], addr[4], addr[5]);

    strncpy(model_id, id, sizeof(model_id) - 1);
    model_id[sizeof(model_id) - 1] = '\0';
    strncpy(gsm_imei, imei, sizeof(gsm_imei) - 1);
    gsm_imei[sizeof(gsm_imei) - 1] = '\0';
}
/**************************************************************************************************
 * @brief  Calendar to string
 * @param  addr  : mac address
 * @param  id    : model id
 * @return None
 ***************************************************************************************************/
void calendar_to_string(const calendar_info_t *cal, char *out, size_t out_len) {

    uint16_t full_year;
    /* If RTC gives year as 0�99 */
    if (cal->year < 100) {
        full_year = 2000 + cal->year;
    } else {
        full_year = cal->year;
    }
    /* Microseconds not available  fixed 000000 */
    snprintf(out, out_len, "%04u-%02u-%02u %02u:%02u:%02u.000000", full_year, cal->month, cal->date, cal->hour, cal->min, cal->sec);
}
#if !CUSTOM_JSON_PACKET
/**************************************************************************************************
 * @brief  Create RTU JSON packet from stored data
 * @param  channel_name : "RTU1", "RTU2", etc.
 * @param  dev          : Pointer to RTU device configuration
 * @param  input_data   : 2D buffer [num_points][max bytes] from Modbus read
 * @param  out_buf      : Output buffer for JSON string
 ***************************************************************************************************/
void create_rtu_json_packet(const char *channel_name, rtu_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf) {

    cJSON *root = cJSON_CreateObject();

    cJSON *gw_info = cJSON_CreateObject();
    cJSON_AddStringToObject(gw_info, "mac", mac_addr);
    cJSON_AddStringToObject(gw_info, "mid", model_id);
    cJSON_AddStringToObject(gw_info, "imei", gsm_imei);
    cJSON_AddItemToObject(root, "gw_info", gw_info);

    /* -------- Slave Info -------- */
    cJSON *slave_info = cJSON_CreateObject();
#if !EPOCH_TIME_IN_PKT
    char time_str[30];
    calendar_info_t real_time;
    epoch_to_calendar(cdev->timestamp, &real_time);
    calendar_to_string(&real_time, time_str, 30);
    cJSON_AddStringToObject(slave_info, "tsp", time_str);
#else
    cJSON_AddNumberToObject(slave_info, "tsp", cdev->timestamp);
#endif
    cJSON_AddStringToObject(slave_info, "dtp", dev->device_type);
    cJSON_AddStringToObject(slave_info, "dnm", dev->device_name);
    cJSON_AddStringToObject(slave_info, "ctp", channel_name);
    cJSON_AddNumberToObject(slave_info, "sid", dev->slave_id);
    cJSON_AddStringToObject(slave_info, "mtp", "live");
    cJSON_AddItemToObject(root, "slave_info", slave_info);

    /* -------- Modbus Data -------- */
    cJSON *modbus = cJSON_CreateObject();
    cJSON_AddNumberToObject(modbus, "dpc", dev->num_points);

    cJSON *dp = cJSON_CreateObject();

    for (int p = 0; p < dev->num_points; p++) {

        const cloud_point_t *pt = &cdev->points[p];
        data_type_t dtype   = dev->points[p].data_type;
        uint8_t reg_count   = dev->points[p].reg_count;

        if (dtype == DT_FLOAT) {
        	float f;
            memcpy(&f, &pt->data[0], sizeof(float));
            double num = (double)f * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        } else if (dtype == DT_UINT16) {

        	uint16_t v = (uint16_t)((pt->data[1] << 8) | pt->data[0]);
            double num = (double)v * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        } else if (dtype == DT_INT16) {

        	int16_t v = (int16_t)((pt->data[1] << 8) | pt->data[0]);
            double num = (double)v * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        } else if (dtype == DT_UINT32) {

        	uint32_t v = (uint32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
            double num = (double)v * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        } else if (dtype == DT_INT32) {

        	int32_t v = (int32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
            double num = (double)v * dev->points[p].scaling_factor;
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

        }  else if (dtype == DT_BOOL) {

        	uint8_t val = pt->data[0];
            cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, val);

        } else if(dtype == DT_DOUBLE) {

        	double d = 0;
        	memcpy(&d, &pt->data[0], sizeof(double));
        	d = d * dev->points[p].scaling_factor;
        	cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, d);
        }
    }

    cJSON_AddItemToObject(modbus, "dp", dp);
    cJSON_AddItemToObject(root, "modbus", modbus);

    if (!cJSON_PrintPreallocated(root, out_buf, JSON_OUT_BUF_SIZE, 0)) {
        PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
        PRINTF("\r\n %s ERROR PACKET:%s,>>>>%u,%p\n", channel_name, out_buf, strlen(out_buf), out_buf);
        out_buf[0] = '\0';
        cJSON_Delete(root);
        return;
    }
    cJSON_Delete(root);
}
/**********************************************************************************************************
 * @brief  Create TCP JSON packet from stored data
 * @param  channel_name : "TCP1", "TCP2", etc.
 * @param  dev          : Pointer to TCP device configuration
 * @param  input_data   : 2D buffer [num_points][max bytes] from Modbus read
 * @param  out_buf      : Output buffer for JSON string
 * @param  slave_ip     : TCP slave IP in uint32_t format (0x0101A8C0)
 ***********************************************************************************************************/
 void create_tcp_json_packet(const char *channel_name, tcp_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf) {

     cJSON *root = cJSON_CreateObject();

     cJSON *gw_info = cJSON_CreateObject();
     cJSON_AddStringToObject(gw_info, "mac", mac_addr);
     cJSON_AddStringToObject(gw_info, "mid", model_id);
     cJSON_AddStringToObject(gw_info, "imei", gsm_imei);
     cJSON_AddItemToObject(root, "gw_info", gw_info);

     /* -------- Slave Info -------- */
     cJSON *slave_info = cJSON_CreateObject();
#if !EPOCH_TIME_IN_PKT
    char time_str[30];
    calendar_info_t real_time;
    epoch_to_calendar(cdev->timestamp, &real_time);
    calendar_to_string(&real_time, time_str, 30);
    cJSON_AddStringToObject(slave_info, "tsp", time_str);
#else
    cJSON_AddNumberToObject(slave_info, "tsp", cdev->timestamp);
#endif
     cJSON_AddStringToObject(slave_info, "dtp", dev->device_type);
     cJSON_AddStringToObject(slave_info, "dnm", dev->device_name);
     cJSON_AddStringToObject(slave_info, "ctp", channel_name);
     cJSON_AddNumberToObject(slave_info, "sid", dev->slave_id);

     /* Convert uint32_t IP to dotted string */
     char ip_str[16];
     sprintf(ip_str, "%u.%u.%u.%u",
             (dev->slave_ip & 0xFF),
             (dev->slave_ip >> 8) & 0xFF,
             (dev->slave_ip >> 16) & 0xFF,
             (dev->slave_ip >> 24) & 0xFF);
     cJSON_AddStringToObject(slave_info, "ip", ip_str);

     cJSON_AddStringToObject(slave_info, "mtp", "live");
     cJSON_AddItemToObject(root, "slave_info", slave_info);

     /* -------- Modbus Data -------- */
     cJSON *modbus = cJSON_CreateObject();
     cJSON_AddNumberToObject(modbus, "dpc", dev->num_points);

     cJSON *dp = cJSON_CreateObject();

     for (int p = 0; p < dev->num_points; p++) {

         const cloud_point_t *pt = &cdev->points[p];
         data_type_t dtype   = dev->points[p].data_type;
         uint8_t reg_count   = dev->points[p].reg_count;

         if (dtype == DT_FLOAT) {
         	 float f;
             memcpy(&f, &pt->data[0], sizeof(float));
             double num = (double)f * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

         } else if (dtype == DT_UINT16) {

         	uint16_t v = (uint16_t)((pt->data[1] << 8) | pt->data[0]);
             double num = (double)v * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

         } else if (dtype == DT_INT16) {

         	int16_t v = (int16_t)((pt->data[1] << 8) | pt->data[0]);
             double num = (double)v * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

         } else if (dtype == DT_UINT32) {

         	uint32_t v = (uint32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
             double num = (double)v * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

         } else if (dtype == DT_INT32) {

         	int32_t v = (int32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
             double num = (double)v * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);

         }  else if (dtype == DT_BOOL) {

         	uint8_t val = pt->data[0];
             cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, val);

         } else if(dtype == DT_DOUBLE) {
         	double d = 0;
         	memcpy(&d, &pt->data[0], sizeof(double));
         	d = d * dev->points[p].scaling_factor;
         	cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, d);
         }
     }

     cJSON_AddItemToObject(modbus, "dp", dp);
     cJSON_AddItemToObject(root, "modbus", modbus);

     if (!cJSON_PrintPreallocated(root, out_buf, JSON_OUT_BUF_SIZE, 0)) {
         PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
         PRINTF("\r\n %s ERROR PACKET:%s,>>>>%u,%p\n", channel_name, out_buf, strlen(out_buf), out_buf);
         out_buf[0] = '\0';
         cJSON_Delete(root);
         return;
     }
     cJSON_Delete(root);
 }
 /******************************************************************************
  * @brief       Create data log json packet
  * @param[in]   None
  * @return      None
  ******************************************************************************/
 void create_data_log_json_packet(log_send_t *dev, uint8_t *out_buf)
 {
     cJSON *root = cJSON_CreateObject();

     /* --- Gateway Info --- */
     cJSON *gw_info = cJSON_CreateObject();
     cJSON_AddStringToObject(gw_info, "mac", mac_addr);
     cJSON_AddStringToObject(gw_info, "mid", model_id);
     cJSON_AddStringToObject(gw_info, "imei", gsm_imei);
     cJSON_AddItemToObject(root, "gw_info", gw_info);

     /* --- Slave Info --- */
     cJSON *slave_info = cJSON_CreateObject();
#if !EPOCH_TIME_IN_PKT
    char time_str[30];
    calendar_info_t real_time;
    epoch_to_calendar(dev->timestamp, &real_time);
    calendar_to_string(&real_time, time_str, 30);
    cJSON_AddStringToObject(slave_info, "tsp", time_str);
#else
    cJSON_AddNumberToObject(slave_info, "tsp", dev->timestamp);
#endif
//     cJSON_AddNumberToObject(slave_info, "tsp", dev->timestamp);
     cJSON_AddStringToObject(slave_info, "dtp", (char*)dev->device_type);
     cJSON_AddStringToObject(slave_info, "dnm", (char*)dev->device_name);

     switch (dev->channel_type)
     {
         case 1: cJSON_AddStringToObject(slave_info, "channel_type", "RTU1"); break;
         case 2: cJSON_AddStringToObject(slave_info, "channel_type", "RTU2"); break;
         case 3: cJSON_AddStringToObject(slave_info, "channel_type", "TCP1"); break;
         default: cJSON_AddStringToObject(slave_info, "channel_type", "RTU1"); break;
     }

     cJSON_AddNumberToObject(slave_info, "sid", dev->slave_id);

     if (dev->channel_type == 3)
     {
         char ip_str[16];
         sprintf(ip_str, "%u.%u.%u.%u",
                 (dev->slave_ip & 0xFF),
                 (dev->slave_ip >> 8) & 0xFF,
                 (dev->slave_ip >> 16) & 0xFF,
                 (dev->slave_ip >> 24) & 0xFF);
         cJSON_AddStringToObject(slave_info, "ip", ip_str);
     }

     cJSON_AddStringToObject(slave_info, "mtp", "log");
     cJSON_AddItemToObject(root, "slave_info", slave_info);

     /* --- Modbus Data Logging --- */
     cJSON *modbus = cJSON_CreateObject();
     cJSON_AddNumberToObject(modbus, "dpc", dev->num_points);

     cJSON *dp = cJSON_CreateObject();

     for (int p = 0; p < dev->num_points; p++)
     {
         log_point_t *src = &dev->points[p];
         uint8_t *buf = src->log_data;
         uint8_t reg_count = src->reg_count;
         switch (src->data_type)
         {
             case DT_FLOAT:
                  {
                     float f = 0;
                     memcpy(&f, &buf[0], sizeof(float));
                     double num = (double)f * dev->points[p].scaling_factor;
                     cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                  }
                  break;

             case DT_BOOL:
                  {
             	    uint8_t f = buf[0];
             	    cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, f);
                  }
                  break;

             case DT_UINT16:
                  {
                     uint16_t val = (uint16_t)((buf[1] << 8) | buf[0]);
                     double num = (double)val * dev->points[p].scaling_factor;
                     cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                  }
                  break;
             case DT_INT16:
                  {
                     int16_t val = (int16_t)((buf[1] << 8) | buf[0]);
                     double num = (double)val * dev->points[p].scaling_factor;
                     cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                  }
                  break;

             case DT_UINT32:
                  {
                     uint32_t val = (uint32_t)((buf[3] << 24) | (buf[2] << 16) | (buf[1] << 8)  | buf[0]);
                     double num = (double)val * dev->points[p].scaling_factor;
                     cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                  }
                  break;
             case DT_INT32:
                  {
                     int32_t val = (int32_t)((buf[3] << 24) | (buf[2] << 16) | (buf[1] << 8)  | buf[0]);
                     double num = (double)val * dev->points[p].scaling_factor;
                     cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, num);
                  }
                  break;
             case DT_DOUBLE:
                  {
             	      double d = 0;
             	      memcpy(&d, &buf[0], sizeof(double));
             	      d *=dev->points[p].scaling_factor;
             	      cJSON_AddNumberToObject(dp, (char*)dev->points[p].json_key, d);
                  }
             	 break;
         }
     }

     cJSON_AddItemToObject(modbus, "dp", dp);
     cJSON_AddItemToObject(root, "modbus", modbus);

     if (!cJSON_PrintPreallocated(root, out_buf, JSON_OUT_BUF_SIZE, 0)) {
         PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
         PRINTF("\r\n %s ERROR PACKET:%s,>>>>%u,%p\n", "Log", out_buf, strlen(out_buf), out_buf);
         out_buf[0] = '\0';
         cJSON_Delete(root);
         return;
     }
     cJSON_Delete(root);
 }
#else
 /**************************************************************************************************
  * @brief  Create RTU JSON packet from stored data
  * @param  channel_name : "RTU1", "RTU2", etc.
  * @param  dev          : Pointer to RTU device configuration
  * @param  input_data   : 2D buffer [num_points][max bytes] from Modbus read
  * @param  out_buf      : Output buffer for JSON string
  ***************************************************************************************************/
void create_custom_rtu_json_packet(const char *channel_name, rtu_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf) {

     cJSON *modbus = cJSON_CreateObject();

     for (int p = 0; p < dev->num_points; p++) {

         const cloud_point_t *pt = &cdev->points[p];
         data_type_t dtype   = dev->points[p].data_type;

         if (dtype == DT_FLOAT) {
         	float f;
             memcpy(&f, &pt->data[0], sizeof(float));
             double num = (double)f * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

         } else if (dtype == DT_UINT16) {

         	uint16_t v = (uint16_t)((pt->data[1] << 8) | pt->data[0]);
             double num = (double)v * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

         } else if (dtype == DT_INT16) {

         	int16_t v = (int16_t)((pt->data[1] << 8) | pt->data[0]);
             double num = (double)v * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

         } else if (dtype == DT_UINT32) {

         	uint32_t v = (uint32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
             double num = (double)v * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

         } else if (dtype == DT_INT32) {

         	int32_t v = (int32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
             double num = (double)v * dev->points[p].scaling_factor;
             cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

         }  else if (dtype == DT_BOOL) {

         	uint8_t val = pt->data[0];
             cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, val);

         } else if(dtype == DT_DOUBLE) {

         	double d = 0;
         	memcpy(&d, &pt->data[0], sizeof(double));
         	d = d * dev->points[p].scaling_factor;
         	cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, d);
         }
     }
     char time_str[30];
     calendar_info_t real_time;
     epoch_to_calendar(cdev->timestamp, &real_time);
     calendar_to_string(&real_time, time_str, 30);
     cJSON_AddStringToObject(modbus, "ts", time_str);

     cJSON_AddStringToObject(modbus, "devicename", (char*)dev->device_name);

     if (!cJSON_PrintPreallocated(modbus, out_buf, JSON_OUT_BUF_SIZE, 0)) {
         PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
         PRINTF("\r\n %s ERROR PACKET:%s,>>>>%u,%p\n", channel_name, out_buf, strlen(out_buf), out_buf);
         out_buf[0] = '\0';
         cJSON_Delete(modbus);
         return;
     }
     cJSON_Delete(modbus);
 }
 /**********************************************************************************************************
  * @brief  Create TCP JSON packet from stored data
  * @param  channel_name : "TCP1", "TCP2", etc.
  * @param  dev          : Pointer to TCP device configuration
  * @param  input_data   : 2D buffer [num_points][max bytes] from Modbus read
  * @param  out_buf      : Output buffer for JSON string
  * @param  slave_ip     : TCP slave IP in uint32_t format (0x0101A8C0)
  ***********************************************************************************************************/
void create_custom_tcp_json_packet(const char *channel_name, tcp_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf) {

      cJSON *modbus = cJSON_CreateObject();

      for (int p = 0; p < dev->num_points; p++) {

          const cloud_point_t *pt = &cdev->points[p];
          data_type_t dtype   = dev->points[p].data_type;
//          uint8_t reg_count   = dev->points[p].reg_count;

          if (dtype == DT_FLOAT) {
          	 float f;
              memcpy(&f, &pt->data[0], sizeof(float));
              double num = (double)f * dev->points[p].scaling_factor;
              cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

          } else if (dtype == DT_UINT16) {

          	uint16_t v = (uint16_t)((pt->data[1] << 8) | pt->data[0]);
              double num = (double)v * dev->points[p].scaling_factor;
              cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

          } else if (dtype == DT_INT16) {

          	int16_t v = (int16_t)((pt->data[1] << 8) | pt->data[0]);
              double num = (double)v * dev->points[p].scaling_factor;
              cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

          } else if (dtype == DT_UINT32) {

          	uint32_t v = (uint32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
              double num = (double)v * dev->points[p].scaling_factor;
              cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

          } else if (dtype == DT_INT32) {

          	int32_t v = (int32_t)((pt->data[3] << 24) | (pt->data[2] << 16) | (pt->data[1] << 8)  | pt->data[0]);
              double num = (double)v * dev->points[p].scaling_factor;
              cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);

          }  else if (dtype == DT_BOOL) {

          	uint8_t val = pt->data[0];
              cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, val);

          } else if(dtype == DT_DOUBLE) {
          	double d = 0;
          	memcpy(&d, &pt->data[0], sizeof(double));
          	d = d * dev->points[p].scaling_factor;
          	cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, d);
          }
      }

      char time_str[30];
      calendar_info_t real_time;
      epoch_to_calendar(cdev->timestamp, &real_time);
      calendar_to_string(&real_time, time_str, 30);
      cJSON_AddStringToObject(modbus, "ts", time_str);

      cJSON_AddStringToObject(modbus, "devicename", (char*)dev->device_name);

      if (!cJSON_PrintPreallocated(modbus, out_buf, JSON_OUT_BUF_SIZE, 0)) {
          PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
          PRINTF("\r\n %s ERROR PACKET:%s,>>>>%u,%p\n", channel_name, out_buf, strlen(out_buf), out_buf);
          out_buf[0] = '\0';
          cJSON_Delete(modbus);
          return;
      }
      cJSON_Delete(modbus);
  }
  /******************************************************************************
   * @brief       Create data log json packet
   * @param[in]   None
   * @return      None
   ******************************************************************************/
void create_custom_data_log_json_packet(log_send_t *dev, uint8_t *out_buf) {


      cJSON *modbus = cJSON_CreateObject();

      for (int p = 0; p < dev->num_points; p++)
      {
          log_point_t *src = &dev->points[p];
          uint8_t *buf = src->log_data;
//          uint8_t reg_count = src->reg_count;
          switch (src->data_type)
          {
              case DT_FLOAT:
                   {
                      float f = 0;
                      memcpy(&f, &buf[0], sizeof(float));
                      double num = (double)f * dev->points[p].scaling_factor;
                      cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                   }
                   break;

              case DT_BOOL:
                   {
              	    uint8_t f = buf[0];
              	    cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, f);
                   }
                   break;

              case DT_UINT16:
                   {
                      uint16_t val = (uint16_t)((buf[1] << 8) | buf[0]);
                      double num = (double)val * dev->points[p].scaling_factor;
                      cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                   }
                   break;
              case DT_INT16:
                   {
                      int16_t val = (int16_t)((buf[1] << 8) | buf[0]);
                      double num = (double)val * dev->points[p].scaling_factor;
                      cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                   }
                   break;

              case DT_UINT32:
                   {
                      uint32_t val = (uint32_t)((buf[3] << 24) | (buf[2] << 16) | (buf[1] << 8)  | buf[0]);
                      double num = (double)val * dev->points[p].scaling_factor;
                      cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                   }
                   break;
              case DT_INT32:
                   {
                      int32_t val = (int32_t)((buf[3] << 24) | (buf[2] << 16) | (buf[1] << 8)  | buf[0]);
                      double num = (double)val * dev->points[p].scaling_factor;
                      cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, num);
                   }
                   break;
              case DT_DOUBLE:
                   {
              	      double d = 0;
              	      memcpy(&d, &buf[0], sizeof(double));
              	      d *=dev->points[p].scaling_factor;
              	      cJSON_AddNumberToObject(modbus, (char*)dev->points[p].json_key, d);
                   }
              	 break;
          }
      }

      char time_str[30];
      calendar_info_t real_time;
      epoch_to_calendar(dev->timestamp, &real_time);
      calendar_to_string(&real_time, time_str, 30);
      cJSON_AddStringToObject(modbus, "ts", time_str);

      cJSON_AddStringToObject(modbus, "devicename", (char*)dev->device_name);

      if (!cJSON_PrintPreallocated(modbus, out_buf, JSON_OUT_BUF_SIZE, 0)) {
          PRINTF("DATA LOG JSON ERROR: buffer too small or heap fragmented\n");
          PRINTF("\r\n %s ERROR PACKET:%s,>>>>%u,%p\n", "Log", out_buf, strlen(out_buf), out_buf);
          out_buf[0] = '\0';
          cJSON_Delete(modbus);
          return;
      }
      cJSON_Delete(modbus);
  }
 #endif
/******************************************************************************
 * @brief       Copy RTU log
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void copy_rtu_log(rtu_device_t *dev,uint8_t chn_type, uint32_t timestamp, uint8_t data[MAX_POINTS][MAX_PAYLOAD], log_send_t *log_info) {

    memset(log_info, 0, sizeof(log_send_t));
    log_info->slave_id = dev->slave_id;
    log_info->slave_ip = 0;
    log_info->slave_port = 0;
    log_info->timestamp = timestamp;
    log_info->channel_type = chn_type;

    memcpy(log_info->device_type, dev->device_type, SIZEOF_JSON_KEY);
    memcpy(log_info->device_name, dev->device_name, SIZEOF_JSON_KEY);

    log_info->num_points = dev->num_points;

    for (int p = 0; p < dev->num_points; p++) {
        data_point_t *src = &dev->points[p];
        log_point_t *dst = &log_info->points[p];

        dst->reg_type      = src->reg_type;
        dst->start_address = src->start_address;
        dst->reg_count     = src->reg_count;
        dst->data_type     = src->data_type;
        dst->scaling_factor= src->scaling_factor;

        memcpy(dst->json_key, src->json_key, SIZEOF_JSON_KEY);
        memcpy(dst->log_data, data[p], MAX_PAYLOAD);
    }

}
/******************************************************************************
 * @brief       Copy tcp log
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void copy_tcp_log(tcp_device_t *dev, uint32_t timestamp, uint8_t data[MAX_POINTS][MAX_PAYLOAD], log_send_t *log_info) {

    memset(log_info, 0, sizeof(log_send_t));
    log_info->slave_id = dev->slave_id;
    log_info->slave_ip = dev->slave_ip;
    log_info->slave_port = dev->slave_port;
    log_info->timestamp = timestamp;
    log_info->channel_type = 3;

    memcpy(log_info->device_type, dev->device_type, SIZEOF_JSON_KEY);
    memcpy(log_info->device_name, dev->device_name, SIZEOF_JSON_KEY);

    log_info->num_points = dev->num_points;

    for (int p = 0; p < dev->num_points; p++) {
        data_point_t *src = &dev->points[p];
        log_point_t *dst = &log_info->points[p];

        dst->reg_type      = src->reg_type;
        dst->start_address = src->start_address;
        dst->reg_count     = src->reg_count;
        dst->data_type     = src->data_type;
        dst->scaling_factor= src->scaling_factor;

        memcpy(dst->json_key, src->json_key, SIZEOF_JSON_KEY);
        memcpy(dst->log_data, data[p], MAX_PAYLOAD);
    }
}
/******************************************************************************
 * @brief       parse json single key value function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_json_key_value(const char *json_packet, const char *json_key, uint8_t *value) {
    cJSON *json = cJSON_Parse(json_packet);
    if (!json) return 0;

    cJSON *item = cJSON_GetObjectItemCaseSensitive(json, json_key);
    if (!cJSON_IsString(item) || item->valuestring == NULL) {
        cJSON_Delete(json);
        return 0;
    }

    *value = (uint8_t)atoi(item->valuestring);  // Convert "01" to 1
    cJSON_Delete(json);
    return 1;
}
/******************************************************************************
 * @brief       Parse json config function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t parse_json_for_fresh_config(const char *json, fresh_device_config_t *config) {
    cJSON *root = cJSON_Parse(json);
    if (!root) return 0;

    cJSON *mac = cJSON_GetObjectItemCaseSensitive(root, "MAC");
    cJSON *dvt = cJSON_GetObjectItemCaseSensitive(root, "MID");
    cJSON *imei = cJSON_GetObjectItemCaseSensitive(root, "IMEI");

    if (!cJSON_IsString(mac) || !cJSON_IsString(dvt)|| !cJSON_IsString(imei)) {
        cJSON_Delete(root);
        return 0;
    }

    const char *mac_str = mac->valuestring;
    size_t len = strlen(mac_str);
    if (len != 12) {  // Must be 12 hex chars for 6 bytes
        cJSON_Delete(root);
        return 0;
    }

    // Convert MAC string (e.g., "020304050607") to 6 bytes
    for (int i = 0; i < 6; i++) {
        char byte_str[3] = { mac_str[i * 2], mac_str[i * 2 + 1], '\0' };
        config->mac_address[i] = (uint8_t)strtoul(byte_str, NULL, 16);
    }

    // Copy device type string
    strncpy(config->device_type_id, dvt->valuestring, sizeof(config->device_type_id) - 1);
    config->device_type_id[sizeof(config->device_type_id) - 1] = '\0';

    /* ---------- IMEI ---------- */
    if (strlen(imei->valuestring) != 15) {   // IMEI must be 15 digits
        cJSON_Delete(root);
        return 0;
    }
    strncpy((char *)config->imei,
            imei->valuestring,
            sizeof(config->imei) - 1);
    config->imei[sizeof(config->imei) - 1] = '\0';

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Function to create a json packet from the fresh device config structure fields
 * @param  config - config is a fresh device config structure variable
 * @param  seq_no - Sequence number of the json packet
 * @param  output_buffer - used for the storing of json packet
 * @retval Success - 1 Failed - 0
 **********************************************************************************************/
uint8_t prepare_read_back_response_for_fresh_device(fresh_device_config_t fresh_dv_cfg, uint8_t *output_buffer) {

	cJSON* root = cJSON_CreateObject();
    if(root == NULL){
    	return 0;
    }

    // Convert MAC address to hex string
    char mac_str[13];  // 12 hex chars + null
    for (int i = 0; i < 6; i++) {
        sprintf(&mac_str[i * 2], "%02X", fresh_dv_cfg.mac_address[i]);
    }

    // Build JSON
    cJSON_AddStringToObject(root, "MTP", "02");
    cJSON_AddStringToObject(root, "MAC", mac_str);
    cJSON_AddStringToObject(root, "MID", fresh_dv_cfg.device_type_id);
    cJSON_AddStringToObject(root, "IMEI", fresh_dv_cfg.imei);

    uint8_t *ptr = cJSON_PrintUnformatted(root);
    strcpy((uint8_t*)output_buffer, (uint8_t*)ptr);
    free(ptr);
    cJSON_Delete(root);
    return 1;
}
/******************************************************************************
 * @brief       function to check valid JSON
 * @param[in]   none
 * @return      none
 ******************************************************************************/
uint8_t is_valid_json(const char *json_buffer,uint16_t buffer_length) {

	const char *endptr = NULL;
	cJSON *root = cJSON_ParseWithLengthOpts(json_buffer, buffer_length, &endptr, 0);
	if (root == NULL || (endptr - json_buffer) != buffer_length) {
	    // Either parsing failed OR not all data was consumed
//	    printf("Invalid JSON or extra data\n");
	    return 0;
	} else {
		return 1;
	    // Valid and complete JSON
	}
}
/***********************************************************************************************
 * @brief  Function to create a packet from an input string
 * @param  input_buffer - input_buffer holds the input json packet
 * @param  status -  holds the status of the input packet
 * @param  output_buffer - holds the output string
 * @retval Success 1 failed 0
 **********************************************************************************************/
uint8_t prepare_response_with_status(uint8_t *input_buffer, uint8_t status,uint8_t *output_buffer) {

	cJSON *root = cJSON_CreateObject();    // root points to new packet
	if (root == NULL) {
		return 0;
	}

	cJSON *parse = cJSON_Parse((const char*)input_buffer);  //  parse points to input packet string
	if (!parse) {
		cJSON_Delete(root);
	    return 0;
	}

	cJSON *response = cJSON_CreateObject();
	if (response == NULL) {
		cJSON_Delete(root);
	    cJSON_Delete(parse);
	    return 0;
	}

    cJSON *item = NULL;
	cJSON_ArrayForEach(item, parse) {
		if (cJSON_IsString(item)) {
			cJSON_AddStringToObject(response, item->string, item->valuestring);
		}
	}

	cJSON_AddItemToObject(root, "RESPONSE", response);
    if (status == 1) {
    	cJSON_AddStringToObject(root, "STATUS", "OK");
    } else {
    	cJSON_AddStringToObject(root, "STATUS", "ERR");
    }

    uint8_t* ptr = cJSON_PrintUnformatted(root);
    strcpy((uint8_t*)output_buffer, (uint8_t*)ptr);
    free(ptr);
    cJSON_Delete(root);
    cJSON_Delete(parse);
    return 1;
}
/***********************************************************************************************
 * @brief  Function to prepare gsm response with status
 * @param  gsm_rsp
 * @param  status
 * @param  output_buffer - holds the output string
 * @retval None
 **********************************************************************************************/
void prepare_gsm_rsp_with_status(const char *gsm_rsp, uint8_t status_ok, uint8_t *output_buffer)
{
    if (output_buffer == NULL) return;

    const char *status = status_ok ? "OK" : "FAIL";

    snprintf((char *)output_buffer, 256,
             "{\"RESPONSE\":{\"AT_RSP\":\"%s\"},\"STATUS\":\"%s\"}",
             gsm_rsp ? gsm_rsp : "",
             status);
}
/***********************************************************************************************
 * @brief  Function for parse_fota_metadata_cjson
 * @param  json str
 * @param  fota_meta_t
 * @retval None
 **********************************************************************************************/
uint8_t parse_fota_metadata_cjson(const char *json_str, fota_meta_t *meta)
{
    if (!json_str || !meta)
        return 0;

    cJSON *root = cJSON_Parse(json_str);
    if (!root)
        return 0;

    const cJSON *fw_version = cJSON_GetObjectItem(root, "fw_version");
    const cJSON *size       = cJSON_GetObjectItem(root, "size");
    const cJSON *chunks     = cJSON_GetObjectItem(root, "chunks");
    const cJSON *update     = cJSON_GetObjectItem(root, "update");
    const cJSON *crc        = cJSON_GetObjectItem(root, "crc");

    /* Validate types */
    if (!cJSON_IsString(fw_version) ||
        !cJSON_IsNumber(size) ||
        !cJSON_IsNumber(chunks) ||
        !cJSON_IsString(update) ||
        !cJSON_IsString(crc))
    {
        cJSON_Delete(root);
        return 0;
    }

    /* Copy values */
    strncpy(meta->fw_version, fw_version->valuestring,
            sizeof(meta->fw_version) - 1);
    meta->fw_version[sizeof(meta->fw_version) - 1] = '\0';

    meta->size   = (uint32_t)size->valuedouble;
    meta->chunks = (uint32_t)chunks->valuedouble;

    meta->crc = (uint16_t)strtoul(crc->valuestring, NULL, 16);


    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Function for Parse opeartion
 * @param  ctp - channel type
 * @retval ctp type
 **********************************************************************************************/
static uint8_t parse_operation(const char *ctp)
{
    if (strcmp(ctp, "add") == 0) return 1;
    if (strcmp(ctp, "edit") == 0) return 2;
    if (strcmp(ctp, "delete") == 0) return 3;
    return 0;
}
/***********************************************************************************************
 * @brief  Function for map ctp string
 * @param  ctp - channel type
 * @retval ctp type
 **********************************************************************************************/
static uint8_t parse_ctp(const char *ctp)
{
    if (strcmp(ctp, "RTU1") == 0) return 1;
    if (strcmp(ctp, "RTU2") == 0) return 2;
    if (strcmp(ctp, "TCP") == 0) return 3;
    return 0;
}

/***********************************************************************************************
 * @brief  Function for map data type string
 * @param  dt - data type
 * @retval data type
 **********************************************************************************************/
static uint8_t parse_dtype(const char *dt)
{
    if (strcmp(dt, "float") == 0) return DT_FLOAT;
    if (strcmp(dt, "int16_t") == 0) return DT_INT16;
    if (strcmp(dt, "uint16_t") == 0) return DT_UINT16;
    if (strcmp(dt, "int32_t") == 0) return DT_INT32;
    if (strcmp(dt, "uint32_t") == 0) return DT_UINT32;
    if (strcmp(dt, "bool") == 0) return DT_BOOL;
    return 0;
}

/***********************************************************************************************
 * @brief  Function for parse json to modbus write struct
 * @param  json_str - input json
 * @param  out - out modbus write structure
 * @retval success or failure
 **********************************************************************************************/
uint8_t parse_json_to_mb(const char *json_str, mb_wrt_t *out) {


    if (!json_str || !out) return 0;

    cJSON *root = cJSON_Parse(json_str);
    if (!root) return 0;

    cJSON *pkt = cJSON_GetObjectItem(root, "pkt_type");
    cJSON *seq = cJSON_GetObjectItem(root, "seq");
    out->seq_no = seq->valueint;
    if (strcmp(pkt->valuestring, "mb_write_req") != 0)
    {
        PRINTF("Unsupported packet type\n");
        cJSON_Delete(root);
        return 0;
    }

    cJSON *mac = cJSON_GetObjectItem(root, "mac");
    if (cJSON_IsString(mac)) {
    	strncpy((char *)out->mac, mac->valuestring, sizeof(out->mac));
    }
    if (strncmp(out->mac, mac_addr, 17) != 0) {
    	PRINTF("MAC COMPARE FAILED\n");
    	cJSON_Delete(root);
    	return 0;
    }

    cJSON *ctp = cJSON_GetObjectItem(root, "ctp");
    if (cJSON_IsString(ctp)) {
    	out->ctp = parse_ctp(ctp->valuestring);
    }
    cJSON *ip = cJSON_GetObjectItem(root, "ip");
    if (cJSON_IsString(ip) && strcmp(ip->valuestring, "-") != 0) {
    	out->ip_addr = inet_addr(ip->valuestring);
    } else {
        out->ip_addr = 0;
    }
    out->port = cJSON_GetObjectItem(root, "port")->valueint;
    out->sid  = cJSON_GetObjectItem(root, "sid")->valueint;
    out->tmt  = cJSON_GetObjectItem(root, "tmt")->valueint;

    /* -------- modbus -------- */
    cJSON *modbus = cJSON_GetObjectItem(root, "modbus");
    if (modbus) {
        out->fc   = cJSON_GetObjectItem(modbus, "fc")->valueint;
        out->addr = cJSON_GetObjectItem(modbus, "addr")->valueint;

        cJSON *dt = cJSON_GetObjectItem(modbus, "dt_type");
        if (cJSON_IsString(dt)) {
            out->data_type = parse_dtype(dt->valuestring);
        }

        out->len = cJSON_GetObjectItem(modbus, "len")->valueint;
        cJSON *data_arr = cJSON_GetObjectItem(modbus, "data");
        if (cJSON_IsArray(data_arr))
        {
            int index = 0;
            int count = 0;

            cJSON *item = NULL;

            cJSON_ArrayForEach(item, data_arr)
            {
                if (count >= out->len) break;  // safety

                if (cJSON_IsNumber(item))
                {
                    switch (out->data_type)
                    {
                        case DT_FLOAT:
                        {
                            float val = (float)item->valuedouble;
                            memcpy(&out->data[index], &val, sizeof(float));
                            index += sizeof(float);
                            break;
                        }

                        case DT_INT16:
                        {
                            int16_t val = (int16_t)item->valueint;
                            memcpy(&out->data[index], &val, sizeof(int16_t));
                            index += sizeof(int16_t);
                            break;
                        }

                        case DT_UINT16:
                        {
                            uint16_t val = (uint16_t)item->valueint;
                            memcpy(&out->data[index], &val, sizeof(uint16_t));
                            index += sizeof(uint16_t);
                            break;
                        }

                        case DT_INT32:
                        {
                            int32_t val = (int32_t)item->valueint;
                            memcpy(&out->data[index], &val, sizeof(int32_t));
                            index += sizeof(int32_t);
                            break;
                        }

                        case DT_UINT32:
                        {
                            uint32_t val = (uint32_t)item->valueint;
                            memcpy(&out->data[index], &val, sizeof(uint32_t));
                            index += sizeof(uint32_t);
                            break;
                        }

                        case DT_BOOL:
                        {
                            uint8_t val = (uint8_t)(item->valueint ? 1 : 0);
                            out->data[index++] = val;
                            break;
                        }

                        default:
                            break;
                    }

                    count++;
                }
            }

            if ((out->data_type) == DT_BOOL) {
            	out->len = index;
            } else {
            	out->len = index/2;
            }
        }
    }
    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Get packet type string from enum value
 * @param  pkt_type - Packet type (uint8_t)
 * @note   Uses lookup table for faster access and scalability
 * @retval Pointer to string on success, "unknown" on invalid input
 **********************************************************************************************/
const char* get_pkt_type_str(uint8_t pkt_type)
{
    switch(pkt_type)
    {
        case 4: return "cfg_get_rsp";
        case 5: return "cfg_set_rsp";
        default: return "unknown";
    }
}
/***********************************************************************************************
 * @brief  Get configuration type string from enum value
 * @param  cfg_type - Configuration type (uint8_t)
 * @note   Uses lookup table for faster access and scalability
 * @retval Pointer to string on success, "unknown" on invalid input
 **********************************************************************************************/
const char* get_cfg_type_str(uint8_t cfg_type)
{
    switch(cfg_type)
    {
        case 1: return "nwk_cfg";
        case 2: return "cloud_cfg";
        case 3: return "serial_cfg";
        case 4: return "data_map";
        default: return "unknown";
    }
}
/***********************************************************************************************
 * @brief  Convert data type enum to corresponding string representation
 * @param  type - Data type (DT_BOOL, DT_INT16, DT_UINT16, DT_INT32, DT_UINT32, DT_FLOAT, DT_DOUBLE)
 * @retval Pointer to constant string representing the data type
 **********************************************************************************************/
static const char* data_type_to_str(uint8_t type)
{
    switch(type)
    {
        case DT_BOOL:   return "bool";
        case DT_INT16:  return "int16";
        case DT_UINT16: return "uint16";
        case DT_INT32:  return "int32";
        case DT_UINT32: return "uint32";
        case DT_FLOAT:  return "float";
        case DT_DOUBLE: return "double";
        default:        return "uint16_t";
    }
}
/***********************************************************************************************
 * @brief  Convert parity value to string representation
 * @param  parity - Parity type ('N' = None, 'E' = Even, 'O' = Odd)
 * @retval Pointer to constant string representing parity ("N", "E", "O")
 **********************************************************************************************/
static const char* parity_to_str(uint8_t parity)
{
    switch (parity)
    {
        case 'E': return "E";   // Even
        case 'O': return "O";   // Odd
        case 'N':
        default:  return "N";   // None
    }
}
/***********************************************************************************************
 * @brief  Convert 32-bit IP address to dotted decimal string format
 * @param  ip  - IPv4 address in uint32_t format
 * @param  buf - Pointer to buffer (minimum 16 bytes) to store string
 * @note   Assumes IP is stored in little-endian format
 * @retval None
 **********************************************************************************************/
static void ip_to_string(uint32_t ip, char *buf)
{
    sprintf(buf, "%u.%u.%u.%u",
            (unsigned int)(ip & 0xFF),
            (unsigned int)((ip >> 8) & 0xFF),
            (unsigned int)((ip >> 16) & 0xFF),
            (unsigned int)((ip >> 24) & 0xFF));
}
/***********************************************************************************************
 * @brief  Convert Operation (CTP) to string representation
 * @param  ctp - Channel type (1 = RTU1, 2 = RTU2, 3 = TCP)
 * @retval Pointer to constant string representing channel type ("RTU1", "RTU2", "TCP")
 **********************************************************************************************/
char* op_to_string(uint8_t op)
{
    switch (op)
    {
        case 1: return "add";
        case 2: return "edit";
        case 3: return "delete";
        default: return "add";
    }
}
/***********************************************************************************************
 * @brief  Convert channel type (CTP) to string representation
 * @param  ctp - Channel type (1 = RTU1, 2 = RTU2, 3 = TCP)
 * @retval Pointer to constant string representing channel type ("RTU1", "RTU2", "TCP")
 **********************************************************************************************/
char* ctp_to_string(uint8_t ctp)
{
    switch (ctp)
    {
        case 1: return "RTU1";
        case 2: return "RTU2";
        case 3: return "TCP";
        default: return "RTU1";
    }
}
/***********************************************************************************************
 * @brief  Function for prepare modbus write response
 * @param  out_buf - output json
 * @param  buf_size - output json buffer size
 * @param  evt- input modbus write structure
 * @param  status - modbus write status
 * @retval success or failure
 **********************************************************************************************/
int prepare_mb_wrt_response(char *out_buf, size_t buf_size, const mb_wrt_t *evt, const char *status) {

    if (!out_buf || !evt || !status) return -1;

    cJSON *root = cJSON_CreateObject();
    if (!root) return -1;

    cJSON_AddStringToObject(root, "mac", evt->mac);
    cJSON_AddStringToObject(root, "pkt_type", "mb_write_rsp");
    cJSON_AddNumberToObject(root, "seq", evt->seq_no);

    cJSON_AddStringToObject(root, "ctp", ctp_to_string(evt->ctp));

    if (evt->ip_addr != 0)
    {
        char ip_str[16];
        snprintf(ip_str, sizeof(ip_str), "%u.%u.%u.%u",
                 (evt->ip_addr) & 0xFF,
                 (evt->ip_addr >> 8) & 0xFF,
                 (evt->ip_addr >> 16) & 0xFF,
                 (evt->ip_addr >> 24) & 0xFF);

        cJSON_AddStringToObject(root, "ip", ip_str);
    } else {
        cJSON_AddStringToObject(root, "ip", "-");
    }

    cJSON_AddNumberToObject(root, "port", evt->port);
    cJSON_AddNumberToObject(root, "sid", evt->sid);
    cJSON_AddNumberToObject(root, "tmt", evt->tmt);


    /* -------- modbus -------- */
    cJSON *modbus = cJSON_CreateObject();
    cJSON_AddStringToObject(modbus, "status", status);
    cJSON_AddItemToObject(root, "modbus", modbus);

    /* -------- Print JSON -------- */
    char *json_str = cJSON_PrintUnformatted(root);
    if (!json_str)
    {
        cJSON_Delete(root);
        return -1;
    }

    strncpy(out_buf, json_str, buf_size - 1);
    out_buf[buf_size - 1] = '\0';

    cJSON_free(json_str);
    cJSON_Delete(root);

    return 0;
}

/***********************************************************************************************
 * @brief  Function for Extract json
 * @param  input - input buffer
 * @param  output - output JSON
 * @param  max_len - output json buffer size
 * @retval ctp
 **********************************************************************************************/
uint8_t extract_json_quoted(char *input, char *output, int max_len)
{
    if (!input || !output) return 0;

    //  Step 1: Find +QMTRECV
    char *start = strstr(input, "+QMTRECV:");
    if (!start) return 0;

    //  Step 2: Find '"' followed by '{'
    char *p = start;
    while (*p)
    {
        if (*p == '"' && *(p + 1) == '{')
        {
            char *json_start = p + 1; // points to '{'
            int brace_count = 0;

            char *q = json_start;

            while (*q)
            {
                if (*q == '{')
                    brace_count++;
                else if (*q == '}')
                    brace_count--;

                //  JSON complete
                if (brace_count == 0)
                {
                    // Ensure closing quote
                    if (*(q + 1) == '"')
                    {
                        int len = q - json_start + 1;

                        if (len >= max_len)
                            return 0; // buffer too small

                        memcpy(output, json_start, len);
                        output[len] = '\0';

                        return len; // success
                    }
                }

                q++;
            }

            // JSON not complete yet (wait for more UART data)
            return 0;
        }

        p++;
    }

    return 0; // not found
}

/***********************************************************************************************
 * @brief  Function for Extract remote cfg json
 * @param  json - input buffer
 * @retval pkt type
 **********************************************************************************************/
uint8_t parse_remote_cfg(const char *json, pkt_type_t *pkt, cfg_type_t *cfg_type_enum)
{
    if (!json) return 0;

    cJSON *root = cJSON_Parse(json);
    if (!root) return 0;

    /* -------- MAC CHECK -------- */
    cJSON *mac = cJSON_GetObjectItem(root, "mac");
    if (!cJSON_IsString(mac)) {
        cJSON_Delete(root);
        return 0;
    }

    if (strncmp(mac->valuestring, (char *)mac_addr, 17) != 0) {
        PRINTF("MAC mismatch\n");
        cJSON_Delete(root);
        return 0;
    }

    /* -------- PACKET TYPE -------- */
    cJSON *pkt_type = cJSON_GetObjectItem(root, "pkt_type");

    if (cJSON_IsString(pkt_type)) {
        if (!strcmp(pkt_type->valuestring, "cfg_start")) {
            *pkt = PKT_CFG_START;
        } else if (!strcmp(pkt_type->valuestring, "cfg_finish")) {
            *pkt = PKT_CFG_FINISH;
        } else if (!strcmp(pkt_type->valuestring, "factory_reset")) {
            *pkt = PKT_FACTORY_RESET;
        } else if (!strcmp(pkt_type->valuestring, "cfg_get_req")) {
            *pkt = PKT_CFG_GET_REQ;
        } else if (!strcmp(pkt_type->valuestring, "cfg_set_req")) {
            *pkt = PKT_CFG_SET_REQ;
        }else if (!strcmp(pkt_type->valuestring, "mb_write_req")) {
            *pkt = PKT_MB_WRT_REQ;
        } else {
        	return 0;
        }
    }

    /* -------- CONFIG TYPE -------- */
    cJSON *cfg_type = cJSON_GetObjectItem(root, "cfg_type");

    if (cJSON_IsString(cfg_type)) {
        if (!strcmp(cfg_type->valuestring, "nwk_cfg")) {
            *cfg_type_enum = CFG_NWK;
        } else if (!strcmp(cfg_type->valuestring, "cloud_cfg")) {
            *cfg_type_enum = CFG_CLOUD;
        } else if (!strcmp(cfg_type->valuestring, "serial_cfg")) {
            *cfg_type_enum = CFG_SERIAL;
        } else if (!strcmp(cfg_type->valuestring, "data_map")) {
            *cfg_type_enum = CFG_DATA_MAP;
        } else {
        	return 0;
        }
    }

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Parse data_map cfg_get request and convert ctp string to numeric
 * @param  input_json - input JSON string
 * @param  ctp_out    - pointer to store mapped value (1=RTU1, 2=RTU2, 3=TCP)
 * @param  dev_no_out - pointer to store device number (0-based)
 * @retval 1 on success, 0 on failure
 ***********************************************************************************************/
uint8_t parse_data_map_get_req(const char *input_json, uint8_t *ctp_out, uint8_t *dev_no_out, uint8_t *operation)
{
    if (input_json == NULL || ctp_out == NULL || dev_no_out == NULL)
        return 0;

    cJSON *root = cJSON_Parse(input_json);
    if (!root)
        return 0;

    /* Extract ctp (STRING) */
    cJSON *ctp = cJSON_GetObjectItem(root, "ctp");
    if (!cJSON_IsString(ctp) || ctp->valuestring == NULL)
    {
        cJSON_Delete(root);
        return 0;
    }

    /* Convert string numeric */
    if (strcmp(ctp->valuestring, "RTU1") == 0)
        *ctp_out = 1;
    else if (strcmp(ctp->valuestring, "RTU2") == 0)
        *ctp_out = 2;
    else if (strcmp(ctp->valuestring, "TCP") == 0)
        *ctp_out = 3;
    else
    {
        cJSON_Delete(root);
        return 0; // invalid ctp
    }

    /* Extract dev_no */
    cJSON *dev_no = cJSON_GetObjectItem(root, "dev_no");
    if (!cJSON_IsNumber(dev_no))
    {
        cJSON_Delete(root);
        return 0;
    }

    cJSON *op     = cJSON_GetObjectItem(root, "op");

    *operation = parse_operation(op->valuestring);
//    if (strcmp(op->valuestring, "add") == 0) {
//    	*operation = 1;
//    } else if (strcmp(op->valuestring, "edit") == 0) {
//        *operation = 2;
//    } else if (strcmp(op->valuestring, "delete") == 0) {
//        *operation = 3;
//    } else {
//        cJSON_Delete(root);
//        return 0; // invalid ctp
//    }

    *dev_no_out = (uint8_t)(dev_no->valueint - 1); // convert to 0-based

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Prepare network configuration GET response JSON
 * @param  cfg      - Pointer to modbus configuration structure
 * @param  out_json - Pointer to output buffer to store JSON string
 * @note   Converts IP addresses to string format and fills network parameters
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t prepare_nwk_cfg_get_response(modbus_cfg_t *cfg, uint8_t *out_json)
{
    if (cfg == NULL || out_json == NULL)
        return 0;

    char ip[16], sn[16], gw[16];

    // Convert IPs to string
    ip_to_string(cfg->network_data.ipv4_address, ip);
    ip_to_string(cfg->network_data.subnet_mask, sn);
    ip_to_string(cfg->network_data.default_gateway, gw);

    cJSON *root = cJSON_CreateObject();
    if (!root) return 0;

    cJSON_AddStringToObject(root, "mac", mac_addr);
    cJSON_AddStringToObject(root, "pkt_type", "cfg_get_rsp");
    cJSON_AddStringToObject(root, "cfg_type", "nwk_cfg");

    cJSON *data = cJSON_CreateObject();
    if (!data)
    {
        cJSON_Delete(root);
        return 0;
    }

    // Add network parameters
    cJSON_AddStringToObject(data, "ip_addr", ip);
    cJSON_AddStringToObject(data, "sn_addr", sn);
    cJSON_AddStringToObject(data, "gw_addr", gw);
    cJSON_AddStringToObject(data, "apn", (char *)cfg->network_data.apn);
    cJSON_AddStringToObject(data, "usr", (char *)cfg->network_data.username);
    cJSON_AddStringToObject(data, "pw",  (char *)cfg->network_data.password);

    cJSON_AddItemToObject(root, "data", data);

    // Print to buffer (no malloc)
    if (!cJSON_PrintPreallocated(root, (char *)out_json, REMOTE_CFG_BUF_LEN, 0))
    {
        cJSON_Delete(root);
        return 0; // buffer too small
    }

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Prepare cloud configuration GET response JSON
 * @param  cfg      - Pointer to modbus configuration structure
 * @param  out_json - Pointer to output buffer to store JSON string
 * @note   Fills response based on selected cloud mode (HTTP, TCP, MQTT)
 *         Unused protocol fields are returned as empty strings
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t prepare_cloud_cfg_get_response(modbus_cfg_t *cfg, uint8_t *out_json)
{
    if (cfg == NULL || out_json == NULL)
        return 0;

    cJSON *root = cJSON_CreateObject();
    if (!root) return 0;

    cJSON_AddStringToObject(root, "mac", mac_addr);
    cJSON_AddStringToObject(root, "pkt_type", "cfg_get_rsp");
    cJSON_AddStringToObject(root, "cfg_type", "cloud_cfg");

    char* proto_typ;
    if (cfg->cloud_data.mode == CLOUD_MODE_TCP) {
    	proto_typ = "HTTP";
    } else if (cfg->cloud_data.mode == CLOUD_MODE_TCP) {
    	proto_typ = "TCP";
    } else {
    	proto_typ = "MQTT";
    }
    cJSON_AddStringToObject(root, "protocol", proto_typ);
    cJSON *data = cJSON_CreateObject();
    if (!data)
    {
        cJSON_Delete(root);
        return 0;
    }

    /* Initialize all fields as empty */
    cJSON_AddStringToObject(data, "httpurl", "");
    cJSON_AddStringToObject(data, "httptype", "");
    cJSON_AddStringToObject(data, "tcpurl", "");
    cJSON_AddStringToObject(data, "tcpport", "");
    cJSON_AddStringToObject(data, "mqtturl", "");
    cJSON_AddStringToObject(data, "mqttport", "");
    cJSON_AddStringToObject(data, "mqttqos", "");
    cJSON_AddStringToObject(data, "mqttcid", "");
    cJSON_AddStringToObject(data, "mqttpubtopic", "");
    cJSON_AddStringToObject(data, "mqttreqtopic", "");
    cJSON_AddStringToObject(data, "mqttrsptopic", "");
    cJSON_AddStringToObject(data, "mqttun", "");
    cJSON_AddStringToObject(data, "mqttpw", "");

    /* Fill based on mode */
    switch (cfg->cloud_data.mode)
    {
        case CLOUD_MODE_HTTP:
        {
            cJSON_ReplaceItemInObject(data, "httpurl",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.http.url));

                cJSON_ReplaceItemInObject(data, "httptype", cJSON_CreateString("POST"));
        }
        break;

        case CLOUD_MODE_TCP:
        {
//            char port_str[8];
//            sprintf(port_str, "%u", cfg->cloud_data.cfg.tcp.port);

            cJSON_ReplaceItemInObject(data, "tcpurl",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.tcp.url));

            cJSON_ReplaceItemInObject(data, "tcpport",
                cJSON_CreateNumber(cfg->cloud_data.cfg.tcp.port));
        }
        break;

        case CLOUD_MODE_MQTT:
        {
//            char port_str[8];
//            char qos_str[4];

//            sprintf(port_str, "%u", cfg->cloud_data.cfg.mqtt.port);
//            sprintf(qos_str, "%u", cfg->cloud_data.cfg.mqtt.qos);

            cJSON_ReplaceItemInObject(data, "mqtturl",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.mqtt.url));

            cJSON_ReplaceItemInObject(data, "mqttport",
            		cJSON_CreateNumber(cfg->cloud_data.cfg.mqtt.port));

            cJSON_ReplaceItemInObject(data, "mqttqos",
            		cJSON_CreateNumber(cfg->cloud_data.cfg.mqtt.qos));

            cJSON_ReplaceItemInObject(data, "mqttcid",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.mqtt.client_id));

            cJSON_ReplaceItemInObject(data, "mqttpubtopic",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.mqtt.pub_topic));

            cJSON_ReplaceItemInObject(data, "mqttreqtopic",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.mqtt.cfg_req_topic));

            cJSON_ReplaceItemInObject(data, "mqttrsptopic",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.mqtt.cfg_rsp_topic));

            cJSON_ReplaceItemInObject(data, "mqttun",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.mqtt.username));

            cJSON_ReplaceItemInObject(data, "mqttpw",
                cJSON_CreateString((char *)cfg->cloud_data.cfg.mqtt.password));
        }
        break;

        default:
            break;
    }

    cJSON_AddItemToObject(root, "data", data);

    // Print to buffer
    if (!cJSON_PrintPreallocated(root, (char *)out_json, REMOTE_CFG_BUF_LEN, 0))
    {
        cJSON_Delete(root);
        return 0;
    }

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Prepare serial configuration GET response JSON
 * @param  cfg      - Pointer to modbus configuration structure
 * @param  out_json - Pointer to output buffer to store JSON string
 * @note   Includes configuration for both serial channels (channel1 & channel2)
 *         Converts parity to string representation
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t prepare_serial_cfg_get_response(modbus_cfg_t *cfg, uint8_t *out_json)
{
    if (cfg == NULL || out_json == NULL)
        return 0;

    cJSON *root = cJSON_CreateObject();
    if (!root) return 0;

    cJSON_AddStringToObject(root, "mac", mac_addr);
    cJSON_AddStringToObject(root, "pkt_type", "cfg_get_rsp");
    cJSON_AddStringToObject(root, "cfg_type", "serial_cfg");

    cJSON *data = cJSON_CreateObject();
    if (!data)
    {
        cJSON_Delete(root);
        return 0;
    }

    // Channel 1
    cJSON_AddNumberToObject(data, "br1", cfg->serial_data.channel1.baud_rate);
    cJSON_AddNumberToObject(data, "db1", cfg->serial_data.channel1.data_bits);
    cJSON_AddStringToObject(data, "pb1", parity_to_str(cfg->serial_data.channel1.parity));
    cJSON_AddNumberToObject(data, "sb1", cfg->serial_data.channel1.stop_bits);

    // Channel 2
    cJSON_AddNumberToObject(data, "br2", cfg->serial_data.channel2.baud_rate);
    cJSON_AddNumberToObject(data, "db2", cfg->serial_data.channel2.data_bits);
    cJSON_AddStringToObject(data, "pb2", parity_to_str(cfg->serial_data.channel2.parity));
    cJSON_AddNumberToObject(data, "sb2", cfg->serial_data.channel2.stop_bits);

    cJSON_AddItemToObject(root, "data", data);

    // Print JSON into preallocated buffer
    if (!cJSON_PrintPreallocated(root, (char *)out_json, REMOTE_CFG_BUF_LEN, 0))
    {
        cJSON_Delete(root);
        return 0; // buffer too small
    }

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Prepare data mapping configuration GET response JSON
 * @param  cfg      - Pointer to modbus configuration structure
 * @param  chn_type - Channel type (1 = RTU1, 2 = RTU2, 3 = TCP)
 * @param  dev_no   - Device index (0-based)
 * @param  out_json - Pointer to output buffer to store JSON string
 * @note   Generates device configuration and modbus data points based on channel type
 *         For RTU: IP and port fields are empty
 *         For TCP: IP and port are included
 *         dev_no is converted to 1-based index in response
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t prepare_data_map_get_response(modbus_cfg_t *cfg, uint8_t chn_type, uint8_t dev_no, uint8_t *out_json) {

    if (!cfg || !out_json) return 0;

    cJSON *root = cJSON_CreateObject();
    if (!root) return 0;

    char *ctp;

    ctp = ctp_to_string(chn_type);

    cJSON_AddStringToObject(root, "mac", mac_addr);
    cJSON_AddStringToObject(root, "pkt_type", "cfg_get_rsp");
    cJSON_AddStringToObject(root, "cfg_type", "data_map");
    cJSON_AddStringToObject(root, "ctp", ctp);
    cJSON_AddNumberToObject(root, "dev_no", (dev_no + 1));

    cJSON *data = cJSON_CreateObject();
    if (!data)
    {
        cJSON_Delete(root);
        return 0;
    }

    cJSON *modbus_arr = cJSON_CreateArray();

    /* ---------------- RTU1 / RTU2 ---------------- */
    if (strcmp(ctp, "RTU1") == 0 || strcmp(ctp, "RTU2") == 0)
    {
        rtu_data_mapping_t *rtu =
            (strcmp(ctp, "RTU1") == 0) ? &cfg->rtu_port_1 : &cfg->rtu_port_2;
        PRINTF("RTU DEV NO:%u\n", dev_no);
        if (dev_no >= rtu->num_devices)
        {
            cJSON_Delete(root);
            return 0;
        }
        rtu_device_t *dev = &rtu->devices[dev_no];

        // Device info
        cJSON_AddNumberToObject(data, "sid", dev->slave_id);
        cJSON_AddStringToObject(data, "ip", "");   // not applicable
        cJSON_AddStringToObject(data, "prt", "");

        cJSON_AddStringToObject(data, "dtp", (char*)dev->device_type);
        cJSON_AddStringToObject(data, "dnm", (char*)dev->device_name);

        cJSON_AddNumberToObject(data, "rsp_tmt", dev->response_timeout_ms);
        cJSON_AddNumberToObject(data, "dpc", dev->num_points);

        // Modbus points
        for (uint8_t i = 0; i < dev->num_points; i++)
        {
            data_point_t *pt = &dev->points[i];

            cJSON *obj = cJSON_CreateObject();

            uint8_t fc;
            if (pt->reg_type == REG_COIL) {
            	fc = 1;
            } else if (pt->reg_type == REG_DISCRETE_INPUT) {
            	fc = 2;
            } else if (pt->reg_type == REG_HOLDING_REGISTER) {
            	fc = 3;
            } else {
            	fc = 4;
            }
            cJSON_AddNumberToObject(obj, "fc", fc);
            cJSON_AddNumberToObject(obj, "addr", pt->start_address);
            cJSON_AddStringToObject(obj, "data_typ", data_type_to_str(pt->data_type));
            cJSON_AddNumberToObject(obj, "sf", pt->scaling_factor);
            cJSON_AddStringToObject(obj, "key", (char*)pt->json_key);

            cJSON_AddItemToArray(modbus_arr, obj);
        }
    }

    /* ---------------- TCP ---------------- */
    else if (strcmp(ctp, "TCP") == 0)
    {
        tcp_data_mapping_t *tcp = &cfg->tcp_port;

        if (dev_no >= tcp->num_devices)
        {
            cJSON_Delete(root);
            return 0;
        }

        tcp_device_t *dev = &tcp->devices[dev_no];

        char ip[16];
        ip_to_string(dev->slave_ip, ip);
//        sprintf(port, "%u", dev->slave_port);

        // Device info
        cJSON_AddNumberToObject(data, "sid", dev->slave_id);
        cJSON_AddStringToObject(data, "ip", ip);
        cJSON_AddNumberToObject(data, "prt", dev->slave_port);

        cJSON_AddStringToObject(data, "dtp", (char*)dev->device_type);
        cJSON_AddStringToObject(data, "dnm", (char*)dev->device_name);

        cJSON_AddNumberToObject(data, "rsp_tmt", dev->response_timeout_ms);
        cJSON_AddNumberToObject(data, "dpc", dev->num_points);

        // Modbus points
        for (uint8_t i = 0; i < dev->num_points; i++)
        {
            data_point_t *pt = &dev->points[i];

            cJSON *obj = cJSON_CreateObject();
            uint8_t fc;
            if (pt->reg_type == REG_COIL) {
            	fc = 1;
            } else if (pt->reg_type == REG_DISCRETE_INPUT) {
            	fc = 2;
            } else if (pt->reg_type == REG_HOLDING_REGISTER) {
            	fc = 3;
            } else {
            	fc = 4;
            }
            cJSON_AddNumberToObject(obj, "fc", fc);
            cJSON_AddNumberToObject(obj, "addr", pt->start_address);
            cJSON_AddStringToObject(obj, "data_typ", data_type_to_str(pt->data_type));
            cJSON_AddNumberToObject(obj, "sf", pt->scaling_factor);
            cJSON_AddStringToObject(obj, "key", (char*)pt->json_key);

            cJSON_AddItemToArray(modbus_arr, obj);
        }
    }

    else
    {
        cJSON_Delete(root);
        return 0;
    }

    cJSON_AddItemToObject(data, "modbus", modbus_arr);
    cJSON_AddItemToObject(root, "data", data);

    if (!cJSON_PrintPreallocated(root, (char *)out_json, REMOTE_CFG_BUF_LEN, 0))
    {
//    	printf("data map error\n");
        cJSON_Delete(root);
        return 0;
    }
//    printf("data map success\n");
    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Create configuration FAIL response JSON packet
 * @param  out_buf  - Pointer to output buffer to store JSON string
 * @param  pkt_type - Packet type (uint8_t mapped to string)
 * @param  cfg_type - Configuration type (uint8_t mapped to string)
 * @param  sts      - Status (1 = success, 0 = fail)
 * @param  ctp      - Connection type (used only when cfg_type is data_map)
 * @param  dev_no   - Device number (1-based, used only when cfg_type is data_map)
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t create_cfg_packet_rsp(char *out_buf, uint8_t pkt_type, uint8_t cfg_type, uint8_t sts, uint8_t ctp, uint8_t dev_no, uint8_t operation)
{
    if (out_buf == NULL)
        return 0;

    const char *pkt_type_str = get_pkt_type_str(pkt_type);
    const char *cfg_type_str = get_cfg_type_str(cfg_type);

    if (pkt_type_str == NULL || cfg_type_str == NULL)
        return 0;

    cJSON *root = cJSON_CreateObject();
    if (root == NULL)
        return 0;

    cJSON_AddStringToObject(root, "mac", mac_addr);
    cJSON_AddStringToObject(root, "pkt_type", pkt_type_str);
    cJSON_AddStringToObject(root, "cfg_type", cfg_type_str);

    /*  Add ctp & dev_no ONLY for data_map */
    if (cfg_type == CFG_DATA_MAP)
    {
    	char *ctp_str;
    	char *op_str;
        ctp_str = ctp_to_string(ctp);
        op_str = op_to_string(operation);
        cJSON_AddStringToObject(root, "ctp", ctp_str);
        cJSON_AddStringToObject(root, "op", op_str);
        cJSON_AddNumberToObject(root, "dev_no", (dev_no+1));
    }

    cJSON *data = cJSON_CreateObject();
    if (data == NULL)
    {
        cJSON_Delete(root);
        return 0;
    }

    if (sts)
        cJSON_AddStringToObject(data, "status", "success");
    else
        cJSON_AddStringToObject(data, "status", "fail");

    cJSON_AddItemToObject(root, "data", data);

    if (!cJSON_PrintPreallocated(root, (char *)out_buf, REMOTE_CFG_BUF_LEN, 0))
    {
        cJSON_Delete(root);
        return 0;
    }

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Parse and apply network configuration SET request JSON
 * @param  in_json - Pointer to input JSON string
 * @param  cfg     - Pointer to modbus configuration structure
 * @note   Converts string IP (e.g., "192.168.1.250") to uint32_t format
 *         Updates network_config_t fields:
 *         ipv4_address, subnet_mask, default_gateway, apn, username, password
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t parse_nwk_cfg_set_req(const char *in_json, modbus_cfg_t *cfg)
{
    if (in_json == NULL || cfg == NULL)
        return 0;

    cJSON *root = cJSON_Parse(in_json);
    if (root == NULL)
        return 0;

    cJSON *data = cJSON_GetObjectItem(root, "data");
    if (data == NULL)
    {
        cJSON_Delete(root);
        return 0;
    }

    cJSON *ip   = cJSON_GetObjectItem(data, "ip_addr");
    cJSON *sn   = cJSON_GetObjectItem(data, "sn_addr");
    cJSON *gw   = cJSON_GetObjectItem(data, "gw_addr");
    cJSON *apn  = cJSON_GetObjectItem(data, "apn");
    cJSON *usr  = cJSON_GetObjectItem(data, "usr");
    cJSON *pw   = cJSON_GetObjectItem(data, "pw");

    if (!cJSON_IsString(ip) || !cJSON_IsString(sn) || !cJSON_IsString(gw) ||
        !cJSON_IsString(apn) || !cJSON_IsString(usr) || !cJSON_IsString(pw))
    {
        cJSON_Delete(root);
        return 0;
    }

    /* Convert IP string to uint32_t */
    cfg->network_data.ipv4_address   = ipaddr_addr(ip->valuestring);
    cfg->network_data.subnet_mask    = ipaddr_addr(sn->valuestring);
    cfg->network_data.default_gateway= ipaddr_addr(gw->valuestring);

    /* Validate conversion (ipaddr_addr returns IPADDR_NONE on failure) */
    if (cfg->network_data.ipv4_address == IPADDR_NONE ||
        cfg->network_data.subnet_mask  == IPADDR_NONE ||
        cfg->network_data.default_gateway == IPADDR_NONE)
    {
        cJSON_Delete(root);
        return 0;
    }

    /* Copy APN / Credentials */
    strncpy((char*)cfg->network_data.apn, apn->valuestring, SIZEOF_APN - 1);
    strncpy((char*)cfg->network_data.username, usr->valuestring, SIZEOF_USERNAME - 1);
    strncpy((char*)cfg->network_data.password, pw->valuestring, SIZEOF_PASSWORD - 1);

    /* Ensure null termination */
    cfg->network_data.apn[SIZEOF_APN - 1] = '\0';
    cfg->network_data.username[SIZEOF_USERNAME - 1] = '\0';
    cfg->network_data.password[SIZEOF_PASSWORD - 1] = '\0';

    cJSON_Delete(root);

    return 1;
}
/***********************************************************************************************
 * @brief  Parse and apply cloud configuration SET request JSON
 * @param  in_json - Pointer to input JSON string
 * @param  cfg     - Pointer to modbus configuration structure
 * @note   Parses configuration strictly based on "protocol" field (HTTP/TCP/MQTT)
 *         Only relevant fields are processed; others are ignored
 *         Empty fields are not overwritten
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t parse_cloud_cfg_set_req(const char *in_json, modbus_cfg_t *cfg)
{
    if (in_json == NULL || cfg == NULL)
        return 0;

    cJSON *root = cJSON_Parse(in_json);
    if (root == NULL)
        return 0;

    cJSON *data     = cJSON_GetObjectItem(root, "data");
    cJSON *protocol = cJSON_GetObjectItem(root, "protocol");

    if (!data || !cJSON_IsString(protocol))
    {
        cJSON_Delete(root);
        return 0;
    }

    /* ================= HTTP ================= */
    if (strcmp(protocol->valuestring, "HTTP") == 0)
    {
        cJSON *httpurl  = cJSON_GetObjectItem(data, "httpurl");
        cJSON *httptype = cJSON_GetObjectItem(data, "httptype");

        if (!cJSON_IsString(httpurl) || !strlen(httpurl->valuestring))
        {
            cJSON_Delete(root);
            return 0;
        }

        cfg->cloud_data.mode = CLOUD_MODE_HTTP;

        strncpy((char*)cfg->cloud_data.cfg.http.url,
                httpurl->valuestring, SIZEOF_URL - 1);
        cfg->cloud_data.cfg.http.url[SIZEOF_URL - 1] = '\0';

        if (cJSON_IsString(httptype))
        {
            if (strcmp(httptype->valuestring, "POST") == 0)
                cfg->cloud_data.cfg.http.method = HTTP_METHOD_POST;
            else
                cfg->cloud_data.cfg.http.method = HTTP_METHOD_GET;
        }
    }

    /* ================= TCP ================= */
    else if (strcmp(protocol->valuestring, "TCP") == 0)
    {
        cJSON *tcpurl  = cJSON_GetObjectItem(data, "tcpurl");
        cJSON *tcpport = cJSON_GetObjectItem(data, "tcpport");

        if (!cJSON_IsString(tcpurl) || !strlen(tcpurl->valuestring))
        {
            cJSON_Delete(root);
            return 0;
        }

        cfg->cloud_data.mode = CLOUD_MODE_TCP;

        strncpy((char*)cfg->cloud_data.cfg.tcp.url,
                tcpurl->valuestring, SIZEOF_URL - 1);
        cfg->cloud_data.cfg.tcp.url[SIZEOF_URL - 1] = '\0';

//        if (cJSON_IsString(tcpport))
            cfg->cloud_data.cfg.tcp.port = tcpport->valueint;
    }

    /* ================= MQTT ================= */
    else if (strcmp(protocol->valuestring, "MQTT") == 0)
    {
        cJSON *mqtturl = cJSON_GetObjectItem(data, "mqtturl");
        cJSON *mqttport= cJSON_GetObjectItem(data, "mqttport");
        cJSON *mqttqos = cJSON_GetObjectItem(data, "mqttqos");
        cJSON *mqttcid = cJSON_GetObjectItem(data, "mqttcid");
        cJSON *pub     = cJSON_GetObjectItem(data, "mqttpubtopic");
        cJSON *req     = cJSON_GetObjectItem(data, "mqttreqtopic");
        cJSON *rsp     = cJSON_GetObjectItem(data, "mqttrsptopic");
        cJSON *user    = cJSON_GetObjectItem(data, "mqttun");
        cJSON *pass    = cJSON_GetObjectItem(data, "mqttpw");

        if (!cJSON_IsString(mqtturl) || !strlen(mqtturl->valuestring))
        {
            cJSON_Delete(root);
            return 0;
        }

        cfg->cloud_data.mode = CLOUD_MODE_MQTT;

        strncpy((char*)cfg->cloud_data.cfg.mqtt.url,
                mqtturl->valuestring, SIZEOF_URL - 1);
        cfg->cloud_data.cfg.mqtt.url[SIZEOF_URL - 1] = '\0';

//        if (cJSON_IsString(mqttport))
            cfg->cloud_data.cfg.mqtt.port = mqttport->valueint;

//        if (cJSON_IsString(mqttqos))
            cfg->cloud_data.cfg.mqtt.qos = mqttqos->valueint;

        if (cJSON_IsString(mqttcid))
        {
            strncpy((char*)cfg->cloud_data.cfg.mqtt.client_id,
                    mqttcid->valuestring, SIZEOF_CLIENTID - 1);
            cfg->cloud_data.cfg.mqtt.client_id[SIZEOF_CLIENTID - 1] = '\0';
        }

        if (cJSON_IsString(pub))
        {
            strncpy((char*)cfg->cloud_data.cfg.mqtt.pub_topic,
                    pub->valuestring, SIZEOF_TOPIC - 1);
            cfg->cloud_data.cfg.mqtt.pub_topic[SIZEOF_TOPIC - 1] = '\0';
        }

        if (cJSON_IsString(req))
        {
            strncpy((char*)cfg->cloud_data.cfg.mqtt.cfg_req_topic,
                    req->valuestring, SIZEOF_TOPIC - 1);
            cfg->cloud_data.cfg.mqtt.cfg_req_topic[SIZEOF_TOPIC - 1] = '\0';
        }

        if (cJSON_IsString(rsp))
        {
            strncpy((char*)cfg->cloud_data.cfg.mqtt.cfg_rsp_topic,
                    rsp->valuestring, SIZEOF_TOPIC - 1);
            cfg->cloud_data.cfg.mqtt.cfg_rsp_topic[SIZEOF_TOPIC - 1] = '\0';
        }

        if (cJSON_IsString(user))
        {
            strncpy((char*)cfg->cloud_data.cfg.mqtt.username,
                    user->valuestring, SIZEOF_USERNAME - 1);
            cfg->cloud_data.cfg.mqtt.username[SIZEOF_USERNAME - 1] = '\0';
        }

        if (cJSON_IsString(pass))
        {
            strncpy((char*)cfg->cloud_data.cfg.mqtt.password,
                    pass->valuestring, SIZEOF_PASSWORD - 1);
            cfg->cloud_data.cfg.mqtt.password[SIZEOF_PASSWORD - 1] = '\0';
        }
    }

    else
    {
        /* Unknown protocol */
        cJSON_Delete(root);
        return 0;
    }

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Parse and apply serial configuration SET request JSON
 * @param  in_json - Pointer to input JSON string
 * @param  cfg     - Pointer to modbus configuration structure
 * @note   Updates both channel1 and channel2 parameters
 *         pb = "N"/"E"/"O" mapped to enum/char
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t parse_serial_cfg_set_req(const char *in_json, modbus_cfg_t *cfg)
{
    if (in_json == NULL || cfg == NULL)
        return 0;

    cJSON *root = cJSON_Parse(in_json);
    if (root == NULL)
        return 0;

    cJSON *data = cJSON_GetObjectItem(root, "data");
    if (data == NULL)
    {
        cJSON_Delete(root);
        return 0;
    }

    /* Channel 1 */
    cJSON *br1 = cJSON_GetObjectItem(data, "br1");
    cJSON *db1 = cJSON_GetObjectItem(data, "db1");
    cJSON *pb1 = cJSON_GetObjectItem(data, "pb1");
    cJSON *sb1 = cJSON_GetObjectItem(data, "sb1");

    /* Channel 2 */
    cJSON *br2 = cJSON_GetObjectItem(data, "br2");
    cJSON *db2 = cJSON_GetObjectItem(data, "db2");
    cJSON *pb2 = cJSON_GetObjectItem(data, "pb2");
    cJSON *sb2 = cJSON_GetObjectItem(data, "sb2");

    if (!cJSON_IsNumber(br1) || !cJSON_IsNumber(db1) || !cJSON_IsString(pb1) || !cJSON_IsNumber(sb1) ||
        !cJSON_IsNumber(br2) || !cJSON_IsNumber(db2) || !cJSON_IsString(pb2) || !cJSON_IsNumber(sb2))
    {
        cJSON_Delete(root);
        return 0;
    }

    /* Channel 1 */
    cfg->serial_data.channel1.baud_rate = br1->valueint;
    cfg->serial_data.channel1.data_bits = db1->valueint;
    cfg->serial_data.channel1.stop_bits = sb1->valueint;
    cfg->serial_data.channel1.parity    = pb1->valuestring[0]; // 'N','E','O'

    /* Channel 2 */
    cfg->serial_data.channel2.baud_rate = br2->valueint;
    cfg->serial_data.channel2.data_bits = db2->valueint;
    cfg->serial_data.channel2.stop_bits = sb2->valueint;
    cfg->serial_data.channel2.parity    = pb2->valuestring[0];

    cJSON_Delete(root);
    return 1;
}
/***********************************************************************************************
 * @brief  Parse and apply data mapping configuration SET request JSON
 * @param  in_json - Pointer to input JSON string
 * @param  cfg     - Pointer to modbus configuration structure
 * @note   Supports RTU (ctp=1/2) and TCP (ctp=3)
 *         dev_no is 1-based index from cloud  converted to 0-based
 *         Parses device info + modbus data points
 *         Limits checked against MAX_DEVICE_COUNT and MAX_DATA_POINT
 * @retval 1 on success, 0 on failure
 **********************************************************************************************/
uint8_t parse_data_map_set_req(const char *in_json, modbus_cfg_t *cfg)
{
    if (in_json == NULL || cfg == NULL)
        return 0;

    cJSON *root = cJSON_Parse(in_json);
    if (root == NULL)
        return 0;

    /* Extract top-level */
    cJSON *data   = cJSON_GetObjectItem(root, "data");
    cJSON *ctp_js = cJSON_GetObjectItem(root, "ctp");
    cJSON *dev_js = cJSON_GetObjectItem(root, "dev_no");
    cJSON *op_js  = cJSON_GetObjectItem(root, "op");

    if (!ctp_js || !dev_js || !op_js)
    {
        cJSON_Delete(root);
        return 0;
    }

    uint8_t dev_no = dev_js->valueint - 1;  // cloud  0-based
    uint8_t ctp = parse_ctp(ctp_js->valuestring);

    char *op_str = op_js->valuestring;

    op_type_t op = parse_operation(op_str);

//    if (strcmp(op_str, "add") == 0)
//        op = OP_ADD;
//    else if (strcmp(op_str, "edit") == 0)
//        op = OP_EDIT;
//    else if (strcmp(op_str, "delete") == 0)
//        op = OP_DELETE;
//    else
//    {
//        cJSON_Delete(root);
//        return 0;
//    }

    /* ===================== DELETE ===================== */
    if (op == OP_DELETE)
    {
        if (ctp == 1 || ctp == 2)
        {
            rtu_data_mapping_t *rtu =
                (ctp == 1) ? &cfg->rtu_port_1 : &cfg->rtu_port_2;

            if (dev_no >= rtu->num_devices)
            {
                cJSON_Delete(root);
                return 0;
            }

            for (uint8_t i = dev_no; i < (rtu->num_devices - 1); i++)
            {
                memcpy(&rtu->devices[i], &rtu->devices[i + 1], sizeof(rtu_device_t));
            }

            memset(&rtu->devices[rtu->num_devices - 1], 0, sizeof(rtu_device_t));
            rtu->num_devices--;
        }
        else if (ctp == 3)
        {
            tcp_data_mapping_t *tcp = &cfg->tcp_port;

            if (dev_no >= tcp->num_devices)
            {
                cJSON_Delete(root);
                return 0;
            }

            for (uint8_t i = dev_no; i < (tcp->num_devices - 1); i++)
            {
                memcpy(&tcp->devices[i], &tcp->devices[i + 1], sizeof(tcp_device_t));
            }

            memset(&tcp->devices[tcp->num_devices - 1], 0, sizeof(tcp_device_t));
            tcp->num_devices--;
        }
        else
        {
            cJSON_Delete(root);
            return 0;
        }

        cJSON_Delete(root);
        return 1;
    }

    /* ===================== ADD / EDIT ===================== */

    if (!data)
    {
        cJSON_Delete(root);
        return 0;
    }

    cJSON *sid = cJSON_GetObjectItem(data, "sid");
    cJSON *dtp = cJSON_GetObjectItem(data, "dtp");
    cJSON *dnm = cJSON_GetObjectItem(data, "dnm");
    cJSON *rsp = cJSON_GetObjectItem(data, "rsp_tmt");
    cJSON *dpc = cJSON_GetObjectItem(data, "dpc");
    cJSON *mod = cJSON_GetObjectItem(data, "modbus");

    if (!sid || !dtp || !dnm || !rsp || !dpc || !cJSON_IsArray(mod))
    {
        cJSON_Delete(root);
        return 0;
    }

    uint8_t num_points = dpc->valueint;
    if (num_points > MAX_DATA_POINT)
        num_points = MAX_DATA_POINT;

    /* ================= RTU ================= */
    if (ctp == 1 || ctp == 2)
    {
        rtu_data_mapping_t *rtu =
            (ctp == 1) ? &cfg->rtu_port_1 : &cfg->rtu_port_2;

        /* ADD  shift right */
        if (op == OP_ADD)
        {
            if (rtu->num_devices >= MAX_DEVICE_COUNT || dev_no > rtu->num_devices)
            {
                cJSON_Delete(root);
                return 0;
            }

            for (int i = rtu->num_devices; i > dev_no; i--)
            {
                memcpy(&rtu->devices[i], &rtu->devices[i - 1], sizeof(rtu_device_t));
            }

            memset(&rtu->devices[dev_no], 0, sizeof(rtu_device_t));
            rtu->num_devices++;
        }
        else if (op == OP_EDIT)
        {
            if (dev_no >= rtu->num_devices)
            {
                cJSON_Delete(root);
                return 0;
            }
        }

        rtu_device_t *dev = &rtu->devices[dev_no];

        dev->slave_id = sid->valueint;
        dev->response_timeout_ms = rsp->valueint;
        dev->num_points = num_points;

        strncpy((char*)dev->device_type, dtp->valuestring, SIZEOF_JSON_KEY - 1);
        strncpy((char*)dev->device_name, dnm->valuestring, SIZEOF_JSON_KEY - 1);

        dev->device_type[SIZEOF_JSON_KEY - 1] = '\0';
        dev->device_name[SIZEOF_JSON_KEY - 1] = '\0';

        for (uint8_t i = 0; i < num_points; i++)
        {
            cJSON *item = cJSON_GetArrayItem(mod, i);
            if (!item) continue;

            data_point_t *pt = &dev->points[i];

            cJSON *fc  = cJSON_GetObjectItem(item, "fc");
            cJSON *addr= cJSON_GetObjectItem(item, "addr");
            cJSON *dt  = cJSON_GetObjectItem(item, "data_typ");
            cJSON *sf  = cJSON_GetObjectItem(item, "sf");
            cJSON *key = cJSON_GetObjectItem(item, "key");

            if (!fc || !addr || !dt || !sf || !key)
                continue;

            switch (fc->valueint)
            {
                case 1: pt->reg_type = REG_COIL; break;
                case 2: pt->reg_type = REG_DISCRETE_INPUT; break;
                case 3: pt->reg_type = REG_HOLDING_REGISTER; break;
                case 4: pt->reg_type = REG_INPUT_REGISTER; break;
                default: pt->reg_type = REG_HOLDING_REGISTER; break;
            }

            pt->start_address = addr->valueint;

            if (strcmp(dt->valuestring, "float") == 0)
            {
                pt->data_type = DT_FLOAT; pt->reg_count = 2;
            }
            else if (strcmp(dt->valuestring, "int16") == 0)
            {
                pt->data_type = DT_INT16; pt->reg_count = 1;
            }
            else if (strcmp(dt->valuestring, "uint16") == 0)
            {
                pt->data_type = DT_UINT16; pt->reg_count = 1;
            }
            else if (strcmp(dt->valuestring, "int32") == 0)
            {
                pt->data_type = DT_INT32; pt->reg_count = 2;
            }
            else if (strcmp(dt->valuestring, "uint32") == 0)
            {
                pt->data_type = DT_UINT32; pt->reg_count = 2;
            }
            else
            {
                pt->data_type = DT_FLOAT; pt->reg_count = 2;
            }

            pt->scaling_factor = (float)sf->valuedouble;

            strncpy((char*)pt->json_key, key->valuestring, SIZEOF_JSON_KEY - 1);
            pt->json_key[SIZEOF_JSON_KEY - 1] = '\0';
        }
    }

    /* ================= TCP ================= */
    else if (ctp == 3)
    {
        tcp_data_mapping_t *tcp = &cfg->tcp_port;

        cJSON *ip  = cJSON_GetObjectItem(data, "ip");
        cJSON *prt = cJSON_GetObjectItem(data, "prt");

        if (!ip || !prt)
        {
            cJSON_Delete(root);
            return 0;
        }

        if (op == OP_ADD)
        {
            if (tcp->num_devices >= MAX_DEVICE_COUNT || dev_no > tcp->num_devices)
            {
                cJSON_Delete(root);
                return 0;
            }

            for (int i = tcp->num_devices; i > dev_no; i--)
            {
                memcpy(&tcp->devices[i], &tcp->devices[i - 1], sizeof(tcp_device_t));
            }

            memset(&tcp->devices[dev_no], 0, sizeof(tcp_device_t));
            tcp->num_devices++;
        }
        else if (op == OP_EDIT)
        {
            if (dev_no >= tcp->num_devices)
            {
                cJSON_Delete(root);
                return 0;
            }
        }

        tcp_device_t *dev = &tcp->devices[dev_no];

        dev->slave_id = sid->valueint;
        dev->slave_ip = ipaddr_addr(ip->valuestring);
        dev->slave_port = prt->valueint;
        dev->response_timeout_ms = rsp->valueint;
        dev->num_points = num_points;

        strncpy((char*)dev->device_type, dtp->valuestring, SIZEOF_JSON_KEY - 1);
        strncpy((char*)dev->device_name, dnm->valuestring, SIZEOF_JSON_KEY - 1);

        dev->device_type[SIZEOF_JSON_KEY - 1] = '\0';
        dev->device_name[SIZEOF_JSON_KEY - 1] = '\0';

        for (uint8_t i = 0; i < num_points; i++)
        {
            cJSON *item = cJSON_GetArrayItem(mod, i);
            if (!item) continue;

            data_point_t *pt = &dev->points[i];

            cJSON *fc  = cJSON_GetObjectItem(item, "fc");
            cJSON *addr= cJSON_GetObjectItem(item, "addr");
            cJSON *dt  = cJSON_GetObjectItem(item, "data_typ");
            cJSON *sf  = cJSON_GetObjectItem(item, "sf");
            cJSON *key = cJSON_GetObjectItem(item, "key");

            if (!fc || !addr || !dt || !sf || !key)
                continue;

            switch (fc->valueint)
            {
                case 1: pt->reg_type = REG_COIL; break;
                case 2: pt->reg_type = REG_DISCRETE_INPUT; break;
                case 3: pt->reg_type = REG_HOLDING_REGISTER; break;
                case 4: pt->reg_type = REG_INPUT_REGISTER; break;
            }

            pt->start_address = addr->valueint;
            pt->scaling_factor = (float)sf->valuedouble;

            strncpy((char*)pt->json_key, key->valuestring, SIZEOF_JSON_KEY - 1);
            pt->json_key[SIZEOF_JSON_KEY - 1] = '\0';
        }
    }
    else
    {
        cJSON_Delete(root);
        return 0;
    }

    cJSON_Delete(root);
    return 1;
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
