/**
  **************************
  * @file    cJSON_parser_modbus_gw.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 11
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CJSON_PARSER_MODBUS_GW_H_
#define __CJSON_PARSER_MODBUS_GW_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "modbus_gw_cfg.h"
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/
 void create_rtu_json_packet(const char *channel_name, rtu_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf);
 void create_tcp_json_packet(const char *channel_name, tcp_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf);

 void copy_rtu_log(rtu_device_t *dev,uint8_t chn_type, uint32_t timestamp, uint8_t data[MAX_POINTS][MAX_PAYLOAD], log_send_t *log_info);
 void copy_tcp_log(tcp_device_t *dev, uint32_t timestamp, uint8_t data[MAX_POINTS][MAX_PAYLOAD], log_send_t *log_info);

 void mac_devid_set_for_cloud(uint8_t addr[6], const char id[10], const char imei[16]);
 uint8_t parse_json_key_value(const char *json_packet, const char *json_key, uint8_t *value);
 uint8_t parse_json_for_fresh_config(const char *json, fresh_device_config_t *config);
 uint8_t is_valid_json(const char *json_buffer,uint16_t buffer_length);
 uint8_t prepare_read_back_response_for_fresh_device(fresh_device_config_t fresh_dv_cfg, uint8_t *output_buffer);
 uint8_t prepare_response_with_status(uint8_t *input_buffer,uint8_t status,uint8_t *output_buffer);
 void prepare_gsm_rsp_with_status(const char *gsm_rsp, uint8_t status_ok, uint8_t *output_buffer);

 void create_data_log_json_packet(log_send_t *dev, uint8_t *out_buf);
 uint8_t parse_fota_metadata_cjson(const char *json_str, fota_meta_t *meta);

 void create_custom_rtu_json_packet(const char *channel_name, rtu_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf);
 void create_custom_tcp_json_packet(const char *channel_name, tcp_device_t *dev, const cloud_device_t *cdev, uint8_t *out_buf);
 void create_custom_data_log_json_packet(log_send_t *dev, uint8_t *out_buf);

 uint8_t parse_json_to_mb(const char *json_str, mb_wrt_t *out);
 int prepare_mb_wrt_response(char *out_buf, size_t buf_size, const mb_wrt_t *evt, const char *status);
 uint8_t extract_json_quoted(char *input, char *output, int max_len);

 uint8_t parse_remote_cfg(const char *json, pkt_type_t *pkt, cfg_type_t *cfg_type_enum);

 uint8_t parse_data_map_get_req(const char *input_json, uint8_t *ctp_out, uint8_t *dev_no_out, uint8_t *operation);
 uint8_t prepare_nwk_cfg_get_response(modbus_cfg_t *cfg, uint8_t *out_json);
 uint8_t prepare_cloud_cfg_get_response(modbus_cfg_t *cfg, uint8_t *out_json);
 uint8_t prepare_serial_cfg_get_response(modbus_cfg_t *cfg, uint8_t *out_json);
 uint8_t prepare_data_map_get_response(modbus_cfg_t *cfg, uint8_t chn_type, uint8_t dev_no, uint8_t *out_json);
 uint8_t create_cfg_packet_rsp(char *out_buf, uint8_t pkt_type, uint8_t cfg_type, uint8_t sts, uint8_t ctp, uint8_t dev_no, uint8_t operation);

 uint8_t parse_cloud_cfg_set_req(const char *in_json, modbus_cfg_t *cfg);
 uint8_t parse_serial_cfg_set_req(const char *in_json, modbus_cfg_t *cfg);
 uint8_t parse_data_map_set_req(const char *in_json, modbus_cfg_t *cfg);
 uint8_t parse_nwk_cfg_set_req(const char *in_json, modbus_cfg_t *cfg);
/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __CJSON_PARSER_MODBUS_GW_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
