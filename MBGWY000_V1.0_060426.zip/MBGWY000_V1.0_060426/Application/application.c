/**
  **************************
  * @file    application.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Jun 30
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "application.h"
#include "tcp_client.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"
#include "httpd_structs.h"
#include "at32f435_437_board.h"
#include "modbus_gw_cfg.h"

#include "hal_ethernet.h"
#include "hal_gpio.h"
#include "hal_system_init.h"
#include "hal_timer.h"
#include "hal_uart.h"
#include "hal_exint.h"

#include "spi_flash.h"
#include "modbus-tcp.h"
#include "modbus-rtu.h"
#include <time.h>
#include "gsm_engine.h"
#include "hal_rtc.h"
#include "cJSON_parser_modbus_gw.h"
#include "epoch_conversion.h"
#include "cs_db.h"
#include "checksum.h"
#include "flash.h"
#include "netconf.h"
#include "xmodem.h"
#include "html_to_spi_flash.h"
#include "at32_emac.h"
#include "led_timer.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#define HTML_STORAGE_LEN                      4096

#define WORKING_MODE_STATUS                   0X0A
#define CONFIG_MODE_STATUS                    0X0B

#define WORKING_MODE_ON_TIME                  3000
#define WORKING_MODE_OFF_TIME                 500

#define WORKING_MODE                         1
#define MODIFY_CONFIG_MODE                   2
#define FACTORY_RESET                        3
#define FACTORY_CONFIG_MODE                  4
#define FRESH_DEVICE_CONFIG                  5
#define MODIFY_CONFIG_STOP                   6
#define MODIFY_CONFIG_CHANGE                 7
#define SPI_ERROR_MODE                       8

#define TCP_MODE                             1
#define HTTP_MODE                            2
#define MQTT_MODE                            3
#define DATA_LOGGING                         4

#define BUTTON_STATE_IDLE                    1
#define BUTTON_STATE_FIRST_PRESS_DETECTED    2
#define BUTTON_STATE_WAIT_SECOND_PRESS       3
#define BUTTON_STATE_LONG_PRESS_ACTIVE       4
#define BUTTON_STATE_DOUBLE_PRESS            5
#define BUTTON_STATE_FACTORY_TMT             6

#define SERIAL1_LED                          1
#define SERIAL2_LED                          2
#define TCP_LED                              3

#define MQTT_MAX_PAYLOAD                     1024
#define FRESH_DEV_CFG_BUF                    1024
#define SUSPEND_TASK_FLAG                    0xAB
#define TIMER_LED_FUN                        1

#define MB_WRT_JSON_BUF_SIZE                 2048

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

TaskHandle_t modbus_task_handler = NULL;
TaskHandle_t gsm_task_handler = NULL;
TaskHandle_t cloud_comm_task_handler = NULL;
TaskHandle_t mb_wrt_task_handler = NULL;
SemaphoreHandle_t ResourceMutex;
SemaphoreHandle_t UartMutex;
SemaphoreHandle_t spiMutex;
SemaphoreHandle_t mb_wrt_mutex;
SemaphoreHandle_t modbus_mutex;
SemaphoreHandle_t cloud_mutex;


cloud_data_t gw_cloud_data;

volatile uint8_t suspend_task;
volatile uint8_t button_state = BUTTON_STATE_IDLE;
volatile uint8_t button_is_down = 0;
volatile uint32_t press_start_time = 0;
volatile uint32_t tmr_count;
volatile uint8_t gsm_ok;

uint8_t *fresh_dev_ptr = NULL;
volatile static uint16_t data_len;
volatile uint8_t device_state = 0;

volatile uint8_t tcp_connected_flg;

modbus_cfg_t modbus_data = {
    .cfg_flg = 0xFF,
	.fota_url = "http://fota.mywire.org",
    .network_data = {
    	.ipv4_address = 0XFA01A8C0,
    	.default_gateway = 0X0101A8C0,
    	.subnet_mask = 0X00FFFFFF,
		.apn = "airtelgprs",
    },
};

uint8_t firmware_version[] = "1.0";
uint8_t msg_type;
log_send_t log_snd_info;
log_store_t log_store_info;

uint8_t *html_storage_buf = NULL;
uint16_t html_storage_length;
uint8_t xmodem_start;
extern xmodem_context_t xmodem_ctx;

uint8_t cloud_rtu1_start;
uint8_t cloud_rtu2_start;
uint8_t cloud_tcp_start;
uint32_t mcu_status;
uint32_t cloud_status;
uint8_t ethernet_ok;

char remote_cfg_buf[MB_WRT_JSON_BUF_SIZE];

void factory_reset(void);
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************
 * @brief       xmodem callback
 * @param[in]   ip_buf - input buffer to write in spi flash
 * @param[in]   buf_len - input buf length
 * @return      none
 ******************************************************************************/
void xModem_cbk(uint8_t *ip_buf, uint8_t buf_len) {

	memcpy((html_storage_buf + html_storage_length), ip_buf, buf_len);
	html_storage_length += buf_len;
	if (html_storage_length == HTML_STORAGE_LEN) {
		html_page_write_into_flash(html_storage_buf, HTML_STORAGE_LEN);
		html_storage_length = 0;
	}
}
/******************************************************************************
 * @brief       xmodem transfer complete function
 * @param[in]   result - xmodem status
 * @param[in]   total_bytes - Total bytes received in xmodem
 * @return      none
 ******************************************************************************/
void xmodem_transfer_complete(xmodem_result_t result, uint32_t total_bytes)
{
    if (result == XMODEM_SUCCESS) {
    	printf("\r\n[XMODEM] File received successfully!\r\n");
    	printf("[XMODEM] File size: %lu bytes\r\n", total_bytes);
        printf("[XMODEM] Ready for next transfer...\r\n");
        if (html_storage_length > 0) {
        	html_page_write_into_flash(html_storage_buf, html_storage_length);
        }
        finalize_last_page_on_eot();
        free(html_storage_buf);
        hal_system_reset();
    } else {
    	PRINTF("\r\n[XMODEM] Transfer failed: %d\r\n", result);
    }
}
/******************************************************************************
 * @brief       xModem Task
 * @param[in]   pvParameters
 * @return      none
 ******************************************************************************/
void xmodem_task(void *pvParameters) {

	if (html_storage_buf == NULL) {
		html_storage_buf = (uint8_t*)malloc(HTML_STORAGE_LEN * 2);
	}
	xmodem_ctx.uart_port = USART_6;
    xmodem_ctx.transfer_complete = xmodem_transfer_complete;
    xmodem_ctx.debug_output_enabled = 0;

    printf("\r\n=== XMODEM Receiver Ready ===\r\n");
    printf("Waiting for XMODEM transfer...\r\n");
    xmodem_start = 1;
    while (1) {
        xmodem_result_t result = xmodem_receive(&xmodem_ctx, 600000);
        if (result == XMODEM_SUCCESS) {
        	PRINTF("Transfer completed successfully!\r\n");
        } else {
        	PRINTF("Transfer failed with error: %d\r\n", result);
        }

        vTaskDelay(1000);
    }
}
/******************************************************************************
 * @brief       handle fresh device config
 * @param[in]   buffer
 * @param[in]   buffer_length
 * @return      none
 ******************************************************************************/
void handle_fresh_dev_config(uint8_t *buffer, uint16_t buffer_length) {

	if (is_valid_json(buffer, buffer_length)) {
		printf("\rVALID PACKET\n");
		parse_json_key_value(buffer,"MTP",&msg_type);
		printf("\rMSG TYPE : %u\n",msg_type);
	} else {
		fresh_dev_ptr[data_len] = '\0';
		msg_type = 5;
	}

}
/******************************************************************************
 * @brief       lwip periodic handle
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void Fresh_dev_task(void *pvParameters) {

	if (fresh_dev_ptr == NULL) {
		fresh_dev_ptr = (uint8_t*)malloc(FRESH_DEV_CFG_BUF);
	}
	uint8_t output_buffer[256];
	printf("FRESH DEV CFG TASK START\n");
	while(1) {
		switch (msg_type) {
		    case 1 :
		             {
		    	         fresh_device_config_t write_config;
		                 parse_json_for_fresh_config(fresh_dev_ptr,&write_config);
		    	         write_fresh_device_config_into_flash(&write_config);
		    	         prepare_response_with_status(fresh_dev_ptr, 1, output_buffer);
		    	         uint8_t len = strlen(output_buffer);
		    	         uart_transmit(USART_6, output_buffer, len, 1000);
		    	    	 printf("\r\nWRITE CONFIG SUCCESS\r\n");
		    	    	 data_len = 0;
		    	    	 msg_type = 0;
		             }
		             break;
		    case 2 :
		             {
		            	 fresh_device_config_t read_config;
		            	 read_fresh_device_config_from_flash(&read_config);
		    	         prepare_read_back_response_for_fresh_device(read_config, output_buffer);
		    	         uint8_t  ip[256];
		    	         prepare_response_with_status(output_buffer, 1, ip);
		    	         uint8_t len = strlen(ip);
		    	         uart_transmit(USART_6, ip, len, 1000);
                         printf("\r\nREAD CONFIG SUCCESS\r\n");
                         data_len = 0;
                         msg_type = 0;
		             }
		    	     break;
		    case 4 : PRINTF("\r\nCONFIG DONE\r\n");
		    	     hal_system_reset();
		    	     data_len = 0;
		    	     break;
		    case 5 :
		            {
		    	         uint8_t gsm_rsp[256] = {0};
   	                     gsm_RxBuffClear();
   	                     uart_transmit(USART_1, fresh_dev_ptr, strlen(fresh_dev_ptr), 1000);
   	                     vTaskDelay(5000);
   	                     read_gsm_response(gsm_rsp, sizeof(gsm_rsp));
   	                     printf("\r\nGSM RESPONSE:\r\n%s\r\n",gsm_rsp);
   	                     msg_type = 0;
   	                     data_len = 0;
		            }
		            break;
		    case 6 :
			        if(xTaskCreate(xmodem_task, "XMODEM", 2048, NULL, 3, NULL) != pdPASS){
			        	PRINTF("ERROR: xmodem task creation failed!\r\n");
			        } else {
			        	PRINTF("\rINFO: xmodem task created successfully\r\n");
			        }
  	                msg_type = 0;
  	                data_len = 0;
			        break;
		    default:
		    	break;
		}
		vTaskDelay(500);
	}
}
/******************************************************************************
 * @brief       Send data to cloud
 * @param[in]   cloud_type - MQTT / HTTP/ TCP
 * @param[in]   json_out - output JSON packet
 * @param[in]   json_len - output JSON Packet length
 * @return      status
 ******************************************************************************/
uint8_t send_cloud_data(uint8_t cloud_type, uint8_t *json_out, uint16_t json_len) {

	uint8_t status = 1;
	if (json_len == 0 || !gsm_ok) {
		PRINTF("CLOUD FAIL\n");
		vTaskDelay(100);
		return 0;
	}
	char *ptr = json_out;
    uint16_t remaining = json_len;

    while (remaining > 0) {

        uint32_t chunk_len = (remaining > MQTT_MAX_PAYLOAD) ? MQTT_MAX_PAYLOAD : remaining;
    	switch(cloud_type) {
    	     case TCP_MODE:
    	    	  status = gsm_send_data_via_tcp(ptr, chunk_len);
    		      break;
    	     case HTTP_MODE:
    	    	  chunk_len = json_len;
    	    	  status = gsm_send_data_via_http(ptr, json_len);
    		      break;
    	     case MQTT_MODE:
    	    	  status = gsm_send_data_via_mqtt(ptr, chunk_len);
    		      break;
    	     default:
    		      break;
    	}
        ptr += chunk_len;
        remaining -= chunk_len;
    }
    PRINTF("CLOUD STS: %u\n", status);
//    vTaskDelay(500);
	return status;
}
/******************************************************************************
 * @brief       led mode set - device mode
 * @param[in]   mode - mode of led
 * @return      none
 ******************************************************************************/
void led_mode_set(uint8_t mode) {

#if TIMER_LED_FUN
	switch (mode) {
          case WORKING_MODE :
    	       hal_timer_pwm_cfg(TIMER5, 3500, 85.7);
    	       break;
          case FACTORY_RESET:
    	       hal_timer_pwm_cfg(TIMER5, 1000, 50);
    	       break;
          case FACTORY_CONFIG_MODE:
    	       hal_timer_pwm_cfg(TIMER5, 2000, 50);
    	       break;
          case SPI_ERROR_MODE:
    	       hal_timer_pwm_cfg(TIMER5, 500, 50);
    	       break;
          default:
  	         break;
	}
#else
	switch(mode) {
	    case WORKING_MODE :
	    	 hal_timer4_led_cfg(WORKING_MODE_ON_TIME);
	    	 break;
	    case FACTORY_RESET:
	    	 hal_timer4_led_cfg(500);
	    	 break;
	    case FACTORY_CONFIG_MODE:
	    	 hal_timer4_led_cfg(1000);
	    	 break;
	    case SPI_ERROR_MODE:
	    	 hal_timer4_led_cfg(250);
	    	 break;
        default:
	         break;
    }
	at32_led_on(LED3);
#endif
}
/******************************************************************************
 * @brief       Read modbus config from spi flash
 * @param[in]   data
 * @return      none
 ******************************************************************************/
void Read_modbus_config(void) {

	memset((uint8_t*)&modbus_data, 0, sizeof(modbus_cfg_t));
	if (!cdb_read_mb_conf((uint8_t*)&modbus_data, sizeof(modbus_cfg_t))) {
		cdb_read_mb_conf((uint8_t*)&modbus_data, sizeof(modbus_cfg_t));
	}
	uint8_t *rx_start = ((uint8_t *)&modbus_data) + offsetof(modbus_cfg_t, data_poll_interval);
	uint8_t *rx_end   = ((uint8_t *)&modbus_data) + offsetof(modbus_cfg_t, checksum);
	uint8_t rx_cs = calculate_checksum_using_addition(rx_start, rx_end - rx_start);
	if (rx_cs != modbus_data.checksum) {
		PRINTF("READ CHECKSUM ERROR:%04X,%04X\n",rx_cs, modbus_data.checksum);
		led_mode_set(SPI_ERROR_MODE);
	}
}
/******************************************************************************
 * @brief       write modbus config into spi flash
 * @param[in]   data
 * @return      none
 ******************************************************************************/
uint8_t write_modbus_config(void) {

	cdb_erase_mb_conf();
	cdb_erase_data_log();
	modbus_data.cfg_flg = 0xFF;
	modbus_data.ssl_cfg_check = 0xFF;
	uint8_t *tx_start = ((uint8_t *)&modbus_data) + offsetof(modbus_cfg_t, data_poll_interval);
	uint8_t *tx_end   = ((uint8_t *)&modbus_data) + offsetof(modbus_cfg_t, checksum);
	uint8_t tx_cs = calculate_checksum_using_addition(tx_start, tx_end - tx_start);
	modbus_data.checksum = tx_cs;
	PRINTF("TX checksum:%04X\n",tx_cs);
	if(cdb_write_mb_conf((uint8_t*)&modbus_data, sizeof(modbus_cfg_t))){
		PRINTF("MODBUS CONFIG WRITE DONE\n");
		device_config_mode_set(WORKING_MODE_STATUS);
		return 1;
	} else {
		led_mode_set(SPI_ERROR_MODE);
		return 0;
	}
}
/*****************************************************************************
 * @brief       Convert firmware version to string
 * @param[in]   event_type
 * @return      none
 ******************************************************************************/
void gsm_callback_app(uint8_t event_type) {

	if (event_type == 1) {
		gsm_ok = TCP_MODE;
	} else if (event_type == 2) {
		gsm_ok = HTTP_MODE;
	} else if (event_type == 3) {
		gsm_ok = MQTT_MODE;
	} else if (event_type == 0XAA){
		led_mode_set(SPI_ERROR_MODE);
	}  else {
		gsm_ok = 0;
	}
}
/******************************************************************************
 * @brief       timer callback function
 * @param[in]   timer_type - which timer triggers interrupt
 * @return      none
 ******************************************************************************/
void timer_cbk(uint8_t timer_type) {

     if (timer_type == TIMER1) {
        tmr_count++;
        switch (button_state) {
             case BUTTON_STATE_FIRST_PRESS_DETECTED:
                  if (button_is_down && (tmr_count >= LONG_PRESS_TIME_MS/10)) {
                	  PRINTF("LONG PRESS\n");
                	  tmr_count = 0;
                	  device_state = FACTORY_RESET;
                	  led_mode_set(FACTORY_RESET);
                      button_state = BUTTON_STATE_FACTORY_TMT;
                  }
                  break;
             case BUTTON_STATE_FACTORY_TMT:
            	  if (tmr_count >= 300) {
            		  button_state = BUTTON_STATE_IDLE;
            		  factory_reset();
            	  }
            	  break;
             case BUTTON_STATE_WAIT_SECOND_PRESS:
                  if (!button_is_down && (tmr_count >= DOUBLE_PRESS_WINDOW_MS/10)) {
                      PRINTF("SINGLE PRESS\n");
                      hal_timer_enable_disable(TIMER1,0);
                      button_state = BUTTON_STATE_IDLE;
                  }
                  break;
             case BUTTON_STATE_DOUBLE_PRESS:
                 if (!button_is_down && (tmr_count >= MODIFY_CONFIG_TIMEOUT_IN_MS/10)) {
                     PRINTF("MODIFY CONFIG TIMEOUT\n");
                     device_state = MODIFY_CONFIG_STOP;
                     button_state = BUTTON_STATE_IDLE;
                     hal_timer_enable_disable(TIMER1, 0);
                     hal_system_reset();
                 }
                 break;
        }
	}
#if !TIMER_LED_FUN
     else {
		at32_led_toggle(LED3);
		if (device_state == WORKING_MODE) {
           if (data_len) {
        	   hal_timer4_led_cfg(WORKING_MODE_ON_TIME);
           } else {
        	   hal_timer4_led_cfg(WORKING_MODE_OFF_TIME);
           }
           data_len = !data_len;
		}
	}
#endif
}
/******************************************************************************
 * @brief       Timer callback function
 * @param[in]   uart_type - Uart Number
 * @param[in]   event_type - data or idle event
 * @param[in]   data - incoming data
 * @return      none
 ******************************************************************************/
void uart_cbk_app(uint8_t uart_type, uint8_t event_type, uint8_t data) {

	if (uart_type == USART_6) {
		if (event_type == 1) {
			if (xmodem_start) {
				transfer_data_to_xmodem(data, USART_6, 1);
			} else {
				fresh_dev_ptr[data_len++] = data;
			}
		} else {
			if (xmodem_start) {
				transfer_data_to_xmodem(data, USART_6, 2);
			} else {
				fresh_dev_ptr[data_len] = '\0';
				handle_fresh_dev_config(fresh_dev_ptr, data_len);
			}
		}
	}
}
/******************************************************************************
 * @brief       User button callback function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void user_button_cbk(void) {

	uint8_t state = hal_gpio_input_pin_read(USR_BUTTON_PORT, USR_BUTTON_PIN);
    if (!state && !button_is_down) {
    	PRINTF("HIGH\n");
    	button_is_down = 1;
        if (button_state == BUTTON_STATE_IDLE || button_state == BUTTON_STATE_DOUBLE_PRESS) {
            button_state  = BUTTON_STATE_FIRST_PRESS_DETECTED;
            tmr_count     = 0;
            hal_timer_enable_disable(TIMER1, 1);
        }
    } else if (state && button_is_down){
    	PRINTF("LOW\n");
        button_is_down = 0;
        if (button_state == BUTTON_STATE_FIRST_PRESS_DETECTED) {
            button_state = BUTTON_STATE_WAIT_SECOND_PRESS;
        } else if (button_state == BUTTON_STATE_WAIT_SECOND_PRESS) {
        	if (device_state == WORKING_MODE) {
                PRINTF("Double press\n");
                suspend_task = SUSPEND_TASK_FLAG;
                device_state = MODIFY_CONFIG_MODE;
                button_state = BUTTON_STATE_DOUBLE_PRESS;
        	} else if (device_state == MODIFY_CONFIG_MODE) {
        		hal_system_reset();
        	}
        }
    }
}
/******************************************************************************
 * @brief       HTTP server callback
 * @param[in]   event
 * @return      none
 ******************************************************************************/
void factory_reset(void) {
	cdb_erase_mb_conf();
	cdb_erase_data_log();
    device_config_mode_set(CONFIG_MODE_STATUS);
	hal_system_reset();
}
/******************************************************************************
 * @brief       HTTP server callback
 * @param[in]   event_type
 * @return      none
 ******************************************************************************/
uint8_t http_cbk_app(uint8_t event_type) {

	switch(event_type) {
	    case 1: if (write_modbus_config()) {
	    	       PRINTF("FRESH CFG SPI\n");
	    	       return 1;
	            } else {
	            	return 0;
	            }
		        break;
	    case 2: hal_system_reset();
	    	    break;
	    case 3: factory_reset();
	    	    break;
	    case 4 :hal_system_reset();
	    	    break;
	}
	return 1;
}
/******************************************************************************
 * @brief       callback function for Ethernet connection
 * @param[in]   status - connection status
 * @return      none
 ******************************************************************************/
void eth_cbk_app(uint8_t status) {

	ethernet_ok = status;
}
/******************************************************************************
 * @brief       callback function for tcp client
 * @param[in]   event_type
 * @param[in]   status - Connection status
 * @return      none
 ******************************************************************************/
void tcp_client_cbk(uint8_t event_type, uint8_t status) {

	if (event_type == 1)  {
		tcp_connected_flg = status;
	}
}

/******************************************************************************
 * @brief       Convert firmware version to string
 * @param[in]   event_type
 * @return      none
 ******************************************************************************/
void mb_wrt_app(uint8_t *buf, uint16_t buf_len) {

	uint16_t sts = extract_json_quoted(buf, remote_cfg_buf, sizeof(remote_cfg_buf));
	if (sts) {
//		PRINTF("<%s>", json);
	    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
	    xSemaphoreGiveFromISR(mb_wrt_mutex, &xHigherPriorityTaskWoken);
	    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
	}
}
/******************************************************************************
 * @brief       Modbus Write Event Task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void mb_wrt_event_task(void *arg)
{
    modbus_t *ctx_uart1 = NULL;
    modbus_t *ctx_uart2 = NULL;
    modbus_t *ctx_tcp   = NULL;
    taskENTER_CRITICAL();
    ctx_uart1 = modbus_new_rtu("uart4", modbus_data.serial_data.channel1.baud_rate, modbus_data.serial_data.channel1.parity,
                              modbus_data.serial_data.channel1.data_bits, modbus_data.serial_data.channel1.stop_bits);
    ctx_uart2 = modbus_new_rtu("uart5", modbus_data.serial_data.channel2.baud_rate, modbus_data.serial_data.channel2.parity,
                              modbus_data.serial_data.channel2.data_bits, modbus_data.serial_data.channel2.stop_bits);

    modbus_connect(ctx_uart1);
    modbus_connect(ctx_uart2);
    taskEXIT_CRITICAL();
    uint8_t out_buf[REMOTE_CFG_BUF_LEN];
    uint8_t start_received = 0;
    TickType_t start_tick = 0;
    const TickType_t timeout_ticks = pdMS_TO_TICKS(600000); // 10 min

    while (1)
    {
        /*  Timeout Check (runs always) */
        if (start_received)
        {
            TickType_t now = xTaskGetTickCount();
            if ((now - start_tick) > timeout_ticks)
            {
                PRINTF("CFG TIMEOUT -> RESETTING MCU\n");
                hal_system_reset();
            }
        }
        if (xSemaphoreTake(mb_wrt_mutex, pdMS_TO_TICKS(100)) == pdTRUE)
        {
            xSemaphoreTake(cloud_mutex, portMAX_DELAY);
            xSemaphoreTake(modbus_mutex, portMAX_DELAY);
            pkt_type_t pkt;
            cfg_type_t cfg_type;
            uint8_t sts = parse_remote_cfg(remote_cfg_buf, &pkt, &cfg_type);
            PRINTF("PKT TYPE:%u, CFG TYPE:%u\n", pkt, cfg_type);
            if (sts) {
            	switch (pkt) {
            	    case PKT_CFG_START:
            	    	 taskENTER_CRITICAL();
            	    	 if (modbus_task_handler != NULL) {
            	    		 vTaskDelete(modbus_task_handler);
            	    		 modbus_task_handler = NULL;
            	    	 }
            	    	 if (cloud_comm_task_handler != NULL) {
            	    		 vTaskDelete(cloud_comm_task_handler);
            	    		 cloud_comm_task_handler = NULL;
            	    	 }
            	    	 led_mode_set(FACTORY_CONFIG_MODE);
                         start_received = 1;
                         start_tick = xTaskGetTickCount();
            	    	 taskEXIT_CRITICAL();
            	    	 PRINTF("PKT_CFG_START\r\n");
            		     break;
            	    case PKT_CFG_FINISH:
                         if (start_received) {
                            write_modbus_config();
                            PRINTF("PKT_CFG_FINISH\r\n");
                            hal_system_reset();
                         }
            	    	 PRINTF("PKT_CFG_FINISH\r\n");
            		     break;
            	    case PKT_FACTORY_RESET:
    //        	    	 factory_reset();
            	    	 PRINTF("PKT_FACTORY_RESET\r\n");
            		     break;
            	    case PKT_CFG_GET_REQ:
            	    	 if (start_received) {
                	    	 if(cfg_type == CFG_NWK) {
                	    		 if(prepare_nwk_cfg_get_response(&modbus_data, out_buf)) {
                	    			 mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 }
                	    	 } else if(cfg_type == CFG_CLOUD) {
                	    		 if(prepare_cloud_cfg_get_response(&modbus_data, out_buf)) {
                	    			 mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 }
                	    	 } else if(cfg_type == CFG_SERIAL) {
                	    		 if(prepare_serial_cfg_get_response(&modbus_data, out_buf)) {
                	    			 mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 }
                	    	 } else if(cfg_type == CFG_DATA_MAP) {
                	    		 uint8_t dev_no = 0, ctp = 0, operation = 0;
                	    		 parse_data_map_get_req(remote_cfg_buf, &ctp, &dev_no, &operation);
                	    		 PRINTF("CTP:%u DEV NO:%u OP:%u\n", ctp, dev_no, operation);
                	    		 if(prepare_data_map_get_response(&modbus_data, ctp, dev_no, out_buf)) {
                	    			 mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 } else {
                	             	create_cfg_packet_rsp(out_buf, pkt, cfg_type, ERROR, ctp, dev_no, operation);
                	             	mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 }
                	    	 }
            	    	 }
            		     break;
            	    case PKT_CFG_SET_REQ:
            	    	 if (start_received) {
                	    	 if(cfg_type == CFG_NWK) {
                	    		 if(parse_nwk_cfg_set_req(remote_cfg_buf, &modbus_data)) {
                	    			 create_cfg_packet_rsp(out_buf, pkt, cfg_type, SUCCESS, 0, 0, 0);
                	    			 mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 }
                	    	 } else if(cfg_type == CFG_CLOUD) {
                	    		 if(parse_cloud_cfg_set_req(remote_cfg_buf, &modbus_data)) {
                	    			 create_cfg_packet_rsp(out_buf, pkt, cfg_type, SUCCESS, 0, 0, 0);
                	    			 mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 }
                	    	 } else if(cfg_type == CFG_SERIAL) {
                	    		 if(parse_serial_cfg_set_req(remote_cfg_buf, &modbus_data)) {
                	    			 create_cfg_packet_rsp(out_buf, pkt, cfg_type, SUCCESS, 0, 0, 0);
                	    			 mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 }
                	    	 } else if(cfg_type == CFG_DATA_MAP) {
                	    		 uint8_t dev_no = 0, ctp = 0, operation = 0;
                	    		 parse_data_map_get_req(remote_cfg_buf, &ctp, &dev_no, &operation);
                	    		 PRINTF(">>CTP:%u DEV NO:%u OP:%u\n", ctp, dev_no, operation);
                	    		 if(parse_data_map_set_req(remote_cfg_buf, &modbus_data)) {
                	    			 create_cfg_packet_rsp(out_buf, pkt, cfg_type, SUCCESS, ctp, dev_no, operation);
                	    			 mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                	    		 }
                	    	 }
            	    	 }
            		     break;
            	    case PKT_MB_WRT_REQ:
            	    {
                    	 modbus_t *ctx;
                    	 uint8_t write_sts = 0;
                    	 mb_wrt_t mb_wrt_event;
                    	 if (parse_json_to_mb(remote_cfg_buf, &mb_wrt_event)) {
                    		 printf("\r\nJSON Parsed Successfully\r\n");
                    	     printf("MAC      : %s\r\n", mb_wrt_event.mac);
                    	     printf("SEQ NO   : %d\r\n", mb_wrt_event.seq_no);
                    	     printf("CTP      : %d\r\n", mb_wrt_event.ctp);
                    	     printf("IP       : %lu\r\n", mb_wrt_event.ip_addr);
                    	     printf("PORT     : %d\r\n", mb_wrt_event.port);
                    	     printf("SID      : %d\r\n", mb_wrt_event.sid);
                    	     printf("TIMEOUT  : %d\r\n", mb_wrt_event.tmt);
                             printf("FC       : %d\r\n", mb_wrt_event.fc);
                    	     printf("ADDR     : %d\r\n", mb_wrt_event.addr);
                    	     printf("DATA TYPE: %d\r\n", mb_wrt_event.data_type);
                    	     printf("LEN      : %d\r\n", mb_wrt_event.len);
                             printf("DATA     : ");
                    	     for (int i = 0; i < mb_wrt_event.len; i++) {
                    	        printf("%04X ", (uint16_t)mb_wrt_event.data[i]);
                    	     }
                    	     printf("\r\n");
                             int ret = -1;
                             if (mb_wrt_event.ctp == 1) {
                            	 ctx = ctx_uart1;
                                 modbus_set_debug(ctx, 0);
                                 modbus_set_slave(ctx, mb_wrt_event.sid);
                                 uint32_t to_sec  = mb_wrt_event.tmt / 1000;
                                 uint32_t to_usec = (mb_wrt_event.tmt % 1000) * 1000;
                                 modbus_set_response_timeout(ctx, to_sec, to_usec);
                                 write_sts = 1;
                             } else if (mb_wrt_event.ctp == 2) {
                    	    	 ctx = ctx_uart2;
                                 modbus_set_debug(ctx, 0);
                                 modbus_set_slave(ctx, mb_wrt_event.sid);
                                 uint32_t to_sec  = mb_wrt_event.tmt / 1000;
                                 uint32_t to_usec = (mb_wrt_event.tmt % 1000) * 1000;
                                 modbus_set_response_timeout(ctx, to_sec, to_usec);
                                 write_sts = 1;
                             } else {
                    	    	 tcp_connected_flg = 0;
                                 if (!ethernet_ok) {
                                	PRINTF("ETHERNET DISCONNECTED\n");
                                 } else {
                                    err_t err = tcp_client_init(0);
                                    if (err != ERR_OK) {
                                    	tcp_connection_close();
                                    } else {
                                        ctx_tcp = modbus_new_tcp(mb_wrt_event.ip_addr, mb_wrt_event.port);
                                        modbus_connect(ctx_tcp);
                                        uint32_t start_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
                                        modbus_set_debug(ctx_tcp, 0);
                                        modbus_set_slave(ctx_tcp, mb_wrt_event.sid);
                                        uint32_t to_sec  = mb_wrt_event.tmt / 1000;
                                        uint32_t to_usec = (mb_wrt_event.tmt % 1000) * 1000;
                                        modbus_set_response_timeout(ctx_tcp, to_sec, to_usec);
                                        ctx = ctx_tcp;
                                        while (!tcp_connected_flg) {
                                            uint32_t now = xTaskGetTickCount() * portTICK_PERIOD_MS;
                                            if ((now - start_time) >= mb_wrt_event.tmt) {
                                                PRINTF("TCP Connect failed\n");
                                                break;
                                             }
                                            vTaskDelay(pdMS_TO_TICKS(10));
                                         }

                                         if (tcp_connected_flg) {
                                        	PRINTF("TCP CONNECTED SUUCESS\n");
                                        	write_sts = 1;
                                         } else {
                                            modbus_close(ctx);
                                            modbus_free(ctx);
                                         }
                                     }
                                 }
                             }
                    	     if (mb_wrt_event.fc == 5 && write_sts) {
                    	    	 uint8_t bit = mb_wrt_event.data[0] ? 1 : 0;
                    	         ret = modbus_write_bit(ctx, mb_wrt_event.addr, bit);
                    	     } else if (mb_wrt_event.fc == 6 && write_sts) {
                    	    	 uint16_t value;
                    	         memcpy(&value, mb_wrt_event.data, sizeof(uint16_t));
                    	         ret = modbus_write_register(ctx, mb_wrt_event.addr, value);
                    	     } else if (mb_wrt_event.fc == 15 && write_sts) {
                    	    	 ret = modbus_write_bits(ctx, mb_wrt_event.addr, mb_wrt_event.len, mb_wrt_event.data);
                    	     } else if (mb_wrt_event.fc == 16 && write_sts) {
                    	    	 int nb = mb_wrt_event.len;
                    	         ret = modbus_write_registers(ctx, mb_wrt_event.addr, nb, (uint16_t *)mb_wrt_event.data);
                    	     }
                             char out_buf[256];
                    	     if (ret == -1) {
                    	    	 prepare_mb_wrt_response(out_buf, sizeof(out_buf), &mb_wrt_event, "FAIL");
                                 PRINTF("MODBUS WRITE FAILED\n");
                    	     } else {
                    	    	 prepare_mb_wrt_response(out_buf, sizeof(out_buf), &mb_wrt_event, "SUCCESS");
                    	    	 PRINTF("MODBUS WRITE SUCCESS\n");
                    	     }
                             mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
                    	     PRINTF("AFTER\n");
                    	 } else {
                    		 printf("JSON Parse Failed\n");
                    	 }
                	     if (mb_wrt_event.ctp == 3 && write_sts) {
                	    	 modbus_close(ctx);
                             modbus_free(ctx);
                	    	 vTaskDelay(1000);
                	     }
            	    }
            		break;
            	    default:
            	    	break;
            	}
            } else {
            	create_cfg_packet_rsp(out_buf, pkt, cfg_type, ERROR, 0, 0, 0);
            	mb_wrt_rsp_via_mqtt(out_buf, strlen(out_buf));
            }
            xSemaphoreGive(cloud_mutex);
            xSemaphoreGive(modbus_mutex);
        }
    }
}
/******************************************************************************
 * @brief       Device mode task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void Modbus_Task(void *pvParameters) {

	int rc = -1;
	uint16_t data_poll_interval_ms = modbus_data.data_poll_interval;
	static modbus_t *ctx_uart1 = NULL;
	static modbus_t *ctx_uart2 = NULL;
	static modbus_t *ctx_tcp = NULL;
	uint8_t coil_buf[32];
    uint16_t reg_data[128];
	taskENTER_CRITICAL();
    ctx_uart1 = modbus_new_rtu("uart4", modbus_data.serial_data.channel1.baud_rate, modbus_data.serial_data.channel1.parity,
    		modbus_data.serial_data.channel1.data_bits, modbus_data.serial_data.channel1.stop_bits);
    ctx_uart2 = modbus_new_rtu("uart5", modbus_data.serial_data.channel2.baud_rate, modbus_data.serial_data.channel2.parity,
    		modbus_data.serial_data.channel2.data_bits, modbus_data.serial_data.channel2.stop_bits);
    modbus_connect(ctx_uart1);
    modbus_connect(ctx_uart2);
    taskEXIT_CRITICAL();
    while (1) {

    	mcu_status++;
    	PRINTF("MODBUS stack: %lu words:%u\n", (unsigned long int)uxTaskGetStackHighWaterMark(NULL), mcu_status);
        /* --- Process RTU Channel 1 --- */

        for (uint8_t i = 0; i < modbus_data.rtu_port_1.num_devices; i++) {
        	xSemaphoreTake(modbus_mutex, portMAX_DELAY);
            rtu_device_t *dev = &modbus_data.rtu_port_1.devices[i];
            modbus_set_debug(ctx_uart1, 0);
            modbus_set_slave(ctx_uart1, dev->slave_id);
            uint32_t to_sec  = dev->response_timeout_ms / 1000;
            uint32_t to_usec = (dev->response_timeout_ms % 1000) * 1000;
            modbus_set_response_timeout(ctx_uart1, to_sec, to_usec);

            for (int p = 0; p < dev->num_points; p++) {
            	memset(reg_data, 0, sizeof(reg_data));
            	int start_address = dev->points[p].start_address;
            	int reg_count = dev->points[p].reg_count;
            	uint8_t reg_type = dev->points[p].reg_type;
                rc = -1;
                xSemaphoreTake(UartMutex, portMAX_DELAY);

                if (reg_type == REG_COIL) {
                    rc = modbus_read_bits(ctx_uart1, start_address, reg_count, coil_buf);
                } else if (reg_type == REG_DISCRETE_INPUT) {
                    rc = modbus_read_input_bits(ctx_uart1, start_address, reg_count, coil_buf);
                } else if (reg_type == REG_INPUT_REGISTER) {
                    rc = modbus_read_input_registers(ctx_uart1, start_address, reg_count, reg_data);
                } else {
                    rc = modbus_read_registers(ctx_uart1, start_address, reg_count, reg_data);
                }

                xSemaphoreGive(UartMutex);
                if (rc == -1) {
                    PRINTF("RTU1 Slave Read Failed\n");
                } else {
                	at32_led_on(LED2);
                    xSemaphoreTake(ResourceMutex, portMAX_DELAY);
                    if ((dev->points[p].reg_type == REG_COIL) || (dev->points[p].reg_type == REG_DISCRETE_INPUT)) {
                   	  memcpy(gw_cloud_data.rtu1[i].points[p].data,(uint8_t *)coil_buf, rc);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                        printf("[RTU1][%d][%d] Coils: ", i, p);
                        for (int j = 0; j < rc; j++) {
                            uint8_t val =
                                gw_cloud_data.rtu1[i].points[p].data[j];
                            printf("%02X ", val);
                        }
                         printf("\n");
#endif
                    } else {
                    	memcpy(gw_cloud_data.rtu1[i].points[p].data,(uint8_t *)reg_data, rc * 2);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                        printf("[RTU1][%d][%d]: ", i, p);
                        for (int j = 0; j < rc; j++) {
                            uint16_t val =
                                gw_cloud_data.rtu1[i].points[p].data[j * 2] |
                               (gw_cloud_data.rtu1[i].points[p].data[j * 2 + 1] << 8);
                            printf("%04X ", val);
                        }
                        printf("\n");
#endif
                    }
                    xSemaphoreGive(ResourceMutex);
                }
                vTaskDelay(100);
                at32_led_off(LED2);
            }
            xSemaphoreTake(ResourceMutex, portMAX_DELAY);
            gw_cloud_data.rtu1[i].timestamp = epoch_time_get();
            xSemaphoreGive(ResourceMutex);
            xSemaphoreGive(modbus_mutex);
        }

        if (!cloud_rtu1_start) {
        	cloud_rtu1_start = 1;
        }

        /* --- Process RTU Channel 2 --- */
        for (uint8_t i = 0; i < modbus_data.rtu_port_2.num_devices; i++) {
        	xSemaphoreTake(modbus_mutex, portMAX_DELAY);
            rtu_device_t *dev = &modbus_data.rtu_port_2.devices[i];
            modbus_set_debug(ctx_uart2, 0);
            modbus_set_slave(ctx_uart2, dev->slave_id);
            uint32_t to_sec  = dev->response_timeout_ms / 1000;
            uint32_t to_usec = (dev->response_timeout_ms % 1000) * 1000;
            modbus_set_response_timeout(ctx_uart2, to_sec, to_usec);

            for (int p = 0; p < dev->num_points; p++) { // dev->num_points
            	memset(reg_data, 0, sizeof(reg_data));
            	int start_address = dev->points[p].start_address;
            	int reg_count = dev->points[p].reg_count;
            	uint8_t reg_type = dev->points[p].reg_type;
                rc = -1;
                xSemaphoreTake(UartMutex, portMAX_DELAY);
                if (reg_type == REG_COIL) {
                    rc = modbus_read_bits(ctx_uart2, start_address, reg_count, coil_buf);
                } else if (reg_type == REG_DISCRETE_INPUT) {
                    rc = modbus_read_input_bits(ctx_uart2, start_address, reg_count, coil_buf);
                } else if (reg_type == REG_INPUT_REGISTER) {
                    rc = modbus_read_input_registers(ctx_uart2, start_address, reg_count, reg_data);
                } else {
                    rc = modbus_read_registers(ctx_uart2, start_address, reg_count, reg_data);
                }
                xSemaphoreGive(UartMutex);
                if (rc == -1) {
                    PRINTF("RTU2 Slave Read Failed\n");
                } else {
                	at32_led_on(LED4);
                    xSemaphoreTake(ResourceMutex, portMAX_DELAY);
                    if ((dev->points[p].reg_type == REG_COIL) || (dev->points[p].reg_type == REG_DISCRETE_INPUT)) {
                  	  memcpy(gw_cloud_data.rtu2[i].points[p].data, (uint8_t *)coil_buf, rc);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                        printf("[RTU2][%d][%d] Coils: ", i, p);
                         for (int j = 0; j < rc; j++) {
                             uint8_t val =
                                 gw_cloud_data.rtu2[i].points[p].data[j];
                             printf("%02X ", val);
                         }
                         printf("\n");
#endif
                    } else {
                    	memcpy(gw_cloud_data.rtu2[i].points[p].data,(uint8_t *)reg_data, rc * 2);
#if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                        printf("[RTU2][%d][%d]: ", i, p);
                        for (int j = 0; j < rc; j++) {
                            uint16_t val =
                                gw_cloud_data.rtu2[i].points[p].data[j * 2] |
                               (gw_cloud_data.rtu2[i].points[p].data[j * 2 + 1] << 8);
                            printf("%04X ", val);
                        }
                        printf("\n");
#endif
                    }
                    xSemaphoreGive(ResourceMutex);
                }
                vTaskDelay(100);
                at32_led_off(LED4);
            }
            xSemaphoreTake(ResourceMutex, portMAX_DELAY);
            gw_cloud_data.rtu2[i].timestamp = epoch_time_get();
            xSemaphoreGive(ResourceMutex);
            xSemaphoreGive(modbus_mutex);

        }
        if (!cloud_rtu2_start) {
        	cloud_rtu2_start = 1;
        }

        /* --- Process TCP Devices --- */
        for (uint8_t i = 0; i < modbus_data.tcp_port.num_devices; i++) {
        	xSemaphoreTake(modbus_mutex, portMAX_DELAY);
            tcp_device_t *dev = &modbus_data.tcp_port.devices[i];
            if (!ethernet_ok) {
            	PRINTF("ETHERNET DISCONNECTED\n");
                xSemaphoreTake(ResourceMutex, portMAX_DELAY);
                gw_cloud_data.tcp[i].timestamp = epoch_time_get();
                xSemaphoreGive(ResourceMutex);
                xSemaphoreGive(modbus_mutex);
            	vTaskDelay(1000);
            	continue;
            }
            err_t err = tcp_client_init(0);
            if (err != ERR_OK) {
            	tcp_connection_close();
                xSemaphoreTake(ResourceMutex, portMAX_DELAY);
                gw_cloud_data.tcp[i].timestamp = epoch_time_get();
                xSemaphoreGive(ResourceMutex);
                xSemaphoreGive(modbus_mutex);
            	vTaskDelay(1000);
                continue;
            }
            ctx_tcp = modbus_new_tcp(dev->slave_ip, dev->slave_port);
            modbus_connect(ctx_tcp);
            uint32_t start_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
            modbus_set_debug(ctx_tcp, 0);
            modbus_set_slave(ctx_tcp, dev->slave_id);
            uint32_t to_sec  = dev->response_timeout_ms / 1000;
            uint32_t to_usec = (dev->response_timeout_ms % 1000) * 1000;
            modbus_set_response_timeout(ctx_tcp, to_sec, to_usec);

            while (!tcp_connected_flg) {
                uint32_t now = xTaskGetTickCount() * portTICK_PERIOD_MS;
                if ((now - start_time) >= dev->response_timeout_ms) {
                    PRINTF("TCP Connect failed\n");
                    break;
                }
                vTaskDelay(pdMS_TO_TICKS(10));
            }

            if (tcp_connected_flg) {

                for (int p = 0; p < dev->num_points; p++) {
                	memset(reg_data, 0, sizeof(reg_data));
                	int start_address = dev->points[p].start_address;
                	int reg_count = dev->points[p].reg_count;
                	uint8_t reg_type = dev->points[p].reg_type;
                    rc = -1;
                    if (reg_type == REG_COIL) {
                        rc = modbus_read_bits(ctx_tcp, start_address, reg_count, coil_buf);
                    } else if (reg_type == REG_DISCRETE_INPUT) {
                        rc = modbus_read_input_bits(ctx_tcp, start_address, reg_count, coil_buf);
                    } else if (reg_type == REG_INPUT_REGISTER) {
                        rc = modbus_read_input_registers(ctx_tcp, start_address, reg_count, reg_data);
                    } else {
                        rc = modbus_read_registers(ctx_tcp, start_address, reg_count, reg_data);
                    }
                    if (rc == -1) {
                        PRINTF("TCP Slave Read Failed\n");
                    } else {
                    	at32_led_on(LED5);
                        xSemaphoreTake(ResourceMutex, portMAX_DELAY);
                        if ((dev->points[p].reg_type == REG_COIL) || (dev->points[p].reg_type == REG_DISCRETE_INPUT)) {
                        	memcpy(gw_cloud_data.tcp[i].points[p].data,(uint8_t *)coil_buf, rc);
    #if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                            printf("[TCP][%d][%d]: ", i, p);
                            for (int j = 0; j < rc; j++) {
                                uint16_t val =
                                    gw_cloud_data.tcp[i].points[p].data[j * 2] |
                                   (gw_cloud_data.tcp[i].points[p].data[j * 2 + 1] << 8);
                                printf("%04X ", val);
                            }
                            printf("\n");
    #endif
                        } else {
                        	memcpy(gw_cloud_data.tcp[i].points[p].data,(uint8_t *)reg_data, rc * 2);
    #if (DEBUG_PRINTF == ENABLE_PRINTF_ALL)
                            printf("[TCP][%d][%d]: ", i, p);
                            for (int j = 0; j < rc; j++) {
                                uint16_t val =
                                    gw_cloud_data.tcp[i].points[p].data[j * 2] |
                                   (gw_cloud_data.tcp[i].points[p].data[j * 2 + 1] << 8);
                                printf("%04X ", val);
                            }
                            printf("\n");
    #endif
                        }
                        xSemaphoreGive(ResourceMutex);
                    }
                    vTaskDelay(100);
                    at32_led_off(LED5);
                }
            }
            modbus_close(ctx_tcp);
            modbus_free(ctx_tcp);
            tcp_connected_flg = 0;
            xSemaphoreTake(ResourceMutex, portMAX_DELAY);
            gw_cloud_data.tcp[i].timestamp = epoch_time_get();
            xSemaphoreGive(ResourceMutex);
            xSemaphoreGive(modbus_mutex);
            vTaskDelay(1000);
        }
        if (!cloud_tcp_start) {
        	cloud_tcp_start = 1;
        }
        vTaskDelay(data_poll_interval_ms);
    }
}
/******************************************************************************
 * @brief       Cloud Communication Task
 * @param[in]   None
 * @return      None
 ******************************************************************************/
void Cloud_communication_Task(void *pvParameters) {

	uint8_t json_out[JSON_OUT_BUF_SIZE];
	taskENTER_CRITICAL();
	xSemaphoreTake(spiMutex, portMAX_DELAY);
	cdb_data_log_pointer_get();
	xSemaphoreGive(spiMutex);
	taskEXIT_CRITICAL();
	uint8_t cloud_mode = modbus_data.cloud_data.mode;
    uint32_t cloud_interval_ms = modbus_data.cloud_data.publish_interval_sec * 1000;
    uint32_t elapsed = cloud_interval_ms; // Force live data on first run
    uint8_t gsm_online = 0;
    while (1) {

        gsm_online = (gsm_ok == TCP_MODE || gsm_ok == HTTP_MODE || gsm_ok == MQTT_MODE);
        if (elapsed >= cloud_interval_ms) {
        	cloud_status++;
        	PRINTF("CLOUD COMM stack: %lu words:%u\n", (unsigned long int)uxTaskGetStackHighWaterMark(NULL), cloud_status);
            if (gsm_online) {
                for (uint8_t i = 0; i < modbus_data.rtu_port_1.num_devices && cloud_rtu1_start; i++) {
                	 xSemaphoreTake(cloud_mutex, portMAX_DELAY);
                     rtu_device_t *dev = &modbus_data.rtu_port_1.devices[i];
                     memset(json_out, 0, JSON_OUT_BUF_SIZE);
	                 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
#if CUSTOM_JSON_PACKET
	                 create_custom_rtu_json_packet("RTU1", dev, &gw_cloud_data.rtu1[i], json_out);
#else
	                 create_rtu_json_packet("RTU1", dev, &gw_cloud_data.rtu1[i], json_out);
#endif
	                 xSemaphoreGive(ResourceMutex);
	                 PRINTF("RTU1 CLOUD PKT:%s>>%u\r\n",json_out, strlen(json_out));
	                 if(!send_cloud_data(cloud_mode, json_out, strlen(json_out))) {
	                	 log_store_t log_str;
	                     log_str.dev_no = i;
	                 	 log_str.channel_type = 1;
	                 	 log_str.log_flg = 0xABAB;
	                 	 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	                 	 log_str.timestamp = gw_cloud_data.rtu1[i].timestamp;
	                  	 for (uint8_t p = 0; p < modbus_data.rtu_port_1.devices[i].num_points; p++) {
	                  		    memcpy(log_str.log_data[p], gw_cloud_data.rtu1[i].points[p].data, MAX_PAYLOAD);
	                  	 }
	                     xSemaphoreTake(spiMutex, portMAX_DELAY);
	                     cdb_write_data_log((uint8_t*)&log_str);
	                     xSemaphoreGive(spiMutex);
	                     xSemaphoreGive(ResourceMutex);
	                 }
	                 xSemaphoreGive(cloud_mutex);
	                 vTaskDelay(500);
                 }
                 /* ---------- RTU2 DEVICES ---------- */
                 for (uint8_t i = 0; i < modbus_data.rtu_port_2.num_devices && cloud_rtu2_start; i++) {
                	 xSemaphoreTake(cloud_mutex, portMAX_DELAY);
                	 memset(json_out, 0, JSON_OUT_BUF_SIZE);
                     rtu_device_t *dev = &modbus_data.rtu_port_2.devices[i];
	                 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
#if CUSTOM_JSON_PACKET
	                 create_custom_rtu_json_packet("RTU2", dev, &gw_cloud_data.rtu2[i], json_out);
#else
	                 create_rtu_json_packet("RTU2", dev, &gw_cloud_data.rtu2[i], json_out);
#endif
	                 xSemaphoreGive(ResourceMutex);
	                 PRINTF("RTU2 CLOUD PKT:%s>>%u\r\n",json_out, strlen(json_out));
	                 if(!send_cloud_data(cloud_mode, json_out, strlen(json_out))) {
	                	 log_store_t log_str;
	                     log_str.dev_no = i;
	                 	 log_str.channel_type = 2;
	                 	 log_str.log_flg = 0xABAB;
	                 	 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	                 	 log_str.timestamp = gw_cloud_data.rtu2[i].timestamp;
	                  	 for (uint8_t p = 0; p < modbus_data.rtu_port_2.devices[i].num_points; p++) {
	                  		    memcpy(log_str.log_data[p], gw_cloud_data.rtu2[i].points[p].data, MAX_PAYLOAD);
	                  	 }
	                     xSemaphoreTake(spiMutex, portMAX_DELAY);
	                     cdb_write_data_log((uint8_t*)&log_str);
	                     xSemaphoreGive(spiMutex);
	                     xSemaphoreGive(ResourceMutex);
	                 }
	                 xSemaphoreGive(cloud_mutex);
	                 vTaskDelay(500);
                 }
                 /* ---------- TCP1 DEVICES ---------- */
                 for (uint8_t i = 0; i < modbus_data.tcp_port.num_devices && cloud_tcp_start; i++) {
                	 xSemaphoreTake(cloud_mutex, portMAX_DELAY);
                	 memset(json_out, 0, JSON_OUT_BUF_SIZE);
                     tcp_device_t *dev = &modbus_data.tcp_port.devices[i];
	                 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
#if CUSTOM_JSON_PACKET
	                 create_custom_tcp_json_packet("TCP", dev, &gw_cloud_data.tcp[i], json_out);
#else
	                 create_tcp_json_packet("TCP", dev, &gw_cloud_data.tcp[i], json_out);
#endif
	                 xSemaphoreGive(ResourceMutex);
	                 PRINTF("TCP CLOUD PKT:%s>>%u\r\n",json_out, strlen(json_out));
	                 if(!send_cloud_data(cloud_mode, json_out, strlen(json_out))) {
	                	 log_store_t log_str;
	                     log_str.dev_no = i;
	                 	 log_str.channel_type = 3;
	                 	 log_str.log_flg = 0xABAB;
	                 	 xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	                 	 log_str.timestamp = gw_cloud_data.tcp[i].timestamp;
	                  	 for (uint8_t p = 0; p < modbus_data.tcp_port.devices[i].num_points; p++) {
	                  		    memcpy(log_str.log_data[p], gw_cloud_data.tcp[i].points[p].data, MAX_PAYLOAD);
	                  	 }
	                     xSemaphoreTake(spiMutex, portMAX_DELAY);
	                     cdb_write_data_log((uint8_t*)&log_str);
	                     xSemaphoreGive(spiMutex);
	                     xSemaphoreGive(ResourceMutex);
	                 }
	                 xSemaphoreGive(cloud_mutex);
	                 vTaskDelay(500);
                 }
            }/* else {
        		for (uint8_t i = 0; i < modbus_data.rtu_port_1.num_devices && cloud_rtu1_start; i++) {
        			log_store_t log_str;
                    rtu_device_t *dev = &modbus_data.rtu_port_1.devices[i];
                    log_str.dev_no = i;
                    log_str.channel_type = 1;
                    log_str.log_flg = 0xABAB;
                    xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	            	log_str.timestamp = gw_cloud_data.rtu1[i].timestamp;
	             	for (uint8_t p = 0; p < modbus_data.rtu_port_1.devices[i].num_points; p++) {
	             		memcpy(log_str.log_data[p], gw_cloud_data.rtu1[i].points[p].data, MAX_PAYLOAD);
	             	}
                    xSemaphoreTake(spiMutex, portMAX_DELAY);
                    cdb_write_data_log((uint8_t*)&log_str);
                    xSemaphoreGive(spiMutex);
                    xSemaphoreGive(ResourceMutex);
               	    vTaskDelay(100);
        		}

                for (uint8_t i = 0; i < modbus_data.rtu_port_2.num_devices && cloud_rtu2_start; i++) {
                	log_store_t log_str;
                    rtu_device_t *dev = &modbus_data.rtu_port_2.devices[i];
                    log_str.dev_no = i;
               	    log_str.channel_type = 2;
               	    log_str.log_flg = 0xABAB;
                    xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	            	log_str.timestamp = gw_cloud_data.rtu2[i].timestamp;
	             	for (uint8_t p = 0; p < modbus_data.rtu_port_2.devices[i].num_points; p++) {
	             		memcpy(log_str.log_data[p], gw_cloud_data.rtu2[i].points[p].data, MAX_PAYLOAD);
	             	}
                    xSemaphoreTake(spiMutex, portMAX_DELAY);
                    cdb_write_data_log((uint8_t*)&log_str);
                    xSemaphoreGive(spiMutex);
                    xSemaphoreGive(ResourceMutex);
                 	vTaskDelay(100);
                }

                for (uint8_t i = 0; i < modbus_data.tcp_port.num_devices && cloud_tcp_start; i++) {
                	log_store_t log_str;
                    tcp_device_t *dev = &modbus_data.tcp_port.devices[i];
                    log_str.dev_no = i;
                    log_str.channel_type = 3;
                    log_str.log_flg = 0xABAB;
                    xSemaphoreTake(ResourceMutex, portMAX_DELAY);
	            	log_str.timestamp = gw_cloud_data.tcp[i].timestamp;
	             	for (uint8_t p = 0; p < modbus_data.tcp_port.devices[i].num_points; p++) {
	             		memcpy(log_str.log_data[p], gw_cloud_data.tcp[i].points[p].data, MAX_PAYLOAD);
	             	}
                    xSemaphoreTake(spiMutex, portMAX_DELAY);
                    cdb_write_data_log((uint8_t*)&log_str);
                    xSemaphoreGive(spiMutex);
                    xSemaphoreGive(ResourceMutex);
               	    vTaskDelay(100);
                }

            } */
            elapsed = 0; // Restart interval counter
        }
        gsm_online = (gsm_ok == TCP_MODE || gsm_ok == HTTP_MODE || gsm_ok == MQTT_MODE);
        /* ===== 2 Every cycle: Send STORED LOGS if GSM is ready ===== */
        if (gsm_online) {
        	xSemaphoreTake(cloud_mutex, portMAX_DELAY);
            memset(&log_store_info, 0, sizeof(log_store_t));
            xSemaphoreTake(spiMutex, portMAX_DELAY);
            uint8_t log_sts = cdb_read_data_log((uint8_t*)&log_store_info);
            xSemaphoreGive(spiMutex);
			if (log_store_info.log_flg == 0xABAB && log_store_info.timestamp != 0) {
				PRINTF("LOG FLAG:%04X, %u\n",log_store_info.log_flg, log_store_info.timestamp);
				log_sts = log_sts & 1;
			} else {
				log_sts = log_sts & 0;
			}
			if (log_sts) {
				memset(json_out, 0, JSON_OUT_BUF_SIZE);
					if (log_store_info.channel_type == 1) {
						rtu_device_t *dev = &modbus_data.rtu_port_1.devices[log_store_info.dev_no];
						copy_rtu_log(dev, 1, log_store_info.timestamp, log_store_info.log_data, &log_snd_info);
					} else if (log_store_info.channel_type == 2) {
						rtu_device_t *dev = &modbus_data.rtu_port_2.devices[log_store_info.dev_no];
						copy_rtu_log(dev, 2, log_store_info.timestamp, log_store_info.log_data, &log_snd_info);
					} else {
						tcp_device_t *dev = &modbus_data.tcp_port.devices[log_store_info.dev_no];
						copy_tcp_log(dev, log_store_info.timestamp, log_store_info.log_data, &log_snd_info);
					}
#if CUSTOM_JSON_PACKET
					create_custom_data_log_json_packet(&log_snd_info, json_out);
#else
					create_data_log_json_packet(&log_snd_info, json_out);
#endif
					PRINTF("DATA LOG CLOUD PKT:%s>>%u\r\n",json_out, strlen(json_out));
					send_cloud_data(cloud_mode, json_out, strlen(json_out));
					vTaskDelay(100);
					elapsed += 1000;
			}
			xSemaphoreGive(cloud_mutex);
        }
        elapsed += 100;
        vTaskDelay(100);
    }
}
/******************************************************************************
 * @brief       GSM Task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void GSM_task(void *PvParameters) {
	gsm_engine();
}
/******************************************************************************
 * @brief       HTTP Server Task
 * @param[in]   None
 * @return      none
 ******************************************************************************/
void http_server_task(void *pvParameters) {

	while(1) {
		hal_gpio_toggle(PORT_WDI, PIN_WDI);
	    handle_ethernet_connection();
	    if (suspend_task == SUSPEND_TASK_FLAG) {
	    	printf("LWIP TASK stack: %lu ,%u,%uwords\n", (unsigned long int)uxTaskGetStackHighWaterMark(NULL), mcu_status, cloud_status);
	    	printf("MODBUS TASK stack: %lu words\n", (unsigned long int)uxTaskGetStackHighWaterMark(modbus_task_handler));
	    	printf("cloud TASK stack: %lu words\n", (unsigned long int)uxTaskGetStackHighWaterMark(cloud_comm_task_handler));
	    	printf("gsm TASK stack: %lu words\n", (unsigned long int)uxTaskGetStackHighWaterMark(gsm_task_handler));
	    	printf("MB WRT TASK stack: %lu words\n", (unsigned long int)uxTaskGetStackHighWaterMark(mb_wrt_task_handler));
	    	taskENTER_CRITICAL();
	    	vTaskDelete(modbus_task_handler);
	    	vTaskDelete(gsm_task_handler);
	    	vTaskDelete(cloud_comm_task_handler);
	    	taskEXIT_CRITICAL();
	    	at32_led_off(LED2);
	    	at32_led_off(LED4);
	    	at32_led_off(LED5);
	    	tcp_connection_close();
	    	httpd_init();
	    	led_mode_set(FACTORY_CONFIG_MODE);
	    	suspend_task = 0;
	    }
	    vTaskDelay(200);
	}
}
/******************************************************************************
 * @brief       Network Task function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void network_task_function(void *pvParameters) {

	while(1) {
		ip_details_t ip_cfg;
   	    fresh_device_config_t read_config;
   	    uint8_t flash_sts = read_fresh_device_config_from_flash(&read_config);
   	    mac_id_set(read_config.mac_address);
   	    mac_devid_set_for_cloud(read_config.mac_address, read_config.device_type_id, read_config.imei);
		uint16_t mode_state = device_config_mode_get();
		PRINTF("1.Device mode:%02X\n",mode_state);
		if (device_state == FRESH_DEVICE_CONFIG) {
			Cold_power_on();
		    if (xTaskCreate((TaskFunction_t)Fresh_dev_task, "fresh_task", 512, NULL, 2, NULL) != pdPASS) {
			    PRINTF("INFO : fresh dev task could not be created\n");
		    } else {
			    PRINTF("INFO: fresh dev task was created successfully\n");
		    }

		} else {
	   	    if (flash_sts == 0) {
	   	    	PRINTF("FOTA MAC ADDRESS READ FAILED\n");
	   	    	while(1);
	   	    }
			if (mode_state == WORKING_MODE_STATUS) {
				Read_modbus_config();
				device_state = WORKING_MODE;
				led_mode_set(WORKING_MODE);
			} else {
				device_state = FACTORY_CONFIG_MODE;
				led_mode_set(FACTORY_CONFIG_MODE);
			}
			ip_cfg.ip_mode = STATIC_IP; // static ip
			if (device_state == WORKING_MODE) {
				PRINTF("WORK WITH NWK\n");
				ip_cfg.local_ip = modbus_data.network_data.ipv4_address;
				ip_cfg.local_gw = modbus_data.network_data.default_gateway;
				ip_cfg.local_mask = modbus_data.network_data.subnet_mask;
			} else {
				PRINTF("WORK WITH DEFAULT\n");
		        ip_cfg.local_ip = 0XFA01A8C0;
		        ip_cfg.local_gw = 0X0101A8C0;
		        ip_cfg.local_mask = 0X00FFFFFF;
			}
			uint8_t error = hal_rmii_ethernet_init(&ip_cfg);
			if (device_state == WORKING_MODE) {
				taskENTER_CRITICAL();
			    if(xTaskCreate((TaskFunction_t)Modbus_Task, "Modbus task", 1024, NULL, tskIDLE_PRIORITY + 2, &modbus_task_handler) != pdPASS) {
					 PRINTF("Modbus task could not be created\r\n");
			    } else {
					 PRINTF("Modbus task was created successfully.\r\n");
			    }
			    if(xTaskCreate((TaskFunction_t)Cloud_communication_Task, "cloud_task", 1536, NULL, tskIDLE_PRIORITY + 3, &cloud_comm_task_handler) != pdPASS) {
					 PRINTF("Cloud communication task could not be created\r\n");
			    } else {
					 PRINTF("Cloud communication task was created successfully.\r\n");
			    }
			    if (xTaskCreate((TaskFunction_t)GSM_task, "gsm_task", 1024, NULL, tskIDLE_PRIORITY + 3, &gsm_task_handler) != pdPASS) {
				    PRINTF("INFO : gsm task could not be created\n");
			    } else {
				    PRINTF("INFO: gsm task was created successfully.\n");
			    }
#if ENABLE_MB_WRT_FEATURE
			    if (xTaskCreate((TaskFunction_t)mb_wrt_event_task, "mb_wrt_event_task", 1152, NULL, tskIDLE_PRIORITY + 2, &mb_wrt_task_handler) != pdPASS) {
				    PRINTF("INFO : gsm task could not be created\n");
			    } else {
				    PRINTF("INFO: gsm task was created successfully.\n");
			    }
#endif
			    taskEXIT_CRITICAL();
			} else {
			    uart_init(UART_4, 9600, 'N', 8, 1);
			    uart_init(UART_5, 9600, 'N', 8, 1);
				httpd_init();
			}
			fill_device_info(read_config.mac_address, modbus_data.network_data.ipv4_address, modbus_data.network_data.subnet_mask,
					modbus_data.network_data.default_gateway, read_config.device_type_id, firmware_version, read_config.imei);
		}
	    vTaskDelete(NULL);
	}
}
/******************************************************************************
 * @brief       Start RTOS function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void start_task(void) {

    ResourceMutex = xSemaphoreCreateMutex();
    if (ResourceMutex != NULL) {
        PRINTF("SEMAPHORE CREATED SUCCESSFULLY\r\n");
    }
    UartMutex = xSemaphoreCreateMutex();
    if (UartMutex != NULL) {
        PRINTF("UART SEMAPHORE CREATED SUCCESSFULLY\r\n");
    }
    spiMutex = xSemaphoreCreateMutex();
    if (spiMutex != NULL) {
        PRINTF("spiMutex SEMAPHORE CREATED SUCCESSFULLY\r\n");
    }
    mb_wrt_mutex = xSemaphoreCreateBinary();
    if (mb_wrt_mutex != NULL) {
        PRINTF("mb wrt SEMAPHORE CREATED SUCCESSFULLY\r\n");
    }
    modbus_mutex = xSemaphoreCreateMutex();
    if (modbus_mutex != NULL) {
        PRINTF("modbus SEMAPHORE CREATED SUCCESSFULLY\r\n");
    }
    cloud_mutex = xSemaphoreCreateMutex();
    if (cloud_mutex != NULL) {
        PRINTF("cloud SEMAPHORE CREATED SUCCESSFULLY\r\n");
    }
	if(xTaskCreate((TaskFunction_t)network_task_function,"Network_task", 1024, NULL, tskIDLE_PRIORITY + 3, NULL) != pdPASS) {
	    PRINTF("Network task could not be created \r\n");
	} else {
		PRINTF("Network task was created successfully.\r\n");
	}
	if (xTaskCreate((TaskFunction_t)http_server_task,"lwip_looping_task", 512, NULL, tskIDLE_PRIORITY + 4, NULL) != pdPASS) {
		PRINTF("INFO : lwip_recv_task could not be created\n");
	} else {
		PRINTF("INFO: lwip_periodic_handle task was created successfully.\n");
	}
	vTaskStartScheduler(); //configMINIMAL_STACK_SIZE
}
/******************************************************************************
 * @brief       Start gsm Init
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void GSM_init(void) {

	hal_gpio_init(PORT_3V8, PIN_3V8, GPIO_OUTPUT, PULL_NONE); // 3v8 pin init
	hal_gpio_write(PORT_3V8, PIN_3V8, GPIO_SET);
	hal_gpio_init(PORT_GSM_ON_OFF, PIN_GSM_ON_OFF, GPIO_OUTPUT, PULL_NONE); // Modem on/off
	hal_gpio_write(PORT_GSM_ON_OFF, PIN_GSM_ON_OFF, GPIO_SET);
	hal_gpio_init(PORT_GSM_RESET, PIN_GSM_RESET, GPIO_OUTPUT, PULL_NONE); // modem rst
	hal_gpio_write(PORT_GSM_RESET, PIN_GSM_RESET, GPIO_SET);
	hal_gpio_write(PORT_GSM_ON_OFF, PIN_GSM_ON_OFF, GPIO_RESET);
	hal_gpio_write(PORT_GSM_RESET, PIN_GSM_RESET, GPIO_RESET);
	if (device_state == FRESH_DEVICE_CONFIG) {
		PRINTF("UART WITHOUT FLOW\n");
		uart_init(USART_1, 115200, 'N', 8, 1);
	} else {
		PRINTF("UART WITH FLOW\n");
		uart_init(USART_1, 115200, 'N', 8, 1); // GSM Init with flow control
	}
}
/******************************************************************************
 * @brief       UART Direction control gpio init function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void uart_dir_control_gpio_init(void) {
	hal_gpio_init(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_OUTPUT, PULL_NONE);
	hal_gpio_write(PORT_UART4_DIR, PIN_UART4_DIR, GPIO_RESET);
	hal_gpio_init(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_OUTPUT, PULL_NONE);
	hal_gpio_write(PORT_UART5_DIR, PIN_UART5_DIR, GPIO_RESET);
	hal_timer_init(TIMER6,1);
}
/******************************************************************************
 * @brief       Watchdog gpio init function
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void watchdog_gpio_init(void) {
	hal_gpio_init(PORT_WDI, PIN_WDI, GPIO_OUTPUT, PULL_NONE);
}
/******************************************************************************
 * @brief       led timer initialization
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void led_init(void) {
	at32_board_init();
}
/******************************************************************************
 * @brief       Pheripheral initialization
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void Peripheral_init(void) {

	watchdog_gpio_init();
	uart_dir_control_gpio_init();
    hal_exint_init(USR_BUTTON_PORT, USR_BUTTON_PIN);
    uint8_t pin_status = hal_gpio_input_pin_read(USR_BUTTON_PORT, USR_BUTTON_PIN);
	if (pin_status == 0) {
		 uart_print_init(115200, 1);
         device_state = FRESH_DEVICE_CONFIG;
	} else {
		uart_print_init(115200, 0);
		led_init();
	}
    spiflash_init();
    uint16_t id = spiflash_read_id();
    PRINTF("SPI ID:%04X\n",id);
	GSM_init();
	hal_timer_init(TIMER1,10);
	hal_rtc_init();
	printf("AT32F437RGT7 Board init\r\n");
}
/******************************************************************************
 * @brief       app_main - start of application
 * @param[in]   none
 * @return      none
 ******************************************************************************/
void App_main(void) {

	Peripheral_init();
	ethernet_callback_register(eth_cbk_app);
	tcp_callback_register(tcp_client_cbk);
	timer_callback_register(timer_cbk);
	http_callback_register(http_cbk_app);
	hal_usr_butn_clbk_reg(user_button_cbk);
	uart_callback_register(uart_cbk_app);
	gsm_engine_callback_register(gsm_callback_app);
	mb_wrt_callback_register(mb_wrt_app);
	xmodem_callback_register(xModem_cbk);
    start_task();
}



 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
