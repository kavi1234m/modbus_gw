#include "../../../target_at32f347/include/flash_map_backend/flash_map_backend.h"
#include "sysflash/sysflash.h"
#include <string.h>
#include <stdlib.h>
#include "bootutil/bootutil_log.h"
#include <mcuboot_config/mcuboot_config.h>
#include "at32f435_437_conf.h"

/* AT32F437 Flash Configuration - Based on Datasheet */
#define FLASH_SECTOR_SIZE       0x800   /* 2KB - Smallest erasable unit */
#define FLASH_WRITE_ALIGN       4       /* 4-byte word writes */
#define FLASH_ERASED_VAL        0xFF    /* Flash reads 0xFF when erased */
#define FLASH_TOTAL_SECTORS     512     /* 512 sectors total (1024KB / 2KB) */

/* Flash memory organization */
#define FLASH_BANK1_START       0x08000000
#define FLASH_BANK1_END         0x0807FFFF  /* 512KB */
#define FLASH_BANK2_START       0x08080000
#define FLASH_BANK2_END         0x080FFFFF  /* 512KB */
#define FLASH_TOTAL_SIZE        0x100000    /* 1024KB */

#ifndef AT_FLASH_BASE
#define AT_FLASH_BASE        (0x08000000)
#endif

#define ARRAY_SIZE(arr) sizeof(arr)/sizeof(arr[0])

static struct flash_area bootloader =
{
    .fa_id = FLASH_AREA_BOOTLOADER,
    .fa_device_id = FLASH_DEVICE_INTERNAL_FLASH,
    .fa_off = AT_FLASH_BASE,
    .fa_size = AT_BOOT_BOOTLOADER_SIZE
};

static struct flash_area primary_img0 =
{
    .fa_id =FLASH_AREA_IMAGE_PRIMARY(0),
    .fa_device_id = FLASH_DEVICE_INTERNAL_FLASH,
    .fa_off = AT_FLASH_BASE + AT_BOOT_BOOTLOADER_SIZE,
    .fa_size = AT_BOOT_PRIMARY_1_SIZE
};

static struct flash_area secondary_img0 =
{
    .fa_id = FLASH_AREA_IMAGE_SECONDARY(0),
    .fa_device_id = FLASH_DEVICE_INTERNAL_FLASH,
    .fa_off = AT_FLASH_BASE + AT_BOOT_BOOTLOADER_SIZE + AT_BOOT_PRIMARY_1_SIZE,
    .fa_size = AT_BOOT_SECONDARY_1_SIZE
};

#ifdef MCUBOOT_SWAP_USING_SCRATCH
static struct flash_area scratch =
{
    .fa_id = FLASH_AREA_IMAGE_SCRATCH,
    .fa_device_id = FLASH_DEVICE_INTERNAL_FLASH,
#if (MCUBOOT_IMAGE_NUMBER == 1) /* if single-image */
    .fa_off = AT_FLASH_BASE +\
               AT_BOOT_BOOTLOADER_SIZE +\
               AT_BOOT_PRIMARY_1_SIZE +\
               AT_BOOT_SECONDARY_1_SIZE,
#elif (MCUBOOT_IMAGE_NUMBER == 2) /* if dual-image */
    .fa_off = AT_FLASH_BASE +\
                AT_BOOT_BOOTLOADER_SIZE +\
                AT_BOOT_PRIMARY_1_SIZE +\
                AT_BOOT_SECONDARY_1_SIZE +\
                AT_BOOT_PRIMARY_2_SIZE +\
                AT_BOOT_SECONDARY_2_SIZE,
#endif
    .fa_size = AT_BOOT_SCRATCH_SIZE
};
#endif

static const struct flash_area *s_flash_areas[] = {
  &bootloader,
  &primary_img0,
  &secondary_img0,
#ifdef MCUBOOT_SWAP_USING_SCRATCH
  &scratch,
#endif
};

static const struct flash_area *prv_lookup_flash_area(uint8_t id) {
  for (size_t i = 0; i < ARRAY_SIZE(s_flash_areas); i++) {
    const struct flash_area *area = s_flash_areas[i];
    if (id == area->fa_id) {
      return area;
    }
  }
  return NULL;
}

int flash_area_open(uint8_t id, const struct flash_area **area_outp)
{
    BOOT_LOG_DBG("%s: ID=%d", __func__, (int)id);
    const struct flash_area *area = prv_lookup_flash_area(id);
    *area_outp = area;
    return area != NULL ? 0 : -1;
}


void flash_area_close(const struct flash_area *area) {
	 (void)area; /* Prevent unused parameter warning */
}

int flash_area_read(const struct flash_area *fa, uint32_t off, void *dst,
                    uint32_t len) {
	if (fa->fa_device_id != FLASH_DEVICE_INTERNAL_FLASH) {
	    return -1;
	  }

	const uint32_t end_offset = off + len;
	  if (end_offset > fa->fa_size) {
	    MCUBOOT_LOG_ERR("%s: Out of Bounds (0x%x vs 0x%x)", __func__, end_offset, fa->fa_size);
	    return -1;
	  }
    /* Direct memory read from flash */
	  void  *src = (void  *)(fa->fa_off + off);
    memcpy(dst, src, len);
    return 0;
}

int flash_area_write(const struct flash_area *fa, uint32_t off, const void *src,
                     uint32_t len) {
    if (fa == NULL || src == NULL) {
        return -1;
    }

    if (off + len > fa->fa_size) {
        MCUBOOT_LOG_ERR("Write beyond area: off=0x%lx, len=%lu, size=0x%lx",
                        (unsigned long)off, (unsigned long)len,
                        (unsigned long)fa->fa_size);
        return -1;
    }

    /* Check alignment */
    if ((off % FLASH_WRITE_ALIGN) != 0 || (len % FLASH_WRITE_ALIGN) != 0) {
        MCUBOOT_LOG_ERR("Unaligned write: off=0x%lx, len=%lu, align=%lu",
                        (unsigned long)off, (unsigned long)len,
                        (unsigned long)FLASH_WRITE_ALIGN);
        return -1;
    }

    flash_status_type status;
    uint32_t address = fa->fa_off + off;
    const uint32_t *data = (const uint32_t *)src;
    uint32_t words = len / 4;

    /* Unlock flash */
    flash_unlock();

    /* Program words */
    for (uint32_t i = 0; i < words; i++) {
        status = flash_word_program(address + (i * 4), data[i]);
        if (status != FLASH_OPERATE_DONE) {
            MCUBOOT_LOG_ERR("Flash write failed at 0x%lx: status=%d",
                           (unsigned long)(address + (i * 4)), status);
            flash_lock();
            return -1;
        }
    }

    flash_lock();
    return 0;
}

int flash_area_erase(const struct flash_area *fa, uint32_t off, uint32_t len) {
    if (fa == NULL) {
        return -1;
    }

    if (off + len > fa->fa_size) {
        MCUBOOT_LOG_ERR("Erase beyond area: off=0x%lx, len=%lu, size=0x%lx",
                        (unsigned long)off, (unsigned long)len,
                        (unsigned long)fa->fa_size);
        return -1;
    }

    /* Must be sector-aligned */
    if ((off % FLASH_SECTOR_SIZE) != 0 || (len % FLASH_SECTOR_SIZE) != 0) {
        MCUBOOT_LOG_ERR("Unaligned erase: off=0x%lx, len=%lu, sector_size=0x%lx",
                        (unsigned long)off, (unsigned long)len,
                        (unsigned long)FLASH_SECTOR_SIZE);
        return -1;
    }

    flash_status_type status;
    uint32_t start_address = fa->fa_off + off;
    uint32_t sectors_to_erase = len / FLASH_SECTOR_SIZE;

    /* Unlock flash */
    flash_unlock();

    /* Erase each sector */
    for (uint32_t i = 0; i < sectors_to_erase; i++) {
        uint32_t sector_address = start_address + (i * FLASH_SECTOR_SIZE);

        status = flash_sector_erase(sector_address);
        if (status != FLASH_OPERATE_DONE) {
            MCUBOOT_LOG_ERR("Sector erase failed at 0x%lx: status=%d",
                           (unsigned long)sector_address, status);
            flash_lock();
            return -1;
        }

        /* Wait for operation to complete */
        status = flash_operation_wait_for(1000); /* 1 second timeout */
        if (status != FLASH_OPERATE_DONE) {
            MCUBOOT_LOG_ERR("Erase timeout at 0x%lx", (unsigned long)sector_address);
            flash_lock();
            return -1;
        }
    }

    flash_lock();
    return 0;
}

size_t flash_area_align(const struct flash_area *area) {
    (void)area;
    return FLASH_WRITE_ALIGN;
}

uint8_t flash_area_erased_val(const struct flash_area *area) {
	(void)area;
	return FLASH_ERASED_VAL;
}

int flash_area_get_sectors(int fa_id, uint32_t *count,
                           struct flash_sector *sectors) {
	const struct flash_area *fa = prv_lookup_flash_area(fa_id);
	if (fa->fa_device_id != FLASH_DEVICE_INTERNAL_FLASH) {
		return -1;
	}

	// All sectors for the NRF52 are the same size
	const size_t sector_size = FLASH_SECTOR_SIZE;
	uint32_t total_count = 0;
	for (size_t off = 0; off < fa->fa_size; off += sector_size) {
		// Note: Offset here is relative to flash area, not device
	    sectors[total_count].fs_off = off;
	    sectors[total_count].fs_size = sector_size;
	    total_count++;
	}

	*count = total_count;
	return 0;
}

int flash_area_get_sector(
		const struct flash_area *fa,
		uint32_t off,
		struct flash_sector *sector){
    sector->fs_off = (off / FLASH_SECTOR_SIZE) * FLASH_SECTOR_SIZE;
    sector->fs_size = FLASH_SECTOR_SIZE;

//    MCUBOOT_LOG_INF("inside get sector");
    return 0;
}

uint32_t flash_sector_get_off(const struct flash_sector *fs)
{
    return fs->fs_off;
}

uint32_t flash_sector_get_size(const struct flash_sector *fs){
	return fs->fs_size;
}
int flash_area_id_from_multi_image_slot(int image_index, int slot) {
    switch (slot) {
      case 0:
        return FLASH_AREA_IMAGE_PRIMARY(image_index);
      case 1:
        return FLASH_AREA_IMAGE_SECONDARY(image_index);
    }

    MCUBOOT_LOG_ERR("Unexpected Request: image_index=%d, slot=%d", image_index, slot);
    return -1; /* flash_area_open will fail on that */
}

int flash_area_id_from_image_slot(int slot) {
  return flash_area_id_from_multi_image_slot(0, slot);
}

/*< Obtains ID of the flash area characterized by `fa` */
int  flash_area_get_id(const struct flash_area *fa){
	return fa->fa_id;
}
/*< Obtains ID of a device the flash area `fa` described region resides on */
int  flash_area_get_device_id(const struct flash_area *fa){
	return fa->fa_device_id;
}
/*< Obtains offset, from the beginning of a device, the flash area described
 * region starts at */
uint32_t flash_area_get_off(const struct flash_area *fa){
	return fa->fa_off;
}
/*< Obtains size, from the offset, of the flash area `fa` characterized region */
uint32_t flash_area_get_size(const struct flash_area *fa){
	return fa->fa_size;
}
