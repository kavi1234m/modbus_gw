/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

#ifndef FLASH_MAP_BACKEND_H__
#define FLASH_MAP_BACKEND_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 *
 * Provides abstraction of flash regions for type of use.
 * I.e. dude where's my image?
 *
 * System will contain a map which contains flash areas. Every
 * region will contain flash identifier, offset within flash and length.
 *
 * 1. This system map could be in a file within filesystem (Initializer
 * must know/figure out where the filesystem is at).
 * 2. Map could be at fixed location for project (compiled to code)
 * 3. Map could be at specific place in flash (put in place at mfg time).
 *
 * Note that the map you use must be valid for BSP it's for,
 * match the linker scripts when platform executes from flash,
 * and match the target offset specified in download script.
 */

#include <stdint.h>
#include <stddef.h>

/**
 * @brief Structure describing an area on a flash device.
 *
 * Multiple flash devices may be available in the system, each of
 * which may have its own areas. For this reason, flash areas track
 * which flash device they are part of.
 */
struct flash_area {
	/**
	  This flash area's ID; unique in the system.
	  The slot/scratch identification */
  uint8_t  fa_id;

  uint8_t  fa_device_id;  /** The device id (usually there's only one) */
  uint16_t pad16;
  uint32_t fa_off;        /** The flash offset from the beginning */
  uint32_t fa_size;       /** The size of this sector */
};

/**
 * @brief Structure describing a sector within a flash area.
 *
 * Each sector has an offset relative to the start of its flash area
 * (NOT relative to the start of its flash device), and a size. A
 * flash area may contain sectors with different sizes.
 */
struct flash_sector {
  //! Offset of this sector, from the start of its flash area (not device).
  uint32_t fs_off;

  //! Size of this sector, in bytes.
  uint32_t fs_size;
};

//! Opens the area for use. id is one of the `fa_id`s */
/*
 * Start using flash area.
 */

int flash_area_open(uint8_t id, const struct flash_area **area_outp) ;
void flash_area_close(const struct flash_area *area);

/*
 * Read/write/erase. Offset is relative from beginning of flash area.
 */

int flash_area_read(
		const struct flash_area *fa,
		uint32_t off,
		void *dst,
		uint32_t len);

int flash_area_write(
		const struct flash_area *fa,
		uint32_t off,
		const void *src,
		uint32_t len);

int flash_area_erase(
		const struct flash_area *fa,
		uint32_t off,
		uint32_t len) ;

/*
 * Alignment restriction for flash writes.
 */
size_t flash_area_align(const struct flash_area *area);

/*
 * What is value is read from erased flash bytes.
 */
uint8_t flash_area_erased_val(const struct flash_area *area);

/*
 * Given flash area ID, return info about sectors within the area.
 */
int flash_area_get_sectors(
		int fa_id,
		uint32_t *count,
		struct flash_sector *sectors);

/* Retrieve the flash sector a given offset, within flash area.
 *
 * @param fa        flash area.
 * @param off       offset of sector.
 * @param sector    pointer to structure for obtained information.
 * Returns 0 on success, or an error code on failure.
 */
int flash_area_get_sector(
		const struct flash_area *fa,
		uint32_t off,
		struct flash_sector *sector);

/*
 * Similar to flash_area_get_sectors(), but return the values in an
 * array of struct flash_area instead.
 */

int flash_area_id_from_multi_image_slot(int image_index, int slot);
int flash_area_id_from_image_slot(int slot);
/*< Returns the slot (0 for primary or 1 for secondary), for the supplied
    `image_index` and `area_id`. `area_id` is unique and is represented by
    `fa_id` in the `flash_area` struct. */
int flash_area_id_to_multi_image_slot(int image_index, int area_id);


uint32_t flash_sector_get_off(const struct flash_sector *fs);

uint32_t flash_sector_get_size(const struct flash_sector *fs);

/*< Obtains ID of the flash area characterized by `fa` */
int     flash_area_get_id(const struct flash_area *fa);
/*< Obtains ID of a device the flash area `fa` described region resides on */
int     flash_area_get_device_id(const struct flash_area *fa);
/*< Obtains offset, from the beginning of a device, the flash area described
 * region starts at */
uint32_t flash_area_get_off(const struct flash_area *fa);
/*< Obtains size, from the offset, of the flash area `fa` characterized region */
uint32_t flash_area_get_size(const struct flash_area *fa);

int external_flash_read(const struct flash_area *fa, uint32_t off,
                        void *dst, uint32_t len);
int external_flash_write(const struct flash_area *fa, uint32_t off,
                         const void *src, uint32_t len);
int external_flash_erase(const struct flash_area *fa, uint32_t off, uint32_t len);

#endif /* FLASH_MAP_BACKEND_H__ */
