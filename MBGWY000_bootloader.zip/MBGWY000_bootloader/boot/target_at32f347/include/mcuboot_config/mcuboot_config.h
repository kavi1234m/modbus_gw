#ifndef __MCUBOOT_CONFIG_H__
#define __MCUBOOT_CONFIG_H__

/*
 * ===========================================================
 *  MCUboot Configuration for AT32F437 (TinyCrypt + Direct XIP)
 * ===========================================================
 */

/*
 * ==========
 * Signature
 * ==========
 * Use only one algorithm.
 * EC256 with TinyCrypt is smallest and secure.
 */
#define MCUBOOT_SIGN_EC256

/*
 * ==========
 * Crypto backend
 * ==========
 */
#define MCUBOOT_USE_TINYCRYPT        1
/* Do not use SHA512 unless using ED25519 */
// #define MCUBOOT_SHA512

/*
 * ==========
 * Boot mode
 * ==========
 * You�re executing directly from external flash (XIP).
 */
#define MCUBOOT_DIRECT_XIP

/* Optional: enable validation of primary image before boot */
#define MCUBOOT_VALIDATE_PRIMARY_SLOT

/* Disable revert/swap logic for smallest binary */
// #define MCUBOOT_DIRECT_XIP_REVERT
// #define MCUBOOT_SWAP_USING_SCRATCH
// #define MCUBOOT_OVERWRITE_ONLY

/*
 * ==========
 * Flash layout
 * ==========
 */
#define MCUBOOT_USE_FLASH_AREA_GET_SECTORS
#define MCUBOOT_MAX_IMG_SECTORS      512
#define MCUBOOT_IMAGE_NUMBER         1

/*
 * ==========
 * Security
 * ==========
 */
/* Disable encrypted images for smallest footprint */
// #define MCUBOOT_ENC_IMAGES
/* Disable PSA / hardware crypto */
// #define MCUBOOT_USE_PSA_CRYPTO
/* Disable fault injection hardening */
#define MCUBOOT_FIH_PROFILE_OFF 1

#define MCUBOOT_USE_TLV_ALLOW_LIST

/*
 * ==========
 * Logging
 * ==========
 * Disable all logs to save flash.
 */
 #define MCUBOOT_HAVE_LOGGING 1
// #define MCUBOOT_LOG_LEVEL MCUBOOT_LOG_LEVEL_ERROR

/*
 * ==========
 * Watchdog and Idle
 * ==========
 */
#define MCUBOOT_WATCHDOG_FEED() do { } while (0)
#define MCUBOOT_CPU_IDLE()      do { } while (0)

#endif /* __MCUBOOT_CONFIG_H__ */
