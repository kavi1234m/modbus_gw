#ifndef __SYSFLASH_H__
#define __SYSFLASH_H__

#include <mcuboot_config/mcuboot_config.h>

//! A user-defined identifier for different storage mediums
//! (i.e internal flash, external NOR flash, eMMC, etc)
#define FLASH_DEVICE_INTERNAL_FLASH     (1)

/* Uncomment if external flash is being used */
#define AT_BOOT_USE_EXTERNAL_FLASH 		(2)

#define FLASH_AREA_BOOTLOADER 0
#define FLASH_AREA_IMAGE_0 1
#define FLASH_AREA_IMAGE_1 2
#define FLASH_AREA_IMAGE_SCRATCH 3
#define FLASH_AREA_IMAGE_2 4
#define FLASH_AREA_IMAGE_3 5


#define AT_FLASH_DEVICE_BASE                (AT_FLASH_BASE)

#ifndef AT_BOOT_SCRATCH_SIZE
#define AT_BOOT_SCRATCH_SIZE                (0xC800)
#endif

#ifndef AT_BOOT_BOOTLOADER_SIZE
#define AT_BOOT_BOOTLOADER_SIZE             (0xC800)	//50kb
#endif

#ifndef AT_BOOT_PRIMARY_1_SIZE
#define AT_BOOT_PRIMARY_1_SIZE              (0x79800)
#endif

#ifndef AT_BOOT_SECONDARY_1_SIZE
#define AT_BOOT_SECONDARY_1_SIZE            (0x79800)
#endif

#if (MCUBOOT_IMAGE_NUMBER == 1)
/*
 * NOTE: the definition below returns the same values for true/false on
 * purpose, to avoid having to mark x as non-used by all callers when
 * running in single image mode.
 */
#define FLASH_AREA_IMAGE_PRIMARY(x)    (((x) == 0) ?                \
                                         FLASH_AREA_IMAGE_0 : \
                                         FLASH_AREA_IMAGE_0)
#define FLASH_AREA_IMAGE_SECONDARY(x)  (((x) == 0) ?                \
                                         FLASH_AREA_IMAGE_1 : \
                                         FLASH_AREA_IMAGE_1)
#elif (MCUBOOT_IMAGE_NUMBER == 2)
/* MCUBoot currently supports only up to 2 updateable firmware images.
 * If the number of the current image is greater than MCUBOOT_IMAGE_NUMBER - 1
 * then a dummy value will be assigned to the flash area macros.
 */
#define FLASH_AREA_IMAGE_PRIMARY(x)    (((x) == 0) ?                \
                                         FLASH_AREA_IMAGE_0: \
                                        ((x) == 1) ?                \
                                        FLASH_AREA_IMAGE_2 : \
                                         255)
#define FLASH_AREA_IMAGE_SECONDARY(x)  (((x) == 0) ?                \
                                        FLASH_AREA_IMAGE_1 : \
                                        ((x) == 1) ?                \
                                        FLASH_AREA_IMAGE_3: \
                                         255)
#else
#error "Image slot and flash area mapping is not defined"
#endif

#endif /* __SYSFLASH_H__ */
