/**
  **************************
  * @file    spi_flash.c
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Aug 1
  * @brief   This file provides functions to manage the following
  *          breif the functionalities here:
  *           - function 1
  *           - function 2
  *           - function 3
  *
  *  @verbatim
  *
  *          ===================================================================
  *                             Working of chip/peripheral/Algorithm
  *          ===================================================================
  *
  *          Heading No.1
  *          =============
  *          Explanation
  *
  *          Heading No.2
  *          =============
  *          Explanation

  *          ===================================================================
  *                              How to use this driver / source
  *          ===================================================================
  *            -
  *            -
  *            -
  *            -
  *
  *  @endverbatim
  *
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2022 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */


/* Includes ------------------------------------------------------------------*/
#include "spi_flash.h"


/* Private typedef -----------------------------------------------------------*/

#define xTaskGetTickCount()                 5000

#define DEV_MODE_ADDR                        0X0000
#define NWK_CFG_ADDR                         0X1000
#define CLOUD_CFG_ADDR                       0X2000
#define SERIAL_CFG_ADDR                      0X3000
#define RTU1_DATA_MAP_CFG_ADDR               0X4000
#define RTU2_DATA_MAP_CFG_ADDR               0X9000
#define TCP_DATA_MAP_CFG_ADDR                0XE000
#define BACKUP_DEV_MODE_ADDR                 0X40000
#define BACKUP_NWK_CFG_ADDR                  0X50000
#define BACKUP_CLOUD_CFG_ADDR                0X60000
#define BACKUP_SERIAL_CFG_ADDR               0X70000
#define BACKUP_RTU1_DATA_MAP_CFG_ADDR        0X80000
#define BACKUP_RTU2_DATA_MAP_CFG_ADDR        0XD0000
#define BACKUP_TCP_DATA_MAP_CFG_ADDR         0X300000

#define MAX_FLASH_READ_RETRY             5

#define CS_SPI_PORT                   GPIOA
#define CS_SPI_PIN                    GPIO_PINS_4
#define SCK_SPI_PORT                  GPIOA
#define SCK_SPI_PIN                   GPIO_PINS_5
#define MISO_SPI_PORT                 GPIOA
#define MISO_SPI_PIN                  GPIO_PINS_6
#define MOSI_SPI_PORT                 GPIOA
#define MOSI_SPI_PIN                  GPIO_PINS_7

#define FLASH_CS_HIGH()                  gpio_bits_set(GPIOA, GPIO_PINS_15)
#define FLASH_CS_LOW()                   gpio_bits_reset(GPIOA, GPIO_PINS_15)

#define PAGE_PROGRAM_TIME    250
#define SECTOR_ERASE_TIME    500

#define SPI_FLASH_ERASE_ERROR   2
#define SPI_FLASH_WRITE_ERROR   3
#define SPI_FLASH_READ_ERROR    4

#define SPI_RETRY_COUNT         5

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint8_t spiflash_sector_buf[SPIF_SECTOR_SIZE];
uint8_t nwk_status;
uint8_t serial_status;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/****************************************************************************************************************
  * @brief  spi configuration.
  * @param  none
  * @retval none
  ***************************************************************************************************************/
void spiflash_init(void)
{
  gpio_init_type gpio_initstructure;
  spi_init_type spi_init_struct;

  crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);
  crm_periph_clock_enable(CRM_GPIOB_PERIPH_CLOCK, TRUE);
  /* software cs, pd0 as a general io to control flash cs */
  gpio_initstructure.gpio_out_type       = GPIO_OUTPUT_PUSH_PULL;
  gpio_initstructure.gpio_pull           = GPIO_PULL_UP;
  gpio_initstructure.gpio_mode           = GPIO_MODE_OUTPUT;
  gpio_initstructure.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_initstructure.gpio_pins           = GPIO_PINS_15;
  gpio_init(GPIOA, &gpio_initstructure);
  gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE15, GPIO_MUX_5);
  /* sck */
  gpio_initstructure.gpio_pull           = GPIO_PULL_UP;
  gpio_initstructure.gpio_mode           = GPIO_MODE_MUX;
  gpio_initstructure.gpio_pins           = GPIO_PINS_3;
  gpio_init(GPIOB, &gpio_initstructure);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE3, GPIO_MUX_5);

  /* miso */
  gpio_initstructure.gpio_pull           = GPIO_PULL_UP;
  gpio_initstructure.gpio_pins           = GPIO_PINS_4;
  gpio_init(GPIOB, &gpio_initstructure);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE4, GPIO_MUX_5);

  /* mosi */
  gpio_initstructure.gpio_pull           = GPIO_PULL_UP;
  gpio_initstructure.gpio_pins           = GPIO_PINS_5;
  gpio_init(GPIOB, &gpio_initstructure);
  gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE5, GPIO_MUX_5);

  FLASH_CS_HIGH();
  crm_periph_clock_enable(CRM_SPI1_PERIPH_CLOCK, TRUE);
  spi_default_para_init(&spi_init_struct);
  spi_init_struct.transmission_mode = SPI_TRANSMIT_FULL_DUPLEX;
  spi_init_struct.master_slave_mode = SPI_MODE_MASTER;
  spi_init_struct.mclk_freq_division = SPI_MCLK_DIV_8;
  spi_init_struct.first_bit_transmission = SPI_FIRST_BIT_MSB;
  spi_init_struct.frame_bit_num = SPI_FRAME_8BIT;
  spi_init_struct.clock_polarity = SPI_CLOCK_POLARITY_HIGH;
  spi_init_struct.clock_phase = SPI_CLOCK_PHASE_2EDGE;
  spi_init_struct.cs_mode_selection = SPI_CS_SOFTWARE_MODE;
  spi_init(SPI1, &spi_init_struct);
  spi_enable(SPI1, TRUE);

}
/****************************************************************************************************************
  * @brief  write data to flash
  * @param  pbuffer: the pointer for data buffer
  * @param  write_addr: the address where the data is written
  * @param  length: buffer length
  * @retval none
  ***************************************************************************************************************/
uint8_t spiflash_write(uint8_t *pbuffer, uint32_t write_addr, uint32_t length)
{
  uint32_t sector_pos;
  uint16_t sector_offset;
  uint16_t sector_remain;
  uint16_t index;
  uint8_t *spiflash_buf;
  spiflash_buf = spiflash_sector_buf;

  /* sector address */
  sector_pos = write_addr / SPIF_SECTOR_SIZE;

  /* address offset in a sector */
  sector_offset = write_addr % SPIF_SECTOR_SIZE;

  /* the remain in a sector */
  sector_remain = SPIF_SECTOR_SIZE - sector_offset;
  if(length <= sector_remain)
  {
    /* smaller than a sector size */
    sector_remain = length;
  }
  while(1)
  {
    /* read a sector */
    spiflash_read(spiflash_buf, sector_pos * SPIF_SECTOR_SIZE, SPIF_SECTOR_SIZE);

    /* validate the read erea */
    for(index = 0; index < sector_remain; index++)
    {
      if(spiflash_buf[sector_offset + index] != 0xFF)
      {
        /* there are some data not equal 0xff, so this secotr needs erased */
        break;
      }
    }
    if(index < sector_remain)
    {
      /* erase the sector */
      spiflash_sector_erase(sector_pos);

      /* copy the write data */
      for(index = 0; index < sector_remain; index++)//write length times
      {
        spiflash_buf[index + sector_offset] = pbuffer[index];
      }
      uint8_t status = spiflash_write_nocheck(spiflash_buf, sector_pos * SPIF_SECTOR_SIZE, SPIF_SECTOR_SIZE); /* program the sector */
      if (!status) {
    	  return 0;
      }
    }
    else
    {
      /* write directly in the erased area */
      uint8_t status = spiflash_write_nocheck(pbuffer, write_addr, sector_remain);
      if (!status) {
    	  return 0;
      }
    }
    if(length == sector_remain)
    {
      /* write end */
      break;
    }
    else
    {
      /* go on writing */
      sector_pos++;
      sector_offset = 0;

      pbuffer += sector_remain;
      write_addr += sector_remain;
      length -= sector_remain;
      if(length > SPIF_SECTOR_SIZE)
      {
        /* could not write the remain data in the next sector */
        sector_remain = SPIF_SECTOR_SIZE;
      }
      else
      {
        /* could write the remain data in the next sector */
        sector_remain = length;
      }
    }
  }
  return 1;
}

/****************************************************************************************************************
  * @brief  read data from flash
  * @param  pbuffer: the pointer for data buffer
  * @param  read_addr: the address where the data is read
  * @param  length: buffer length
  * @retval none
  ***************************************************************************************************************/
uint8_t spiflash_read(uint8_t *pbuffer, uint32_t read_addr, uint32_t length)
{
  FLASH_CS_LOW();
  spi_byte_write(SPIF_READDATA); /* send instruction */
  spi_byte_write((uint8_t)((read_addr) >> 16)); /* send 24-bit address */
  spi_byte_write((uint8_t)((read_addr) >> 8));
  spi_byte_write((uint8_t)read_addr);
  spi_bytes_read(pbuffer, length);
  FLASH_CS_HIGH();
  return 1;
}

/****************************************************************************************************************
  * @brief  erase a sector data
  * @param  erase_addr: sector address to erase
  * @retval none
  ***************************************************************************************************************/
uint8_t spiflash_sector_erase(uint32_t erase_addr)
{
  erase_addr *= SPIF_SECTOR_SIZE; /* translate sector address to byte address */
  spiflash_write_enable();
  if(!spiflash_wait_busy(SECTOR_ERASE_TIME)) {
	  return 0;
  }
  FLASH_CS_LOW();
  spi_byte_write(SPIF_SECTORERASE);
  spi_byte_write((uint8_t)((erase_addr) >> 16));
  spi_byte_write((uint8_t)((erase_addr) >> 8));
  spi_byte_write((uint8_t)erase_addr);
  FLASH_CS_HIGH();
  if(!spiflash_wait_busy(SECTOR_ERASE_TIME)) {
	  return 0;
  }
  return 1;
}

/****************************************************************************************************************
  * @brief  write data without check
  * @param  pbuffer: the pointer for data buffer
  * @param  write_addr: the address where the data is written
  * @param  length: buffer length
  * @retval none
  ***************************************************************************************************************/
uint8_t spiflash_write_nocheck(uint8_t *pbuffer, uint32_t write_addr, uint32_t length)
{
  uint16_t page_remain;

  /* remain bytes in a page */
  page_remain = SPIF_PAGE_SIZE - write_addr % SPIF_PAGE_SIZE;
  if(length <= page_remain)
  {
    /* smaller than a page size */
    page_remain = length;
  }
  while(1)
  {
    uint8_t status = spiflash_page_write(pbuffer, write_addr, page_remain);
    if(!status) {
    	return 0;
    }
    if(length == page_remain)
    {
      /* all data are programmed */
      break;
    }
    else
    {
      /* length > page_remain */
      pbuffer += page_remain;
      write_addr += page_remain;

      /* the remain bytes to be prorammed */
      length -= page_remain;
      if(length > SPIF_PAGE_SIZE)
      {
        /* can be progrmmed a page at a time */
        page_remain = SPIF_PAGE_SIZE;
      }
      else
      {
        /* smaller than a page size */
        page_remain = length;
      }
    }
  }
  return 1;
}

/****************************************************************************************************************
  * @brief  write a page data
  * @param  pbuffer: the pointer for data buffer
  * @param  write_addr: the address where the data is written
  * @param  length: buffer length
  * @retval none
  ***************************************************************************************************************/
uint8_t spiflash_page_write(uint8_t *pbuffer, uint32_t write_addr, uint32_t length)
{
  if((0 < length) && (length <= SPIF_PAGE_SIZE))
  {
    /* set write enable */
    spiflash_write_enable();

    FLASH_CS_LOW();

    /* send instruction */
    spi_byte_write(SPIF_PAGEPROGRAM);

    /* send 24-bit address */
    spi_byte_write((uint8_t)((write_addr) >> 16));
    spi_byte_write((uint8_t)((write_addr) >> 8));
    spi_byte_write((uint8_t)write_addr);
    spi_bytes_write(pbuffer,length);

    FLASH_CS_HIGH();

    /* wait for program end */
    uint8_t status = spiflash_wait_busy(PAGE_PROGRAM_TIME);
    if (!status ) {
    	return 0;
    } else {
    	return 1;
    }
  }
  return 0;
}

/****************************************************************************************************************
  * @brief  write data continuously
  * @param  pbuffer: the pointer for data buffer
  * @param  length: buffer length
  * @retval none
  ***************************************************************************************************************/
void spi_bytes_write(uint8_t *pbuffer, uint32_t length)
{
  volatile uint8_t dummy_data;
  while(length--)
  {
    while(spi_i2s_flag_get(SPI1, SPI_I2S_TDBE_FLAG) == RESET);
    spi_i2s_data_transmit(SPI1, *pbuffer);
    while(spi_i2s_flag_get(SPI1, SPI_I2S_RDBF_FLAG) == RESET);
    dummy_data = (uint8_t)spi_i2s_data_receive(SPI1);
    pbuffer++;
  }

  /* wait spi idle when communication end */
  while(spi_i2s_flag_get(SPI1, SPI_I2S_BF_FLAG) != RESET);
}

/**
  * @brief  read data continuously
  * @param  pbuffer: buffer to save data
  * @param  length: buffer length
  * @retval none
  */
void spi_bytes_read(uint8_t *pbuffer, uint32_t length)
{
  uint8_t write_value = FLASH_SPI_DUMMY_BYTE;

  while(length--)
  {
    while(spi_i2s_flag_get(SPI1, SPI_I2S_TDBE_FLAG) == RESET);
    spi_i2s_data_transmit(SPI1, write_value);
    while(spi_i2s_flag_get(SPI1, SPI_I2S_RDBF_FLAG) == RESET);
    *pbuffer = (uint8_t)spi_i2s_data_receive(SPI1);
    pbuffer++;
  }

  /* wait spi idle when communication end */
  while(spi_i2s_flag_get(SPI1, SPI_I2S_BF_FLAG) != RESET);
}
/****************************************************************************************************************
  * @brief  wait program done
  * @param  none
  * @retval none
  ***************************************************************************************************************/
uint8_t spiflash_wait_busy(uint16_t timeout_ms)
{
    uint32_t start = xTaskGetTickCount(); // replace with your system tick function
    while (spiflash_read_sr1() & 0x01) // WIP bit set?
    {
        if ((xTaskGetTickCount() - start) > timeout_ms) {
            return 0; // Timeout
        }
    }
//	while((spiflash_read_sr1() & 0x01) == 0x01);
    return 1; // Ready
}
/****************************************************************************************************************
  * @brief  read sr1 register
  * @param  none
  * @retval none
  ***************************************************************************************************************/
uint8_t spiflash_read_sr1(void)
{
  uint8_t breadbyte = 0;
  FLASH_CS_LOW();
  spi_byte_write(SPIF_READSTATUSREG1);
  breadbyte = (uint8_t)spi_byte_read();
  FLASH_CS_HIGH();
  return (breadbyte);
}

/****************************************************************************************************************
  * @brief  enable write operation
  * @param  none
  * @retval none
  ***************************************************************************************************************/
void spiflash_write_enable(void)
{
  FLASH_CS_LOW();
  spi_byte_write(SPIF_WRITEENABLE);
  FLASH_CS_HIGH();
}

/****************************************************************************************************************
  * @brief  read device id
  * @param  none
  * @retval device id
  ***************************************************************************************************************/
uint16_t spiflash_read_id(void)
{
  uint16_t wreceivedata = 0;
  FLASH_CS_LOW();
  spi_byte_write(SPIF_MANUFACTDEVICEID);
  spi_byte_write(0x00);
  spi_byte_write(0x00);
  spi_byte_write(0x00);
  wreceivedata |= spi_byte_read() << 8;
  wreceivedata |= spi_byte_read();
  FLASH_CS_HIGH();
  return wreceivedata;
}

/***************************************************************************************************************
  * @brief  write a byte to flash
  * @param  data: data to write
  * @retval flash return data
  ***************************************************************************************************************/
uint8_t spi_byte_write(uint8_t data)
{
  uint8_t brxbuff;
  spi_i2s_dma_transmitter_enable(SPI1, FALSE);
  spi_i2s_dma_receiver_enable(SPI1, FALSE);
  spi_i2s_data_transmit(SPI1, data);
  while(spi_i2s_flag_get(SPI1, SPI_I2S_RDBF_FLAG) == RESET);
  brxbuff = (uint8_t)spi_i2s_data_receive(SPI1);

  /* wait spi idle when communication end */
  while(spi_i2s_flag_get(SPI1, SPI_I2S_BF_FLAG) != RESET);
  return brxbuff;
}

/**************************************************************************************************************
  * @brief  read a byte to flash
  * @param  none
  * @retval flash return data
  *************************************************************************************************************/
uint8_t spi_byte_read(void)
{
  return (spi_byte_write(FLASH_SPI_DUMMY_BYTE));
}
/**************************************************************************************************************
  * @brief  Check device mode
  * @param  none
  * @retval flash return data
  *************************************************************************************************************/
uint8_t check_device_mode(void) {
	uint32_t flash_id_index = spiflash_read_id();
	printf("SPI ID : %X\n",flash_id_index);
    uint32_t mode;
    spiflash_read((uint8_t *)&mode, DEV_MODE_ADDR, sizeof(mode));
    printf("MODE : %x\n",mode);
    return (uint8_t)mode;
}
 /***********End of function_demo() function****************/


/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
