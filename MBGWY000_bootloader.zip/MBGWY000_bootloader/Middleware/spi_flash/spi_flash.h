/**
  **************************
  * @file    spi_flash.h
  * @author  Kaviyarasan , Calixto Firmware Team
  * @version V1.0.0
  * @date    2025 Aug 1
  * @brief   This file contains all the functions prototypes for the __.
  **************************
  *
  * <h2><center>&copy; COPYRIGHT 2024 Calixto Systems Pvt Ltd</center></h2>
  **************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SPI_FLASH_H_
#define __SPI_FLASH_H_


#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
//#include "modbus_gw_cfg.h"
#include "at32f435_437.h"
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/
//#define SPI_TRANS_DMA

#define W25Q80                           0xEF13 // 1 mb
#define W25Q16                           0xEF14 // 2
#define W25Q32                           0xEF15 // 4
#define W25Q64                           0xEF16 // 8
#define W25Q128                          0xEF17 // 16

#define SPIF_CHIP_SIZE                   0x1000000
#define SPIF_SECTOR_SIZE                 4096
#define SPIF_PAGE_SIZE                   256

#define SPIF_WRITEENABLE                 0x06
#define SPIF_WRITEDISABLE                0x04
/* s7-s0 */
#define SPIF_READSTATUSREG1              0x05
#define SPIF_WRITESTATUSREG1             0x01
/* s15-s8 */
#define SPIF_READSTATUSREG2              0x35
#define SPIF_WRITESTATUSREG2             0x31
/* s23-s16 */
#define SPIF_READSTATUSREG3              0x15
#define SPIF_WRITESTATUSREG3             0x11
#define SPIF_READDATA                    0x03
#define SPIF_FASTREADDATA                0x0B
#define SPIF_FASTREADDUAL                0x3B
#define SPIF_PAGEPROGRAM                 0x02
/* block size:64kb */
#define SPIF_BLOCKERASE                  0xD8
#define SPIF_SECTORERASE                 0x20
#define SPIF_CHIPERASE                   0xC7
#define SPIF_POWERDOWN                   0xB9
#define SPIF_RELEASEPOWERDOWN            0xAB
#define SPIF_DEVICEID                    0xAB
#define SPIF_MANUFACTDEVICEID            0x90
#define SPIF_JEDECDEVICEID               0x9F
#define FLASH_SPI_DUMMY_BYTE             0xA5
/* Exported functions --------------------------------------------------------*/

/*  Functions used to _________________ ***/

 void spiflash_init(void);
 uint8_t spiflash_write(uint8_t *pbuffer, uint32_t write_addr, uint32_t length);
 uint8_t spiflash_read(uint8_t *pbuffer, uint32_t read_addr, uint32_t length);
 uint8_t spiflash_sector_erase(uint32_t erase_addr);
 uint8_t spiflash_write_nocheck(uint8_t *pbuffer, uint32_t write_addr, uint32_t length);
 uint8_t spiflash_page_write(uint8_t *pbuffer, uint32_t write_addr, uint32_t length);
 void spi_bytes_write(uint8_t *pbuffer, uint32_t length);
 void spi_bytes_read(uint8_t *pbuffer, uint32_t length);
 uint8_t spiflash_wait_busy(uint16_t timeout_ms);
 uint8_t spiflash_read_sr1(void);
 void spiflash_write_enable(void);
 uint16_t spiflash_read_id(void);
 uint8_t spi_byte_write(uint8_t data);
 uint8_t spi_byte_read(void);
 uint8_t spiflash_sector_erase(uint32_t erase_addr);

// uint8_t write_modbus_cfg_into_spi_flash(nwk_config *ip_nwk, serial_config_all *ip_serial, modbus_config_t *modbus_cfg);
// uint8_t read_modbus_cfg_from_spi_flash(nwk_config *op_nwk, serial_config_all *op_serial, modbus_config_t *op_modbus_cfg);
// uint8_t write_firmware_version_to_flash(firmware_version_t *firm);
// uint8_t read_firmware_from_flash(firmware_version_t *firm);
 uint8_t check_device_mode(void);
 uint8_t erase_modbus_config(void);
/* Initialization and Configuration functions ***********/



#ifdef __cplusplus
}
#endif

#endif /* __FILENAME_H_ */




/***** (C) COPYRIGHT 2025 Calixto Systems Pvt Ltd ***END OF FILE*/
