boot/key/bootutil_public_keys.o: ../boot/key/bootutil_public_keys.c \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/sign_key.h \
 d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/sign_key.h:
d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h:
