boot/ext/tinycrypt-sha512/lib/source/sha512.o: \
 ../boot/ext/tinycrypt-sha512/lib/source/sha512.c \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt-sha512\lib\include/tinycrypt/sha512.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/utils.h
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt-sha512\lib\include/tinycrypt/sha512.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/utils.h:
