boot/ext/tinycrypt/lib/source/hmac.o: \
 ../boot/ext/tinycrypt/lib/source/hmac.c \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/hmac.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/sha256.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/utils.h
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/hmac.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/sha256.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/utils.h:
