boot/ext/tinycrypt/lib/source/ecc.o: \
 ../boot/ext/tinycrypt/lib/source/ecc.c \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/ecc.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/ecc_platform_specific.h
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/ecc.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/ecc_platform_specific.h:
