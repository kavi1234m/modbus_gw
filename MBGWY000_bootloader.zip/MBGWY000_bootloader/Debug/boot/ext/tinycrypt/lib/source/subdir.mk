################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../boot/ext/tinycrypt/lib/source/aes_decrypt.c \
../boot/ext/tinycrypt/lib/source/aes_encrypt.c \
../boot/ext/tinycrypt/lib/source/cbc_mode.c \
../boot/ext/tinycrypt/lib/source/ccm_mode.c \
../boot/ext/tinycrypt/lib/source/cmac_mode.c \
../boot/ext/tinycrypt/lib/source/ctr_mode.c \
../boot/ext/tinycrypt/lib/source/ctr_prng.c \
../boot/ext/tinycrypt/lib/source/ecc.c \
../boot/ext/tinycrypt/lib/source/ecc_dh.c \
../boot/ext/tinycrypt/lib/source/ecc_dsa.c \
../boot/ext/tinycrypt/lib/source/ecc_platform_specific.c \
../boot/ext/tinycrypt/lib/source/hmac.c \
../boot/ext/tinycrypt/lib/source/hmac_prng.c \
../boot/ext/tinycrypt/lib/source/sha256.c \
../boot/ext/tinycrypt/lib/source/utils.c 

OBJS += \
./boot/ext/tinycrypt/lib/source/aes_decrypt.o \
./boot/ext/tinycrypt/lib/source/aes_encrypt.o \
./boot/ext/tinycrypt/lib/source/cbc_mode.o \
./boot/ext/tinycrypt/lib/source/ccm_mode.o \
./boot/ext/tinycrypt/lib/source/cmac_mode.o \
./boot/ext/tinycrypt/lib/source/ctr_mode.o \
./boot/ext/tinycrypt/lib/source/ctr_prng.o \
./boot/ext/tinycrypt/lib/source/ecc.o \
./boot/ext/tinycrypt/lib/source/ecc_dh.o \
./boot/ext/tinycrypt/lib/source/ecc_dsa.o \
./boot/ext/tinycrypt/lib/source/ecc_platform_specific.o \
./boot/ext/tinycrypt/lib/source/hmac.o \
./boot/ext/tinycrypt/lib/source/hmac_prng.o \
./boot/ext/tinycrypt/lib/source/sha256.o \
./boot/ext/tinycrypt/lib/source/utils.o 

C_DEPS += \
./boot/ext/tinycrypt/lib/source/aes_decrypt.d \
./boot/ext/tinycrypt/lib/source/aes_encrypt.d \
./boot/ext/tinycrypt/lib/source/cbc_mode.d \
./boot/ext/tinycrypt/lib/source/ccm_mode.d \
./boot/ext/tinycrypt/lib/source/cmac_mode.d \
./boot/ext/tinycrypt/lib/source/ctr_mode.d \
./boot/ext/tinycrypt/lib/source/ctr_prng.d \
./boot/ext/tinycrypt/lib/source/ecc.d \
./boot/ext/tinycrypt/lib/source/ecc_dh.d \
./boot/ext/tinycrypt/lib/source/ecc_dsa.d \
./boot/ext/tinycrypt/lib/source/ecc_platform_specific.d \
./boot/ext/tinycrypt/lib/source/hmac.d \
./boot/ext/tinycrypt/lib/source/hmac_prng.d \
./boot/ext/tinycrypt/lib/source/sha256.d \
./boot/ext/tinycrypt/lib/source/utils.d 


# Each subdirectory must supply rules for building sources it contributes
boot/ext/tinycrypt/lib/source/%.o: ../boot/ext/tinycrypt/lib/source/%.c boot/ext/tinycrypt/lib/source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\internal_flash" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\spi_flash" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\mbedtls-asn1\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt-sha512\lib\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\src" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\fiat" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\target_at32f347\include" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


