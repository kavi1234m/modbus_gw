boot/ext/tinycrypt/lib/source/ecc_platform_specific.o: \
 ../boot/ext/tinycrypt/lib/source/ecc_platform_specific.c
