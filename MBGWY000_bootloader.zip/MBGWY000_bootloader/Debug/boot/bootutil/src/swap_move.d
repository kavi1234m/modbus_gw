boot/bootutil/src/swap_move.o: ../boot/bootutil/src/swap_move.c \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/bootutil.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/fault_injection_hardening.h \
 d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/bootutil_public.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/bootutil_macros.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/image.h \
 d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\flash_map_backend\flash_map_backend.h \
 ../boot/bootutil/src/bootutil_priv.h \
 ../boot/bootutil/src/../../target_at32f347/include/flash_map_backend/flash_map_backend.h \
 ../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h \
 ../boot/bootutil/src/../../target_at32f347/include/sysflash/sysflash.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\target_at32f347\include/mcuboot_config/mcuboot_config.h \
 ../boot/bootutil/src/swap_priv.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/bootutil_log.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/ignore.h \
 d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_logging.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/ignore.h
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/bootutil.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/fault_injection_hardening.h:
d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/bootutil_public.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/bootutil_macros.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/image.h:
d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\flash_map_backend\flash_map_backend.h:
../boot/bootutil/src/bootutil_priv.h:
../boot/bootutil/src/../../target_at32f347/include/flash_map_backend/flash_map_backend.h:
../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h:
../boot/bootutil/src/../../target_at32f347/include/sysflash/sysflash.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\target_at32f347\include/mcuboot_config/mcuboot_config.h:
../boot/bootutil/src/swap_priv.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/bootutil_log.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/ignore.h:
d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_logging.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/ignore.h:
