boot/bootutil/src/caps.o: ../boot/bootutil/src/caps.c \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/caps.h \
 ../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/caps.h:
../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h:
