################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../boot/bootutil/src/boot_record.c \
../boot/bootutil/src/bootutil_find_key.c \
../boot/bootutil/src/bootutil_img_hash.c \
../boot/bootutil/src/bootutil_img_security_cnt.c \
../boot/bootutil/src/bootutil_misc.c \
../boot/bootutil/src/bootutil_public.c \
../boot/bootutil/src/caps.c \
../boot/bootutil/src/ed25519_psa.c \
../boot/bootutil/src/encrypted.c \
../boot/bootutil/src/encrypted_psa.c \
../boot/bootutil/src/fault_injection_hardening.c \
../boot/bootutil/src/fault_injection_hardening_delay_rng_mbedtls.c \
../boot/bootutil/src/image_ecdsa.c \
../boot/bootutil/src/image_ed25519.c \
../boot/bootutil/src/image_rsa.c \
../boot/bootutil/src/image_validate.c \
../boot/bootutil/src/loader.c \
../boot/bootutil/src/ram_load.c \
../boot/bootutil/src/swap_misc.c \
../boot/bootutil/src/swap_move.c \
../boot/bootutil/src/swap_offset.c \
../boot/bootutil/src/swap_scratch.c \
../boot/bootutil/src/tlv.c 

OBJS += \
./boot/bootutil/src/boot_record.o \
./boot/bootutil/src/bootutil_find_key.o \
./boot/bootutil/src/bootutil_img_hash.o \
./boot/bootutil/src/bootutil_img_security_cnt.o \
./boot/bootutil/src/bootutil_misc.o \
./boot/bootutil/src/bootutil_public.o \
./boot/bootutil/src/caps.o \
./boot/bootutil/src/ed25519_psa.o \
./boot/bootutil/src/encrypted.o \
./boot/bootutil/src/encrypted_psa.o \
./boot/bootutil/src/fault_injection_hardening.o \
./boot/bootutil/src/fault_injection_hardening_delay_rng_mbedtls.o \
./boot/bootutil/src/image_ecdsa.o \
./boot/bootutil/src/image_ed25519.o \
./boot/bootutil/src/image_rsa.o \
./boot/bootutil/src/image_validate.o \
./boot/bootutil/src/loader.o \
./boot/bootutil/src/ram_load.o \
./boot/bootutil/src/swap_misc.o \
./boot/bootutil/src/swap_move.o \
./boot/bootutil/src/swap_offset.o \
./boot/bootutil/src/swap_scratch.o \
./boot/bootutil/src/tlv.o 

C_DEPS += \
./boot/bootutil/src/boot_record.d \
./boot/bootutil/src/bootutil_find_key.d \
./boot/bootutil/src/bootutil_img_hash.d \
./boot/bootutil/src/bootutil_img_security_cnt.d \
./boot/bootutil/src/bootutil_misc.d \
./boot/bootutil/src/bootutil_public.d \
./boot/bootutil/src/caps.d \
./boot/bootutil/src/ed25519_psa.d \
./boot/bootutil/src/encrypted.d \
./boot/bootutil/src/encrypted_psa.d \
./boot/bootutil/src/fault_injection_hardening.d \
./boot/bootutil/src/fault_injection_hardening_delay_rng_mbedtls.d \
./boot/bootutil/src/image_ecdsa.d \
./boot/bootutil/src/image_ed25519.d \
./boot/bootutil/src/image_rsa.d \
./boot/bootutil/src/image_validate.d \
./boot/bootutil/src/loader.d \
./boot/bootutil/src/ram_load.d \
./boot/bootutil/src/swap_misc.d \
./boot/bootutil/src/swap_move.d \
./boot/bootutil/src/swap_offset.d \
./boot/bootutil/src/swap_scratch.d \
./boot/bootutil/src/tlv.d 


# Each subdirectory must supply rules for building sources it contributes
boot/bootutil/src/%.o: ../boot/bootutil/src/%.c boot/bootutil/src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\internal_flash" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\spi_flash" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\mbedtls-asn1\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt-sha512\lib\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\src" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\fiat" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\target_at32f347\include" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


