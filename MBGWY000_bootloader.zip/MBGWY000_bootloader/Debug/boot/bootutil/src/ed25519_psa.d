boot/bootutil/src/ed25519_psa.o: ../boot/bootutil/src/ed25519_psa.c
