boot/bootutil/src/ram_load.o: ../boot/bootutil/src/ram_load.c
