boot/bootutil/src/encrypted.o: ../boot/bootutil/src/encrypted.c \
 ../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h
../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h:
