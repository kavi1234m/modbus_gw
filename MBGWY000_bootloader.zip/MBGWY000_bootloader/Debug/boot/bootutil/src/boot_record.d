boot/bootutil/src/boot_record.o: ../boot/bootutil/src/boot_record.c \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/crypto/sha.h \
 d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h \
 d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_logging.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/ignore.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/sha256.h \
 D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h \
 ../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/crypto/sha.h:
d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_config.h:
d:\at32f437_workspace\mbgwy000_bootloader\boot\target_at32f347\include\mcuboot_config\mcuboot_logging.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include/bootutil/ignore.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/sha256.h:
D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include/tinycrypt/constants.h:
../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h:
