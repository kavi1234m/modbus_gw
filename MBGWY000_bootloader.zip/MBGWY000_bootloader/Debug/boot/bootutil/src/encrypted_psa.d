boot/bootutil/src/encrypted_psa.o: ../boot/bootutil/src/encrypted_psa.c
