boot/bootutil/src/image_ed25519.o: ../boot/bootutil/src/image_ed25519.c \
 ../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h
../boot/bootutil/src/../../target_at32f347/include/mcuboot_config/mcuboot_config.h:
