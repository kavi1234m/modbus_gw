################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../boot/target_at32f347/src/flash_map/flash_map.c 

OBJS += \
./boot/target_at32f347/src/flash_map/flash_map.o 

C_DEPS += \
./boot/target_at32f347/src/flash_map/flash_map.d 


# Each subdirectory must supply rules for building sources it contributes
boot/target_at32f347/src/flash_map/%.o: ../boot/target_at32f347/src/flash_map/%.c boot/target_at32f347/src/flash_map/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GNU Arm Cross C Compiler'
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections  -g -DAT_START_F437_V1 -DAT32F437RGT7 -DUSE_STDPERIPH_DRIVER -I"../include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\checksum" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\internal_flash" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\Middleware\spi_flash" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\mbedtls-asn1\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt-sha512\lib\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\tinycrypt\lib\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\include" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\bootutil\src" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\ext\fiat" -I"D:\AT32F437_WORKSPACE\MBGWY000_bootloader\boot\target_at32f347\include" -I"../include/libraries/drivers/inc" -I"../include/libraries/cmsis/cm4/core_support" -I"../include/libraries/cmsis/cm4/device_support" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


