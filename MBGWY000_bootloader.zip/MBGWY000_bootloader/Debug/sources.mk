################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
OBJS := 
SECONDARY_FLASH := 
SECONDARY_SIZE := 
ASM_DEPS := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Middleware/checksum \
Middleware/internal_flash \
Middleware/spi_flash \
boot/bootutil/src \
boot/ext/fiat/src \
boot/ext/mbedtls-asn1/src \
boot/ext/tinycrypt/lib/source \
boot/ext/tinycrypt-sha512/lib/source \
boot/key \
boot/target_at32f347/src/flash_map \
bsp \
cmsis \
firmware \
user \

